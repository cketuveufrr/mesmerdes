"""Isolated, drop-in POCA speed optimizations for ``scripts/train_ps.py``.

The original SwarmACB package is never modified. Only the optimized POCA
network, rollout buffer and trainer live in this package; all environment,
configuration and mission code continues to come from the original project.
"""

from .poca_buffer import POCARolloutBuffer
from .poca_networks import Actor, DiscreteActor, POCACritic, RecurrentDiscreteActor
from .poca_trainer import (
    POCAConfig,
    POCATrainer,
    trust_region_policy_loss,
    trust_region_value_loss,
)

__all__ = [
    "Actor",
    "DiscreteActor",
    "POCACritic",
    "POCARolloutBuffer",
    "POCAConfig",
    "POCATrainer",
    "RecurrentDiscreteActor",
    "trust_region_policy_loss",
    "trust_region_value_loss",
]
