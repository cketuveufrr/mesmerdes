"""Cyclamen-PS trainer inheriting the isolated optimized POCA trainer.

Only the local actor observation is extended. The critic state, critic network,
counterfactual baseline, POCA losses, rollout cadence and schedules remain
identical to ``poca_alt.poca_opti``.
"""

from __future__ import annotations

from pathlib import Path

import torch
import torch.nn.functional as F

from ..poca_opti.poca_trainer import POCATrainer
from .poca_networks import PreviousStateRecurrentDiscreteActor


CYCLAMEN_PS_VERSION = 1
ACTOR_OBSERVATION_SCHEMA = "raw_local_obs+previous_module_one_hot_v1"


class POCATrainerPS(POCATrainer):
    """Optimized POCA with previous executed module added to the actor only."""

    def _actor_observation_dim(self, raw_obs_dim: int) -> int:
        if not self.discrete:
            raise ValueError("Cyclamen-PS requires discrete module actions")
        return int(raw_obs_dim) + int(self.num_actions)

    def _build_recurrent_actor(
        self,
        raw_obs_dim: int,
        actor_obs_dim: int,
        num_actions: int,
        hidden_dim: int,
        num_layers: int,
        memory_size: int,
    ):
        expected = int(raw_obs_dim) + int(num_actions)
        if int(actor_obs_dim) != expected:
            raise RuntimeError(
                f"Invalid Cyclamen-PS actor width: expected {expected}, "
                f"got {actor_obs_dim}"
            )
        return PreviousStateRecurrentDiscreteActor(
            raw_obs_dim=raw_obs_dim,
            num_actions=num_actions,
            hidden=hidden_dim,
            num_layers=num_layers,
            memory_size=memory_size,
        )

    def _prepare_actor_observations(self, obs_stacked: torch.Tensor) -> torch.Tensor:
        if not self.tensor_env:
            raise RuntimeError("Cyclamen-PS is currently restricted to Mercator tensor environments")
        if obs_stacked.shape[-1] != self.raw_obs_dim:
            raise ValueError(
                f"Expected raw actor observation width {self.raw_obs_dim}, "
                f"got {obs_stacked.shape[-1]}"
            )

        # Mercator episodes reset synchronously. At step zero there is no previous
        # module, represented by an all-zero vector. Thereafter _last_module_ids is
        # exactly the discrete module executed during the preceding decision.
        if int(self.unwrapped.episode_step_python) == 0:
            previous_module = torch.zeros(
                self.num_envs,
                self.num_agents,
                self.num_actions,
                dtype=obs_stacked.dtype,
                device=obs_stacked.device,
            )
        else:
            module_ids = self.unwrapped._last_module_ids
            previous_module = F.one_hot(
                module_ids.to(torch.long),
                num_classes=self.num_actions,
            ).to(dtype=obs_stacked.dtype)
        return torch.cat((obs_stacked, previous_module), dim=-1)

    def save_checkpoint(self, path):
        torch.save({
            "paper_parity_version": 3,
            "cyclamen_ps_version": CYCLAMEN_PS_VERSION,
            "actor_observation_schema": ACTOR_OBSERVATION_SCHEMA,
            "previous_state_actor_only": True,
            "previous_state_dim": self.num_actions,
            "actor": self.actor.state_dict(),
            "critic": self.critic.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "global_step": self.global_step,
            "update_count": self.update_count,
            "seed": self.cfg.seed,
            "hidden_dim": getattr(self.cfg, "hidden_dim", 256),
            "num_layers": getattr(self.cfg, "num_layers", 2),
            "recurrent": self.recurrent,
            "memory_size": getattr(self.cfg, "memory_size", 0),
            "memory_size_semantics": "mlagents_total",
            "lstm_hidden_size": self.actor.hidden_size if self.recurrent else 0,
            "sequence_length": getattr(self.cfg, "sequence_length", 0),
            "critic_hidden_dim": self.cfg.critic_hidden_dim,
            "critic_num_layers": self.cfg.critic_num_layers,
            "critic_num_heads": self.cfg.critic_num_heads,
            "decision_period": self.decision_period,
            "discrete": self.discrete,
            "num_actions": self.num_actions if self.discrete else 0,
            "act_dim": self.act_dim,
            "state_dim": self.state_dim,
            "raw_obs_dim": self.raw_obs_dim,
            "obs_dim": self.obs_dim,
        }, path)
        print(f"[POCA-PS] Saved -> {path}")

    def load_checkpoint(self, path):
        ckpt = torch.load(path, map_location=self.device)
        if int(ckpt.get("cyclamen_ps_version", 0)) != CYCLAMEN_PS_VERSION:
            raise RuntimeError(
                "Refusing to resume a non-Cyclamen-PS checkpoint. The actor input "
                "schema differs; start Cyclamen-PS training from a fresh run."
            )
        if ckpt.get("actor_observation_schema") != ACTOR_OBSERVATION_SCHEMA:
            raise RuntimeError("Cyclamen-PS checkpoint observation schema mismatch")
        if int(ckpt.get("state_dim", -1)) != self.state_dim:
            raise RuntimeError("Cyclamen-PS critic-state architecture mismatch")
        try:
            self.actor.load_state_dict(ckpt["actor"])
            self.critic.load_state_dict(ckpt["critic"])
            self.optimizer.load_state_dict(ckpt["optimizer"])
        except RuntimeError as exc:
            raise RuntimeError("Cyclamen-PS checkpoint architecture mismatch") from exc
        self.global_step = int(ckpt["global_step"])
        self.update_count = int(ckpt["update_count"])
        print(f"[POCA-PS] Loaded <- {path}  (step {self.global_step})")
