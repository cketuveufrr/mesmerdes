"""Actor extension for Cyclamen-PS.

The base Cyclamen encoder, LSTM and action head are inherited unchanged from
``poca_alt.poca_opti``. A zero-initialized projection of the previous executed
module is added to the encoded local observation. Consequently, with the same
random seed, Cyclamen-PS has exactly the same initial logits and recurrent state
as optimized Cyclamen; the new information only matters after learning updates.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from ..poca_opti.poca_networks import RecurrentDiscreteActor


class PreviousStateRecurrentDiscreteActor(RecurrentDiscreteActor):
    """Cyclamen actor conditioned on the previous executed module.

    Input schema::

        [raw_local_observation, one_hot(previous_module)]

    The previous-module branch is actor-only and does not alter the POCA critic.
    """

    def __init__(
        self,
        raw_obs_dim: int,
        num_actions: int,
        hidden: int = 128,
        num_layers: int = 1,
        memory_size: int = 128,
    ):
        super().__init__(
            raw_obs_dim,
            num_actions,
            hidden=hidden,
            num_layers=num_layers,
            memory_size=memory_size,
        )
        self.raw_obs_dim = int(raw_obs_dim)
        self.previous_state_dim = int(num_actions)
        self.actor_obs_dim = self.raw_obs_dim + self.previous_state_dim
        self.previous_module_projection = nn.Linear(
            self.previous_state_dim,
            hidden,
            bias=False,
        )
        nn.init.zeros_(self.previous_module_projection.weight)

    def forward_sequence(
        self,
        obs_seq: torch.Tensor,
        state: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> tuple[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        if obs_seq.shape[-1] != self.actor_obs_dim:
            raise ValueError(
                f"Cyclamen-PS expects actor observations of width "
                f"{self.actor_obs_dim}, got {obs_seq.shape[-1]}"
            )
        batch_size, sequence_length = obs_seq.shape[:2]
        raw_obs = obs_seq[..., : self.raw_obs_dim]
        previous_module = obs_seq[..., self.raw_obs_dim :]

        encoded_raw = self.net(
            raw_obs.reshape(batch_size * sequence_length, self.raw_obs_dim)
        )
        encoded_previous = self.previous_module_projection(
            previous_module.reshape(
                batch_size * sequence_length,
                self.previous_state_dim,
            )
        )
        encoded = (encoded_raw + encoded_previous).view(
            batch_size,
            sequence_length,
            -1,
        )
        if state is None:
            state = self.initial_state(batch_size, obs_seq.device)
        recurrent_output, next_state = self.lstm(encoded, state)
        return self.logits_head(recurrent_output), next_state
