"""Isolated alternative POCA implementations.

``poca_opti`` is the optimized baseline. ``poca_opti_ps`` inherits from it and
adds the previous executed module to the actor observation only.
"""
