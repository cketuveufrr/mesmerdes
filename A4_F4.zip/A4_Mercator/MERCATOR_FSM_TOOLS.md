# Lanceur Mercator unifié

Le point d’entrée recommandé est désormais :

```text
scripts/launch.py
```

Il sélectionne automatiquement le YAML `mercator` ou `tmercator` et délègue
au moteur FSM ou au visualiseur de checkpoint. Les robots sont colorés selon
le module AutoMoDe choisi et le visualiseur de checkpoint affiche aussi un HUD
avec le nombre de robots dans chaque module.

```bash
# FSM réelle, tMercator, coloration par module
python scripts/launch.py --mission AAC2 --profile tmercator --fsm-index 1

# Module fixe
python scripts/launch.py --mission FOR --profile tmercator --module attraction

# Checkpoint
python scripts/launch.py --mission GRID --profile tmercator \
  --checkpoint checkpoints/GRID_tmercator/poca_final.pt --deterministic
```

# Outil FSM Mercator unifié

Toutes les missions Mercator utilisant les vraies FSM Chocolate passent désormais
par un seul moteur :

```text
scripts/mercator_fsm.py
```

La mission sélectionne automatiquement la tâche Gymnasium, le YAML, le fichier
FSM, les métriques, le cadrage et le dossier de résultats.

| Sélecteur | Mission | Tâche Gymnasium | YAML |
|---|---|---|---|
| `AAC` | Aggregation, Experiment 1 | `SwarmACB-MercatorAggregation-v0` | `configs/mercator/AAC_mercator_cyclamen.yaml` |
| `AAC2` | Aggregation, Experiment 2 | `SwarmACB-MercatorAggregation2-v0` | `configs/mercator/AAC2_mercator_cyclamen.yaml` |
| `FOR` | Foraging, Experiment 1 | `SwarmACB-MercatorForaging-v0` | `configs/mercator/FOR_mercator_cyclamen.yaml` |
| `FOR2` | Foraging, Experiment 2 | `SwarmACB-MercatorForaging2-v0` | `configs/mercator/FOR2_mercator_cyclamen.yaml` |
| `GRID` | Grid Exploration, Experiment 1 | `SwarmACB-MercatorGridExploration-v0` | `configs/mercator/GRID_mercator_cyclamen.yaml` |
| `GRID2` | Grid Exploration, Experiment 2 | `SwarmACB-MercatorGridExploration2-v0` | `configs/mercator/GRID2_mercator_cyclamen.yaml` |

## Observer une FSM

```bash
python scripts/mercator_fsm.py \
  --mission GRID \
  --observe \
  --fsm-index 1
```

La coloration peut suivre l'état de la FSM ou le module AutoMoDe :

```bash
python scripts/mercator_fsm.py \
  --mission AAC2 \
  --observe \
  --fsm-index 4 \
  --color-by module
```

`--num-episodes 0` conserve la fenêtre ouverte. Une valeur positive arrête la
lecture après ce nombre d'épisodes.

## Évaluer les FSM

Une FSM :

```bash
python scripts/mercator_fsm.py \
  --mission FOR2 \
  --score \
  --fsm-index 1 \
  --episodes 50 \
  --num-envs 25 \
  --seed 0
```

Les dix FSM d'une mission :

```bash
python scripts/mercator_fsm.py \
  --mission GRID2 \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 50 \
  --seed 0
```

Le script produit un CSV par épisode, un CSV récapitulatif et un JSON détaillé.
Les dossiers par défaut sont propres à chaque mission.

## Foraging Experiment 2

La mission `FOR2` utilise la petite arène de l'Experiment 2 avec trois robots,
deux sources noires en `(+/-0.8, 0)` de rayon `0.265 m`, et un nid de score
à `y <= -0.63`. Le sol blanc visible par la FSM reste le polygone exact à
cinq triangles de la loop function. Comme pour `AAC2`, la lumière du petit
setup est volontairement activée à `1.0` pour rendre exécutables les états de
photo-/anti-phototaxie présents dans les FSM.

Le fichier des dix FSM est :

```text
configs/mercator/fsms/fsm_mercator_foraging2_experiment2.txt
```

## Grid Exploration

La mission utilise une grille `10 x 10`. À chaque tick de contrôle :

1. les cases contenant au moins un centre de robot sont remises à zéro ;
2. les 100 âges sont additionnés ;
3. toutes les cases vieillissent d'un tick ;
4. la contribution de récompense vaut `-somme_des_âges / 100`.

La somme des récompenses de l'épisode est donc directement l'objectif final de
la loop function ARGoS. Le sol perçu par la FSM est uniformément gris. Les
métriques ajoutent l'âge moyen et maximal, la couverture cumulée et le nombre de
cases visitées.

Le fichier des dix FSM originales est :

```text
configs/mercator/fsms/fsm_mercator_grid_exploration_experiment1.txt
```

SHA-256 :

```text
51cea00eb09a944bd79f98bbe52d37c7b9014ebbfdfcdee0f57f94437829c885
```

## Compatibilité des anciennes commandes

Les anciens noms de scripts sont conservés sous forme de lanceurs très courts.
Ils injectent leur mission historique puis exécutent `mercator_fsm.py`. Toute la
logique d'observation, de scoring et de sélection des FSM n'existe donc plus
qu'en un seul endroit.

## Fidélité du runtime Chocolate

Le moteur commun conserve :

- les paramètres réels `att` et `rep` et le paramètre entier `rwm` ;
- le décodage des destinations qui exclut l'état courant ;
- les six conditions Chocolate ;
- l'ordre aléatoire des transitions sortantes et la première condition valide ;
- l'absence de test de transition au premier tick d'entrée ;
- le reset du comportement lors d'une entrée dans un état.

## Grid Exploration Experiment 2

Le sélecteur `GRID2` utilise la petite arène dodécagonale de l'Experiment 2,
trois robots et une grille `10 x 10` couvrant une taille logique de `2.65 m`.
L'ordre de l'objectif reste strictement : remise à zéro des cases occupées,
somme des âges, puis incrément de toutes les cases. La lumière est volontairement
active à `1.0`, comme pour `AAC2` et `FOR2`.

Le fichier des dix FSM originales est :

```text
configs/mercator/fsms/fsm_mercator_grid_exploration2_experiment2.txt
```
