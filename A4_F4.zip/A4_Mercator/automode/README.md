# AutoMoDe-Chocolate vectorisé pour A4_Mercator - version 0.2

Ce dossier se place directement à la racine du projet `A4_Mercator`. Il ajoute une chaîne de conception automatique de contrôleurs Chocolate utilisant directement le backend analytique `MercatorTensorEnv`, sans démarrer Isaac Sim.

## Correction importante de la version 0.2

La version 0.1 pouvait commencer une génération avec le reliquat du budget. Un candidat évalué une seule fois dans cette génération incomplète pouvait alors remplacer les candidats correctement évalués. Le symptôme était explicite : `Épisodes best : 1` et un écart-type nul.

La version 0.2 impose désormais les invariants suivants :

1. une génération de recherche est exécutée entièrement ou n'est pas commencée ;
2. une partie du budget est réservée à une validation finale indépendante ;
3. tous les finalistes sont réévalués sur exactement le même nombre de nouveaux épisodes ;
4. `best_fsm.txt` est choisi uniquement à partir de cette validation équilibrée ;
5. un reliquat éventuel ne peut jamais modifier le classement ;
6. `summary.json` sépare les simulations de recherche et de validation.

Pour AAC2 avec les paramètres recommandés :

```text
budget                     100000
population                 1024
round-repeats              1 2 4 8
coût d'une génération      4096 simulations
recherche                   19 générations = 77824 simulations
validation finale           32 FSM x 693 épisodes = 22176 simulations
budget total                100000 simulations exactement
```

## Installation

Décompresser l'archive à la racine du projet :

```text
A4_Mercator/
├── automode/
├── configs/
├── scripts/
└── source/
```

Puis lancer :

```bash
python -m automode self-test
```

## Conception AAC2 corrigée

Une conception :

```bash
python -m automode design \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --device cuda:1 \
  --batch-size 1024 \
  --population-size 1024 \
  --budget 100000 \
  --round-repeats 1 2 4 8 \
  --validation-budget 20000 \
  --validation-candidates 32 \
  --min-validation-episodes 100 \
  --seed 1 \
  --output results/automode/AAC2/paper_100k_v2/seed_1
```

Le script de campagne fourni lance dix conceptions indépendantes et remplit le GPU en exécutant plusieurs processus de 1024 environnements, plutôt qu'en gonflant artificiellement la population d'une seule recherche :

```bash
chmod +x run_aac2_paper_campaign_v2.sh
DEVICE=cuda:1 MAX_PARALLEL=8 ./run_aac2_paper_campaign_v2.sh
```

## Contrôle de fidélité avant la campagne

Le script évalue d'abord les dix FSM Mercator/AAC2 fournies dans :

```text
configs/mercator/fsms/fsm_mercator_aggregation2_experiment2.txt
```

Ce contrôle est indispensable. Si ces contrôleurs de référence obtiennent eux aussi des scores très bas dans le backend tensoriel, le problème ne vient pas seulement de l'optimiseur : il faut alors vérifier la fidélité du simulateur, des comportements ou de la fonction objectif avant de consommer un million de simulations.

Par défaut, le script arrête la campagne si le meilleur contrôleur de référence est sous `REFERENCE_HARD_MIN=1500`, et émet un avertissement sous `REFERENCE_WARN_MIN=2200`. Ces seuils sont des garde-fous pratiques pour l'échelle AAC2, pas des résultats publiés imposés par le code. Ils sont modifiables par variables d'environnement.

## Fichiers de sortie d'une conception

```text
best_fsm.txt                 gagnant de la validation équilibrée
summary.json                 budget, paramètres, scores recherche/validation
history.jsonl                événements détaillés de recherche et validation
validation_fsms.txt          finalistes réévalués
validation_results.json      classement sur les épisodes indépendants
top_fsms.txt                 archive de recherche
top_fsms.json                statistiques de recherche et de validation
post_selection_extra.json    seulement si un reliquat non classant existe
```

Les champs importants de `summary.json` sont :

```text
algorithm
search_simulations
validation_simulations
validation_candidates
validation_episodes_per_candidate
best_validation_score
best_validation_std
best_validation_episodes
```

Pour une sortie valide avec les réglages AAC2 recommandés, `best_validation_episodes` vaut 693, jamais 1.

## Réévaluation des dix FSM produites

Après la campagne :

```bash
python -m automode evaluate \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --fsm-file results/automode/AAC2/paper_100k_v2/best_10_fsms.txt \
  --episodes 1000 \
  --batch-size 1024 \
  --device cuda:1 \
  --seed 2000001 \
  --output-json results/automode/AAC2/paper_100k_v2/final_independent_evaluation.json
```

## Benchmark

```bash
python -m automode benchmark \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --device cuda:1 \
  --batch-size 1024 2048 4096 8192 16384 \
  --episode-steps 1200 \
  --rounds 3
```

## Espace Chocolate

Le contrôleur comporte de un à quatre états et jusqu'à quatre transitions sortantes par état.

Modules :

```text
0 exploration, rwm dans [1,100]
1 stop
2 phototaxis
3 anti-phototaxis
4 attraction, att dans [1,5]
5 répulsion, rep dans [1,5]
```

Conditions :

```text
0 sol noir
1 sol gris
2 sol blanc
3 nombre de voisins, p dans [1,10], w dans [0,20]
4 nombre de voisins inversé, p dans [1,10], w dans [0,20]
5 probabilité fixe, p dans [0,1]
```

La sérialisation est compatible avec `scripts/mercator_chocolate_fsm.py` et avec les 60 FSM fournies dans le projet.

## Fidélité scientifique

Le moteur principal s'appelle `vectorized-race-v2-balanced-validation`. Il utilise l'espace Chocolate et un mécanisme de recherche/racing vectorisé, mais il ne reproduit pas bit à bit R/irace. Le package conserve aussi une couche `automode/irace`, plus proche de l'orchestration historique mais non vectorisée.

Le budget, la durée des épisodes, le nombre de robots et le nombre de conceptions peuvent correspondre au protocole du papier. L'algorithme de recherche natif reste toutefois une méthode distincte ; toute comparaison scientifique doit le déclarer explicitement.

## Tests

```bash
python -m automode self-test
```

Les tests vérifient notamment :

- les 60 FSM de référence ;
- les opérateurs de génération et mutation ;
- la sémantique des transitions et paramètres de comportement ;
- la parité avec le runtime Chocolate déjà présent ;
- les objectifs des six missions ;
- l'exécution tensorielle ;
- l'absence de génération partielle ;
- l'égalité du nombre d'épisodes entre finalistes ;
- la consommation exacte du budget ;
- l'ordonnancement GPU candidat x répétition.

## Version 0.3.0 — correction de la géométrie Experiment 2

`MercatorTensorEnv` construit nativement les centres de murs de l'Experiment 1.
Pour AAC2, FOR2 et GRID2, changer seulement `arena_side_length` à 0.70 m ne
change pas ces centres. AutoMoDe 0.3 installe donc explicitement les douze
centres de murs de l'Experiment 2 (inradius 1.3073 m, circumradius
1.3550846413 m) avant tout reset évalué. Le sanity check de campagne vérifie
ces dimensions et sauvegarde le fingerprint de l'arène dans les JSON
d'évaluation.
