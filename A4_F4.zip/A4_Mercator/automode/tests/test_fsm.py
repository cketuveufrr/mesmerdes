from __future__ import annotations

import importlib.util
from pathlib import Path
import random
import sys
import unittest

from automode.bootstrap import project_root
from automode.fsm import (
    ChocolateFSM,
    load_fsm_lines,
    mutate_fsm,
    parse_fsm,
    random_fsm,
    serialize_fsm,
)


def _host_module():
    path = project_root() / "scripts" / "mercator_chocolate_fsm.py"
    spec = importlib.util.spec_from_file_location("host_mercator_chocolate_fsm", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Impossible de charger {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class FSMTests(unittest.TestCase):
    def test_all_reference_fsms_are_compatible_with_host_parser(self) -> None:
        host = _host_module()
        files = sorted((project_root() / "configs" / "mercator" / "fsms").glob("*.txt"))
        self.assertEqual(len(files), 6)
        total = 0
        for path in files:
            lines = path.read_text(encoding="utf-8").splitlines()
            for ours in load_fsm_lines(lines):
                serialized = serialize_fsm(ours)
                reparsed = parse_fsm(serialized)
                self.assertEqual(ours, reparsed)
                theirs = host.parse_fsm(serialized)
                self.assertEqual(ours.num_states, theirs.num_states)
                for ours_state, their_state in zip(ours.states, theirs.states):
                    self.assertEqual(ours_state.module_id, their_state.module_id)
                    self.assertEqual(ours_state.parameter, their_state.parameter)
                    self.assertEqual(len(ours_state.transitions), len(their_state.transitions))
                    for ours_t, their_t in zip(ours_state.transitions, their_state.transitions):
                        self.assertEqual(ours_t.destination, their_t.destination)
                        self.assertEqual(ours_t.condition_id, their_t.condition_id)
                        self.assertAlmostEqual(ours_t.p, their_t.p, places=7)
                        if ours_t.w is None:
                            self.assertIsNone(their_t.w)
                        else:
                            self.assertAlmostEqual(ours_t.w, their_t.w, places=7)
                total += 1
        self.assertEqual(total, 60)

    def test_random_and_mutated_roundtrips(self) -> None:
        rng = random.Random(938271)
        candidate: ChocolateFSM = random_fsm(rng)
        for index in range(5000):
            if index % 11 == 0:
                candidate = random_fsm(rng)
            else:
                candidate = mutate_fsm(candidate, rng, strength=1 + index % 4)
            candidate.validate()
            self.assertEqual(candidate, parse_fsm(serialize_fsm(candidate)))

    def test_irace_destination_normalization(self) -> None:
        text = (
            "--nstates 2 --s0 1 --n0 1 --n0x0 17 --c0x0 5 --p0x0 1 "
            "--s1 1 --n1 1 --n1x0 12 --c1x0 5 --p1x0 0"
        )
        with self.assertRaises(ValueError):
            parse_fsm(text)
        parsed = parse_fsm(text, normalize_irace_destinations=True)
        self.assertEqual(parsed.states[0].transitions[0].destination, 1)
        self.assertEqual(parsed.states[1].transitions[0].destination, 0)


if __name__ == "__main__":
    unittest.main()
