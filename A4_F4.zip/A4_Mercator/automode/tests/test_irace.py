from __future__ import annotations

import unittest

from automode.irace.generate import generate_parameter_file, generate_scenario
from automode.irace.target_runner import _extract


class IraceCompatibilityTests(unittest.TestCase):
    def test_grammar_has_six_modules_and_chocolate_conditions(self) -> None:
        grammar = generate_parameter_file()
        self.assertIn('NumStates "--nstates " i (1,4)', grammar)
        self.assertIn('S0 "--s0 " c (0,1,2,3,4,5)', grammar)
        self.assertIn('ATT0 "--att0 " r (1,5) | as.numeric(S0)==4', grammar)
        self.assertIn('REP0 "--rep0 " r (1,5) | as.numeric(S0)==5', grammar)
        self.assertIn('B0x0 "--p0x0 " i (1,10)', grammar)
        self.assertIn('WI3x3 "--w3x3 " r (0,20)', grammar)
        self.assertNotIn('c (0,1,2,3,4,5,6)', grammar)

    def test_standard_runner_prefix_is_removed(self) -> None:
        seed, text = _extract(
            ["17", "4", "12345", "instance", "--nstates", "1", "--s0", "1"]
        )
        self.assertEqual(seed, 12345)
        self.assertEqual(text, "--nstates 1 --s0 1")

    def test_scenario_contains_budget(self) -> None:
        from pathlib import Path
        scenario = generate_scenario(Path("p.txt"), Path("runner"), 100000, Path("log.Rdata"))
        self.assertIn("maxExperiments = 100000", scenario)
        self.assertIn('targetRunner = "runner"', scenario)


if __name__ == "__main__":
    unittest.main()
