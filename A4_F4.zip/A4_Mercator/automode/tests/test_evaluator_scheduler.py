from __future__ import annotations

import unittest

import torch

from automode.evaluator import MercatorAutoMoDeEvaluator


class EvaluatorSchedulerTests(unittest.TestCase):
    def test_balances_candidate_and_repeat_dimensions(self) -> None:
        evaluator = MercatorAutoMoDeEvaluator.__new__(MercatorAutoMoDeEvaluator)
        evaluator.batch_size = 16
        evaluator.seed = 10
        evaluator._evaluation_round = 0
        calls = []

        def fake_run_group(candidates, repeats, *, seed):
            calls.append((len(candidates), repeats, seed))
            return torch.zeros((len(candidates), repeats), dtype=torch.float32)

        evaluator._run_group = fake_run_group  # type: ignore[method-assign]
        candidates = [object(), object(), object(), object()]
        result = evaluator.evaluate(candidates, episodes_per_candidate=10)

        self.assertEqual(tuple(result.raw.shape), (4, 10))
        self.assertEqual(result.simulations, 40)
        # batch 16 and four candidates -> four repetitions per full call,
        # then a final two-repetition block. V1 instead made one candidate per call.
        self.assertEqual([(c, r) for c, r, _ in calls], [(4, 4), (4, 4), (4, 2)])
        self.assertEqual([seed for _, _, seed in calls], [10, 1_000_013, 2_000_016])


if __name__ == "__main__":
    unittest.main()
