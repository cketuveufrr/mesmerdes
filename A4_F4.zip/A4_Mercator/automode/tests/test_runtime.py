from __future__ import annotations

import importlib.util
import sys
import unittest

import torch

from automode.bootstrap import project_root
from automode.fsm import ChocolateFSM, State, Transition, serialize_fsm
from automode.runtime import HeterogeneousChocolateRuntime


def _host_module():
    path = project_root() / "scripts" / "mercator_chocolate_fsm.py"
    spec = importlib.util.spec_from_file_location("host_runtime_chocolate", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Impossible de charger {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def deterministic_fsm() -> ChocolateFSM:
    return ChocolateFSM(
        (
            State(0, 7.0, (Transition(1, 5, 1.0),)),
            State(4, 2.5, (Transition(0, 5, 0.0),)),
        )
    ).validate()


class RuntimeTests(unittest.TestCase):
    def test_entry_tick_and_parameters(self) -> None:
        runtime = HeterogeneousChocolateRuntime(2, 3, "cpu")
        runtime.load([deterministic_fsm(), deterministic_fsm()])
        ground = torch.full((2, 3), 0.5)
        neighbors = torch.zeros((2, 3))

        first = runtime.step(ground, neighbors)
        self.assertTrue(torch.equal(first.module_ids, torch.zeros((2, 3), dtype=torch.long)))
        self.assertTrue(torch.equal(first.exploration_tau, torch.full((2, 3), 7, dtype=torch.long)))
        self.assertTrue(bool(first.state_entry_mask.all()))
        self.assertFalse(bool(first.transitioned.any()))

        second = runtime.step(ground, neighbors)
        self.assertTrue(bool(second.transitioned.all()))
        self.assertTrue(bool((runtime.state_ids == 1).all()))

        third = runtime.step(ground, neighbors)
        self.assertTrue(bool((third.module_ids == 4).all()))
        self.assertTrue(torch.allclose(third.attraction_alpha, torch.full((2, 3), 2.5)))
        self.assertTrue(bool(third.state_entry_mask.all()))
        self.assertFalse(bool(third.transitioned.any()))

    def test_deterministic_parity_with_host_runtime(self) -> None:
        host = _host_module()
        fsm = deterministic_fsm()
        host_fsm = host.parse_fsm(serialize_fsm(fsm))
        theirs = host.BatchedChocolateRuntime(host_fsm, 3, 4, "cpu")
        ours = HeterogeneousChocolateRuntime(3, 4, "cpu")
        ours.load([fsm, fsm, fsm])
        ground = torch.tensor(
            [[0.0, 0.5, 1.0, 0.5], [1.0, 0.0, 0.5, 1.0], [0.5, 0.5, 0.5, 0.5]],
            dtype=torch.float32,
        )
        neighbors = torch.tensor(
            [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 0]], dtype=torch.float32
        )
        for _ in range(8):
            a = ours.step(ground, neighbors)
            b = theirs.step(ground, neighbors)
            for name in (
                "module_ids",
                "state_ids",
                "exploration_tau",
                "attraction_alpha",
                "repulsion_alpha",
                "state_entry_mask",
                "transitioned",
            ):
                self.assertTrue(torch.equal(getattr(a, name), getattr(b, name)), name)

    def test_common_random_numbers_match_candidate_repetitions(self) -> None:
        stochastic = ChocolateFSM(
            (
                State(1, None, (Transition(1, 5, 0.5),)),
                State(1, None, (Transition(0, 5, 0.5),)),
            )
        ).validate()
        runtime = HeterogeneousChocolateRuntime(6, 5, "cpu")
        runtime.load([stochastic] * 6)
        ground = torch.full((6, 5), 0.5)
        neighbors = torch.zeros((6, 5))
        runtime.step(ground, neighbors, common_random_groups=(2, 3))
        step = runtime.step(ground, neighbors, common_random_groups=(2, 3))
        self.assertTrue(torch.equal(step.transitioned[0:3], step.transitioned[3:6]))


if __name__ == "__main__":
    unittest.main()
