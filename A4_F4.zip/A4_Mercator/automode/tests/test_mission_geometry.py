from __future__ import annotations

import math
import os
from pathlib import Path
import sys
import unittest

import torch

ROOT = Path(__file__).resolve().parents[2]
os.environ.setdefault("AUTOMODE_PROJECT_ROOT", str(ROOT))
os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from automode.config import build_tensor_env_cfg, load_mission_config
from automode.mission_geometry import (
    EXPERIMENT2_WALL_CENTERS,
    build_experiment2_arena,
    configure_mission_geometry,
)


class MissionGeometryTests(unittest.TestCase):
    def test_experiment2_geometry_has_exact_small_wall_centres(self):
        arena = build_experiment2_arena()
        self.assertEqual(arena.wall_centers, EXPERIMENT2_WALL_CENTERS)
        self.assertEqual(len(arena.wall_segments), 12)
        self.assertAlmostEqual(arena.inradius, 1.3073, places=4)
        self.assertLess(arena.circumradius, 1.36)
        self.assertGreater(arena.circumradius, 1.34)
        self.assertEqual(
            arena.fingerprint,
            "e680c08510fafc04f5bcbb02bb1df3ff26ccc23b07a12fc9587ed33c6731cfcf",
        )

    def test_aac2_evaluator_geometry_is_not_experiment1_geometry(self):
        from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
            MercatorTensorEnv,
        )

        loaded = load_mission_config("configs/mercator/AAC2_mercator_cyclamen.yaml")
        cfg = build_tensor_env_cfg(loaded, device="cpu", num_envs=32, seed=123)
        env = MercatorTensorEnv(cfg)
        try:
            # Host default is the large Experiment-1 wall-centre layout.
            self.assertGreater(env._arena_geometry.inradius, 4.7)
            configure_mission_geometry(env, loaded.mission)
            self.assertAlmostEqual(env._arena_geometry.inradius, 1.3073, places=4)
            self.assertLess(float(env.agent_pos.norm(dim=-1).max()), 1.25)
            self.assertTrue(torch.isfinite(env.agent_pos).all())
            self.assertEqual(env.wall_segments.shape, (12, 2, 2))
        finally:
            env.close()

    def test_aac_remains_on_large_experiment1_geometry(self):
        from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
            MercatorTensorEnv,
        )

        loaded = load_mission_config("configs/mercator/AAC_mercator_cyclamen.yaml")
        cfg = build_tensor_env_cfg(loaded, device="cpu", num_envs=2, seed=1)
        env = MercatorTensorEnv(cfg)
        try:
            configure_mission_geometry(env, loaded.mission)
            self.assertGreater(env._arena_geometry.inradius, 4.7)
            self.assertLess(env._arena_geometry.inradius, 4.9)
        finally:
            env.close()


if __name__ == "__main__":
    unittest.main()
