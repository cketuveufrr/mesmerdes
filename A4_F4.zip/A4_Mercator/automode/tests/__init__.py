"""Regression tests shipped with the root-level AutoMoDe package."""
