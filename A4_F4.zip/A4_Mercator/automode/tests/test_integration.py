from __future__ import annotations

from pathlib import Path
import random
import tempfile
import unittest

from automode.bootstrap import project_root
from automode.config import load_mission_config
from automode.evaluator import MercatorAutoMoDeEvaluator
from automode.fsm import random_fsm
from automode.optimizer import VectorizedRaceOptimizer


class IntegrationTests(unittest.TestCase):
    def test_all_configs_and_small_missions_run_tensor_only(self) -> None:
        # Loading/building every mission catches YAML/schema regressions without
        # invoking the expensive 20-robot CPU rejection sampler in a unit test.
        from automode.config import build_tensor_env_cfg

        for mission in ("AAC", "AAC2", "FOR", "FOR2", "GRID", "GRID2"):
            with self.subTest(config=mission):
                loaded = load_mission_config(
                    f"configs/mercator/{mission}_mercator_cyclamen.yaml"
                )
                cfg = build_tensor_env_cfg(loaded, device="cpu", num_envs=1, seed=17)
                self.assertEqual(cfg.num_agents, 3 if mission.endswith("2") else 20)
                self.assertEqual(int(cfg.episode_length_s), 120)

        # Exercise actual tensor simulation for the three small-arena missions.
        for mission in ("AAC2", "FOR2", "GRID2"):
            with self.subTest(runtime=mission):
                loaded = load_mission_config(
                    f"configs/mercator/{mission}_mercator_cyclamen.yaml"
                )
                evaluator = MercatorAutoMoDeEvaluator(
                    loaded, device="cpu", batch_size=2, seed=17, episode_steps=2
                )
                try:
                    result = evaluator.evaluate(
                        [random_fsm(random.Random(100 + len(mission)))],
                        episodes_per_candidate=2,
                    )
                    self.assertEqual(tuple(result.raw.shape), (1, 2))
                    self.assertEqual(result.simulations, 2)
                    self.assertEqual(evaluator.num_agents, 3)
                finally:
                    evaluator.close()

    def test_optimizer_consumes_exact_budget_and_writes_outputs(self) -> None:
        loaded = load_mission_config("configs/mercator/AAC2_mercator_cyclamen.yaml")
        evaluator = MercatorAutoMoDeEvaluator(
            loaded, device="cpu", batch_size=8, seed=5, episode_steps=2
        )
        try:
            with tempfile.TemporaryDirectory() as tmp:
                optimizer = VectorizedRaceOptimizer(
                    evaluator,
                    budget=25,
                    population_size=8,
                    round_repeats=(1, 2),
                    validation_budget=9,
                    validation_candidates=3,
                    min_validation_episodes=1,
                    seed=5,
                    output_dir=tmp,
                )
                result = optimizer.run()
                self.assertEqual(result.simulations_used, 25)
                self.assertEqual(result.search_simulations, 16)
                self.assertEqual(result.validation_simulations, 9)
                self.assertEqual(result.best_episodes, 4)
                for name in ("best_fsm.txt", "summary.json", "top_fsms.txt", "top_fsms.json", "history.jsonl", "validation_results.json", "validation_fsms.txt"):
                    self.assertTrue((Path(tmp) / name).is_file(), name)
        finally:
            evaluator.close()


if __name__ == "__main__":
    unittest.main()
