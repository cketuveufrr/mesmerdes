from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
import types
import unittest

import torch

from automode.bootstrap import project_root
from automode.objectives import AggregationObjective, ForagingObjective, GridObjective


def _load_model(relative: str, name: str):
    path = project_root() / relative
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Impossible de charger {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _load_foraging2_model():
    root = project_root() / "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions"
    package_paths = {
        "host_missions": root,
        "host_missions.mercator_foraging": root / "mercator_foraging",
        "host_missions.mercator_foraging2": root / "mercator_foraging2",
    }
    for name, path in package_paths.items():
        package = types.ModuleType(name)
        package.__path__ = [str(path)]
        sys.modules[name] = package
    base = _load_model(
        "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_foraging/mercator_foraging_model.py",
        "host_missions.mercator_foraging.mercator_foraging_model",
    )
    return _load_model(
        "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_foraging2/mercator_foraging2_model.py",
        "host_missions.mercator_foraging2.mercator_foraging2_model",
    )


class ObjectiveTests(unittest.TestCase):
    def test_aggregation_floor_and_score(self) -> None:
        obj = AggregationObjective(
            2,
            3,
            "cpu",
            {"black_center": (0.0, 2.35), "white_center": (0.0, -2.35), "zone_radius": 1.17},
        )
        points = torch.tensor(
            [[[0.0, 2.35], [0.0, -2.35], [0.0, 0.0]], [[1.17, 2.35], [3.0, 3.0], [0.0, 2.35]]]
        )
        self.assertTrue(torch.equal(obj.ground(points), torch.tensor([[0.0, 1.0, 0.5], [0.0, 0.5, 0.0]])))
        reward = obj.post_step(points)
        self.assertTrue(torch.equal(reward, torch.tensor([1.0, 2.0])))

    def _compare_foraging(self, experiment2: bool) -> None:
        if experiment2:
            module = _load_foraging2_model()
            settings = {"food_centers": ((0.8, 0.0), (-0.8, 0.0)), "food_radius": 0.265, "nest_limit_y": -0.63}
        else:
            module = _load_model(
                "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_foraging/mercator_foraging_model.py",
                "host_foraging_model",
            )
            settings = {"food_centers": ((2.9, 0.0), (-2.9, 0.0)), "food_radius": 0.58, "nest_limit_y": -2.35}
        generator = torch.Generator().manual_seed(8192 + int(experiment2))
        scale = 1.4 if experiment2 else 5.0
        points = (torch.rand((7, 13, 2), generator=generator) * 2.0 - 1.0) * scale
        obj = ForagingObjective(7, 13, "cpu", settings, experiment2=experiment2)
        self.assertTrue(torch.equal(obj.ground(points), module.ground_scalar(points)))

        carrying = torch.rand((7, 13), generator=generator) > 0.5
        obj.carrying.copy_(carrying)
        host_step = module.update_carrying_state(points, carrying)
        reward = obj.post_step(points)
        self.assertTrue(torch.equal(obj.carrying, host_step.carrying))
        self.assertTrue(torch.equal(reward, host_step.delivery_mask.sum(dim=1).to(torch.float32)))

    def test_foraging1_matches_host_model(self) -> None:
        self._compare_foraging(False)

    def test_foraging2_matches_host_model(self) -> None:
        self._compare_foraging(True)

    def _compare_grid(self, experiment2: bool) -> None:
        if experiment2:
            module = _load_model(
                "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_grid_exploration2/mercator_grid_exploration2_model.py",
                "host_grid2_model",
            )
            arena = 2.65
        else:
            module = _load_model(
                "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_grid_exploration/mercator_grid_exploration_model.py",
                "host_grid_model",
            )
            arena = 9.65
        generator = torch.Generator().manual_seed(3901 + int(experiment2))
        positions = (torch.rand((5, 20, 2), generator=generator) * 1.2 - 0.1) * arena - arena / 2
        ages = torch.randint(0, 50, (5, 10, 10), generator=generator)
        obj = GridObjective(5, 20, "cpu", {"grid_arena_size": arena, "grid_size": 10})
        obj.ages.copy_(ages)
        expected = module.update_grid_ages(ages, positions)
        reward = obj.post_step(positions)
        self.assertTrue(torch.equal(obj.ages, expected.ages))
        self.assertTrue(torch.equal(reward, expected.reward))

    def test_grid1_matches_host_model(self) -> None:
        self._compare_grid(False)

    def test_grid2_matches_host_model(self) -> None:
        self._compare_grid(True)


if __name__ == "__main__":
    unittest.main()
