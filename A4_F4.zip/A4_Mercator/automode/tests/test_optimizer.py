from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

import torch

from automode.evaluator import EvaluationResult
from automode.fsm import serialize_fsm
from automode.optimizer import VectorizedRaceOptimizer


class FakeEvaluator:
    """Fast deterministic evaluator used to test budget/selection invariants."""

    def __init__(self) -> None:
        self.loaded = SimpleNamespace(mission="AAC2", path=Path("fake.yaml"))
        self.device = torch.device("cpu")
        self.batch_size = 64
        self.episode_steps = 1200
        self.call_index = 0

    def evaluate(self, candidates, *, episodes_per_candidate=1):
        self.call_index += 1
        rows = []
        for candidate_index, fsm in enumerate(candidates):
            # Stable candidate component plus deterministic per-episode variation.
            key = serialize_fsm(fsm)
            base = float(sum(key.encode("utf-8")) % 1000)
            values = [
                base + 0.01 * self.call_index + 0.001 * candidate_index + 0.0001 * episode
                for episode in range(int(episodes_per_candidate))
            ]
            rows.append(torch.tensor(values, dtype=torch.float32))
        raw = torch.stack(rows)
        return EvaluationResult(
            means=raw.mean(dim=1),
            stds=raw.std(dim=1, unbiased=False),
            raw=raw,
            simulations=len(candidates) * int(episodes_per_candidate),
        )


class OptimizerBudgetTests(unittest.TestCase):
    def test_complete_generations_and_balanced_validation(self) -> None:
        evaluator = FakeEvaluator()
        with tempfile.TemporaryDirectory() as tmp:
            optimizer = VectorizedRaceOptimizer(
                evaluator,
                budget=100,
                population_size=8,
                round_repeats=(1, 2),
                survival_rate=0.5,
                validation_budget=20,
                validation_candidates=4,
                min_validation_episodes=2,
                seed=123,
                output_dir=tmp,
            )
            self.assertEqual(optimizer.generation_cost(), 16)
            self.assertEqual(optimizer.final_survivor_count(), 2)
            result = optimizer.run()

            self.assertEqual(result.simulations_used, 100)
            self.assertEqual(result.search_simulations, 80)
            self.assertEqual(result.validation_simulations, 20)
            self.assertEqual(result.generations, 5)
            self.assertEqual(result.best_episodes, 5)

            summary = json.loads((Path(tmp) / "summary.json").read_text())
            self.assertEqual(summary["algorithm"], optimizer.ALGORITHM_NAME)
            self.assertEqual(summary["validation_candidates"], 4)
            self.assertEqual(summary["validation_episodes_per_candidate"], 5)
            self.assertEqual(summary["validation_tail"], 0)
            self.assertEqual(summary["best_episodes"], 5)

            validation = json.loads((Path(tmp) / "validation_results.json").read_text())
            self.assertEqual(len(validation), 4)
            self.assertEqual(
                {row["validation_stats"]["count"] for row in validation},
                {5},
            )

            events = [json.loads(line) for line in (Path(tmp) / "history.jsonl").read_text().splitlines()]
            stages = [event for event in events if event["event"] == "search_stage"]
            self.assertEqual(len(stages), 10)  # 5 generations x 2 complete stages
            self.assertEqual({event["new_repeats"] for event in stages}, {1, 2})

    def test_validation_plan_uses_divisor_and_exact_budget(self) -> None:
        evaluator = FakeEvaluator()
        with tempfile.TemporaryDirectory() as tmp:
            optimizer = VectorizedRaceOptimizer(
                evaluator,
                budget=101,
                population_size=8,
                round_repeats=(1, 2),
                survival_rate=0.5,
                validation_budget=21,
                validation_candidates=4,
                min_validation_episodes=2,
                seed=456,
                output_dir=tmp,
            )
            result = optimizer.run()
            summary = json.loads((Path(tmp) / "summary.json").read_text())
            self.assertEqual(result.simulations_used, 101)
            self.assertEqual(result.search_simulations, 80)
            # 21 is not divisible by 4; the planner selects 3 x 7 rather than
            # comparing four candidates on unequal episode counts.
            self.assertEqual(summary["validation_candidates"], 3)
            self.assertEqual(summary["validation_episodes_per_candidate"], 7)
            self.assertEqual(summary["validation_tail"], 0)
            self.assertEqual(result.best_episodes, 7)

    def test_rejects_budget_that_cannot_fit_one_full_race(self) -> None:
        evaluator = FakeEvaluator()
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, "génération complète"):
                VectorizedRaceOptimizer(
                    evaluator,
                    budget=20,
                    population_size=8,
                    round_repeats=(1, 2),
                    validation_budget=5,
                    validation_candidates=2,
                    min_validation_episodes=1,
                    output_dir=tmp,
                )


if __name__ == "__main__":
    unittest.main()
