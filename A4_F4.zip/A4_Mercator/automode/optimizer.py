"""Budget-safe vectorized racing optimizer for Chocolate FSMs.

This optimizer is deliberately stricter than the first native implementation:

* a generation is either evaluated completely or not started;
* a configurable part of the 100k-simulation budget is reserved for an
  independent, balanced final validation;
* every controller participating in final selection receives exactly the same
  number of fresh episodes;
* a short, lucky controller from an incomplete budget tail can never become
  ``best_fsm.txt``.

The original AutoMoDe-Chocolate design method uses R/irace.  This native engine
keeps the Chocolate controller space and a racing/search philosophy while
batching simulations on the tensor backend.  It is not bit-identical to irace.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import math
from pathlib import Path
import random
import time
from typing import Iterable, Sequence

from .evaluator import MercatorAutoMoDeEvaluator
from .fsm import ChocolateFSM, mutate_fsm, random_fsm, serialize_fsm, unique_fsms


@dataclass
class RunningStats:
    count: int = 0
    total: float = 0.0
    total_sq: float = 0.0

    def update(self, values: Iterable[float]) -> None:
        for value in values:
            x = float(value)
            self.count += 1
            self.total += x
            self.total_sq += x * x

    @property
    def mean(self) -> float:
        return self.total / self.count if self.count else float("-inf")

    @property
    def variance(self) -> float:
        if self.count < 1:
            return float("inf")
        return max(0.0, self.total_sq / self.count - self.mean * self.mean)

    @property
    def std(self) -> float:
        return math.sqrt(self.variance)

    def as_dict(self) -> dict[str, float | int]:
        return {"count": self.count, "mean": self.mean, "std": self.std}


@dataclass
class ArchiveEntry:
    fsm: ChocolateFSM
    search_stats: RunningStats = field(default_factory=RunningStats)
    validation_stats: RunningStats = field(default_factory=RunningStats)
    finalist_count: int = 0
    first_generation: int = 0
    last_generation: int = 0

    # Backward-compatible alias used by a few external scripts from v1.
    @property
    def stats(self) -> RunningStats:
        return self.search_stats


@dataclass(frozen=True)
class OptimizationResult:
    best_fsm: ChocolateFSM
    best_score: float
    best_std: float
    best_episodes: int
    simulations_used: int
    search_simulations: int
    validation_simulations: int
    generations: int
    elapsed_s: float
    output_dir: Path


class VectorizedRaceOptimizer:
    """Run complete vectorized races followed by balanced hold-out validation."""

    ALGORITHM_NAME = "vectorized-race-v2-balanced-validation"

    def __init__(
        self,
        evaluator: MercatorAutoMoDeEvaluator,
        *,
        budget: int,
        population_size: int,
        round_repeats: Sequence[int] = (1, 2, 4, 8),
        survival_rate: float = 0.5,
        random_fraction: float = 0.15,
        elite_keep: int = 4,
        mutation_strength: int = 2,
        validation_budget: int = 20_000,
        validation_candidates: int = 32,
        min_validation_episodes: int = 50,
        seed: int = 0,
        output_dir: str | Path = "results/automode",
    ) -> None:
        if budget < 1:
            raise ValueError("budget doit être positif")
        if population_size < 2:
            raise ValueError("population_size doit être >= 2")
        if not round_repeats or any(int(value) < 1 for value in round_repeats):
            raise ValueError("round_repeats doit contenir des entiers positifs")
        if not 0.0 < survival_rate < 1.0:
            raise ValueError("survival_rate doit être dans ]0,1[")
        if not 0.0 <= random_fraction <= 1.0:
            raise ValueError("random_fraction doit être dans [0,1]")
        if validation_budget < 1 or validation_budget >= budget:
            raise ValueError("validation_budget doit être dans [1, budget-1]")
        if validation_candidates < 2:
            raise ValueError("validation_candidates doit être >= 2")
        if min_validation_episodes < 1:
            raise ValueError("min_validation_episodes doit être positif")

        self.evaluator = evaluator
        self.budget = int(budget)
        self.population_size = int(population_size)
        self.round_repeats = tuple(int(value) for value in round_repeats)
        self.survival_rate = float(survival_rate)
        self.random_fraction = float(random_fraction)
        self.elite_keep = max(1, int(elite_keep))
        self.mutation_strength = max(1, int(mutation_strength))
        self.validation_budget = int(validation_budget)
        self.validation_candidates = int(validation_candidates)
        self.min_validation_episodes = int(min_validation_episodes)
        self.rng = random.Random(int(seed))
        self.seed = int(seed)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.archive: dict[str, ArchiveEntry] = {}
        self.simulations_used = 0
        self.search_simulations = 0
        self.validation_simulations = 0
        self.post_selection_simulations = 0
        self.generation = 0
        self.history_path = self.output_dir / "history.jsonl"
        self.history_path.write_text("", encoding="utf-8")

        full_cost = self.generation_cost(self.population_size)
        if full_cost + self.validation_budget > self.budget:
            raise ValueError(
                "Budget insuffisant pour une génération complète et la validation: "
                f"generation={full_cost}, validation={self.validation_budget}, "
                f"budget={self.budget}. Réduisez population_size/round_repeats ou "
                "validation_budget."
            )

    def generation_cost(self, population_size: int | None = None) -> int:
        """Exact number of simulations consumed by one complete race."""

        survivors = int(population_size or self.population_size)
        if survivors < 1:
            return 0
        total = 0
        for repeats in self.round_repeats:
            total += survivors * repeats
            if survivors > 1:
                survivors = max(1, int(math.ceil(survivors * self.survival_rate)))
        return total

    def final_survivor_count(self, population_size: int | None = None) -> int:
        survivors = int(population_size or self.population_size)
        for _ in self.round_repeats:
            if survivors > 1:
                survivors = max(1, int(math.ceil(survivors * self.survival_rate)))
        return survivors

    def _entry(self, fsm: ChocolateFSM) -> ArchiveEntry:
        key = serialize_fsm(fsm)
        entry = self.archive.get(key)
        if entry is None:
            entry = ArchiveEntry(
                fsm=fsm,
                first_generation=self.generation,
                last_generation=self.generation,
            )
            self.archive[key] = entry
        entry.last_generation = self.generation
        return entry

    def _log(self, event: dict) -> None:
        event = {"time": time.time(), **event}
        with self.history_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, sort_keys=True) + "\n")

    @staticmethod
    def _local_rank(stats: RunningStats, fsm: ChocolateFSM) -> tuple[float, int, int]:
        states, transitions = fsm.complexity()
        return (stats.mean, -states, -transitions)

    def _archive_rank(self, entry: ArchiveEntry) -> tuple[int, float, int, int, int]:
        states, transitions = entry.fsm.complexity()
        return (
            int(entry.finalist_count > 0),
            entry.search_stats.mean,
            entry.search_stats.count,
            -states,
            -transitions,
        )

    @staticmethod
    def _validation_rank(entry: ArchiveEntry) -> tuple[float, int, int]:
        states, transitions = entry.fsm.complexity()
        return (entry.validation_stats.mean, -states, -transitions)

    def _initial_population(self, size: int) -> list[ChocolateFSM]:
        population: list[ChocolateFSM] = []
        seen: set[str] = set()
        while len(population) < size:
            candidate = random_fsm(self.rng)
            key = serialize_fsm(candidate)
            if key not in seen:
                seen.add(key)
                population.append(candidate)
        return population

    def _parent_pool(self, finalists: Sequence[ChocolateFSM]) -> list[ChocolateFSM]:
        combined = list(finalists)
        ranked_archive = sorted(self.archive.values(), key=self._archive_rank, reverse=True)
        combined.extend(entry.fsm for entry in ranked_archive[: max(16, self.elite_keep * 8)])
        return unique_fsms(combined)

    def _next_population(self, finalists: Sequence[ChocolateFSM], size: int) -> list[ChocolateFSM]:
        parents = self._parent_pool(finalists)
        ranked = sorted(
            parents,
            key=lambda fsm: self._archive_rank(self._entry(fsm)),
            reverse=True,
        )
        result = ranked[: min(self.elite_keep, size)]
        seen = {serialize_fsm(fsm) for fsm in result}
        random_target = int(round(size * self.random_fraction))
        mutation_target = size - random_target
        attempts = 0
        while len(result) < mutation_target and attempts < size * 300:
            attempts += 1
            tournament = self.rng.sample(ranked, k=min(3, len(ranked)))
            parent = max(tournament, key=lambda fsm: self._archive_rank(self._entry(fsm)))
            strength = max(1, self.mutation_strength + self.rng.choice((-1, 0, 0, 1)))
            candidate = mutate_fsm(parent, self.rng, strength=strength)
            key = serialize_fsm(candidate)
            if key not in seen:
                seen.add(key)
                result.append(candidate)
        while len(result) < size:
            candidate = random_fsm(self.rng)
            key = serialize_fsm(candidate)
            if key not in seen:
                seen.add(key)
                result.append(candidate)
        return result

    def _evaluate_search_stage(
        self,
        survivors: Sequence[ChocolateFSM],
        repeats: int,
        local: dict[str, RunningStats],
        stage: int,
    ) -> None:
        result = self.evaluator.evaluate(survivors, episodes_per_candidate=repeats)
        raw = result.raw.detach().cpu().tolist()
        for fsm, values in zip(survivors, raw):
            key = serialize_fsm(fsm)
            local[key].update(values)
            self._entry(fsm).search_stats.update(values)
        self.simulations_used += result.simulations
        self.search_simulations += result.simulations
        leader = max(survivors, key=lambda fsm: self._local_rank(local[serialize_fsm(fsm)], fsm))
        leader_stats = local[serialize_fsm(leader)]
        self._log(
            {
                "event": "search_stage",
                "generation": self.generation,
                "stage": stage,
                "candidates": len(survivors),
                "new_repeats": repeats,
                "simulations_used": self.simulations_used,
                "leader_mean": leader_stats.mean,
                "leader_std": leader_stats.std,
                "leader_episodes": leader_stats.count,
                "leader_fsm": serialize_fsm(leader),
            }
        )

    def _save_snapshot(self) -> None:
        ranked = sorted(self.archive.values(), key=self._archive_rank, reverse=True)
        top = ranked[: min(100, len(ranked))]
        (self.output_dir / "top_fsms.txt").write_text(
            "\n".join(serialize_fsm(entry.fsm) for entry in top) + ("\n" if top else ""),
            encoding="utf-8",
        )
        payload = [
            {
                "rank": index + 1,
                "fsm": serialize_fsm(entry.fsm),
                "stats": entry.search_stats.as_dict(),
                "search_stats": entry.search_stats.as_dict(),
                "validation_stats": entry.validation_stats.as_dict(),
                "finalist_count": entry.finalist_count,
                "first_generation": entry.first_generation,
                "last_generation": entry.last_generation,
            }
            for index, entry in enumerate(top)
        ]
        (self.output_dir / "top_fsms.json").write_text(
            json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
        )

    def _choose_validation_plan(self, remaining: int, eligible_count: int) -> tuple[int, int, int]:
        """Return (candidate_count, equal_episodes, post_selection_tail).

        Prefer a divisor of the remaining budget so all final candidates receive
        exactly the same number of episodes and the full budget is consumed.
        When no suitable divisor exists, a remainder smaller than the candidate
        count is spent only after the winner is selected and cannot affect rank.
        """

        max_candidates = min(
            self.validation_candidates,
            eligible_count,
            remaining // self.min_validation_episodes,
        )
        if max_candidates < 2:
            raise RuntimeError(
                "Budget de validation insuffisant: "
                f"remaining={remaining}, eligible={eligible_count}, "
                f"min_episodes={self.min_validation_episodes}"
            )
        for count in range(max_candidates, 1, -1):
            if remaining % count == 0:
                episodes = remaining // count
                if episodes >= self.min_validation_episodes:
                    return count, episodes, 0
        episodes = remaining // max_candidates
        tail = remaining - max_candidates * episodes
        return max_candidates, episodes, tail

    def _run_balanced_validation(self) -> tuple[ArchiveEntry, int, int, int]:
        remaining = self.budget - self.simulations_used
        eligible = [entry for entry in self.archive.values() if entry.finalist_count > 0]
        if len(eligible) < 2:
            eligible = list(self.archive.values())
        eligible.sort(key=self._archive_rank, reverse=True)
        candidate_count, episodes, tail = self._choose_validation_plan(remaining, len(eligible))
        pool = eligible[:candidate_count]
        fsms = [entry.fsm for entry in pool]

        self._log(
            {
                "event": "validation_start",
                "candidate_count": candidate_count,
                "episodes_per_candidate": episodes,
                "reserved_simulations": candidate_count * episodes,
                "post_selection_tail": tail,
                "simulations_used": self.simulations_used,
            }
        )
        result = self.evaluator.evaluate(fsms, episodes_per_candidate=episodes)
        raw = result.raw.detach().cpu().tolist()
        for entry, values in zip(pool, raw):
            entry.validation_stats.update(values)
        self.simulations_used += result.simulations
        self.validation_simulations += result.simulations

        ranked_validation = sorted(pool, key=self._validation_rank, reverse=True)
        best = ranked_validation[0]

        validation_payload = []
        for rank, entry in enumerate(ranked_validation, start=1):
            validation_payload.append(
                {
                    "rank": rank,
                    "fsm": serialize_fsm(entry.fsm),
                    "search_stats": entry.search_stats.as_dict(),
                    "validation_stats": entry.validation_stats.as_dict(),
                    "finalist_count": entry.finalist_count,
                }
            )
        (self.output_dir / "validation_fsms.txt").write_text(
            "\n".join(item["fsm"] for item in validation_payload) + "\n",
            encoding="utf-8",
        )
        (self.output_dir / "validation_results.json").write_text(
            json.dumps(validation_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        # A remainder cannot influence selection. It is consumed only after the
        # balanced comparison so simulations_used remains exactly the paper budget.
        if tail:
            extra = self.evaluator.evaluate([best.fsm], episodes_per_candidate=tail)
            self.simulations_used += extra.simulations
            self.validation_simulations += extra.simulations
            self.post_selection_simulations += extra.simulations
            post_values = extra.raw[0].detach().cpu().tolist()
            (self.output_dir / "post_selection_extra.json").write_text(
                json.dumps(
                    {
                        "fsm": serialize_fsm(best.fsm),
                        "episodes": tail,
                        "mean": sum(post_values) / len(post_values),
                        "values": post_values,
                        "note": "Not used to select or report the balanced-validation winner.",
                    },
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )

        self._log(
            {
                "event": "validation_complete",
                "candidate_count": candidate_count,
                "episodes_per_candidate": episodes,
                "post_selection_tail": tail,
                "simulations_used": self.simulations_used,
                "winner_mean": best.validation_stats.mean,
                "winner_std": best.validation_stats.std,
                "winner_fsm": serialize_fsm(best.fsm),
            }
        )
        return best, candidate_count, episodes, tail

    def run(self) -> OptimizationResult:
        started = time.perf_counter()
        population = self._initial_population(self.population_size)
        full_generation_cost = self.generation_cost(self.population_size)
        search_limit = self.budget - self.validation_budget

        self._log(
            {
                "event": "run_start",
                "algorithm": self.ALGORITHM_NAME,
                "budget": self.budget,
                "search_limit": search_limit,
                "minimum_validation_budget": self.validation_budget,
                "generation_cost": full_generation_cost,
                "population_size": self.population_size,
            }
        )

        # Strictly complete generations only. No affordable/min(repeats) branch.
        while self.simulations_used + full_generation_cost <= search_limit:
            self.generation += 1
            local = {serialize_fsm(fsm): RunningStats() for fsm in population}
            survivors = list(population)

            for stage, repeats in enumerate(self.round_repeats):
                self._evaluate_search_stage(survivors, repeats, local, stage)
                if len(survivors) > 1:
                    keep = max(1, int(math.ceil(len(survivors) * self.survival_rate)))
                    survivors = sorted(
                        survivors,
                        key=lambda fsm: self._local_rank(local[serialize_fsm(fsm)], fsm),
                        reverse=True,
                    )[:keep]

            for fsm in survivors:
                self._entry(fsm).finalist_count += 1
            self._save_snapshot()
            best_local = max(
                survivors,
                key=lambda fsm: self._local_rank(local[serialize_fsm(fsm)], fsm),
            )
            stats = local[serialize_fsm(best_local)]
            print(
                f"generation={self.generation} "
                f"search={self.search_simulations}/{search_limit} "
                f"total={self.simulations_used}/{self.budget} "
                f"finalistes={len(survivors)} "
                f"meilleur_recherche={stats.mean:.6g} ± {stats.std:.4g} "
                f"n={stats.count}",
                flush=True,
            )
            population = self._next_population(survivors, self.population_size)

        if self.generation < 1:
            raise RuntimeError("Aucune génération complète n'a pu être exécutée")

        self._log(
            {
                "event": "search_complete",
                "generations": self.generation,
                "search_simulations": self.search_simulations,
                "remaining_for_validation": self.budget - self.simulations_used,
            }
        )
        best_entry, validation_count, validation_episodes, validation_tail = (
            self._run_balanced_validation()
        )
        if self.simulations_used != self.budget:
            raise RuntimeError(
                f"Erreur interne de budget: {self.simulations_used} != {self.budget}"
            )

        elapsed = time.perf_counter() - started
        best_string = serialize_fsm(best_entry.fsm)
        (self.output_dir / "best_fsm.txt").write_text(best_string + "\n", encoding="utf-8")
        summary = {
            "algorithm": self.ALGORITHM_NAME,
            "mission": self.evaluator.loaded.mission,
            "config": str(self.evaluator.loaded.path),
            "device": str(self.evaluator.device),
            "batch_size": self.evaluator.batch_size,
            "episode_steps": self.evaluator.episode_steps,
            "budget": self.budget,
            "simulations_used": self.simulations_used,
            "search_simulations": self.search_simulations,
            "validation_simulations": self.validation_simulations,
            "post_selection_simulations": self.post_selection_simulations,
            "minimum_validation_budget": self.validation_budget,
            "population_size": self.population_size,
            "round_repeats": list(self.round_repeats),
            "survival_rate": self.survival_rate,
            "random_fraction": self.random_fraction,
            "elite_keep": self.elite_keep,
            "mutation_strength": self.mutation_strength,
            "validation_candidates_requested": self.validation_candidates,
            "validation_candidates": validation_count,
            "validation_episodes_per_candidate": validation_episodes,
            "validation_tail": validation_tail,
            "min_validation_episodes": self.min_validation_episodes,
            "seed": self.seed,
            "generations": self.generation,
            "generation_cost": full_generation_cost,
            "elapsed_s": elapsed,
            "best_fsm": best_string,
            "best_score": best_entry.validation_stats.mean,
            "best_std": best_entry.validation_stats.std,
            "best_episodes": best_entry.validation_stats.count,
            "best_validation_score": best_entry.validation_stats.mean,
            "best_validation_std": best_entry.validation_stats.std,
            "best_validation_episodes": best_entry.validation_stats.count,
            "best_search_score": best_entry.search_stats.mean,
            "best_search_std": best_entry.search_stats.std,
            "best_search_episodes": best_entry.search_stats.count,
            "archive_size": len(self.archive),
        }
        (self.output_dir / "summary.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        self._save_snapshot()
        return OptimizationResult(
            best_fsm=best_entry.fsm,
            best_score=best_entry.validation_stats.mean,
            best_std=best_entry.validation_stats.std,
            best_episodes=best_entry.validation_stats.count,
            simulations_used=self.simulations_used,
            search_simulations=self.search_simulations,
            validation_simulations=self.validation_simulations,
            generations=self.generation,
            elapsed_s=elapsed,
            output_dir=self.output_dir,
        )
