"""Fully vectorized heterogeneous AutoMoDe-Chocolate runtime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch

from .fsm import ChocolateFSM, MAX_STATES, MAX_TRANSITIONS


@dataclass(frozen=True)
class RuntimeStep:
    module_ids: torch.Tensor
    state_ids: torch.Tensor
    exploration_tau: torch.Tensor
    attraction_alpha: torch.Tensor
    repulsion_alpha: torch.Tensor
    state_entry_mask: torch.Tensor
    transitioned: torch.Tensor


@dataclass(frozen=True)
class EncodedFSMBatch:
    module_ids: torch.Tensor       # [E,S]
    parameters: torch.Tensor       # [E,S]
    destinations: torch.Tensor     # [E,S,T]
    conditions: torch.Tensor       # [E,S,T]
    p: torch.Tensor                # [E,S,T]
    w: torch.Tensor                # [E,S,T]
    valid: torch.Tensor            # [E,S,T]

    @property
    def num_envs(self) -> int:
        return int(self.module_ids.shape[0])


def encode_fsms(fsms: Sequence[ChocolateFSM], device: torch.device | str) -> EncodedFSMBatch:
    if not fsms:
        raise ValueError("Au moins une FSM est requise")
    dev = torch.device(device)
    e = len(fsms)
    # Populate on CPU and transfer each dense tensor once. Scalar assignments
    # directly into CUDA tensors would enqueue thousands of tiny operations for
    # every race stage and can dominate short evaluations.
    module_ids = torch.zeros(e, MAX_STATES, dtype=torch.long)
    parameters = torch.ones(e, MAX_STATES, dtype=torch.float32)
    destinations = torch.zeros(e, MAX_STATES, MAX_TRANSITIONS, dtype=torch.long)
    conditions = torch.zeros(e, MAX_STATES, MAX_TRANSITIONS, dtype=torch.long)
    p = torch.zeros(e, MAX_STATES, MAX_TRANSITIONS, dtype=torch.float32)
    w = torch.zeros(e, MAX_STATES, MAX_TRANSITIONS, dtype=torch.float32)
    valid = torch.zeros(e, MAX_STATES, MAX_TRANSITIONS, dtype=torch.bool)

    for env_index, fsm in enumerate(fsms):
        fsm.validate()
        for state_index, state in enumerate(fsm.states):
            module_ids[env_index, state_index] = state.module_id
            if state.parameter is not None:
                parameters[env_index, state_index] = float(state.parameter)
            for transition_index, transition in enumerate(state.transitions):
                destinations[env_index, state_index, transition_index] = transition.destination
                conditions[env_index, state_index, transition_index] = transition.condition_id
                p[env_index, state_index, transition_index] = float(transition.p)
                if transition.w is not None:
                    w[env_index, state_index, transition_index] = float(transition.w)
                valid[env_index, state_index, transition_index] = True
    if dev.type != "cpu":
        module_ids = module_ids.to(dev)
        parameters = parameters.to(dev)
        destinations = destinations.to(dev)
        conditions = conditions.to(dev)
        p = p.to(dev)
        w = w.to(dev)
        valid = valid.to(dev)
    return EncodedFSMBatch(module_ids, parameters, destinations, conditions, p, w, valid)


class HeterogeneousChocolateRuntime:
    """Execute a distinct FSM in every environment of an ``[E,N]`` batch."""

    def __init__(self, num_envs: int, num_agents: int, device: torch.device | str):
        self.device = torch.device(device)
        self.num_envs = int(num_envs)
        self.num_agents = int(num_agents)
        shape = (self.num_envs, self.num_agents)
        self.state_ids = torch.zeros(shape, dtype=torch.long, device=self.device)
        self.entering = torch.ones(shape, dtype=torch.bool, device=self.device)
        self._env_index = torch.arange(self.num_envs, device=self.device).view(-1, 1)
        self.encoded: EncodedFSMBatch | None = None

    def load(self, fsms: Sequence[ChocolateFSM]) -> None:
        if len(fsms) != self.num_envs:
            raise ValueError(f"Attendu {self.num_envs} FSM, reçu {len(fsms)}")
        self.encoded = encode_fsms(fsms, self.device)
        self.reset()

    def reset(self) -> None:
        self.state_ids.zero_()
        self.entering.fill_(True)

    def _gather_state(self, tensor: torch.Tensor) -> torch.Tensor:
        return tensor[self._env_index, self.state_ids]

    def step(
        self,
        ground: torch.Tensor,
        neighbor_count: torch.Tensor,
        *,
        common_random_groups: tuple[int, int] | None = None,
    ) -> RuntimeStep:
        if self.encoded is None:
            raise RuntimeError("Aucune FSM chargée")
        expected = (self.num_envs, self.num_agents)
        if tuple(ground.shape) != expected or tuple(neighbor_count.shape) != expected:
            raise ValueError(f"ground/neighbor_count doivent avoir la forme {expected}")
        ground = ground.to(self.device, torch.float32)
        neighbor_count = neighbor_count.to(self.device, torch.float32)
        encoded = self.encoded

        state_before = self.state_ids.clone()
        entry_before = self.entering.clone()
        module_ids = self._gather_state(encoded.module_ids)
        state_parameter = self._gather_state(encoded.parameters)

        exploration_tau = torch.where(
            module_ids == 0,
            state_parameter.round().to(torch.long),
            torch.zeros_like(module_ids),
        )
        attraction_alpha = torch.where(
            module_ids == 4,
            state_parameter,
            torch.ones_like(state_parameter),
        )
        repulsion_alpha = torch.where(
            module_ids == 5,
            state_parameter,
            torch.ones_like(state_parameter),
        )

        destinations = encoded.destinations[self._env_index, state_before]
        conditions = encoded.conditions[self._env_index, state_before]
        p = encoded.p[self._env_index, state_before]
        w = encoded.w[self._env_index, state_before]
        valid = encoded.valid[self._env_index, state_before] & (~entry_before).unsqueeze(-1)

        g = ground.unsqueeze(-1)
        n = neighbor_count.unsqueeze(-1)
        xi = torch.trunc(p)
        logistic = torch.sigmoid(w * (n - xi))
        probabilities = torch.where(
            conditions == 0,
            (g <= 0.10).to(torch.float32) * p,
            torch.where(
                conditions == 1,
                ((g > 0.10) & (g < (160.0 / 255.0))).to(torch.float32) * p,
                torch.where(
                    conditions == 2,
                    (g >= (220.0 / 255.0)).to(torch.float32) * p,
                    torch.where(
                        conditions == 3,
                        logistic,
                        torch.where(
                            conditions == 4,
                            1.0 - logistic,
                            p,
                        ),
                    ),
                ),
            ),
        ).clamp_(0.0, 1.0)

        if common_random_groups is None:
            success_u = torch.rand(
                self.num_envs, self.num_agents, MAX_TRANSITIONS, device=self.device
            )
            priority = torch.rand_like(success_u)
        else:
            candidates, repeats = common_random_groups
            active = int(candidates) * int(repeats)
            if active > self.num_envs or candidates < 1 or repeats < 1:
                raise ValueError("common_random_groups invalide")
            base_success = torch.rand(repeats, self.num_agents, MAX_TRANSITIONS, device=self.device)
            base_priority = torch.rand_like(base_success)
            success_u = base_success.repeat(candidates, 1, 1)
            priority = base_priority.repeat(candidates, 1, 1)
            if active < self.num_envs:
                padding_shape = (self.num_envs - active, self.num_agents, MAX_TRANSITIONS)
                success_u = torch.cat((success_u, torch.rand(padding_shape, device=self.device)), dim=0)
                priority = torch.cat((priority, torch.rand(padding_shape, device=self.device)), dim=0)

        successes = (success_u < probabilities) & valid
        ranked = torch.where(successes, priority, torch.full_like(priority, float("inf")))
        chosen = ranked.argmin(dim=-1)
        any_success = successes.any(dim=-1)
        selected_destination = destinations.gather(-1, chosen.unsqueeze(-1)).squeeze(-1)
        next_states = torch.where(any_success, selected_destination, state_before)

        self.state_ids.copy_(next_states)
        self.entering.copy_(any_success)
        return RuntimeStep(
            module_ids=module_ids,
            state_ids=state_before,
            exploration_tau=exploration_tau,
            attraction_alpha=attraction_alpha,
            repulsion_alpha=repulsion_alpha,
            state_entry_mask=entry_before,
            transitioned=any_success,
        )
