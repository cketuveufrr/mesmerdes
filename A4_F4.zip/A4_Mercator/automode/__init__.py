"""Vectorized AutoMoDe-Chocolate design for the Mercator tensor backend."""

from .fsm import ChocolateFSM, State, Transition, parse_fsm, serialize_fsm

__all__ = [
    "ChocolateFSM",
    "State",
    "Transition",
    "parse_fsm",
    "serialize_fsm",
]

__version__ = "0.3.0"
