"""Tensor-only mission floor models and paper objective functions."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Sequence

import torch


class Objective:
    """Stateful vectorized objective interface."""

    def __init__(self, num_envs: int, num_agents: int, device: torch.device | str, settings: dict[str, Any]):
        self.num_envs = int(num_envs)
        self.num_agents = int(num_agents)
        self.device = torch.device(device)
        self.settings = settings
        self.score = torch.zeros(self.num_envs, dtype=torch.float32, device=self.device)

    def reset(self) -> None:
        self.score.zero_()

    def ground(self, points: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError

    def post_step(self, positions: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError


class AggregationObjective(Objective):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        settings = self.settings
        self.black_center = torch.tensor(settings["black_center"], dtype=torch.float32, device=self.device)
        self.white_center = torch.tensor(settings["white_center"], dtype=torch.float32, device=self.device)
        self.radius_sq = float(settings["zone_radius"]) ** 2

    def ground(self, points: torch.Tensor) -> torch.Tensor:
        black = (points - self.black_center).square().sum(dim=-1) <= self.radius_sq
        white = (points - self.white_center).square().sum(dim=-1) <= self.radius_sq
        result = torch.full(points.shape[:-1], 0.5, dtype=points.dtype, device=points.device)
        result.masked_fill_(black, 0.0)
        result.masked_fill_(white, 1.0)
        return result

    def post_step(self, positions: torch.Tensor) -> torch.Tensor:
        n_black = ((positions - self.black_center).square().sum(dim=-1) <= self.radius_sq).sum(dim=1).to(torch.float32)
        self.score.add_(n_black)
        return n_black


def _triangle_membership(points: torch.Tensor, a: torch.Tensor, b: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
    def area2(p, q, r):
        return torch.abs(
            p[..., 0] * (q[..., 1] - r[..., 1])
            + q[..., 0] * (r[..., 1] - p[..., 1])
            + r[..., 0] * (p[..., 1] - q[..., 1])
        )
    return torch.abs(area2(a, b, c) - (area2(a, b, points) + area2(a, c, points) + area2(b, c, points))) < 2e-4


def _nest_polygon(*, wall_center: float, wall_length: float, max_dim: float, nest_limit_y: float, wall_width: float = 0.01) -> tuple[tuple[float, float], ...]:
    drop = math.sin(math.radians(60.0)) * wall_length / 2.0
    return (
        (-wall_center - wall_width, nest_limit_y),
        (wall_center + wall_width, nest_limit_y),
        (wall_center - math.cos(math.radians(60.0)) * wall_length / 2.0 + wall_width, nest_limit_y - drop - wall_width),
        (wall_length / 2.0 + wall_width, -max_dim),
        (-(wall_length / 2.0 + wall_width), -max_dim),
        (-wall_center + math.cos(math.radians(60.0)) * wall_length / 2.0 - wall_width, nest_limit_y - drop - wall_width),
    )


def _floor_nest_membership(points: torch.Tensor, limit: float, polygon: Sequence[Sequence[float]]) -> torch.Tensor:
    vertices = torch.as_tensor(polygon, dtype=points.dtype, device=points.device)
    center = torch.tensor((0.0, limit), dtype=points.dtype, device=points.device)
    bottom, top, angle1, angle2, angle3, angle4 = vertices
    inside = (
        _triangle_membership(points, center, top, angle1)
        | _triangle_membership(points, center, angle2, angle3)
        | _triangle_membership(points, center, angle1, angle2)
        | _triangle_membership(points, center, angle3, angle4)
        | _triangle_membership(points, center, angle4, bottom)
    )
    return (points[..., 1] < limit) & inside


class ForagingObjective(Objective):
    def __init__(self, *args, experiment2: bool = False, **kwargs):
        super().__init__(*args, **kwargs)
        settings = self.settings
        self.food_centers = torch.tensor(settings["food_centers"], dtype=torch.float32, device=self.device)
        self.food_radius_sq = float(settings["food_radius"]) ** 2
        self.nest_limit_y = float(settings["nest_limit_y"])
        self.carrying = torch.zeros(self.num_envs, self.num_agents, dtype=torch.bool, device=self.device)
        if experiment2:
            self.nest_polygon = _nest_polygon(wall_center=1.131, wall_length=0.70, max_dim=1.305, nest_limit_y=self.nest_limit_y)
        else:
            self.nest_polygon = _nest_polygon(wall_center=4.1562, wall_length=2.57, max_dim=4.7957, nest_limit_y=self.nest_limit_y)

    def reset(self) -> None:
        super().reset()
        self.carrying.zero_()

    def food_membership(self, points: torch.Tensor) -> torch.Tensor:
        return (points.unsqueeze(-2) - self.food_centers).square().sum(dim=-1) <= self.food_radius_sq

    def ground(self, points: torch.Tensor) -> torch.Tensor:
        food = self.food_membership(points).any(dim=-1)
        nest = _floor_nest_membership(points, self.nest_limit_y, self.nest_polygon)
        result = torch.full(points.shape[:-1], 0.5, dtype=points.dtype, device=points.device)
        result = torch.where(nest, torch.ones_like(result), result)
        return torch.where(food, torch.zeros_like(result), result)

    def post_step(self, positions: torch.Tensor) -> torch.Tensor:
        in_food = self.food_membership(positions).any(dim=-1)
        after_pickup = self.carrying | in_food
        in_nest = positions[..., 1] <= self.nest_limit_y
        delivered = in_nest & after_pickup
        self.carrying.copy_(after_pickup & ~delivered)
        reward = delivered.sum(dim=1).to(torch.float32)
        self.score.add_(reward)
        return reward


class GridObjective(Objective):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.arena_size = float(self.settings["grid_arena_size"])
        self.grid_size = int(self.settings.get("grid_size", 10))
        self.ages = torch.zeros(
            self.num_envs,
            self.grid_size,
            self.grid_size,
            dtype=torch.long,
            device=self.device,
        )

    def reset(self) -> None:
        super().reset()
        self.ages.zero_()

    def ground(self, points: torch.Tensor) -> torch.Tensor:
        return torch.full(points.shape[:-1], 0.5, dtype=points.dtype, device=points.device)

    def post_step(self, positions: torch.Tensor) -> torch.Tensor:
        scaled = self.grid_size * (positions / self.arena_size + 0.5)
        x = torch.floor(scaled[..., 0]).to(torch.long)
        y = torch.floor(scaled[..., 1]).to(torch.long)
        valid = (x >= 0) & (x < self.grid_size) & (y >= 0) & (y < self.grid_size)
        linear = (x * self.grid_size + y).clamp(0, self.grid_size * self.grid_size - 1)
        counts = torch.zeros(
            self.num_envs,
            self.grid_size * self.grid_size,
            dtype=torch.long,
            device=self.device,
        )
        counts.scatter_add_(1, linear, valid.to(torch.long))
        visited = counts.view(self.num_envs, self.grid_size, self.grid_size) > 0
        reset_ages = torch.where(visited, torch.zeros_like(self.ages), self.ages)
        reward = -reset_ages.sum(dim=(1, 2)).to(torch.float32) / float(self.grid_size**2)
        self.ages.copy_(reset_ages + 1)
        self.score.add_(reward)
        return reward


def make_objective(mission: str, num_envs: int, num_agents: int, device: torch.device | str, settings: dict[str, Any]) -> Objective:
    if mission in ("AAC", "AAC2"):
        return AggregationObjective(num_envs, num_agents, device, settings)
    if mission == "FOR":
        return ForagingObjective(num_envs, num_agents, device, settings, experiment2=False)
    if mission == "FOR2":
        return ForagingObjective(num_envs, num_agents, device, settings, experiment2=True)
    if mission in ("GRID", "GRID2"):
        return GridObjective(num_envs, num_agents, device, settings)
    raise ValueError(f"Mission non supportée: {mission}")
