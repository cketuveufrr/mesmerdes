"""Mission-specific arena selection for the tensor-only AutoMoDe evaluator.

The host ``MercatorTensorEnv`` currently constructs the Experiment-1 arena
unconditionally.  Changing only ``arena_side_length`` is not sufficient for
Experiment 2 because its twelve wall centres are different by roughly a factor
of 3.65.  This module applies the exact small dodecagon used by AAC2/FOR2/GRID2
before any scored episode is sampled.
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any

import torch

from .bootstrap import prepare_imports


EXPERIMENT2_WALL_CENTERS: tuple[tuple[float, float], ...] = (
    (-1.3123, 0.0),
    (1.3123, 0.0),
    (0.0, 1.3123),
    (0.0, -1.3123),
    (-0.6591, -1.1373),
    (-1.1373, -0.6591),
    (0.6591, 1.1373),
    (1.1373, 0.6591),
    (-0.6591, 1.1373),
    (-1.1373, 0.6591),
    (0.6591, -1.1373),
    (1.1373, -0.6591),
)
EXPERIMENT2_WALL_YAW_DEG: tuple[float, ...] = (
    0.0,
    0.0,
    90.0,
    90.0,
    60.0,
    30.0,
    60.0,
    30.0,
    -60.0,
    -30.0,
    -60.0,
    -30.0,
)


def _round_nested(value: Any, digits: int = 9) -> Any:
    if isinstance(value, float):
        return round(value, digits)
    if isinstance(value, (tuple, list)):
        return [_round_nested(v, digits) for v in value]
    if isinstance(value, dict):
        return {k: _round_nested(value[k], digits) for k in sorted(value)}
    return value


def _fingerprint(payload: dict[str, Any]) -> str:
    canonical = json.dumps(
        _round_nested(payload),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _line_intersection(
    n1: tuple[float, float],
    d1: float,
    n2: tuple[float, float],
    d2: float,
) -> tuple[float, float]:
    det = n1[0] * n2[1] - n1[1] * n2[0]
    if abs(det) < 1e-12:
        raise ValueError("Adjacent arena wall planes are parallel")
    return (
        (d1 * n2[1] - n1[1] * d2) / det,
        (n1[0] * d2 - d1 * n2[0]) / det,
    )


def build_experiment2_arena(
    wall_side_length: float = 0.70,
    wall_thickness: float = 0.01,
    wall_height: float = 0.08,
):
    """Return the exact Experiment-2 arena without importing Isaac missions."""

    prepare_imports()
    from SwarmACB_isaac.tasks.direct.mercator_light.arena_geometry import ArenaGeometry

    half = 0.5 * float(wall_side_length)
    centers: list[tuple[float, float]] = []
    yaws: list[float] = []
    segments: list[tuple[tuple[float, float], tuple[float, float]]] = []
    normals: list[tuple[float, float]] = []
    offsets: list[float] = []

    for center, argos_yaw_deg in zip(
        EXPERIMENT2_WALL_CENTERS, EXPERIMENT2_WALL_YAW_DEG
    ):
        cx, cy = float(center[0]), float(center[1])
        segment_yaw = math.radians(float(argos_yaw_deg) + 90.0)
        tx, ty = math.cos(segment_yaw), math.sin(segment_yaw)
        a = (cx - half * tx, cy - half * ty)
        b = (cx + half * tx, cy + half * ty)

        radius = math.hypot(cx, cy)
        if radius <= 0.0:
            raise ValueError("Arena wall centre cannot be at the origin")
        nx, ny = cx / radius, cy / radius
        inner_offset = cx * nx + cy * ny - 0.5 * float(wall_thickness)

        centers.append((cx, cy))
        yaws.append(segment_yaw)
        segments.append((a, b))
        normals.append((nx, ny))
        offsets.append(inner_offset)

    order = sorted(range(12), key=lambda i: math.atan2(normals[i][1], normals[i][0]))
    floor_vertices = []
    for pos, index in enumerate(order):
        next_index = order[(pos + 1) % len(order)]
        floor_vertices.append(
            _line_intersection(
                normals[index],
                offsets[index],
                normals[next_index],
                offsets[next_index],
            )
        )

    circumradius = max(math.hypot(x, y) for x, y in floor_vertices)
    inradius = min(offsets)
    payload = {
        "schema": "mercator-aggregation2-arena-v1",
        "wall_side_length": float(wall_side_length),
        "wall_thickness": float(wall_thickness),
        "wall_height": float(wall_height),
        "argos_wall_centers": EXPERIMENT2_WALL_CENTERS,
        "argos_wall_yaw_deg": EXPERIMENT2_WALL_YAW_DEG,
        "wall_segments": segments,
        "outward_normals": normals,
        "inner_offsets": offsets,
        "floor_vertices": floor_vertices,
    }
    return ArenaGeometry(
        wall_side_length=float(wall_side_length),
        wall_thickness=float(wall_thickness),
        wall_height=float(wall_height),
        wall_centers=tuple(centers),
        wall_segment_yaws_rad=tuple(yaws),
        wall_segments=tuple(segments),
        outward_normals=tuple(normals),
        inner_offsets=tuple(offsets),
        floor_vertices=tuple(floor_vertices),
        circumradius=float(circumradius),
        inradius=float(inradius),
        fingerprint=_fingerprint(payload),
    )


def configure_mission_geometry(env: Any, mission: str) -> None:
    """Install the correct mission arena into an existing tensor environment.

    ``MercatorTensorEnv.__init__`` has already allocated all persistent tensors.
    Replacing the immutable wall tensors is therefore cheap.  A reset is then
    forced so no pose sampled in the old arena can leak into an evaluation.
    """

    prepare_imports()
    from SwarmACB_isaac.tasks.direct.mercator_light.arena_geometry import (
        build_argos_aac_arena,
        build_environment_signature,
    )

    if mission in {"AAC2", "FOR2", "GRID2"}:
        arena = build_experiment2_arena(
            wall_side_length=float(env.cfg.arena_side_length),
            wall_thickness=float(env.cfg.arena_wall_thickness),
            wall_height=float(env.cfg.arena_wall_height),
        )
        expected_max_center = 1.32
    elif mission in {"AAC", "FOR", "GRID"}:
        arena = build_argos_aac_arena(
            wall_side_length=float(env.cfg.arena_side_length),
            wall_thickness=float(env.cfg.arena_wall_thickness),
            wall_height=float(env.cfg.arena_wall_height),
        )
        expected_max_center = 4.80
    else:
        raise ValueError(f"Mission Mercator non supportée: {mission}")

    max_center = max(math.hypot(x, y) for x, y in arena.wall_centers)
    if abs(max_center - expected_max_center) > 0.03:
        raise RuntimeError(
            f"Géométrie {mission} incohérente: rayon des centres de murs "
            f"{max_center:.6f} m"
        )

    dev = env.device
    env._arena_geometry = arena
    env._environment_signature = build_environment_signature(env.cfg, arena)
    env.wall_segments = torch.tensor(
        arena.wall_segments, dtype=torch.float32, device=dev
    )
    env.wall_outward_normals = torch.tensor(
        arena.outward_normals, dtype=torch.float32, device=dev
    )
    env.wall_inner_offsets = torch.tensor(
        arena.inner_offsets, dtype=torch.float32, device=dev
    )
    env.sensors.bind_wall_segments(env.wall_segments)

    # The environment constructor sampled poses using its default arena.
    # Discard them immediately and sample inside the selected mission arena.
    env._reset_all(initial=True)


__all__ = [
    "EXPERIMENT2_WALL_CENTERS",
    "EXPERIMENT2_WALL_YAW_DEG",
    "build_experiment2_arena",
    "configure_mission_geometry",
]
