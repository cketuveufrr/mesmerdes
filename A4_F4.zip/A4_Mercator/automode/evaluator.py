"""High-throughput evaluator binding Chocolate FSMs to MercatorTensorEnv."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence

import torch

from .bootstrap import prepare_imports
from .config import LoadedMissionConfig, build_tensor_env_cfg
from .fsm import ChocolateFSM
from .mission_geometry import configure_mission_geometry
from .objectives import Objective, make_objective
from .runtime import HeterogeneousChocolateRuntime


@dataclass(frozen=True)
class EvaluationResult:
    means: torch.Tensor
    stds: torch.Tensor
    raw: torch.Tensor
    simulations: int


class MercatorAutoMoDeEvaluator:
    """Persistent tensor-only simulation service for heterogeneous FSM batches."""

    def __init__(
        self,
        loaded: LoadedMissionConfig,
        *,
        device: str,
        batch_size: int,
        seed: int = 0,
        episode_steps: int | None = None,
    ) -> None:
        prepare_imports()
        from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
            MercatorTensorEnv,
        )

        if batch_size < 1:
            raise ValueError("batch_size doit être positif")
        self.loaded = loaded
        self.device = torch.device(device)
        self.batch_size = int(batch_size)
        self.seed = int(seed)
        self._evaluation_round = 0
        cfg = build_tensor_env_cfg(
            loaded,
            device=str(self.device),
            num_envs=self.batch_size,
            seed=self.seed,
        )
        self.cfg = cfg
        self.env = MercatorTensorEnv(cfg)
        configure_mission_geometry(self.env, loaded.mission)
        # Respect no-light missions if a future config sets intensity to zero.
        self.env.sensors.light_enabled = float(loaded.environment.get("light_intensity", 1.0)) > 0.0
        self.runtime = HeterogeneousChocolateRuntime(
            self.batch_size, cfg.num_agents, self.device
        )
        settings = dict(loaded.environment)
        settings.setdefault("black_center", cfg.black_center)
        settings.setdefault("white_center", cfg.white_center)
        settings.setdefault("zone_radius", cfg.zone_radius)
        if loaded.mission == "FOR":
            settings.setdefault("food_centers", ((2.9, 0.0), (-2.9, 0.0)))
            settings.setdefault("food_radius", 0.58)
            settings.setdefault("nest_limit_y", -2.35)
        elif loaded.mission == "FOR2":
            settings.setdefault("food_centers", ((0.8, 0.0), (-0.8, 0.0)))
            settings.setdefault("food_radius", 0.265)
            settings.setdefault("nest_limit_y", -0.63)
        elif loaded.mission == "GRID":
            settings.setdefault("grid_arena_size", 9.65)
            settings.setdefault("grid_size", 10)
        elif loaded.mission == "GRID2":
            settings.setdefault("grid_arena_size", 2.65)
            settings.setdefault("grid_size", 10)
        self.objective: Objective = make_objective(
            loaded.mission,
            self.batch_size,
            cfg.num_agents,
            self.device,
            settings,
        )
        self.episode_steps = (
            int(episode_steps) if episode_steps is not None else int(self.env.max_episode_length)
        )
        if self.episode_steps < 1:
            raise ValueError("episode_steps doit être positif")

    @property
    def num_agents(self) -> int:
        return int(self.cfg.num_agents)

    def _manual_reset(self, candidates: int, repeats: int, *, seed: int) -> None:
        """Reset physics with common initial poses across the candidate group."""

        active = candidates * repeats
        if not 1 <= active <= self.batch_size:
            raise ValueError("Groupe d'évaluation incompatible avec batch_size")
        torch.manual_seed(int(seed))
        if self.device.type == "cuda":
            torch.cuda.manual_seed_all(int(seed))
        base_pos, base_yaw = self.env._sample_argos_spawns(repeats)
        pos = base_pos.repeat(candidates, 1, 1)
        yaw = base_yaw.repeat(candidates, 1)
        padding = self.batch_size - active
        if padding:
            pad_pos, pad_yaw = self.env._sample_argos_spawns(padding)
            pos = torch.cat((pos, pad_pos), dim=0)
            yaw = torch.cat((yaw, pad_yaw), dim=0)
        self.env.agent_pos.copy_(pos)
        self.env.agent_yaw.copy_(yaw)
        self.env._last_module_ids.zero_()
        self.env._cached_wheels.zero_()
        self.env.behavior_modules.reset_state()
        self.env._episode_step = 0
        self.env.episode_length_buf.zero_()
        self.objective.reset()
        self.runtime.reset()

    def _run_group(
        self,
        candidates: Sequence[ChocolateFSM],
        repeats: int,
        *,
        seed: int,
    ) -> torch.Tensor:
        c = len(candidates)
        active = c * int(repeats)
        if c < 1 or repeats < 1 or active > self.batch_size:
            raise ValueError("Taille de groupe invalide")
        padded = [fsm for fsm in candidates for _ in range(repeats)]
        padded.extend([candidates[0]] * (self.batch_size - active))
        self.runtime.load(padded)
        self._manual_reset(c, repeats, seed=seed)
        # Decouple controller randomness from rejection-sampling consumption in
        # the reset. Candidate chunks that share a group seed now receive the
        # same random stream for transitions and behavior-internal sampling.
        controller_seed = int(seed) ^ 0x5DEECE66D
        torch.manual_seed(controller_seed)
        if self.device.type == "cuda":
            torch.cuda.manual_seed_all(controller_seed)

        with torch.no_grad():
            for _ in range(self.episode_steps):
                ground_points = self.env._ground_sensor_points()
                ground = self.objective.ground(ground_points)
                sensors = self.env.sensors.compute_all(
                    self.env.agent_pos,
                    self.env.agent_yaw,
                    self.env.wall_segments,
                    self.env.light_pos,
                )
                step = self.runtime.step(
                    ground,
                    sensors.neighbor_count,
                    common_random_groups=(c, repeats),
                )
                wheels = self.env.behavior_modules.compute(
                    step.module_ids,
                    sensors,
                    exploration_tau=step.exploration_tau,
                    attraction_alpha=step.attraction_alpha,
                    repulsion_alpha=step.repulsion_alpha,
                    state_entry_mask=step.state_entry_mask,
                )
                self.env._last_module_ids.copy_(step.module_ids)
                self.env._cached_wheels.copy_(wheels)
                self.env._integrate()
                self.objective.post_step(self.env.agent_pos)
        return self.objective.score[:active].view(c, repeats).clone()

    def evaluate(
        self,
        candidates: Sequence[ChocolateFSM],
        *,
        episodes_per_candidate: int = 1,
    ) -> EvaluationResult:
        if not candidates:
            raise ValueError("Aucun candidat à évaluer")
        repeats_total = int(episodes_per_candidate)
        if repeats_total < 1:
            raise ValueError("episodes_per_candidate doit être positif")

        rows: list[list[torch.Tensor]] = [[] for _ in candidates]
        repeat_offset = 0
        while repeat_offset < repeats_total:
            # Fill the persistent tensor batch in both dimensions.  The v1
            # scheduler used every remaining repetition at once, which reduced a
            # 32-candidate final validation to one candidate per GPU call.  Here
            # we first reserve room for as many candidates as possible and use
            # the remaining batch dimension for common repetitions.
            candidates_in_full_chunk = min(len(candidates), self.batch_size)
            repeats_for_full_chunk = max(1, self.batch_size // candidates_in_full_chunk)
            repeat_chunk = min(repeats_total - repeat_offset, repeats_for_full_chunk)
            max_candidates = max(1, self.batch_size // repeat_chunk)
            # Reuse the same seed across candidate chunks so candidates see the
            # same initial conditions and controller random numbers for this
            # repetition block (common random numbers).
            group_seed = self.seed + 1_000_003 * self._evaluation_round
            self._evaluation_round += 1
            for start in range(0, len(candidates), max_candidates):
                chunk = candidates[start : start + max_candidates]
                scores = self._run_group(chunk, repeat_chunk, seed=group_seed)
                for local, row in enumerate(scores):
                    rows[start + local].append(row)
            repeat_offset += repeat_chunk

        raw = torch.stack([torch.cat(parts) for parts in rows], dim=0)
        means = raw.mean(dim=1)
        stds = raw.std(dim=1, unbiased=False)
        return EvaluationResult(
            means=means,
            stds=stds,
            raw=raw,
            simulations=len(candidates) * repeats_total,
        )

    def synchronize(self) -> None:
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)

    def close(self) -> None:
        self.env.close()
