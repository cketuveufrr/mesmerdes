"""Configuration loading and mission inference for root-level AutoMoDe."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .bootstrap import prepare_imports


@dataclass(frozen=True)
class LoadedMissionConfig:
    path: Path
    run_name: str
    variant: str
    task: str
    mission: str
    environment: dict[str, Any]


def infer_mission(task: str, path: str | Path = "") -> str:
    joined = f"{task} {Path(path).name}".upper()
    for name in ("AAC2", "FOR2", "GRID2", "AAC", "FOR", "GRID"):
        if name in joined:
            return name
    mapping = {
        "SWARMACB-MERCATORAGGREGATION2-V0": "AAC2",
        "SWARMACB-MERCATORAGGREGATION-V0": "AAC",
        "SWARMACB-MERCATORFORAGING2-V0": "FOR2",
        "SWARMACB-MERCATORFORAGING-V0": "FOR",
        "SWARMACB-MERCATORGRIDEXPLORATION2-V0": "GRID2",
        "SWARMACB-MERCATORGRIDEXPLORATION-V0": "GRID",
    }
    if task.upper() in mapping:
        return mapping[task.upper()]
    raise ValueError(
        f"Mission Mercator inconnue pour task={task!r}, config={str(path)!r}. "
        "Missions supportées: AAC, AAC2, FOR, FOR2, GRID, GRID2."
    )


def load_mission_config(path: str | Path) -> LoadedMissionConfig:
    root = prepare_imports()
    config_path = Path(path)
    if not config_path.is_absolute():
        config_path = root / config_path
    config_path = config_path.resolve()
    if not config_path.is_file():
        raise FileNotFoundError(config_path)
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    behaviors = raw.get("behaviors", raw)
    if not isinstance(behaviors, dict) or not behaviors:
        raise ValueError("Config YAML sans bloc behaviors")
    run_name, block = next(iter(behaviors.items()))
    if not isinstance(block, dict):
        raise ValueError("Bloc behavior invalide")
    variant = str(block.get("variant", "cyclamen"))
    environment = dict(block.get("environment", {}))
    task = str(block.get("task", environment.get("task", "")))
    mission = infer_mission(task, config_path)
    return LoadedMissionConfig(
        path=config_path,
        run_name=str(run_name),
        variant=variant,
        task=task,
        mission=mission,
        environment=environment,
    )


def build_tensor_env_cfg(
    loaded: LoadedMissionConfig,
    *,
    device: str,
    num_envs: int,
    seed: int,
):
    """Build the host ``MercatorTensorEnvCfg`` while retaining mission-only keys."""

    prepare_imports()
    from SwarmACB_isaac.tasks.direct.mercator_light.mercator_profiles import (
        expand_robot_profile_overrides,
    )
    from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
        MercatorTensorEnvCfg,
    )

    environment = expand_robot_profile_overrides(dict(loaded.environment))
    cfg = MercatorTensorEnvCfg(variant=loaded.variant, device=device, seed=int(seed))
    valid: dict[str, Any] = {}
    for key, value in environment.items():
        if key in {"task", "decision_period", "food_centers", "food_radius", "nest_limit_y", "grid_arena_size", "grid_size"}:
            continue
        if key == "num_envs" or key == "sim_dt" or hasattr(cfg, key):
            valid[key] = value
    cfg.apply_overrides(valid)
    # Experiment 2 uses three Mercators; its YAML relies on the Isaac mission
    # subclass default and therefore does not repeat num_agents explicitly.
    if loaded.mission.endswith("2") and "num_agents" not in environment:
        cfg.num_agents = 3
        cfg.update_variant(cfg.variant)
    cfg.scene.num_envs = int(num_envs)
    cfg.seed = int(seed)
    cfg.device = str(device)
    return cfg
