"""Command-line interface for the root-level Mercator AutoMoDe package."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import torch

from .bootstrap import project_root
from .config import load_mission_config
from .evaluator import MercatorAutoMoDeEvaluator
from .fsm import load_fsm_lines, parse_fsm, random_fsm, serialize_fsm
from .optimizer import VectorizedRaceOptimizer


def _default_device() -> str:
    return "cuda:0" if torch.cuda.is_available() else "cpu"


def _load_candidates(args: argparse.Namespace):
    candidates = []
    if getattr(args, "fsm", None):
        candidates.append(parse_fsm(args.fsm))
    if getattr(args, "fsm_file", None):
        path = Path(args.fsm_file)
        if not path.is_absolute():
            path = project_root() / path
        candidates.extend(load_fsm_lines(path.read_text(encoding="utf-8").splitlines()))
    if not candidates:
        raise SystemExit("Fournissez --fsm ou --fsm-file")
    return candidates


def command_design(args: argparse.Namespace) -> int:
    loaded = load_mission_config(args.config)
    output = args.output or (
        project_root() / "results" / "automode" / loaded.mission / f"seed_{args.seed}"
    )
    population = args.population_size or args.batch_size
    evaluator = MercatorAutoMoDeEvaluator(
        loaded,
        device=args.device,
        batch_size=args.batch_size,
        seed=args.seed,
        episode_steps=args.episode_steps,
    )
    try:
        optimizer = VectorizedRaceOptimizer(
            evaluator,
            budget=args.budget,
            population_size=population,
            round_repeats=args.round_repeats,
            survival_rate=args.survival_rate,
            random_fraction=args.random_fraction,
            elite_keep=args.elite_keep,
            mutation_strength=args.mutation_strength,
            validation_budget=args.validation_budget,
            validation_candidates=args.validation_candidates,
            min_validation_episodes=args.min_validation_episodes,
            seed=args.seed,
            output_dir=output,
        )
        result = optimizer.run()
    finally:
        evaluator.close()
    print("\nConception terminée")
    print(f"Mission        : {loaded.mission}")
    print(f"Simulations    : {result.simulations_used}")
    print(f"  recherche    : {result.search_simulations}")
    print(f"  validation   : {result.validation_simulations}")
    print(f"Temps          : {result.elapsed_s:.1f} s")
    print(f"Score validation: {result.best_score:.8g} ± {result.best_std:.5g}")
    print(f"Épisodes best  : {result.best_episodes} (tous les finalistes ont le même n)")
    print(f"Résultats      : {result.output_dir}")
    print(f"FSM            : {serialize_fsm(result.best_fsm)}")
    return 0


def command_evaluate(args: argparse.Namespace) -> int:
    loaded = load_mission_config(args.config)
    candidates = _load_candidates(args)
    evaluator = MercatorAutoMoDeEvaluator(
        loaded,
        device=args.device,
        batch_size=args.batch_size,
        seed=args.seed,
        episode_steps=args.episode_steps,
    )
    try:
        started = time.perf_counter()
        result = evaluator.evaluate(candidates, episodes_per_candidate=args.episodes)
        evaluator.synchronize()
        elapsed = time.perf_counter() - started
    finally:
        evaluator.close()
    means = result.means.cpu().tolist()
    stds = result.stds.cpu().tolist()
    rows = []
    for index, (fsm, mean, std) in enumerate(zip(candidates, means, stds), start=1):
        fsm_text = serialize_fsm(fsm)
        rows.append(
            {
                "index": index,
                "score": float(mean),
                "std": float(std),
                "episodes": int(args.episodes),
                "fsm": fsm_text,
            }
        )
        print(f"{index:4d} score={mean:.8g} std={std:.5g} {fsm_text}")
    print(
        f"{result.simulations} simulations en {elapsed:.3f} s "
        f"({result.simulations / max(elapsed, 1e-12):.2f} simulations/s)"
    )
    if args.output_json:
        output = Path(args.output_json)
        if not output.is_absolute():
            output = project_root() / output
        output.parent.mkdir(parents=True, exist_ok=True)
        arena = evaluator.env._arena_geometry
        payload = {
            "mission": loaded.mission,
            "config": str(loaded.path),
            "device": str(args.device),
            "seed": int(args.seed),
            "episodes_per_fsm": int(args.episodes),
            "simulations": int(result.simulations),
            "elapsed_s": float(elapsed),
            "arena": {
                "fingerprint": str(arena.fingerprint),
                "inradius_m": float(arena.inradius),
                "circumradius_m": float(arena.circumradius),
                "max_wall_center_radius_m": max(
                    (float(x) ** 2 + float(y) ** 2) ** 0.5
                    for x, y in arena.wall_centers
                ),
            },
            "results": rows,
        }
        output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"JSON           : {output}")
    return 0


def command_benchmark(args: argparse.Namespace) -> int:
    import random

    loaded = load_mission_config(args.config)
    for batch_size in args.batch_size:
        evaluator = MercatorAutoMoDeEvaluator(
            loaded,
            device=args.device,
            batch_size=batch_size,
            seed=args.seed,
            episode_steps=args.episode_steps,
        )
        candidates = [random_fsm(random.Random(args.seed + i)) for i in range(batch_size)]
        try:
            evaluator.evaluate(candidates, episodes_per_candidate=1)
            evaluator.synchronize()
            started = time.perf_counter()
            for _ in range(args.rounds):
                evaluator.evaluate(candidates, episodes_per_candidate=1)
            evaluator.synchronize()
            elapsed = time.perf_counter() - started
        finally:
            evaluator.close()
        simulations = batch_size * args.rounds
        ticks = simulations * (args.episode_steps or evaluator.episode_steps)
        print(
            f"batch={batch_size:5d} agents={evaluator.num_agents:2d} "
            f"sim/s={simulations/elapsed:9.3f} ticks-env/s={ticks/elapsed:11.1f} "
            f"elapsed={elapsed:.3f}s"
        )
    return 0


def command_self_test(_: argparse.Namespace) -> int:
    import unittest

    start_dir = Path(__file__).resolve().parent / "tests"
    suite = unittest.defaultTestLoader.discover(str(start_dir), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m automode",
        description="AutoMoDe-Chocolate vectorisé pour le backend tensoriel Mercator.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    design = sub.add_parser("design", help="concevoir automatiquement une FSM Chocolate")
    design.add_argument("--config", required=True)
    design.add_argument("--device", default=_default_device())
    design.add_argument("--batch-size", type=int, default=512)
    design.add_argument("--budget", type=int, default=100_000)
    design.add_argument("--population-size", type=int, default=None)
    design.add_argument("--round-repeats", type=int, nargs="+", default=[1, 2, 4, 8])
    design.add_argument("--survival-rate", type=float, default=0.5)
    design.add_argument("--random-fraction", type=float, default=0.15)
    design.add_argument("--elite-keep", type=int, default=4)
    design.add_argument("--mutation-strength", type=int, default=2)
    design.add_argument(
        "--validation-budget",
        type=int,
        default=20_000,
        help="budget minimum réservé à la validation finale équilibrée",
    )
    design.add_argument(
        "--validation-candidates",
        type=int,
        default=32,
        help="nombre maximal de finalistes réévalués sur exactement les mêmes épisodes",
    )
    design.add_argument(
        "--min-validation-episodes",
        type=int,
        default=50,
        help="minimum d'épisodes indépendants par finaliste",
    )
    design.add_argument("--seed", type=int, default=0)
    design.add_argument("--episode-steps", type=int, default=None, help=argparse.SUPPRESS)
    design.add_argument("--output", default=None)
    design.set_defaults(func=command_design)

    evaluate = sub.add_parser("evaluate", help="évaluer une ou plusieurs FSM")
    evaluate.add_argument("--config", required=True)
    evaluate.add_argument("--fsm")
    evaluate.add_argument("--fsm-file")
    evaluate.add_argument("--episodes", type=int, default=100)
    evaluate.add_argument("--batch-size", type=int, default=512)
    evaluate.add_argument("--device", default=_default_device())
    evaluate.add_argument("--seed", type=int, default=0)
    evaluate.add_argument("--output-json", default=None)
    evaluate.add_argument("--episode-steps", type=int, default=None, help=argparse.SUPPRESS)
    evaluate.set_defaults(func=command_evaluate)

    benchmark = sub.add_parser("benchmark", help="mesurer le runtime FSM complet")
    benchmark.add_argument("--config", required=True)
    benchmark.add_argument("--batch-size", type=int, nargs="+", default=[128, 256, 512, 1024])
    benchmark.add_argument("--device", default=_default_device())
    benchmark.add_argument("--seed", type=int, default=0)
    benchmark.add_argument("--rounds", type=int, default=3)
    benchmark.add_argument("--episode-steps", type=int, default=1200)
    benchmark.set_defaults(func=command_benchmark)

    self_test = sub.add_parser("self-test", help="exécuter les tests intégrés")
    self_test.set_defaults(func=command_self_test)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))
