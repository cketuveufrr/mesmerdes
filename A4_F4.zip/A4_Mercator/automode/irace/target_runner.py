"""One-evaluation target runner for the original irace command-line protocol.

This compatibility runner is intentionally simple and process-based. It is
scientifically useful for reproducing the R/irace outer loop, but it cannot
match the throughput of the native persistent vectorized-race engine because
irace invokes a new target process for each evaluation.
"""

from __future__ import annotations

import os
import sys

from automode.config import load_mission_config
from automode.evaluator import MercatorAutoMoDeEvaluator
from automode.fsm import parse_fsm


def _extract(argv: list[str]) -> tuple[int, str]:
    try:
        option_index = argv.index("--nstates")
    except ValueError as exc:
        raise ValueError("Options FSM absentes: --nstates introuvable") from exc
    prefix = argv[:option_index]
    fsm_text = " ".join(argv[option_index:])
    seed = 0
    # Standard irace target-runner prefix:
    # configuration_id instance_id seed instance [parameters...]
    if len(prefix) >= 3:
        try:
            seed = int(prefix[2])
        except ValueError:
            seed = 0
    return seed, fsm_text


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    config = os.environ.get("AUTOMODE_CONFIG")
    if not config:
        print("AUTOMODE_CONFIG doit pointer vers le YAML de mission", file=sys.stderr)
        return 2
    try:
        seed, fsm_text = _extract(args)
        fsm = parse_fsm(fsm_text, normalize_irace_destinations=True)
        loaded = load_mission_config(config)
        evaluator = MercatorAutoMoDeEvaluator(
            loaded,
            device=os.environ.get("AUTOMODE_DEVICE", "cpu"),
            batch_size=1,
            seed=seed,
            episode_steps=(
                int(os.environ["AUTOMODE_EPISODE_STEPS"])
                if os.environ.get("AUTOMODE_EPISODE_STEPS")
                else None
            ),
        )
        try:
            result = evaluator.evaluate([fsm], episodes_per_candidate=1)
            evaluator.synchronize()
            score = float(result.means.item())
        finally:
            evaluator.close()
        # irace minimizes; the Mercator paper objectives are maximized.
        print(f"{-score:.17g}")
        return 0
    except Exception as exc:
        print(f"AutoMoDe target-runner error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
