"""Compatibility helpers for the original R/irace AutoMoDe outer loop."""
