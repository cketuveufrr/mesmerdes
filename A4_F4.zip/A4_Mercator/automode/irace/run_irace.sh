#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  automode/irace/run_irace.sh CONFIG OUTPUT_DIR [BUDGET] [SEED] [DEVICE]

Exemple:
  automode/irace/run_irace.sh \
    configs/mercator/AAC_mercator_cyclamen.yaml \
    results/automode/irace/AAC 100000 1234 cuda:0
EOF
}

if [[ $# -lt 2 || $# -gt 5 ]]; then
  usage >&2
  exit 2
fi
if ! command -v irace >/dev/null 2>&1; then
  echo "Erreur: la commande irace n'est pas installée ou absente du PATH." >&2
  exit 127
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CONFIG="$1"
OUTPUT="$2"
BUDGET="${3:-100000}"
SEED="${4:-1234}"
DEVICE="${5:-cuda:0}"

cd "$ROOT"
mkdir -p "$OUTPUT"
OUTPUT="$(cd "$OUTPUT" && pwd)"
if [[ "$CONFIG" != /* ]]; then
  CONFIG="$ROOT/$CONFIG"
fi
export AUTOMODE_CONFIG="$CONFIG"
export AUTOMODE_DEVICE="$DEVICE"

python -m automode.irace.generate \
  --parameters "$OUTPUT/parameters.txt" \
  --scenario "$OUTPUT/scenario.txt" \
  --runner "$ROOT/automode/irace/target_runner.sh" \
  --log "$OUTPUT/irace.Rdata" \
  --budget "$BUDGET"

exec irace --exec-dir="$OUTPUT" --seed "$SEED" --scenario "$OUTPUT/scenario.txt"
