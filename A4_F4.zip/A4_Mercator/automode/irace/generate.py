"""Generate an irace grammar adapted to the six-module Mercator RM 1.2 setup."""

from __future__ import annotations

import argparse
from pathlib import Path

from automode.fsm import MAX_STATES, MAX_TRANSITIONS


def generate_parameter_file(max_states: int = MAX_STATES, max_transitions: int = MAX_TRANSITIONS) -> str:
    if not 1 <= max_states <= MAX_STATES:
        raise ValueError(f"max_states doit être dans [1,{MAX_STATES}]")
    if not 1 <= max_transitions <= MAX_TRANSITIONS:
        raise ValueError(f"max_transitions doit être dans [1,{MAX_TRANSITIONS}]")
    lines = [f'NumStates "--nstates " i (1,{max_states})']
    for state in range(max_states):
        exists = f"as.numeric(NumStates)>{state}"
        lines.append(f'S{state} "--s{state} " c (0,1,2,3,4,5) | {exists}')
        lines.append(f'RWM{state} "--rwm{state} " i (1,100) | as.numeric(S{state})==0')
        lines.append(f'ATT{state} "--att{state} " r (1,5) | as.numeric(S{state})==4')
        lines.append(f'REP{state} "--rep{state} " r (1,5) | as.numeric(S{state})==5')
        lines.append(
            f'NumConnections{state} "--n{state} " i (1,{max_transitions}) | '
            f'as.numeric(NumStates)>1 && {exists}'
        )
        for transition in range(max_transitions):
            enabled = (
                f"as.numeric(NumStates)>1 && {exists} && "
                f"as.numeric(NumConnections{state})>{transition}"
            )
            prefix = f"{state}x{transition}"
            # The original generator uses (0,3) even when fewer states exist.
            # target_runner normalizes this destination option modulo the actual
            # number of valid destination states.
            lines.append(f'N{prefix} "--n{prefix} " i (0,{max_states - 1}) | {enabled}')
            lines.append(f'C{prefix} "--c{prefix} " c (0,1,2,3,4,5) | {enabled}')
            lines.append(
                f'P{prefix} "--p{prefix} " r (0,1) | {enabled} && '
                f'as.numeric(C{prefix}) %in% c(0,1,2,5)'
            )
            lines.append(
                f'B{prefix} "--p{prefix} " i (1,10) | {enabled} && as.numeric(C{prefix})==3'
            )
            lines.append(
                f'W{prefix} "--w{prefix} " r (0,20) | {enabled} && as.numeric(C{prefix})==3'
            )
            lines.append(
                f'BI{prefix} "--p{prefix} " i (1,10) | {enabled} && as.numeric(C{prefix})==4'
            )
            lines.append(
                f'WI{prefix} "--w{prefix} " r (0,20) | {enabled} && as.numeric(C{prefix})==4'
            )
    return "\n".join(lines) + "\n"


def generate_scenario(parameter_file: Path, target_runner: Path, budget: int, log_file: Path) -> str:
    if budget < 1:
        raise ValueError("budget doit être positif")
    return "\n".join(
        (
            f'targetRunner = "{target_runner}"',
            f'parameterFile = "{parameter_file}"',
            f'maxExperiments = {int(budget)}',
            f'logFile = "{log_file}"',
            "debugLevel = 0",
            "",
        )
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parameters", required=True)
    parser.add_argument("--scenario", required=True)
    parser.add_argument("--runner", required=True)
    parser.add_argument("--log", required=True)
    parser.add_argument("--budget", type=int, default=100_000)
    args = parser.parse_args(argv)
    parameter_path = Path(args.parameters).resolve()
    scenario_path = Path(args.scenario).resolve()
    runner_path = Path(args.runner).resolve()
    log_path = Path(args.log).resolve()
    parameter_path.parent.mkdir(parents=True, exist_ok=True)
    scenario_path.parent.mkdir(parents=True, exist_ok=True)
    parameter_path.write_text(generate_parameter_file(), encoding="utf-8")
    scenario_path.write_text(
        generate_scenario(parameter_path, runner_path, args.budget, log_path),
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
