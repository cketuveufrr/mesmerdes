"""Locate and import the host A4_Mercator project without Isaac Sim."""

from __future__ import annotations

import os
from pathlib import Path
import sys


def project_root() -> Path:
    """Return the repository root containing ``source/SwarmACB_isaac``.

    The ``automode`` folder is intended to be copied directly into that root.
    ``AUTOMODE_PROJECT_ROOT`` can override discovery for tests or custom layouts.
    """

    override = os.environ.get("AUTOMODE_PROJECT_ROOT")
    candidates: list[Path] = []
    if override:
        candidates.append(Path(override).expanduser().resolve())
    here = Path(__file__).resolve()
    candidates.extend([here.parent.parent, Path.cwd().resolve()])
    for candidate in candidates:
        marker = candidate / "source" / "SwarmACB_isaac" / "SwarmACB_isaac"
        if marker.is_dir():
            return candidate
    searched = ", ".join(str(path) for path in candidates)
    raise RuntimeError(
        "Impossible de trouver la racine A4_Mercator. Placez le dossier "
        f"automode à la racine du projet ou définissez AUTOMODE_PROJECT_ROOT. "
        f"Chemins testés: {searched}"
    )


def prepare_imports() -> Path:
    """Disable Isaac task registration and prepend the local package path."""

    root = project_root()
    os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")
    source = root / "source" / "SwarmACB_isaac"
    source_str = str(source)
    if source_str not in sys.path:
        sys.path.insert(0, source_str)
    root_str = str(root)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)
    return root
