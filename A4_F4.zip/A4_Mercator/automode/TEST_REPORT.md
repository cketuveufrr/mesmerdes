# Rapport de validation - AutoMoDe Mercator 0.2

Date : 2026-07-20

Environnement interne :

```text
Python 3.13.5
PyTorch 2.10.0+cpu
PyYAML 6.0.3
CUDA disponible : non
```

## Défaut corrigé

La version précédente pouvait consacrer le reliquat du budget à une génération incomplète puis sélectionner une FSM observée une seule fois. La correction interdit toute génération partielle et choisit le résultat final sur une validation équilibrée avec de nouveaux épisodes.

## Invariants testés

### Budget et générations

- Une génération est complète ou absente.
- Le coût exact d'une génération est calculé avant son lancement.
- Le budget total est consommé exactement.
- Le reliquat ne peut pas influencer le classement final.
- Une configuration qui ne permet pas une génération complète plus la validation est refusée.

### Validation finale

- Tous les finalistes comparés ont exactement le même nombre d'épisodes.
- `best_fsm.txt` vient exclusivement du classement de validation.
- `best_episodes` est le nombre d'épisodes de validation, pas le nombre d'épisodes d'une génération tronquée.
- Le planificateur cherche un diviseur du budget restant afin d'éviter un reliquat.

### Ordonnancement tensoriel

Le planificateur remplit le batch sur les deux dimensions : candidats et répétitions. Exemple testé : un batch de 16, quatre candidats et dix épisodes produit des appels `4x4`, `4x4`, puis `4x2`, au lieu d'évaluer les candidats un par un.

### FSM et runtime

- Les 60 FSM de référence des six fichiers `configs/mercator/fsms/*.txt` sont parsées par le nouveau parseur puis par `scripts/mercator_chocolate_fsm.py`.
- 5 000 cycles aléatoires de génération, mutation, sérialisation et reparsing ont réussi.
- La sémantique du tick d'entrée est vérifiée.
- Les paramètres `rwm`, `att` et `rep` sont vérifiés.
- Le runtime hétérogène est comparé au runtime Chocolate existant sur une FSM déterministe.
- Le partage des tirages aléatoires entre répétitions communes est vérifié.

### Objectifs

- Agrégation : géométrie des zones et accumulation du nombre de robots sur la zone noire.
- Foraging Expériences 1 et 2 : sol, portage et livraison comparés aux modèles de référence du projet.
- Grid Exploration Expériences 1 et 2 : âges et récompense comparés aux fonctions de référence.

### Intégration

- Les six configurations sont chargées.
- Un court épisode tensoriel est exécuté sur les missions Expérience 2.
- Une conception complète CPU de test consomme exactement 25 simulations : 16 de recherche et 9 de validation.
- Les fichiers `validation_results.json` et `validation_fsms.txt` sont créés.

## Commande et résultat

```bash
python -m automode self-test
```

Résultat obtenu :

```text
Ran 20 tests in 13.817s
OK
```

## Test CLI de bout en bout

La commande suivante est utilisée comme test d'installation rapide :

```bash
python -m automode design \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --device cpu \
  --batch-size 8 \
  --population-size 8 \
  --budget 25 \
  --round-repeats 1 2 \
  --validation-budget 9 \
  --validation-candidates 3 \
  --min-validation-episodes 1 \
  --episode-steps 2 \
  --seed 7 \
  --output /tmp/automode_v2_smoke
```

Attendus vérifiés :

```text
simulations_used = 25
search_simulations = 16
validation_simulations = 9
validation_candidates = 2
validation_episodes_per_candidate = 4
best_episodes = 4
algorithm = vectorized-race-v2-balanced-validation
```

Le neuvième épisode de validation éventuel est consommé après sélection et ne modifie pas le gagnant.


## Test intégral du plan AAC2 à 100 000 simulations

Le moteur a également été exécuté de bout en bout avec le plan réel AAC2, en remplaçant seulement la simulation physique par un évaluateur déterministe rapide. Ce test exerce la génération, les mutations, l’archive, les dix-neuf générations, la validation finale et tous les fichiers de sortie.

Résultat vérifié :

```text
simulations_used                 100000
search_simulations               77824
validation_simulations           22176
generations                      19
generation_cost                  4096
validation_candidates            32
validation_episodes_per_candidate 693
validation_tail                  0
best_episodes                    693
```

Les 32 entrées de `validation_results.json` possèdent toutes exactement 693 épisodes. Le test a duré 23,21 s hors simulation physique.

Le planificateur de l’évaluateur a aussi été vérifié spécifiquement pour `32 x 693` : il effectue 21 appels pleins de `32 x 32` épisodes, puis un appel de `32 x 21`, sans évaluation candidat par candidat.

## Limites de la validation interne

Le conteneur ne possède pas de GPU CUDA. Le code CUDA ne peut donc pas être exécuté ici. Les tests utilisent le même chemin tensoriel PyTorch sur CPU, et le script de campagne lance avant toute optimisation un contrôle GPU des dix FSM AAC2 de référence.

Une évaluation CPU complète de dix FSM sur 1 200 ticks a été tentée mais n'était pas praticable dans le temps du conteneur. Ce contrôle est donc explicitement délégué à la machine cible, où le benchmark communiqué atteint plusieurs centaines de simulations par seconde.

Le moteur natif n'est pas R/irace. Il respecte l'espace de contrôleurs et les contraintes de budget, mais doit être décrit comme `vectorized-race-v2-balanced-validation` dans toute publication.

## 0.3.0 geometry regression

The first GPU sanity run of 0.2.0 exposed a host-backend bug: AAC2 inherited the
Experiment-1 wall-centre coordinates (inradius about 4.7907 m) while only the
wall length was overridden to 0.70 m. The supplied AAC2 FSMs consequently
scored only 313--616 over 256 episodes. Version 0.3.0 installs the exact
Experiment-2 wall centres before every evaluated reset.

Validated invariants:

- Experiment-2 inradius: 1.3073000000 m;
- Experiment-2 circumradius: 1.3550846413 m;
- exact arena fingerprint:
  e680c08510fafc04f5bcbb02bb1df3ff26ccc23b07a12fc9587ed33c6731cfcf;
- AAC/AAC2 geometry separation;
- all six mission evaluator constructors;
- 23 unit/integration tests;
- CLI JSON arena metadata;
- full campaign dry-run with ten concurrent seeds.
