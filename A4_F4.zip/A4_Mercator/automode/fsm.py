"""AutoMoDe-Chocolate finite-state-machine representation and search operators.

The command-line serialization is compatible with the parser already shipped in
``scripts/mercator_chocolate_fsm.py``. Mercator module IDs are:

0 exploration, 1 stop, 2 phototaxis, 3 anti-phototaxis,
4 attraction, 5 repulsion.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import math
import random
import shlex
from typing import Iterable, Sequence

MODULE_NAMES = {
    0: "exploration",
    1: "stop",
    2: "phototaxis",
    3: "anti_phototaxis",
    4: "attraction",
    5: "repulsion",
}
CONDITION_NAMES = {
    0: "black_floor",
    1: "gray_floor",
    2: "white_floor",
    3: "neighbors_count",
    4: "inverted_neighbors_count",
    5: "fixed_probability",
}
MAX_STATES = 4
MAX_TRANSITIONS = 4


@dataclass(frozen=True)
class Transition:
    destination: int
    condition_id: int
    p: float
    w: float | None = None

    def validate(self, num_states: int, source: int) -> None:
        if not 0 <= self.destination < num_states or self.destination == source:
            raise ValueError(
                f"Destination invalide S{source}->S{self.destination} pour {num_states} états"
            )
        if self.condition_id not in CONDITION_NAMES:
            raise ValueError(f"Condition inconnue: {self.condition_id}")
        if self.condition_id in (3, 4):
            if self.w is None:
                raise ValueError("Les conditions de voisinage exigent w")
            if not 1 <= int(self.p) <= 10:
                raise ValueError("Le seuil de voisinage p doit être dans [1,10]")
            if not 0.0 <= float(self.w) <= 20.0:
                raise ValueError("w doit être dans [0,20]")
        elif not 0.0 <= float(self.p) <= 1.0:
            raise ValueError("Une probabilité p doit être dans [0,1]")


@dataclass(frozen=True)
class State:
    module_id: int
    parameter: float | None
    transitions: tuple[Transition, ...]

    def validate(self, index: int, num_states: int) -> None:
        if self.module_id not in MODULE_NAMES:
            raise ValueError(f"Module inconnu: {self.module_id}")
        if self.module_id == 0:
            if self.parameter is None or not 1 <= int(self.parameter) <= 100:
                raise ValueError("Exploration exige rwm dans [1,100]")
        elif self.module_id in (4, 5):
            if self.parameter is None or not 1.0 <= float(self.parameter) <= 5.0:
                raise ValueError("Attraction/répulsion exige un paramètre dans [1,5]")
        elif self.parameter is not None:
            raise ValueError("Ce module ne prend pas de paramètre")
        expected_min = 0 if num_states == 1 else 1
        if not expected_min <= len(self.transitions) <= MAX_TRANSITIONS:
            raise ValueError(
                f"S{index}: nombre de transitions {len(self.transitions)} invalide"
            )
        for transition in self.transitions:
            transition.validate(num_states, index)


@dataclass(frozen=True)
class ChocolateFSM:
    states: tuple[State, ...]

    def validate(self) -> "ChocolateFSM":
        if not 1 <= len(self.states) <= MAX_STATES:
            raise ValueError(f"Le nombre d'états doit être dans [1,{MAX_STATES}]")
        for index, state in enumerate(self.states):
            state.validate(index, len(self.states))
        return self

    @property
    def num_states(self) -> int:
        return len(self.states)

    def to_string(self) -> str:
        return serialize_fsm(self)

    def complexity(self) -> tuple[int, int]:
        return self.num_states, sum(len(state.transitions) for state in self.states)


def _option_map(text: str) -> dict[str, str]:
    tokens = shlex.split(text.strip())
    if len(tokens) % 2:
        raise ValueError("La FSM doit contenir des paires --clé valeur")
    values: dict[str, str] = {}
    for key, value in zip(tokens[0::2], tokens[1::2]):
        if not key.startswith("--"):
            raise ValueError(f"Option attendue, reçu {key!r}")
        clean = key[2:]
        if clean in values:
            raise ValueError(f"Option dupliquée --{clean}")
        values[clean] = value
    return values


def parse_fsm(text: str, *, normalize_irace_destinations: bool = False) -> ChocolateFSM:
    values = _option_map(text)
    try:
        num_states = int(float(values["nstates"]))
    except KeyError as exc:
        raise ValueError("Option --nstates absente") from exc
    if not 1 <= num_states <= MAX_STATES:
        raise ValueError(f"Nombre d'états invalide: {num_states}")

    states: list[State] = []
    for state_index in range(num_states):
        module_id = int(float(values[f"s{state_index}"]))
        parameter: float | None = None
        if module_id == 0:
            parameter = float(int(float(values[f"rwm{state_index}"])))
        elif module_id == 4:
            parameter = float(values[f"att{state_index}"])
        elif module_id == 5:
            parameter = float(values[f"rep{state_index}"])

        transition_count = int(float(values.get(f"n{state_index}", "0")))
        transitions: list[Transition] = []
        destinations = [idx for idx in range(num_states) if idx != state_index]
        if num_states == 1 and transition_count:
            raise ValueError("Une FSM à un état ne peut pas avoir de transition")
        for transition_index in range(transition_count):
            prefix = f"{state_index}x{transition_index}"
            option = int(float(values[f"n{prefix}"]))
            if normalize_irace_destinations and destinations:
                option %= len(destinations)
            if not 0 <= option < len(destinations):
                raise ValueError(
                    f"Destination option {option} invalide pour S{state_index}"
                )
            condition = int(float(values[f"c{prefix}"]))
            p = float(values[f"p{prefix}"])
            w = float(values[f"w{prefix}"]) if f"w{prefix}" in values else None
            transitions.append(Transition(destinations[option], condition, p, w))
        states.append(State(module_id, parameter, tuple(transitions)))
    return ChocolateFSM(tuple(states)).validate()


def _fmt(value: float) -> str:
    if math.isclose(value, round(value), rel_tol=0.0, abs_tol=1e-12):
        return str(int(round(value)))
    return format(float(value), ".17g")


def serialize_fsm(fsm: ChocolateFSM) -> str:
    fsm.validate()
    parts = ["--nstates", str(fsm.num_states)]
    for state_index, state in enumerate(fsm.states):
        parts.extend((f"--s{state_index}", str(state.module_id)))
        if state.module_id == 0:
            parts.extend((f"--rwm{state_index}", str(int(state.parameter))))
        elif state.module_id == 4:
            parts.extend((f"--att{state_index}", _fmt(float(state.parameter))))
        elif state.module_id == 5:
            parts.extend((f"--rep{state_index}", _fmt(float(state.parameter))))
        if fsm.num_states > 1:
            parts.extend((f"--n{state_index}", str(len(state.transitions))))
        destinations = [idx for idx in range(fsm.num_states) if idx != state_index]
        for transition_index, transition in enumerate(state.transitions):
            prefix = f"{state_index}x{transition_index}"
            parts.extend((f"--n{prefix}", str(destinations.index(transition.destination))))
            parts.extend((f"--c{prefix}", str(transition.condition_id)))
            parts.extend((f"--p{prefix}", _fmt(transition.p)))
            if transition.condition_id in (3, 4):
                assert transition.w is not None
                parts.extend((f"--w{prefix}", _fmt(transition.w)))
    return " ".join(parts)


def _random_parameter(module_id: int, rng: random.Random) -> float | None:
    if module_id == 0:
        return float(rng.randint(1, 100))
    if module_id in (4, 5):
        return rng.uniform(1.0, 5.0)
    return None


def random_transition(source: int, num_states: int, rng: random.Random) -> Transition:
    destinations = [idx for idx in range(num_states) if idx != source]
    condition = rng.randrange(6)
    destination = rng.choice(destinations)
    if condition in (3, 4):
        return Transition(destination, condition, float(rng.randint(1, 10)), rng.uniform(0.0, 20.0))
    return Transition(destination, condition, rng.random(), None)


def random_fsm(rng: random.Random) -> ChocolateFSM:
    num_states = rng.randint(1, MAX_STATES)
    states: list[State] = []
    for source in range(num_states):
        module = rng.randrange(6)
        count = 0 if num_states == 1 else rng.randint(1, MAX_TRANSITIONS)
        transitions = tuple(random_transition(source, num_states, rng) for _ in range(count))
        states.append(State(module, _random_parameter(module, rng), transitions))
    return ChocolateFSM(tuple(states)).validate()


def _remap_after_state_removal(
    transition: Transition, source_old: int, removed: int, num_states_new: int, rng: random.Random
) -> Transition:
    source_new = source_old - (1 if source_old > removed else 0)
    destination = transition.destination
    if destination == removed:
        choices = [idx for idx in range(num_states_new) if idx != source_new]
        destination_new = rng.choice(choices)
    else:
        destination_new = destination - (1 if destination > removed else 0)
        if destination_new == source_new:
            choices = [idx for idx in range(num_states_new) if idx != source_new]
            destination_new = rng.choice(choices)
    return replace(transition, destination=destination_new)


def mutate_fsm(parent: ChocolateFSM, rng: random.Random, strength: int = 1) -> ChocolateFSM:
    """Return a valid structural/parametric mutation of ``parent``.

    Multiple elementary mutations are allowed because irace samples globally,
    while a local evolutionary search otherwise changes topology too slowly.
    """

    candidate = parent
    for _ in range(max(1, int(strength))):
        operations = ["module", "parameter", "transition", "add_transition", "remove_transition"]
        if candidate.num_states < MAX_STATES:
            operations.append("add_state")
        if candidate.num_states > 1:
            operations.append("remove_state")
        operation = rng.choice(operations)
        states = list(candidate.states)

        if operation == "module":
            index = rng.randrange(candidate.num_states)
            old = states[index]
            module = rng.choice([value for value in MODULE_NAMES if value != old.module_id])
            states[index] = replace(old, module_id=module, parameter=_random_parameter(module, rng))

        elif operation == "parameter":
            eligible = [i for i, state in enumerate(states) if state.module_id in (0, 4, 5)]
            if eligible:
                index = rng.choice(eligible)
                states[index] = replace(
                    states[index], parameter=_random_parameter(states[index].module_id, rng)
                )
            else:
                continue

        elif operation == "transition" and candidate.num_states > 1:
            source = rng.randrange(candidate.num_states)
            transitions = list(states[source].transitions)
            transition_index = rng.randrange(len(transitions))
            mode = rng.choice(("destination", "condition", "p", "w"))
            transition = transitions[transition_index]
            if mode == "destination":
                choices = [idx for idx in range(candidate.num_states) if idx != source]
                transition = replace(transition, destination=rng.choice(choices))
            elif mode == "condition":
                condition = rng.randrange(6)
                transition = (
                    Transition(transition.destination, condition, float(rng.randint(1, 10)), rng.uniform(0.0, 20.0))
                    if condition in (3, 4)
                    else Transition(transition.destination, condition, rng.random(), None)
                )
            elif mode == "p":
                transition = replace(
                    transition,
                    p=float(rng.randint(1, 10)) if transition.condition_id in (3, 4) else rng.random(),
                )
            elif transition.condition_id in (3, 4):
                transition = replace(transition, w=rng.uniform(0.0, 20.0))
            else:
                continue
            transitions[transition_index] = transition
            states[source] = replace(states[source], transitions=tuple(transitions))

        elif operation == "add_transition" and candidate.num_states > 1:
            eligible = [i for i, state in enumerate(states) if len(state.transitions) < MAX_TRANSITIONS]
            if not eligible:
                continue
            source = rng.choice(eligible)
            states[source] = replace(
                states[source],
                transitions=states[source].transitions + (random_transition(source, candidate.num_states, rng),),
            )

        elif operation == "remove_transition" and candidate.num_states > 1:
            eligible = [i for i, state in enumerate(states) if len(state.transitions) > 1]
            if not eligible:
                continue
            source = rng.choice(eligible)
            transitions = list(states[source].transitions)
            transitions.pop(rng.randrange(len(transitions)))
            states[source] = replace(states[source], transitions=tuple(transitions))

        elif operation == "add_state":
            old_num_states = candidate.num_states
            new_index = old_num_states
            module = rng.randrange(6)
            if old_num_states == 1:
                # The formerly transition-less singleton must become connected.
                states[0] = replace(
                    states[0],
                    transitions=(random_transition(0, 2, rng),),
                )
            new_state = State(
                module,
                _random_parameter(module, rng),
                (random_transition(new_index, old_num_states + 1, rng),),
            )
            # Existing destinations remain valid because the new state is appended.
            states.append(new_state)

        elif operation == "remove_state":
            removed = rng.randrange(candidate.num_states)
            new_num_states = candidate.num_states - 1
            new_states: list[State] = []
            for source_old, state in enumerate(states):
                if source_old == removed:
                    continue
                if new_num_states == 1:
                    remapped = ()
                else:
                    remapped = tuple(
                        _remap_after_state_removal(
                            transition, source_old, removed, new_num_states, rng
                        )
                        for transition in state.transitions
                    )
                new_states.append(replace(state, transitions=remapped))
            states = new_states

        candidate = ChocolateFSM(tuple(states)).validate()
    return candidate


def unique_fsms(fsms: Iterable[ChocolateFSM]) -> list[ChocolateFSM]:
    seen: set[str] = set()
    result: list[ChocolateFSM] = []
    for fsm in fsms:
        key = serialize_fsm(fsm)
        if key not in seen:
            seen.add(key)
            result.append(fsm)
    return result


def load_fsm_lines(lines: Sequence[str]) -> list[ChocolateFSM]:
    return [
        parse_fsm(line)
        for line in lines
        if line.strip() and not line.lstrip().startswith("#")
    ]
