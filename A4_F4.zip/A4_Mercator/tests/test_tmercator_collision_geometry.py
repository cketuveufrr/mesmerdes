from __future__ import annotations

import importlib.util
from pathlib import Path
import subprocess
import sys
import types

import torch


ROOT = Path(__file__).resolve().parents[1]
DIRECT = ROOT / "source" / "SwarmACB_isaac" / "SwarmACB_isaac" / "tasks" / "direct"
LIGHT = DIRECT / "mercator_light"


def ensure_package(name: str, path: Path) -> None:
    if name in sys.modules:
        return
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    sys.modules[name] = module


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_light_modules():
    for name, path in {
        "SwarmACB_isaac": DIRECT.parents[2],
        "SwarmACB_isaac.tasks": DIRECT.parents[1],
        "SwarmACB_isaac.tasks.direct": DIRECT,
        "SwarmACB_isaac.tasks.direct.mercator_light": LIGHT,
    }.items():
        ensure_package(name, path)
    modules = {}
    for short in (
        "arena_geometry",
        "argos_spawn",
        "mercator_geometry",
        "mercator_sensors",
        "mercator_behavior_modules",
        "mercator_tensor_env",
    ):
        modules[short] = load_module(
            f"SwarmACB_isaac.tasks.direct.mercator_light.{short}_tmercator_test",
            LIGHT / f"{short}.py",
        )
        # Relative imports expect the canonical module name.
        sys.modules[f"SwarmACB_isaac.tasks.direct.mercator_light.{short}"] = modules[short]
    return modules


def test_circle_ray_and_pairwise_collision_are_exact():
    geometry = load_module("tmercator_geometry_under_test", LIGHT / "mercator_geometry.py")
    origins = torch.tensor([[[[0.0, 0.0]]]])
    directions = torch.tensor([[[[1.0, 0.0]]]])
    centers = torch.tensor([[[[1.0, 0.0]]]])
    distance = geometry.ray_circle_distances(origins, directions, centers, 0.105, 2.0)
    torch.testing.assert_close(distance, torch.tensor([[[0.8950]]]), atol=1e-6, rtol=0.0)

    positions = torch.tensor([[[0.0, 0.0], [0.15, 0.0]]])
    corrected = geometry.resolve_pairwise_circle_collisions(positions, 0.105, iterations=1)
    separation = torch.linalg.vector_norm(corrected[:, 1] - corrected[:, 0], dim=-1)
    torch.testing.assert_close(separation, torch.tensor([0.2100]), atol=1e-6, rtol=0.0)
    torch.testing.assert_close(corrected.mean(dim=1), positions.mean(dim=1))


def test_circle_wall_and_spawn_predicates_use_the_ring_radius():
    geometry = load_module("tmercator_geometry_wall_test", LIGHT / "mercator_geometry.py")
    normals = torch.tensor(((1.0, 0.0), (-1.0, 0.0), (0.0, 1.0), (0.0, -1.0)))
    offsets = torch.ones(4)
    candidate = torch.tensor(((0.8949, 0.0), (0.8951, 0.0)))
    inside = geometry.circles_inside_walls(candidate, normals, offsets, 0.105)
    assert inside.tolist() == [True, False]

    existing = torch.tensor([[[0.0, 0.0]], [[0.0, 0.0]]])
    candidates = torch.tensor([[0.2099, 0.0], [0.2101, 0.0]])
    overlap = geometry.candidate_circle_overlaps_existing(candidates, existing, 0.105)
    assert overlap.tolist() == [True, False]


def test_tensor_backend_runs_tmercator_circle_profile_on_cpu():
    modules = load_light_modules()
    tensor = modules["mercator_tensor_env"]
    cfg = tensor.MercatorTensorEnvCfg()
    cfg.device = "cpu"
    cfg.num_agents = 3
    cfg.scene.num_envs = 2
    cfg.apply_overrides(
        {
            "num_envs": 2,
            "robot_profile": "tmercator",
            "robot_length": 0.216,
            "robot_width": 0.185,
            "robot_height": 0.170,
            "robot_base_height": 0.114,
            "collision_shape": "circle",
            "collision_radius": 0.105,
            "collision_ring_radius": 0.105,
            "collision_ring_height": 0.056,
            "collision_ring_thickness": 0.010,
            "lidar_height": 0.140,
            "ground_sensor_offset": [0.05, 0.0],
            "wheelbase": 0.147,
            "teraranger_layout": "uniform_ring",
            "teraranger_ring_radius": 0.105,
            "teraranger_origin_offset": 0.0,
        }
    )
    env = tensor.MercatorTensorEnv(cfg)
    try:
        observations, _ = env.reset_tensor(seed=11)
        assert observations.shape == (2, 3, 2)
        assert env.collision_shape == "circle"
        assert env.collision_radius == 0.105
        distances = torch.cdist(env.agent_pos, env.agent_pos)
        distances += torch.eye(3).unsqueeze(0) * 10.0
        assert float(distances.min()) >= 0.2100 - 1e-5

        actions = torch.zeros((2, 3, 1), dtype=torch.long)
        observations, reward, terminated, truncated, _ = env.step_tensor(actions)
        assert observations.shape == (2, 3, 2)
        assert reward.shape == terminated.shape == truncated.shape == (2,)
    finally:
        env.close()


def test_launch_dry_run_routes_all_three_controller_modes():
    launcher = ROOT / "scripts" / "launch.py"
    fsm = subprocess.run(
        [
            sys.executable,
            str(launcher),
            "--mission", "AAC2",
            "--profile", "tmercator",
            "--fsm-index", "2",
            "--dry-run",
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    assert "scripts/mercator_fsm.py" in fsm
    assert "AAC2_tmercator_cyclamen.yaml" in fsm
    assert "--color-by module" in fsm

    module = subprocess.run(
        [
            sys.executable,
            str(launcher),
            "--mission", "FOR",
            "--profile", "tmercator",
            "--module", "attraction",
            "--dry-run",
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    assert "scripts/visualize_mercator.py" in module
    assert "--module 4" in module

    checkpoint_path = ROOT / "tests" / "_dummy_launch_checkpoint.pt"
    checkpoint_path.touch()
    try:
        checkpoint = subprocess.run(
            [
                sys.executable,
                str(launcher),
                "--mission", "GRID",
                "--profile", "tmercator",
                "--checkpoint", str(checkpoint_path),
                "--deterministic",
                "--dry-run",
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        ).stdout
    finally:
        checkpoint_path.unlink(missing_ok=True)
    assert "scripts/visualize_mercator.py" in checkpoint
    assert f"--checkpoint {checkpoint_path}" in checkpoint
    assert "--deterministic" in checkpoint

    score = subprocess.run(
        [
            sys.executable,
            str(launcher),
            "--mission", "GRID2",
            "--profile", "mercator",
            "--score",
            "--all-fsms",
            "--episodes", "3",
            "--num-envs", "2",
            "--dry-run",
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    assert "scripts/mercator_fsm.py" in score
    assert "--score --all-fsms --episodes 3 --num-envs 2" in score
