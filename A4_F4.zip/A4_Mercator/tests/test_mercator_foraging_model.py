from __future__ import annotations

import importlib.util
import math
from pathlib import Path
import random
import sys

import torch

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
    / "missions"
    / "mercator_foraging"
    / "mercator_foraging_model.py"
)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


model = load_module("mercator_foraging_model_under_test", MODEL_PATH)

SOURCE_NEST_POLYGON = (
    (-4.1662, -2.35),
    (4.1662, -2.35),
    (3.5237, -2.35 - math.sin(math.radians(60.0)) * 2.57 / 2.0 - 0.01),
    (1.295, -4.7957),
    (-1.295, -4.7957),
    (-3.5237, -2.35 - math.sin(math.radians(60.0)) * 2.57 / 2.0 - 0.01),
)


def source_triangle_contains(q, a, b, c) -> bool:
    def area(p1, p2, p3):
        return abs(
            p1[0] * (p2[1] - p3[1])
            + p2[0] * (p3[1] - p1[1])
            + p3[0] * (p1[1] - p2[1])
        ) / 2.0

    reference = area(a, b, c)
    parts = area(a, b, q) + area(a, c, q) + area(b, c, q)
    return abs(reference - parts) < 0.0001


def source_floor_value(point) -> float:
    x, y = point
    if math.dist((x, y), (2.9, 0.0)) <= 0.58:
        return 0.0
    if math.dist((x, y), (-2.9, 0.0)) <= 0.58:
        return 0.0
    if y < -2.35:
        bottom, top, angle1, angle2, angle3, angle4 = SOURCE_NEST_POLYGON
        center = (0.0, -2.35)
        white = (
            source_triangle_contains(point, center, top, angle1)
            or source_triangle_contains(point, center, angle2, angle3)
            or source_triangle_contains(point, center, angle1, angle2)
            or source_triangle_contains(point, center, angle3, angle4)
            or source_triangle_contains(point, center, angle4, bottom)
        )
        if white:
            return 1.0
    return 0.5


def test_source_constants_are_exact():
    assert model.FOOD_CENTERS == ((2.9, 0.0), (-2.9, 0.0))
    assert model.FOOD_RADIUS == 0.58
    assert model.NEST_LIMIT_Y == -2.35
    for actual, expected in zip(model.NEST_FLOOR_POLYGON, SOURCE_NEST_POLYGON):
        assert math.isclose(actual[0], expected[0], rel_tol=0.0, abs_tol=1e-12)
        assert math.isclose(actual[1], expected[1], rel_tol=0.0, abs_tol=1e-12)


def test_floor_categories_and_scoring_boundary_are_distinct():
    points = torch.tensor(
        [
            [2.9, 0.0],       # food source 1
            [-2.9, 0.0],      # food source 2
            [0.0, 0.0],       # gray arena
            [0.0, -3.0],      # white nest
            [0.0, -2.35],     # gray floor boundary, scoring nest boundary
            [4.175, -2.36],   # inside arena half-plane, outside source white polygon
        ],
        dtype=torch.float64,
    )
    actual = model.ground_scalar(points)
    expected = torch.tensor([0.0, 0.0, 0.5, 1.0, 0.5, 0.5], dtype=torch.float64)
    torch.testing.assert_close(actual, expected, rtol=0.0, atol=0.0)
    assert bool(model.score_nest_membership(points[4:5])[0])
    assert not bool(model.floor_nest_membership(points[4:5])[0])


def test_vectorized_floor_matches_source_triangle_code_randomly():
    rng = random.Random(17491)
    points = [
        (rng.uniform(-4.9, 4.9), rng.uniform(-4.9, 4.9))
        for _ in range(20_000)
    ]
    tensor = torch.tensor(points, dtype=torch.float64)
    actual = model.ground_scalar(tensor).tolist()
    expected = [source_floor_value(point) for point in points]
    assert actual == expected


def test_float32_floor_matches_source_away_from_boundaries():
    rng = random.Random(5531)
    points = [
        (rng.uniform(-4.5, 4.5), rng.uniform(-4.5, 4.5))
        for _ in range(20_000)
    ]
    tensor = torch.tensor(points, dtype=torch.float32)
    actual = model.ground_scalar(tensor).tolist()
    expected = [source_floor_value(point) for point in points]
    assert actual == expected


def test_pickup_delivery_and_no_double_scoring():
    carrying = torch.zeros((1, 2), dtype=torch.bool)

    at_source = torch.tensor([[[2.9, 0.0], [0.0, 0.0]]])
    step = model.update_carrying_state(at_source, carrying)
    assert step.pickup_mask.tolist() == [[True, False]]
    assert step.delivery_mask.tolist() == [[False, False]]
    assert step.carrying.tolist() == [[True, False]]

    at_nest = torch.tensor([[[0.0, -2.35], [0.0, 0.0]]])
    step = model.update_carrying_state(at_nest, step.carrying)
    assert step.pickup_mask.tolist() == [[False, False]]
    assert step.delivery_mask.tolist() == [[True, False]]
    assert step.carrying.tolist() == [[False, False]]

    step = model.update_carrying_state(at_nest, step.carrying)
    assert not bool(step.delivery_mask.any())
    assert not bool(step.carrying.any())


def test_batched_sequence_matches_scalar_poststep_reference():
    generator = torch.Generator().manual_seed(9245)
    envs, robots, steps = 7, 20, 250
    carrying = torch.zeros((envs, robots), dtype=torch.bool)
    reference = [[False for _ in range(robots)] for _ in range(envs)]
    vector_deliveries = torch.zeros(envs, dtype=torch.long)
    scalar_deliveries = [0 for _ in range(envs)]

    for _ in range(steps):
        positions = torch.empty((envs, robots, 2)).uniform_(-4.6, 4.6, generator=generator)
        # Force regular source/nest encounters rather than relying on rare random hits.
        positions[0, 0] = torch.tensor([2.9, 0.0])
        positions[1, 1] = torch.tensor([-2.9, 0.0])
        positions[2, 2] = torch.tensor([0.0, -3.0])

        result = model.update_carrying_state(positions, carrying)
        vector_deliveries += result.delivery_mask.sum(dim=1)
        carrying = result.carrying

        for env_id in range(envs):
            for robot_id in range(robots):
                x, y = (float(v) for v in positions[env_id, robot_id])
                in_source = (
                    math.dist((x, y), (2.9, 0.0)) <= 0.58
                    or math.dist((x, y), (-2.9, 0.0)) <= 0.58
                )
                if in_source:
                    reference[env_id][robot_id] = True
                elif y <= -2.35:
                    scalar_deliveries[env_id] += int(reference[env_id][robot_id])
                    reference[env_id][robot_id] = False

    assert vector_deliveries.tolist() == scalar_deliveries
    assert carrying.tolist() == reference


def test_input_shape_validation():
    try:
        model.update_carrying_state(torch.zeros(2, 3), torch.zeros(2, dtype=torch.bool))
    except ValueError as exc:
        assert "XY axis" in str(exc)
    else:
        raise AssertionError("Expected invalid shape to be rejected")
