from __future__ import annotations

import ast
import hashlib
import importlib.util
import math
from pathlib import Path
import sys
import types

import torch
import yaml

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def ensure_package(name: str, path: Path | None = None) -> None:
    if name in sys.modules:
        return
    module = types.ModuleType(name)
    module.__path__ = [] if path is None else [str(path)]
    sys.modules[name] = module


def load_arena_modules():
    package_paths = {
        "SwarmACB_isaac": SOURCE.parents[2],
        "SwarmACB_isaac.tasks": SOURCE.parents[1],
        "SwarmACB_isaac.tasks.direct": SOURCE,
        "SwarmACB_isaac.tasks.direct.mercator_light": SOURCE / "mercator_light",
        "SwarmACB_isaac.tasks.direct.missions": SOURCE / "missions",
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2": (
            SOURCE / "missions" / "mercator_aggregation2"
        ),
    }
    for name, path in package_paths.items():
        ensure_package(name, path)

    geometry = load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.arena_geometry",
        SOURCE / "mercator_light" / "arena_geometry.py",
    )
    small = load_module(
        (
            "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2."
            "mercator_aggregation2_arena"
        ),
        SOURCE
        / "missions"
        / "mercator_aggregation2"
        / "mercator_aggregation2_arena.py",
    )
    return geometry, small


def test_experiment2_small_arena_exact_geometry_and_old_arena_fingerprint():
    geometry, small = load_arena_modules()
    arena = small.build_argos_aac2_arena()

    expected_centers = (
        (-1.3123, 0.0),
        (1.3123, 0.0),
        (0.0, 1.3123),
        (0.0, -1.3123),
        (-0.6591, -1.1373),
        (-1.1373, -0.6591),
        (0.6591, 1.1373),
        (1.1373, 0.6591),
        (-0.6591, 1.1373),
        (-1.1373, 0.6591),
        (0.6591, -1.1373),
        (1.1373, -0.6591),
    )
    expected_yaws = (0, 0, 90, 90, 60, 30, 60, 30, -60, -30, -60, -30)
    assert arena.wall_centers == expected_centers
    assert small.ARGOS2_WALL_YAW_DEG == expected_yaws
    assert arena.wall_side_length == 0.70
    assert arena.wall_thickness == 0.01
    assert arena.wall_height == 0.08
    assert len(arena.wall_segments) == 12
    assert len(arena.floor_vertices) == 12

    for segment in arena.wall_segments:
        length = math.dist(segment[0], segment[1])
        assert math.isclose(length, 0.70, rel_tol=0.0, abs_tol=1e-12)

    for x, y in arena.floor_vertices:
        for (nx, ny), offset in zip(arena.outward_normals, arena.inner_offsets):
            assert nx * x + ny * y <= offset + 1e-9

    # Baseline recorded before adding Experiment 2. This proves that the
    # Experiment-1 large arena builder itself is unchanged.
    original = geometry.build_argos_aac_arena()
    assert original.fingerprint == (
        "e38720a899acd6ef265d8a4ab36c9293f2dad5bf7d22968d0e7e6ddc27eb47ea"
    )
    assert arena.fingerprint != original.fingerprint


def test_exact_cpp_uniform_disk_transform():
    spawn = load_module(
        "argos_spawn_under_test", SOURCE / "mercator_light" / "argos_spawn.py"
    )
    pairs = torch.tensor(
        [[0.25, 0.50], [0.80, 0.20], [0.0, 0.0], [1.0, 1.0]],
        dtype=torch.float64,
    )
    actual = spawn.chocolate_big_aac_disk_points(pairs, 1.2)

    expected = []
    for first, second in pairs.tolist():
        a, b = sorted((first, second))
        if b == 0.0:
            expected.append((0.0, 0.0))
        else:
            expected.append(
                (
                    b * 1.2 * math.cos(math.tau * (a / b)),
                    b * 1.2 * math.sin(math.tau * (a / b)),
                )
            )
    torch.testing.assert_close(
        actual, torch.tensor(expected, dtype=torch.float64), rtol=0.0, atol=1e-14
    )

    generator = torch.Generator().manual_seed(4802)
    samples = torch.rand((200_000, 2), generator=generator)
    points = spawn.chocolate_big_aac_disk_points(samples, 1.2)
    radii = torch.linalg.vector_norm(points, dim=-1)
    assert float(radii.max()) <= 1.2 + 1e-6
    # Uniform disk E[r^2] = R^2/2. This catches radial-uniform sampling errors.
    assert math.isclose(
        float((radii * radii).mean()), 1.2**2 / 2.0, rel_tol=0.0, abs_tol=0.006
    )


def test_light_intensity_zero_disables_all_light_channels():
    ensure_package("SwarmACB_isaac")
    ensure_package("SwarmACB_isaac.tasks")
    ensure_package("SwarmACB_isaac.tasks.direct")
    ensure_package("SwarmACB_isaac.tasks.direct.mercator_light")
    load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.mercator_geometry",
        SOURCE / "mercator_light" / "mercator_geometry.py",
    )
    sensors_module = load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.mercator_sensors",
        SOURCE / "mercator_light" / "mercator_sensors.py",
    )

    positions = torch.tensor([[[0.0, 0.0], [0.3, 0.1]]])
    yaws = torch.tensor([[0.0, 1.0]])
    light_xy = torch.tensor([0.0, -2.0])
    enabled = sensors_module.MercatorLightSensors(light_enabled=True)
    disabled = sensors_module.MercatorLightSensors(light_enabled=False)

    enabled_outputs = enabled.compute_light(positions, yaws, light_xy)
    disabled_outputs = disabled.compute_light(positions, yaws, light_xy)
    assert bool((enabled_outputs[0] > 0.0).any())
    for tensor in disabled_outputs:
        torch.testing.assert_close(tensor, torch.zeros_like(tensor), rtol=0.0, atol=0.0)


def test_yaml_and_fsm_match_experiment2_contract():
    config_path = ROOT / "configs" / "mercator" / "AAC2_mercator_cyclamen.yaml"
    data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    behavior_name, block = next(iter(data["behaviors"].items()))
    environment = block["environment"]
    assert behavior_name == "AAC2_mercator_cyclamen_"
    assert environment["task"] == "SwarmACB-MercatorAggregation2-v0"
    assert environment["num_envs"] == 5
    assert environment["episode_length_s"] == 120.0
    assert environment["black_center"] == [0.0, 0.63]
    assert environment["white_center"] == [0.0, -0.63]
    assert environment["zone_radius"] == 0.32
    assert environment["light_position"] == [0.0, -2.0, 0.4]
    assert environment["light_intensity"] == 1.0
    assert environment["spawn_mode"] == "argos_uniform_disk_rejection"
    assert environment["spawn_half_range"] == 1.2
    assert environment["arena_side_length"] == 0.70
    assert block["max_steps"] == 18_000_000

    parser_module = load_module(
        "mercator_chocolate_fsm_exp2_under_test",
        ROOT / "scripts" / "mercator_chocolate_fsm.py",
    )
    fsm_path = (
        ROOT
        / "configs"
        / "mercator"
        / "fsms"
        / "fsm_mercator_aggregation2_experiment2.txt"
    )
    assert hashlib.sha256(fsm_path.read_bytes()).hexdigest() == (
        "9bd17a456d398fb4ec2e7f5c27191793d9e210007a4033de8b0339d5b7926aa6"
    )
    fsms = parser_module.load_fsm_file(fsm_path)
    assert len(fsms) == 10
    assert [fsm.num_states for fsm in fsms] == [2, 4, 3, 3, 2, 4, 4, 4, 3, 3]
    for fsm in fsms:
        for state in fsm.states:
            assert 0 <= state.module_id <= 5
            for transition in state.transitions:
                assert 0 <= transition.condition_id <= 5
                assert 0 <= transition.destination < fsm.num_states


def test_unified_fsm_cli_registration_and_visualizer_compatibility():
    unified_path = ROOT / "scripts" / "mercator_fsm.py"
    unified = unified_path.read_text(encoding="utf-8")
    tree = ast.parse(unified, filename=str(unified_path))
    assert tree is not None
    assert '"--mission"' in unified
    assert 'mode.add_argument("--observe"' in unified
    assert 'mode.add_argument("--score"' in unified
    assert "add_mutually_exclusive_group(required=True)" in unified
    for mission, task, fsm_name in (
        ("AAC", "SwarmACB-MercatorAggregation-v0", "fsm_mercator_aggregation_experiment1.txt"),
        ("AAC2", "SwarmACB-MercatorAggregation2-v0", "fsm_mercator_aggregation2_experiment2.txt"),
        ("FOR", "SwarmACB-MercatorForaging-v0", "fsm_mercator_foraging_experiment1.txt"),
        ("GRID", "SwarmACB-MercatorGridExploration-v0", "fsm_mercator_grid_exploration_experiment1.txt"),
    ):
        assert f'"{mission}": MissionSpec(' in unified
        assert task in unified
        assert fsm_name in unified

    registration_path = SOURCE / "missions" / "mercator_aggregation2" / "__init__.py"
    registration = registration_path.read_text(encoding="utf-8")
    ast.parse(registration, filename=str(registration_path))
    assert 'id="SwarmACB-MercatorAggregation2-v0"' in registration
    assert "MercatorAggregation2Env" in registration

    visualizer = (ROOT / "scripts" / "visualize_mercator.py").read_text(encoding="utf-8")
    ast.parse(visualizer)
    assert 'task_id == "SwarmACB-MercatorAggregation2-v0"' in visualizer
    assert "4.2 if small_arena else 13.0" in visualizer
    assert 'hasattr(base, "last_grid_mean_age")' in visualizer
    assert 'hasattr(base, "last_deliveries")' in visualizer


def test_existing_missions_keep_names_and_compatibility_launchers():
    for relative, behavior in {
        "configs/mercator/AAC_mercator_cyclamen.yaml": "AAC_mercator_cyclamen_",
        "configs/mercator/FOR_mercator_cyclamen.yaml": "FOR_mercator_cyclamen_",
    }.items():
        data = yaml.safe_load((ROOT / relative).read_text(encoding="utf-8"))
        assert next(iter(data["behaviors"])) == behavior

    launchers = {
        "observe_mercator_fsm.py": ("AAC", "--observe"),
        "score_mercator_fsm.py": ("AAC", "--score"),
        "observe_mercator_foraging_fsm.py": ("FOR", "--observe"),
        "score_mercator_foraging_fsm.py": ("FOR", "--score"),
        "mercator_aggregation2_fsm.py": ("AAC2", None),
    }
    for filename, (mission, mode) in launchers.items():
        path = ROOT / "scripts" / filename
        text = path.read_text(encoding="utf-8")
        ast.parse(text, filename=str(path))
        assert "mercator_fsm.py" in text
        assert "runpy.run_path" in text
        assert f'"{mission}"' in text
        if mode is not None:
            assert f'"{mode}"' in text
        assert len(text.splitlines()) <= 15

    assert not (ROOT / "configs" / "mercator" / "AAC_mercator_cyclamen2.yaml").exists()
    assert (ROOT / "configs" / "mercator" / "AAC2_mercator_cyclamen.yaml").exists()
