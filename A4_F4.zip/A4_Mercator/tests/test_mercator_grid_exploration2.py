from __future__ import annotations

import ast
import hashlib
import importlib.util
import math
from pathlib import Path
import subprocess
import sys

import torch
import yaml


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
)
MISSION_DIR = SOURCE / "missions" / "mercator_grid_exploration2"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def scalar_reference_step(
    ages: list[list[int]], positions: list[tuple[float, float]]
):
    arena_size = 2.65
    grid_size = 10
    updated = [row[:] for row in ages]
    visited: set[tuple[int, int]] = set()
    for x, y in positions:
        ix = int(grid_size * (x / arena_size + 0.5))
        iy = int(grid_size * (y / arena_size + 0.5))
        if 0 <= ix < grid_size and 0 <= iy < grid_size:
            updated[ix][iy] = 0
            visited.add((ix, iy))
    total = sum(sum(row) for row in updated)
    max_age = max(max(row) for row in updated)
    for ix in range(grid_size):
        for iy in range(grid_size):
            updated[ix][iy] += 1
    return updated, total, max_age, len(visited)


def test_grid2_objective_matches_independent_scalar_translation():
    model = load_module(
        "mercator_grid2_model_under_test",
        MISSION_DIR / "mercator_grid_exploration2_model.py",
    )
    generator = torch.Generator().manual_seed(20260719)
    envs, robots, steps = 9, 3, 500
    tensor_ages = torch.zeros(envs, 10, 10, dtype=torch.long)
    scalar_ages = [[[0 for _ in range(10)] for _ in range(10)] for _ in range(envs)]

    # Experiment-2 GetRandomPosition samples in a disk of radius 1.2 m.
    a = torch.rand(steps, envs, robots, generator=generator)
    b = torch.rand(steps, envs, robots, generator=generator)
    lower = torch.minimum(a, b)
    upper = torch.maximum(a, b)
    angle = 2.0 * math.pi * lower / upper.clamp_min(torch.finfo(torch.float32).tiny)
    positions = torch.stack((upper * 1.2 * torch.cos(angle), upper * 1.2 * torch.sin(angle)), dim=-1)

    for step_id in range(steps):
        current = positions[step_id]
        result = model.update_grid_ages(tensor_ages, current)
        for env_id in range(envs):
            reference = scalar_reference_step(
                scalar_ages[env_id], [tuple(v) for v in current[env_id].tolist()]
            )
            scalar_ages[env_id] = reference[0]
            assert int(result.total_age[env_id].item()) == reference[1]
            assert int(result.max_age[env_id].item()) == reference[2]
            assert int(result.visited_cells[env_id].item()) == reference[3]
            assert math.isclose(
                result.reward[env_id].item(),
                -reference[1] / 100.0,
                rel_tol=0.0,
                abs_tol=1e-5,
            )
            assert result.ages[env_id].tolist() == reference[0]
        tensor_ages = result.ages


def test_grid2_cell_mapping_order_and_uniform_gray_floor():
    model = load_module(
        "mercator_grid2_mapping_under_test",
        MISSION_DIR / "mercator_grid_exploration2_model.py",
    )
    points = torch.tensor(
        [[[-1.325, -1.325], [-1.324, -1.324], [0.0, 0.0], [1.324, 1.324], [1.325, 1.325]]],
        dtype=torch.float64,
    )
    x, y, valid = model.position_to_grid_cells(points)
    assert x.tolist() == [[0, 0, 5, 9, 10]]
    assert y.tolist() == [[0, 0, 5, 9, 10]]
    assert valid.tolist() == [[True, True, True, True, False]]

    ages = torch.zeros(1, 10, 10, dtype=torch.long)
    repeated = torch.tensor([[[-1.0, -1.0], [1.0, 1.0], [1.0, 1.0]]])
    first = model.update_grid_ages(ages, repeated)
    assert first.total_age.tolist() == [0.0]
    assert first.visited_cells.tolist() == [2.0]
    second = model.update_grid_ages(first.ages, repeated)
    assert second.total_age.tolist() == [98.0]
    torch.testing.assert_close(second.reward, torch.tensor([-0.98]), rtol=0.0, atol=1e-6)

    gray = model.ground_scalar(torch.randn(4, 3, 2))
    torch.testing.assert_close(gray, torch.full((4, 3), 0.5))


def test_grid2_yaml_registration_fsm_and_unified_cli_contract():
    data = yaml.safe_load(
        (ROOT / "configs" / "mercator" / "GRID2_mercator_cyclamen.yaml").read_text()
    )
    behavior_name, block = next(iter(data["behaviors"].items()))
    env = block["environment"]
    assert behavior_name == "GRID2_mercator_cyclamen_"
    assert block["max_steps"] == 18_000_000
    assert env["task"] == "SwarmACB-MercatorGridExploration2-v0"
    assert env["num_envs"] == 5
    assert env["episode_length_s"] == 120.0
    assert env["grid_arena_size"] == 2.65
    assert env["grid_size"] == 10
    assert env["light_position"] == [0.0, -2.0, 0.4]
    assert env["light_intensity"] == 1.0
    assert env["spawn_mode"] == "argos_uniform_disk_rejection"
    assert env["spawn_half_range"] == 1.2
    assert env["arena_side_length"] == 0.70
    assert env["cyclamen_neighbor_range"] == 0.75
    assert env["teraranger_max_range"] == 2.0

    registration = (MISSION_DIR / "__init__.py").read_text(encoding="utf-8")
    ast.parse(registration)
    assert 'id="SwarmACB-MercatorGridExploration2-v0"' in registration
    assert "MercatorGridExploration2Env" in registration

    fsm_path = (
        ROOT / "configs" / "mercator" / "fsms" /
        "fsm_mercator_grid_exploration2_experiment2.txt"
    )
    assert hashlib.sha256(fsm_path.read_bytes()).hexdigest() == (
        "9f992b59dea40d812df1d7ff73a917534968ce204080183e537a16d18d949aff"
    )
    assert len(fsm_path.read_bytes()) == 3911
    parser = load_module(
        "mercator_grid2_fsm_parser_under_test",
        ROOT / "scripts" / "mercator_chocolate_fsm.py",
    )
    fsms = parser.load_fsm_file(fsm_path)
    assert len(fsms) == 10
    assert [fsm.num_states for fsm in fsms] == [4, 3, 3, 4, 2, 3, 2, 2, 3, 3]
    for fsm in fsms:
        for state in fsm.states:
            assert state.module_id == 0
            for transition in state.transitions:
                assert 0 <= transition.condition_id <= 5
                assert 0 <= transition.destination < fsm.num_states

    unified = (ROOT / "scripts" / "mercator_fsm.py").read_text(encoding="utf-8")
    assert '"GRID2": MissionSpec(' in unified
    assert 'task_id="SwarmACB-MercatorGridExploration2-v0"' in unified
    assert 'config="configs/mercator/GRID2_mercator_cyclamen.yaml"' in unified
    assert "fsm_mercator_grid_exploration2_experiment2.txt" in unified
    assert "camera_height=4.2" in unified and "camera_y=-3.0" in unified
    assert not (ROOT / "scripts" / "observe_mercator_grid2_fsm.py").exists()
    assert not (ROOT / "scripts" / "score_mercator_grid2_fsm.py").exists()

    help_run = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "mercator_fsm.py"), "--help"],
        text=True,
        capture_output=True,
        check=False,
    )
    assert help_run.returncode == 0
    assert "--mission {AAC,AAC2,FOR,FOR2,GRID,GRID2}" in help_run.stdout


def test_grid2_environment_sources_small_arena_and_non_regression():
    for path in [
        *MISSION_DIR.glob("*.py"),
        ROOT / "scripts" / "mercator_fsm.py",
        ROOT / "scripts" / "visualize_mercator.py",
    ]:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    env_source = (MISSION_DIR / "mercator_grid_exploration2_env.py").read_text()
    assert "class MercatorGridExploration2Env(MercatorGridExplorationEnv)" in env_source
    assert "build_argos_aac2_arena" in env_source
    assert "build_grid2_environment_signature" in env_source
    assert "update_grid_ages(" in env_source

    visualizer = (ROOT / "scripts" / "visualize_mercator.py").read_text()
    assert '"SwarmACB-MercatorGridExploration2-v0"' in visualizer

    expected = {
        "scripts/mercator_chocolate_fsm.py": "c37ac48aecc205632167b09015be76ebe9d258d33e4c0311830bc33ea493289e",
        "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_grid_exploration/mercator_grid_exploration_env.py": "84df7bcd88c6ed1bf5f8ee43313079d252548de226eed13935c54907025066da",
        "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_foraging2/mercator_foraging2_env.py": "b48d7eef21c7f80133ee8c6dd18f92f0f4ebcb313525b3c7b1532ec118237a99",
        "configs/mercator/fsms/fsm_mercator_grid_exploration_experiment1.txt": "51cea00eb09a944bd79f98bbe52d37c7b9014ebbfdfcdee0f57f94437829c885",
        "configs/mercator/fsms/fsm_mercator_foraging2_experiment2.txt": "690840b19e0269fe4c57b9361dc6082a6a3e8008775ced8b5f6cbf66ce69a5e5",
    }
    for relative, digest in expected.items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == digest
