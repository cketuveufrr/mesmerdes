from __future__ import annotations

import ast
import hashlib
import importlib.util
from pathlib import Path
import math
import sys

import torch
import yaml


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
)
GRID = SOURCE / "missions" / "mercator_grid_exploration"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def scalar_reference_step(ages: list[list[int]], positions: list[tuple[float, float]]):
    size = 9.65
    grid_size = 10
    updated = [row[:] for row in ages]
    visited: set[tuple[int, int]] = set()
    for x, y in positions:
        ix = int(grid_size * (x / size + 0.5))
        iy = int(grid_size * (y / size + 0.5))
        if 0 <= ix < grid_size and 0 <= iy < grid_size:
            updated[ix][iy] = 0
            visited.add((ix, iy))
    total = sum(sum(row) for row in updated)
    max_age = max(max(row) for row in updated)
    for ix in range(grid_size):
        for iy in range(grid_size):
            updated[ix][iy] += 1
    return updated, total, max_age, len(visited)


def test_grid_objective_matches_independent_scalar_translation():
    model = load_module(
        "mercator_grid_model_under_test",
        GRID / "mercator_grid_exploration_model.py",
    )
    generator = torch.Generator().manual_seed(1937)
    envs, robots, steps = 7, 20, 75
    tensor_ages = torch.zeros(envs, 10, 10, dtype=torch.long)
    scalar_ages = [[[0 for _ in range(10)] for _ in range(10)] for _ in range(envs)]

    for _ in range(steps):
        positions = (torch.rand(envs, robots, 2, generator=generator) * 9.2) - 4.6
        result = model.update_grid_ages(tensor_ages, positions)
        for env_id in range(envs):
            reference = scalar_reference_step(
                scalar_ages[env_id], [tuple(v) for v in positions[env_id].tolist()]
            )
            scalar_ages[env_id] = reference[0]
            assert int(result.total_age[env_id].item()) == reference[1]
            assert int(result.max_age[env_id].item()) == reference[2]
            assert int(result.visited_cells[env_id].item()) == reference[3]
            assert math.isclose(result.reward[env_id].item(), -reference[1] / 100.0, rel_tol=0.0, abs_tol=1e-6)
            assert result.ages[env_id].tolist() == reference[0]
        tensor_ages = result.ages


def test_grid_order_reset_sum_then_increment_and_uniform_gray_ground():
    model = load_module(
        "mercator_grid_model_order_under_test",
        GRID / "mercator_grid_exploration_model.py",
    )
    ages = torch.zeros(1, 10, 10, dtype=torch.long)
    positions = torch.tensor([[[-4.0, -4.0], [4.0, 4.0], [4.0, 4.0]]])

    first = model.update_grid_ages(ages, positions)
    assert first.total_age.tolist() == [0.0]
    assert first.reward.tolist() == [0.0]
    assert first.visited_cells.tolist() == [2.0]
    assert bool((first.ages == 1).all())

    second = model.update_grid_ages(first.ages, positions)
    assert second.total_age.tolist() == [98.0]
    torch.testing.assert_close(second.reward, torch.tensor([-0.98]), rtol=0.0, atol=1e-6)
    assert second.visited_cells.tolist() == [2.0]
    assert int((second.ages == 1).sum().item()) == 2
    assert int((second.ages == 2).sum().item()) == 98

    points = torch.randn(3, 20, 2)
    gray = model.ground_scalar(points)
    torch.testing.assert_close(gray, torch.full((3, 20), 0.5))


def test_grid_cell_mapping_and_invalid_points():
    model = load_module(
        "mercator_grid_model_mapping_under_test",
        GRID / "mercator_grid_exploration_model.py",
    )
    positions = torch.tensor(
        [[[-4.825, -4.825], [-4.824, -4.824], [0.0, 0.0], [4.824, 4.824], [4.825, 4.825]]],
        dtype=torch.float64,
    )
    x, y, valid = model.position_to_grid_cells(positions)
    assert x.tolist() == [[0, 0, 5, 9, 10]]
    assert y.tolist() == [[0, 0, 5, 9, 10]]
    assert valid.tolist() == [[True, True, True, True, False]]


def test_grid_yaml_registration_environment_and_fsm_contract():
    data = yaml.safe_load(
        (ROOT / "configs" / "mercator" / "GRID_mercator_cyclamen.yaml").read_text()
    )
    behavior_name, block = next(iter(data["behaviors"].items()))
    env = block["environment"]
    assert behavior_name == "GRID_mercator_cyclamen_"
    assert block["max_steps"] == 120_000_000
    assert env["task"] == "SwarmACB-MercatorGridExploration-v0"
    assert env["num_envs"] == 5
    assert env["episode_length_s"] == 120.0
    assert env["grid_arena_size"] == 9.65
    assert env["grid_size"] == 10
    assert env["light_position"] == [0.0, -5.0, 0.8]
    assert env["light_intensity"] == 5.0
    assert env["spawn_mode"] == "argos_uniform_box_rejection"
    assert env["spawn_half_range"] == 4.6
    assert env["teraranger_max_range"] == 2.0

    registration = (GRID / "__init__.py").read_text(encoding="utf-8")
    ast.parse(registration)
    assert 'id="SwarmACB-MercatorGridExploration-v0"' in registration
    assert "MercatorGridExplorationEnv" in registration

    env_source = (GRID / "mercator_grid_exploration_env.py").read_text(encoding="utf-8")
    ast.parse(env_source)
    assert "class MercatorGridExplorationEnv(MercatorAggregationEnv)" in env_source
    assert "update_grid_ages(" in env_source
    assert "build_grid_environment_signature(" in env_source
    assert "self._episode_group_reward += step.reward" in env_source

    fsm_path = (
        ROOT
        / "configs"
        / "mercator"
        / "fsms"
        / "fsm_mercator_grid_exploration_experiment1.txt"
    )
    assert hashlib.sha256(fsm_path.read_bytes()).hexdigest() == (
        "51cea00eb09a944bd79f98bbe52d37c7b9014ebbfdfcdee0f57f94437829c885"
    )
    parser = load_module(
        "mercator_grid_fsm_parser_under_test",
        ROOT / "scripts" / "mercator_chocolate_fsm.py",
    )
    fsms = parser.load_fsm_file(fsm_path)
    assert len(fsms) == 10
    assert [fsm.num_states for fsm in fsms] == [3, 4, 4, 3, 3, 3, 3, 3, 3, 2]
    for fsm in fsms:
        for state in fsm.states:
            assert 0 <= state.module_id <= 5
            if state.module_id in (4, 5):
                assert isinstance(state.parameter, float)
            for transition in state.transitions:
                assert 0 <= transition.condition_id <= 5
                assert 0 <= transition.destination < fsm.num_states


def test_restored_mercator_proximity_and_real_att_rep_parameters():
    sensor_path = SOURCE / "mercator_light" / "mercator_sensors.py"
    text = sensor_path.read_text(encoding="utf-8")
    tree = ast.parse(text, filename=str(sensor_path))
    assert tree is not None
    assert "teraranger_max_range: float = 2.0" in text
    assert "teraranger_origin_offset: float = 0.005" in text
    assert "((1.0 / distance.clamp_min(1e-8)) - 2.5) / 17.5" in text
    assert "UNIFORM_RING_HEADINGS" in text

    parser = load_module(
        "mercator_real_parameter_parser_under_test",
        ROOT / "scripts" / "mercator_chocolate_fsm.py",
    )
    att = parser.parse_fsm("--nstates 1 --s0 4 --att0 2.74 --n0 0")
    rep = parser.parse_fsm("--nstates 1 --s0 5 --rep0 4.76 --n0 0")
    assert att.states[0].parameter == 2.74
    assert rep.states[0].parameter == 4.76


def test_unified_cli_help_and_argument_validation_do_not_require_isaac():
    # argparse exits before SimulationApp import for --help and malformed calls.
    import subprocess

    script = ROOT / "scripts" / "mercator_fsm.py"
    help_run = subprocess.run(
        [sys.executable, str(script), "--help"],
        text=True,
        capture_output=True,
        check=False,
    )
    assert help_run.returncode == 0
    assert "--mission {AAC,AAC2,FOR,FOR2,GRID,GRID2}" in help_run.stdout
    assert "--observe" in help_run.stdout and "--score" in help_run.stdout

    missing_mode = subprocess.run(
        [sys.executable, str(script), "--mission", "GRID"],
        text=True,
        capture_output=True,
        check=False,
    )
    assert missing_mode.returncode == 2
    assert "one of the arguments --observe --score is required" in missing_mode.stderr

    bad_mission = subprocess.run(
        [sys.executable, str(script), "--mission", "UNKNOWN", "--score"],
        text=True,
        capture_output=True,
        check=False,
    )
    assert bad_mission.returncode == 2
    assert "choose AAC, AAC2, FOR, FOR2, GRID, or GRID2" in bad_mission.stderr
