from __future__ import annotations

import importlib.util
import math
from pathlib import Path
import sys
import types

import torch
import yaml


ROOT = Path(__file__).resolve().parents[1]
DIRECT = (
    ROOT / "source" / "SwarmACB_isaac" / "SwarmACB_isaac" / "tasks" / "direct"
)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def ensure_package(name: str, path: Path) -> None:
    if name in sys.modules:
        return
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    sys.modules[name] = module


def load_sensor_module():
    package_paths = {
        "SwarmACB_isaac": DIRECT.parents[2],
        "SwarmACB_isaac.tasks": DIRECT.parents[1],
        "SwarmACB_isaac.tasks.direct": DIRECT,
        "SwarmACB_isaac.tasks.direct.mercator_light": DIRECT / "mercator_light",
    }
    for name, path in package_paths.items():
        ensure_package(name, path)
    load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.mercator_geometry",
        DIRECT / "mercator_light" / "mercator_geometry.py",
    )
    return load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.mercator_sensors_profile_test",
        DIRECT / "mercator_light" / "mercator_sensors.py",
    )


def test_profile_expansion_default_selection_and_explicit_priority():
    profiles = load_module(
        "mercator_profiles_under_test",
        DIRECT / "mercator_light" / "mercator_profiles.py",
    )

    # Silence means no injected overrides: env cfg native defaults remain active.
    assert profiles.expand_robot_profile_overrides({"task": "x"}) == {"task": "x"}

    native = profiles.expand_robot_profile_overrides({"robot_profile": "mercator"})
    assert native["robot_profile"] == "mercator"
    assert native["robot_length"] == 0.26
    assert native["robot_width"] == 0.25
    assert native["wheelbase"] == 0.18
    assert native["ground_sensor_offset"] == (0.056, 0.0)
    assert native["lidar_tower_offset"] == (0.0, 0.0)
    assert native["teraranger_layout"] == "native_asymmetric"
    assert native["teraranger_max_range"] == 2.0

    transfer = profiles.expand_robot_profile_overrides({"robot_profile": "tmercator"})
    assert transfer["robot_length"] == 0.216
    assert transfer["robot_width"] == 0.185
    assert transfer["robot_height"] == 0.170
    assert transfer["robot_base_height"] == 0.114
    assert transfer["collision_shape"] == "circle"
    assert transfer["collision_radius"] == 0.105
    assert transfer["collision_ring_radius"] == 0.105
    assert transfer["collision_ring_height"] == 0.056
    assert transfer["wheelbase"] == 0.147
    assert transfer["ground_sensor_offset"] == (0.05, 0.0)
    assert transfer["teraranger_layout"] == "uniform_ring"
    assert transfer["teraranger_ring_radius"] == 0.105
    assert transfer["teraranger_origin_offset"] == 0.0
    assert transfer["teraranger_max_range"] == 2.0

    overridden = profiles.expand_robot_profile_overrides(
        {"robot_profile": "tmercator", "wheelbase": 0.31}
    )
    assert overridden["wheelbase"] == 0.31
    assert overridden["robot_width"] == 0.185


def test_all_six_missions_have_explicit_native_and_tmercator_yaml_profiles():
    config_dir = ROOT / "configs" / "mercator"
    common_visual = {
        "lidar_tower_diameter": 0.065,
        "lidar_tower_offset": [0.0, 0.0],
    }
    for mission in ("AAC", "AAC2", "FOR", "FOR2", "GRID", "GRID2"):
        native_data = yaml.safe_load(
            (config_dir / f"{mission}_mercator_cyclamen.yaml").read_text()
        )
        transfer_data = yaml.safe_load(
            (config_dir / f"{mission}_tmercator_cyclamen.yaml").read_text()
        )
        native_name, native_block = next(iter(native_data["behaviors"].items()))
        transfer_name, transfer_block = next(iter(transfer_data["behaviors"].items()))
        assert native_name == f"{mission}_mercator_cyclamen_"
        assert transfer_name == f"{mission}_tmercator_cyclamen_"
        native = native_block["environment"]
        transfer = transfer_block["environment"]
        assert native["task"] == transfer["task"]
        assert native["robot_profile"] == "mercator"
        assert native["robot_length"] == 0.26
        assert native["robot_width"] == 0.25
        assert native["wheelbase"] == 0.147
        assert native["ground_sensor_offset"] == [0.05, 0.0]
        assert native["teraranger_layout"] == "native_asymmetric"
        assert native["teraranger_ring_radius"] == 0.143
        assert native["teraranger_origin_offset"] == 0.005
        assert native["teraranger_max_range"] == 2.0

        assert transfer["robot_profile"] == "tmercator"
        assert transfer["robot_length"] == 0.216
        assert transfer["robot_width"] == 0.185
        assert transfer["robot_height"] == 0.170
        assert transfer["robot_base_height"] == 0.114
        assert transfer["collision_shape"] == "circle"
        assert transfer["collision_radius"] == 0.105
        assert transfer["collision_ring_radius"] == 0.105
        assert transfer["collision_ring_height"] == 0.056
        assert transfer["collision_ring_thickness"] == 0.010
        assert transfer["lidar_height"] == 0.140
        assert transfer["wheelbase"] == 0.147
        assert transfer["ground_sensor_offset"] == [0.05, 0.0]
        assert transfer["teraranger_layout"] == "uniform_ring"
        assert transfer["teraranger_ring_radius"] == 0.105
        assert transfer["teraranger_origin_offset"] == 0.0
        assert transfer["teraranger_max_range"] == 2.0
        assert native["robot_height"] == 0.20
        assert native["robot_base_height"] == 0.08
        assert native["lidar_height"] == 0.17545
        for key, expected in common_visual.items():
            assert native[key] == expected
            assert transfer[key] == expected


def test_native_sensor_layout_is_preserved_and_tmercator_is_uniform_ring():
    sensors = load_sensor_module()
    cls = sensors.MercatorLightSensors

    native = cls(
        teraranger_layout="native_asymmetric",
        teraranger_ring_radius=0.143,
        teraranger_origin_offset=0.005,
        teraranger_max_range=2.0,
    )
    expected_angles = torch.tensor(cls.TERARANGER_HEADINGS, dtype=torch.float32)
    expected_offsets = torch.tensor(cls.TERARANGER_OFFSETS, dtype=torch.float32)
    expected_dirs = torch.stack((torch.cos(expected_angles), torch.sin(expected_angles)), -1)
    torch.testing.assert_close(native.sensor_angles.cpu(), expected_angles)
    torch.testing.assert_close(native.sensor_offsets.cpu(), expected_offsets)
    torch.testing.assert_close(
        native.local_ray_origins.cpu(), expected_offsets + 0.005 * expected_dirs
    )

    transfer = cls(
        teraranger_layout="uniform_ring",
        collision_shape="circle",
        robot_collision_radius=0.105,
        teraranger_ring_radius=0.105,
        teraranger_origin_offset=0.0,
        teraranger_max_range=2.0,
    )
    expected_degrees = torch.tensor(
        [45.0, 0.0, -45.0, -90.0, -135.0, 180.0, 135.0, 90.0]
    )
    expected_radians = expected_degrees * (math.pi / 180.0)
    torch.testing.assert_close(transfer.sensor_angles.cpu(), expected_radians)
    radii = torch.linalg.vector_norm(transfer.local_ray_origins.cpu(), dim=-1)
    torch.testing.assert_close(radii, torch.full((8,), 0.105), rtol=0.0, atol=1e-6)
    torch.testing.assert_close(
        transfer.local_ray_origins.cpu(), 0.105 * transfer.sensor_dirs.cpu()
    )


def test_backends_and_checkpoint_signatures_receive_profile_fields():
    cfg_source = (
        DIRECT / "missions" / "mercator_aggregation" / "mercator_aggregation_env_cfg.py"
    ).read_text()
    env_source = (
        DIRECT / "missions" / "mercator_aggregation" / "mercator_aggregation_env.py"
    ).read_text()
    tensor_source = (DIRECT / "mercator_light" / "mercator_tensor_env.py").read_text()
    loader_source = (DIRECT / "agents" / "config_loader.py").read_text()
    assert 'robot_profile: str = "mercator"' in cfg_source
    assert 'teraranger_layout: str = "native_asymmetric"' in cfg_source
    for field in (
        "teraranger_layout=cfg.teraranger_layout",
        "teraranger_ring_radius=cfg.teraranger_ring_radius",
        "teraranger_origin_offset=cfg.teraranger_origin_offset",
        "collision_shape=self.collision_shape",
        "robot_collision_radius=self.collision_radius",
    ):
        assert field in env_source
        assert field in tensor_source
    assert "expand_robot_profile_overrides" in loader_source

    signature_files = (
        DIRECT / "mercator_light" / "arena_geometry.py",
        DIRECT / "missions" / "mercator_foraging" / "mercator_foraging_model.py",
        DIRECT / "missions" / "mercator_foraging2" / "mercator_foraging2_model.py",
        DIRECT / "missions" / "mercator_grid_exploration" / "mercator_grid_exploration_model.py",
        DIRECT / "missions" / "mercator_grid_exploration2" / "mercator_grid_exploration2_model.py",
    )
    for path in signature_files:
        text = path.read_text()
        assert '"robot_profile": str(cfg.robot_profile)' in text
        assert '"teraranger_layout": str(cfg.teraranger_layout)' in text
        assert '"teraranger_ring_radius": float(cfg.teraranger_ring_radius)' in text
        assert '"teraranger_origin_offset": float(cfg.teraranger_origin_offset)' in text
        assert '"collision_shape": str(cfg.collision_shape)' in text
        assert '"collision_radius": float(cfg.collision_radius)' in text


def test_real_config_loader_expands_profiles_for_all_six_missions():
    agents_path = DIRECT / "agents"
    ensure_package("SwarmACB_isaac.tasks.direct.agents", agents_path)
    ensure_package("SwarmACB_isaac.tasks.direct.mercator_light", DIRECT / "mercator_light")
    load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.mercator_profiles",
        DIRECT / "mercator_light" / "mercator_profiles.py",
    )

    class FakePOCAConfig:
        def __init__(self):
            self.trainer_type = "poca"
            self.mini_batch_size = 2048
            self.lr = 3e-4
            self.beta = 0.005
            self.clip_eps = 0.2
            self.lam = 0.95
            self.num_epochs = 3
            self.lr_schedule = "constant"
            self.eps_schedule = "constant"
            self.beta_schedule = "constant"
            self.hidden_dim = 128
            self.num_layers = 1
            self.critic_hidden_dim = 128
            self.critic_num_layers = 2
            self.critic_num_heads = 4
            self.recurrent = False
            self.memory_size = 64
            self.sequence_length = 128
            self.gamma = 0.99
            self.reward_strength = 1.0
            self.total_timesteps = 1
            self.horizon = 128
            self.summary_freq = 1
            self.checkpoint_interval = 1
            self.keep_checkpoints = 5
            self.buffer_size_hint = 0
            self.decision_period = 1
            self.seed = 0

    class FakeOptionConfig(FakePOCAConfig):
        def __init__(self):
            super().__init__()
            self.num_options = 6
            self.termination_penalty = 0.0
            self.termination_coef = 1.0
            self.termination_entropy_coef = 0.0
            self.value_coef = 0.5
            self.option_value_coef = 0.5
            self.baseline_coef = 0.5

    poca_module = types.ModuleType(
        "SwarmACB_isaac.tasks.direct.agents.poca_trainer"
    )
    poca_module.POCAConfig = FakePOCAConfig
    sys.modules[poca_module.__name__] = poca_module
    option_module = types.ModuleType(
        "SwarmACB_isaac.tasks.direct.agents.option_critic_trainer"
    )
    option_module.FixedOptionCriticConfig = FakeOptionConfig
    sys.modules[option_module.__name__] = option_module

    loader = load_module(
        "SwarmACB_isaac.tasks.direct.agents.config_loader_profile_test",
        agents_path / "config_loader.py",
    )
    config_dir = ROOT / "configs" / "mercator"
    for mission in ("AAC", "AAC2", "FOR", "FOR2", "GRID", "GRID2"):
        _, _, _, native = loader.load_config(
            config_dir / f"{mission}_mercator_cyclamen.yaml"
        )
        _, _, _, transfer = loader.load_config(
            config_dir / f"{mission}_tmercator_cyclamen.yaml"
        )
        assert native["robot_profile"] == "mercator"
        assert native["ground_sensor_offset"] == [0.05, 0.0]
        assert native["teraranger_layout"] == "native_asymmetric"
        assert native["teraranger_max_range"] == 2.0
        assert transfer["robot_profile"] == "tmercator"
        assert transfer["robot_length"] == 0.216
        assert transfer["robot_width"] == 0.185
        assert transfer["robot_height"] == 0.170
        assert transfer["robot_base_height"] == 0.114
        assert transfer["collision_shape"] == "circle"
        assert transfer["collision_radius"] == 0.105
        assert transfer["wheelbase"] == 0.147
        assert transfer["ground_sensor_offset"] == [0.05, 0.0]
        assert transfer["teraranger_layout"] == "uniform_ring"
        assert transfer["teraranger_ring_radius"] == 0.105
        assert transfer["teraranger_max_range"] == 2.0

    _, _, _, epuck = loader.load_config(
        ROOT / "configs" / "epucks" / "DirGate_cyclamen.yaml"
    )
    assert "robot_profile" not in epuck
    assert "teraranger_layout" not in epuck


def test_unified_fsm_outputs_are_profile_labeled():
    source = (ROOT / "scripts" / "mercator_fsm.py").read_text()
    assert '"robot_profile": str(base.cfg.robot_profile)' in source
    assert '"robot_profile": str(records[0]["robot_profile"])' in source
    assert 'prefix = f"{SPEC.output_prefix}_{profile}"' in source
    assert 'print(f"Profile               : {env_cfg.robot_profile}")' in source
