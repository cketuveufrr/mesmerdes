from __future__ import annotations

import ast
import importlib.util
from pathlib import Path
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def test_chocolate_file_parses_all_ten_fsms():
    parser_module = load_module(
        "mercator_chocolate_fsm_under_test", ROOT / "scripts" / "mercator_chocolate_fsm.py"
    )
    fsms = parser_module.load_fsm_file(
        ROOT / "configs" / "mercator" / "fsms" / "fsm_mercator_foraging_experiment1.txt"
    )
    assert len(fsms) == 10
    assert [fsm.num_states for fsm in fsms] == [4, 3, 3, 4, 3, 3, 4, 3, 3, 4]
    for fsm in fsms:
        for state in fsm.states:
            assert 0 <= state.module_id <= 5
            for transition in state.transitions:
                assert 0 <= transition.condition_id <= 5
                assert 0 <= transition.destination < fsm.num_states


def test_foraging_yaml_selects_only_new_mercator_task():
    path = ROOT / "configs" / "mercator" / "FOR_mercator_cyclamen.yaml"
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    block = next(iter(data["behaviors"].values()))
    environment = block["environment"]
    assert environment["task"] == "SwarmACB-MercatorForaging-v0"
    assert environment["episode_length_s"] == 120.0
    assert environment["food_centers"] == [[2.9, 0.0], [-2.9, 0.0]]
    assert environment["food_radius"] == 0.58
    assert environment["nest_limit_y"] == -2.35
    assert environment["spawn_mode"] == "argos_uniform_box_rejection"


def test_new_python_files_are_syntactically_valid_and_task_is_registered():
    paths = [
        ROOT / "scripts" / "observe_mercator_foraging_fsm.py",
        ROOT / "scripts" / "score_mercator_foraging_fsm.py",
        ROOT / "scripts" / "visualize_mercator.py",
        *(
            ROOT
            / "source"
            / "SwarmACB_isaac"
            / "SwarmACB_isaac"
            / "tasks"
            / "direct"
            / "missions"
            / "mercator_foraging"
        ).glob("*.py"),
    ]
    for path in paths:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    registration = (
        ROOT
        / "source"
        / "SwarmACB_isaac"
        / "SwarmACB_isaac"
        / "tasks"
        / "direct"
        / "missions"
        / "mercator_foraging"
        / "__init__.py"
    ).read_text(encoding="utf-8")
    assert 'id="SwarmACB-MercatorForaging-v0"' in registration
    assert "MercatorForagingEnv" in registration


def test_aggregation_compatibility_launchers_remain_aac_restricted():
    for filename, mode in (
        ("observe_mercator_fsm.py", "--observe"),
        ("score_mercator_fsm.py", "--score"),
    ):
        text = (ROOT / "scripts" / filename).read_text(encoding="utf-8")
        assert '"--mission", "AAC"' in text
        assert f'"{mode}"' in text
        assert "mercator_fsm.py" in text
        assert '"FOR"' not in text
        assert '"AAC2"' not in text
        assert '"GRID"' not in text
