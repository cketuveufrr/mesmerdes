from __future__ import annotations

import ast
import hashlib
import importlib.util
import math
from pathlib import Path
import sys
import types

import torch
import yaml

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
)
MISSION_DIR = SOURCE / "missions" / "mercator_foraging2"


def ensure_package(name: str, path: Path | None = None) -> None:
    if name in sys.modules:
        return
    module = types.ModuleType(name)
    module.__path__ = [] if path is None else [str(path)]
    sys.modules[name] = module


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_foraging_models():
    package_paths = {
        "SwarmACB_isaac": SOURCE.parents[2],
        "SwarmACB_isaac.tasks": SOURCE.parents[1],
        "SwarmACB_isaac.tasks.direct": SOURCE,
        "SwarmACB_isaac.tasks.direct.missions": SOURCE / "missions",
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging": (
            SOURCE / "missions" / "mercator_foraging"
        ),
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging2": MISSION_DIR,
    }
    for name, path in package_paths.items():
        ensure_package(name, path)
    model1 = load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging.mercator_foraging_model",
        SOURCE / "missions" / "mercator_foraging" / "mercator_foraging_model.py",
    )
    model2 = load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging2.mercator_foraging2_model",
        MISSION_DIR / "mercator_foraging2_model.py",
    )
    return model1, model2


def triangle_area(a, b, c) -> float:
    return abs(
        a[0] * (b[1] - c[1])
        + b[0] * (c[1] - a[1])
        + c[0] * (a[1] - b[1])
    ) / 2.0


def in_triangle(q, a, b, c) -> bool:
    reference = triangle_area(a, b, c)
    parts = triangle_area(a, b, q) + triangle_area(a, c, q) + triangle_area(b, c, q)
    return abs(reference - parts) < 0.0001


def scalar_floor(x: float, y: float) -> float:
    if math.dist((x, y), (0.8, 0.0)) <= 0.265:
        return 0.0
    if math.dist((x, y), (-0.8, 0.0)) <= 0.265:
        return 0.0
    if y >= -0.63:
        return 0.5

    center = (0.0, -0.63)
    top = (1.131 + 0.01, -0.63)
    bottom = (-1.131 - 0.01, -0.63)
    angle_y = -0.63 - math.sin(math.radians(60.0)) * 0.70 / 2.0 - 0.01
    angle1 = (1.131 - math.cos(math.radians(60.0)) * 0.70 / 2.0 + 0.01, angle_y)
    angle2 = (0.70 / 2.0 + 0.01, -1.305)
    angle3 = (-(0.70 / 2.0 + 0.01), -1.305)
    angle4 = (-1.131 + math.cos(math.radians(60.0)) * 0.70 / 2.0 - 0.01, angle_y)
    inside = (
        in_triangle((x, y), center, top, angle1)
        or in_triangle((x, y), center, angle2, angle3)
        or in_triangle((x, y), center, angle1, angle2)
        or in_triangle((x, y), center, angle3, angle4)
        or in_triangle((x, y), center, angle4, bottom)
    )
    return 1.0 if inside else 0.5


def test_experiment2_floor_geometry_matches_independent_cpp_translation():
    _, model = load_foraging_models()
    assert model.FOOD_CENTERS == ((0.8, 0.0), (-0.8, 0.0))
    assert model.FOOD_RADIUS == 0.265
    assert model.NEST_LIMIT_Y == -0.63

    generator = torch.Generator().manual_seed(22026)
    points = torch.empty((20_000, 2), dtype=torch.float64).uniform_(
        -1.4, 1.4, generator=generator
    )
    actual = model.ground_scalar(points)
    expected = torch.tensor(
        [scalar_floor(float(x), float(y)) for x, y in points.tolist()],
        dtype=torch.float64,
    )
    torch.testing.assert_close(actual, expected, rtol=0.0, atol=0.0)

    boundaries = torch.tensor(
        [
            [0.0, -0.63],       # strict floor boundary: gray
            [0.0, -0.630001],   # just inside white floor
            [0.8 + 0.265, 0.0], # inclusive food radius
            [0.8 + 0.265001, 0.0],
        ],
        dtype=torch.float64,
    )
    assert model.ground_scalar(boundaries).tolist() == [0.5, 1.0, 0.0, 0.5]
    assert model.score_nest_membership(boundaries).tolist() == [True, True, False, False]


def test_foraging2_update_matches_scalar_poststep_over_many_ticks():
    _, model = load_foraging_models()
    envs, robots, steps = 9, 3, 500
    generator = torch.Generator().manual_seed(202602)
    carrying = torch.zeros((envs, robots), dtype=torch.bool)
    reference = [[False for _ in range(robots)] for _ in range(envs)]
    vector_deliveries = torch.zeros(envs, dtype=torch.long)
    scalar_deliveries = [0 for _ in range(envs)]

    for step_index in range(steps):
        positions = torch.empty((envs, robots, 2), dtype=torch.float64).uniform_(
            -1.2, 1.2, generator=generator
        )
        # Guaranteed pickup/delivery traffic in addition to random encounters.
        positions[0, 0] = torch.tensor([0.8, 0.0], dtype=torch.float64) if step_index % 2 == 0 else torch.tensor([0.0, -0.8], dtype=torch.float64)
        positions[1, 1] = torch.tensor([-0.8, 0.0], dtype=torch.float64) if step_index % 3 == 0 else positions[1, 1]
        positions[2, 2] = torch.tensor([0.0, -0.63], dtype=torch.float64) if step_index % 3 == 1 else positions[2, 2]

        result = model.update_carrying_state(
            positions,
            carrying,
            model.FOOD_CENTERS,
            model.FOOD_RADIUS,
            model.NEST_LIMIT_Y,
        )
        vector_deliveries += result.delivery_mask.sum(dim=1)
        carrying = result.carrying

        for env_id in range(envs):
            for robot_id in range(robots):
                x, y = (float(v) for v in positions[env_id, robot_id])
                if math.dist((x, y), (0.8, 0.0)) <= 0.265:
                    reference[env_id][robot_id] = True
                elif math.dist((x, y), (-0.8, 0.0)) <= 0.265:
                    reference[env_id][robot_id] = True
                elif y <= -0.63:
                    scalar_deliveries[env_id] += int(reference[env_id][robot_id])
                    reference[env_id][robot_id] = False

    assert vector_deliveries.tolist() == scalar_deliveries
    assert carrying.tolist() == reference


def test_foraging2_yaml_fsm_and_unified_cli_contract():
    config = yaml.safe_load(
        (ROOT / "configs" / "mercator" / "FOR2_mercator_cyclamen.yaml").read_text()
    )
    behavior_name, block = next(iter(config["behaviors"].items()))
    env = block["environment"]
    assert behavior_name == "FOR2_mercator_cyclamen_"
    assert block["max_steps"] == 18_000_000
    assert env["task"] == "SwarmACB-MercatorForaging2-v0"
    assert env["num_envs"] == 5
    assert env["food_centers"] == [[0.8, 0.0], [-0.8, 0.0]]
    assert env["food_radius"] == 0.265
    assert env["nest_limit_y"] == -0.63
    assert env["light_position"] == [0.0, -2.0, 0.4]
    assert env["light_intensity"] == 1.0
    assert env["spawn_mode"] == "argos_uniform_disk_rejection"
    assert env["spawn_half_range"] == 1.2
    assert env["arena_side_length"] == 0.70

    parser = load_module(
        "mercator_chocolate_fsm_for2_under_test",
        ROOT / "scripts" / "mercator_chocolate_fsm.py",
    )
    fsm_path = (
        ROOT / "configs" / "mercator" / "fsms" /
        "fsm_mercator_foraging2_experiment2.txt"
    )
    assert hashlib.sha256(fsm_path.read_bytes()).hexdigest() == (
        "690840b19e0269fe4c57b9361dc6082a6a3e8008775ced8b5f6cbf66ce69a5e5"
    )
    fsms = parser.load_fsm_file(fsm_path)
    assert len(fsms) == 10
    assert [fsm.num_states for fsm in fsms] == [4, 4, 2, 4, 3, 2, 2, 2, 3, 2]
    assert fsms[0].states[0].parameter == 4.68
    assert fsms[1].states[2].parameter == 2.9
    for fsm in fsms:
        for state in fsm.states:
            assert 0 <= state.module_id <= 5
            for transition in state.transitions:
                assert 0 <= transition.condition_id <= 5
                assert 0 <= transition.destination < fsm.num_states

    unified = (ROOT / "scripts" / "mercator_fsm.py").read_text()
    assert '"FOR2": MissionSpec(' in unified
    assert 'task_id="SwarmACB-MercatorForaging2-v0"' in unified
    assert 'config="configs/mercator/FOR2_mercator_cyclamen.yaml"' in unified
    assert 'fsm_mercator_foraging2_experiment2.txt' in unified
    assert 'camera_height=4.2' in unified
    assert 'camera_y=-3.0' in unified
    assert not (ROOT / "scripts" / "observe_mercator_foraging2_fsm.py").exists()
    assert not (ROOT / "scripts" / "score_mercator_foraging2_fsm.py").exists()


def test_foraging2_registration_env_source_and_visualizer_small_camera():
    for path in [
        *MISSION_DIR.glob("*.py"),
        ROOT / "scripts" / "mercator_fsm.py",
        ROOT / "scripts" / "visualize_mercator.py",
    ]:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    registration = (MISSION_DIR / "__init__.py").read_text()
    assert 'id="SwarmACB-MercatorForaging2-v0"' in registration
    assert "MercatorForaging2Env" in registration

    env_source = (MISSION_DIR / "mercator_foraging2_env.py").read_text()
    assert "build_argos_aac2_arena" in env_source
    assert "build_foraging2_environment_signature" in env_source
    assert "NEST_FLOOR_POLYGON" in env_source

    visualizer = (ROOT / "scripts" / "visualize_mercator.py").read_text()
    assert '"SwarmACB-MercatorForaging2-v0"' in visualizer
    assert '"SwarmACB-MercatorAggregation2-v0"' in visualizer


def test_unrelated_mercator_science_files_are_byte_identical():
    expected = {
        "scripts/mercator_chocolate_fsm.py": "c37ac48aecc205632167b09015be76ebe9d258d33e4c0311830bc33ea493289e",
        "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_foraging/mercator_foraging_env.py": "86c4051f2b7b4f601efb4f1de2de7265cba12f70786c089591780260beccbe92",
        "source/SwarmACB_isaac/SwarmACB_isaac/tasks/direct/missions/mercator_aggregation2/mercator_aggregation2_arena.py": "26a39a5f6ec2c13971f5ca6bab471b61b859ef04c266a836b92c1d68446c1152",
        "configs/mercator/fsms/fsm_mercator_aggregation_experiment1.txt": "9dc66421227458e1dac3362a27648adc70920ed496034180637e5d6179ffaa19",
        "configs/mercator/fsms/fsm_mercator_aggregation2_experiment2.txt": "9bd17a456d398fb4ec2e7f5c27191793d9e210007a4033de8b0339d5b7926aa6",
        "configs/mercator/fsms/fsm_mercator_foraging_experiment1.txt": "a0375020ea2139c6bd1b04c0842d744db67d855ddf28a8fd20bd8ae04f3a935a",
        "configs/mercator/fsms/fsm_mercator_grid_exploration_experiment1.txt": "51cea00eb09a944bd79f98bbe52d37c7b9014ebbfdfcdee0f57f94437829c885",
    }
    for relative, digest in expected.items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == digest


def load_foraging2_env_with_stubs():
    prefix = "SwarmACB_isaac.tasks.direct.missions"
    for name in list(sys.modules):
        if name.startswith(prefix + ".mercator_foraging") or name.startswith(
            prefix + ".mercator_aggregation"
        ) or name.startswith("SwarmACB_isaac.tasks.direct.mercator_light"):
            sys.modules.pop(name, None)

    for name, path in {
        "SwarmACB_isaac": SOURCE.parents[2],
        "SwarmACB_isaac.tasks": SOURCE.parents[1],
        "SwarmACB_isaac.tasks.direct": SOURCE,
        "SwarmACB_isaac.tasks.direct.mercator_light": SOURCE / "mercator_light",
        "SwarmACB_isaac.tasks.direct.missions": SOURCE / "missions",
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation": SOURCE / "missions" / "mercator_aggregation",
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2": SOURCE / "missions" / "mercator_aggregation2",
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging": SOURCE / "missions" / "mercator_foraging",
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging2": MISSION_DIR,
    }.items():
        ensure_package(name, path)

    ensure_package("isaaclab")
    sim = types.ModuleType("isaaclab.sim")
    sys.modules["isaaclab.sim"] = sim

    pxr = types.ModuleType("pxr")
    pxr.Gf = types.SimpleNamespace()
    pxr.UsdGeom = types.SimpleNamespace()
    sys.modules["pxr"] = pxr
    ensure_package("omni")
    omni = sys.modules["omni"]
    omni.usd = types.ModuleType("omni.usd")
    sys.modules["omni.usd"] = omni.usd

    load_module(
        "SwarmACB_isaac.tasks.direct.mercator_light.arena_geometry",
        SOURCE / "mercator_light" / "arena_geometry.py",
    )
    load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2.mercator_aggregation2_arena",
        SOURCE / "missions" / "mercator_aggregation2" / "mercator_aggregation2_arena.py",
    )

    parent_name = (
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation."
        "mercator_aggregation_env"
    )
    parent = types.ModuleType(parent_name)

    class FakeAggregationEnv:
        def _reset_idx(self, idx):
            self.completed_group_reward[idx] = self._episode_group_reward[idx]
            self._episode_group_reward[idx] = 0.0

    parent.MercatorAggregationEnv = FakeAggregationEnv
    sys.modules[parent_name] = parent

    cfg1_name = (
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging."
        "mercator_foraging_env_cfg"
    )
    cfg1 = types.ModuleType(cfg1_name)
    cfg1.MercatorForagingEnvCfg = type("MercatorForagingEnvCfg", (), {})
    sys.modules[cfg1_name] = cfg1
    load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging.mercator_foraging_model",
        SOURCE / "missions" / "mercator_foraging" / "mercator_foraging_model.py",
    )
    load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging.mercator_foraging_env",
        SOURCE / "missions" / "mercator_foraging" / "mercator_foraging_env.py",
    )

    cfg2_name = (
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging2."
        "mercator_foraging2_env_cfg"
    )
    cfg2 = types.ModuleType(cfg2_name)
    cfg2.MercatorForaging2EnvCfg = type("MercatorForaging2EnvCfg", (), {})
    sys.modules[cfg2_name] = cfg2
    load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging2.mercator_foraging2_model",
        MISSION_DIR / "mercator_foraging2_model.py",
    )
    return load_module(
        "SwarmACB_isaac.tasks.direct.missions.mercator_foraging2.mercator_foraging2_env",
        MISSION_DIR / "mercator_foraging2_env.py",
    )


def test_foraging2_environment_contract_without_isaac_runtime():
    module = load_foraging2_env_with_stubs()
    env = module.MercatorForaging2Env.__new__(module.MercatorForaging2Env)
    env.cfg = types.SimpleNamespace(
        food_centers=((0.8, 0.0), (-0.8, 0.0)),
        food_radius=0.265,
        nest_limit_y=-0.63,
        possible_agents=["Mercator_00", "Mercator_01", "Mercator_02"],
        arena_side_length=0.70,
        arena_wall_thickness=0.01,
        arena_wall_height=0.08,
    )
    env.device = torch.device("cpu")
    env.num_envs = 1
    env.agent_pos = torch.tensor([[[0.8, 0.0], [0.0, 0.0], [-0.8, 0.0]]])
    env._carrying_food = torch.zeros((1, 3), dtype=torch.bool)
    env._episode_pickups = torch.zeros(1)
    env._episode_group_reward = torch.zeros(1)
    env.completed_group_reward = torch.zeros(1)
    for name in (
        "last_n_black", "last_n_white", "last_deliveries", "last_pickups",
        "last_carrying", "last_in_food", "last_in_nest", "completed_deliveries",
        "completed_pickups", "completed_carrying",
    ):
        setattr(env, name, torch.zeros(1))

    rewards = env._get_rewards()
    assert rewards["Mercator_00"].tolist() == [0.0]
    assert env._carrying_food.tolist() == [[True, False, True]]
    assert env._episode_pickups.tolist() == [2.0]

    env.agent_pos = torch.tensor([[[0.0, -0.63], [0.0, 0.0], [0.0, -0.8]]])
    rewards = env._get_rewards()
    assert rewards["Mercator_00"].tolist() == [2.0]
    assert env._episode_group_reward.tolist() == [2.0]
    assert not bool(env._carrying_food.any())

    floor = env._ground_scalar_at(torch.tensor([[[0.0, -0.63], [0.0, -0.631]]]))
    assert floor.tolist() == [[0.5, 1.0]]
    arena = env._build_arena_geometry(env.cfg)
    assert len(arena.wall_centers) == 12
    assert arena.wall_side_length == 0.70

    env._reset_idx([0])
    assert env.completed_deliveries.tolist() == [2.0]
    assert env.completed_pickups.tolist() == [2.0]
    assert env._episode_group_reward.tolist() == [0.0]
