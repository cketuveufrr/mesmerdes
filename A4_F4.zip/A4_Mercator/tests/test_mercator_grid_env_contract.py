from __future__ import annotations

import importlib.util
from pathlib import Path
from types import ModuleType, SimpleNamespace
import sys

import torch


ROOT = Path(__file__).resolve().parents[1]
MISSION_DIR = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
    / "missions"
    / "mercator_grid_exploration"
)
PACKAGE = "SwarmACB_isaac.tasks.direct.missions.mercator_grid_exploration"


def package(name: str) -> ModuleType:
    module = sys.modules.get(name)
    if module is None:
        module = ModuleType(name)
        module.__path__ = []
        sys.modules[name] = module
    return module


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_env_with_stubs():
    for name in (
        "SwarmACB_isaac",
        "SwarmACB_isaac.tasks",
        "SwarmACB_isaac.tasks.direct",
        "SwarmACB_isaac.tasks.direct.missions",
        PACKAGE,
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation",
    ):
        package(name)

    isaaclab = package("isaaclab")
    sim = ModuleType("isaaclab.sim")
    isaaclab.sim = sim
    sys.modules["isaaclab.sim"] = sim

    parent_name = (
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation."
        "mercator_aggregation_env"
    )
    parent = ModuleType(parent_name)

    class FakeAggregationEnv:
        def _reset_idx(self, idx):
            self.completed_group_reward[idx] = self._episode_group_reward[idx]
            self._episode_group_reward[idx] = 0.0

    parent.MercatorAggregationEnv = FakeAggregationEnv
    sys.modules[parent_name] = parent

    cfg_name = f"{PACKAGE}.mercator_grid_exploration_env_cfg"
    cfg_module = ModuleType(cfg_name)
    cfg_module.MercatorGridExplorationEnvCfg = type(
        "MercatorGridExplorationEnvCfg", (), {}
    )
    sys.modules[cfg_name] = cfg_module

    load(
        f"{PACKAGE}.mercator_grid_exploration_model",
        MISSION_DIR / "mercator_grid_exploration_model.py",
    )
    return load(
        f"{PACKAGE}.mercator_grid_exploration_env",
        MISSION_DIR / "mercator_grid_exploration_env.py",
    )


def make_contract_env(env_class):
    env = env_class.__new__(env_class)
    env.cfg = SimpleNamespace(
        grid_arena_size=9.65,
        grid_size=10,
        possible_agents=["Mercator_00", "Mercator_01"],
    )
    env.device = torch.device("cpu")
    env.num_envs = 1
    env.agent_pos = torch.tensor([[[-4.0, -4.0], [4.0, 4.0]]])
    env._grid_ages = torch.zeros(1, 10, 10, dtype=torch.long)
    env._ever_visited = torch.zeros(1, 10, 10, dtype=torch.bool)
    env._episode_visited_cell_events = torch.zeros(1)
    env._episode_group_reward = torch.zeros(1)
    env.completed_group_reward = torch.zeros(1)
    env.last_n_black = torch.zeros(1)
    env.last_n_white = torch.zeros(1)
    env.last_grid_total_age = torch.zeros(1)
    env.last_grid_mean_age = torch.zeros(1)
    env.last_grid_max_age = torch.zeros(1)
    env.last_grid_visited_cells = torch.zeros(1)
    env.last_grid_coverage = torch.zeros(1)
    env.completed_grid_total_age = torch.zeros(1)
    env.completed_grid_mean_age = torch.zeros(1)
    env.completed_grid_max_age = torch.zeros(1)
    env.completed_grid_visited_cells = torch.zeros(1)
    env.completed_grid_coverage = torch.zeros(1)
    env.completed_grid_visit_events = torch.zeros(1)
    return env


def test_grid_environment_reward_and_reset_contract_without_isaac_runtime():
    module = load_env_with_stubs()
    env = make_contract_env(module.MercatorGridExplorationEnv)

    rewards = env._get_rewards()
    assert rewards["Mercator_00"].tolist() == [0.0]
    assert rewards["Mercator_01"].tolist() == [0.0]
    assert env.last_grid_total_age.tolist() == [0.0]
    assert env.last_grid_visited_cells.tolist() == [2.0]
    torch.testing.assert_close(env.last_grid_coverage, torch.tensor([0.02]))
    assert bool((env._grid_ages == 1).all())

    rewards = env._get_rewards()
    torch.testing.assert_close(rewards["Mercator_00"], torch.tensor([-0.98]))
    torch.testing.assert_close(env._episode_group_reward, torch.tensor([-0.98]))
    assert env.last_grid_total_age.tolist() == [98.0]
    torch.testing.assert_close(env.last_grid_mean_age, torch.tensor([0.98]))
    assert env.last_grid_max_age.tolist() == [1.0]
    assert env._episode_visited_cell_events.tolist() == [4.0]

    env._reset_idx([0])
    torch.testing.assert_close(env.completed_group_reward, torch.tensor([-0.98]))
    assert env.completed_grid_total_age.tolist() == [98.0]
    torch.testing.assert_close(env.completed_grid_mean_age, torch.tensor([0.98]))
    assert env.completed_grid_max_age.tolist() == [1.0]
    assert env.completed_grid_visited_cells.tolist() == [2.0]
    torch.testing.assert_close(env.completed_grid_coverage, torch.tensor([0.02]))
    assert env.completed_grid_visit_events.tolist() == [4.0]
    assert not bool(env._grid_ages.any())
    assert not bool(env._ever_visited.any())
    assert env._episode_visited_cell_events.tolist() == [0.0]


def test_grid_environment_ground_and_zone_contract():
    module = load_env_with_stubs()
    env = make_contract_env(module.MercatorGridExplorationEnv)
    points = torch.tensor([[[0.0, 0.0], [3.0, -2.0]]])
    assert env._ground_scalar_at(points).tolist() == [[0.5, 0.5]]
    black, white = env._zone_counts_from_centers()
    assert black.tolist() == [0.0]
    assert white.tolist() == [0.0]
