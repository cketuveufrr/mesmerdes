from __future__ import annotations

import importlib.util
from pathlib import Path
from types import ModuleType, SimpleNamespace
import sys

import torch

ROOT = Path(__file__).resolve().parents[1]
MISSION_DIR = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
    / "missions"
    / "mercator_foraging"
)
PACKAGE = "SwarmACB_isaac.tasks.direct.missions.mercator_foraging"


def package(name: str) -> ModuleType:
    module = sys.modules.get(name)
    if module is None:
        module = ModuleType(name)
        module.__path__ = []
        sys.modules[name] = module
    return module


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_env_with_stubs():
    for name in (
        "SwarmACB_isaac",
        "SwarmACB_isaac.tasks",
        "SwarmACB_isaac.tasks.direct",
        "SwarmACB_isaac.tasks.direct.missions",
        PACKAGE,
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation",
    ):
        package(name)

    isaaclab = package("isaaclab")
    sim = ModuleType("isaaclab.sim")
    isaaclab.sim = sim
    sys.modules["isaaclab.sim"] = sim

    pxr = ModuleType("pxr")
    pxr.Gf = SimpleNamespace()
    pxr.UsdGeom = SimpleNamespace()
    sys.modules["pxr"] = pxr

    omni = package("omni")
    omni.usd = ModuleType("omni.usd")
    sys.modules["omni.usd"] = omni.usd

    parent_name = (
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation."
        "mercator_aggregation_env"
    )
    parent = ModuleType(parent_name)

    class FakeAggregationEnv:
        def _reset_idx(self, idx):
            self.completed_group_reward[idx] = self._episode_group_reward[idx]
            self._episode_group_reward[idx] = 0.0

    parent.MercatorAggregationEnv = FakeAggregationEnv
    sys.modules[parent_name] = parent

    cfg_name = f"{PACKAGE}.mercator_foraging_env_cfg"
    cfg_module = ModuleType(cfg_name)
    cfg_module.MercatorForagingEnvCfg = type("MercatorForagingEnvCfg", (), {})
    sys.modules[cfg_name] = cfg_module

    load(f"{PACKAGE}.mercator_foraging_model", MISSION_DIR / "mercator_foraging_model.py")
    return load(f"{PACKAGE}.mercator_foraging_env", MISSION_DIR / "mercator_foraging_env.py")


def make_contract_env(env_class):
    env = env_class.__new__(env_class)
    env.cfg = SimpleNamespace(
        food_centers=((2.9, 0.0), (-2.9, 0.0)),
        food_radius=0.58,
        nest_limit_y=-2.35,
        possible_agents=["Mercator_00", "Mercator_01"],
    )
    env.device = torch.device("cpu")
    env.num_envs = 1
    env.agent_pos = torch.tensor([[[2.9, 0.0], [0.0, 0.0]]])
    env._carrying_food = torch.zeros((1, 2), dtype=torch.bool)
    env._episode_pickups = torch.zeros(1)
    env._episode_group_reward = torch.zeros(1)
    env.completed_group_reward = torch.zeros(1)
    env.last_n_black = torch.zeros(1)
    env.last_n_white = torch.zeros(1)
    env.last_deliveries = torch.zeros(1)
    env.last_pickups = torch.zeros(1)
    env.last_carrying = torch.zeros(1)
    env.last_in_food = torch.zeros(1)
    env.last_in_nest = torch.zeros(1)
    env.completed_deliveries = torch.zeros(1)
    env.completed_pickups = torch.zeros(1)
    env.completed_carrying = torch.zeros(1)
    return env


def test_environment_reward_and_reset_contract_without_isaac_runtime():
    module = load_env_with_stubs()
    env = make_contract_env(module.MercatorForagingEnv)

    rewards = env._get_rewards()
    assert rewards["Mercator_00"].tolist() == [0.0]
    assert rewards["Mercator_01"].tolist() == [0.0]
    assert env._carrying_food.tolist() == [[True, False]]
    assert env._episode_pickups.tolist() == [1.0]
    assert env.last_in_food.tolist() == [1.0]

    env.agent_pos = torch.tensor([[[0.0, -2.35], [0.0, 0.0]]])
    rewards = env._get_rewards()
    assert rewards["Mercator_00"].tolist() == [1.0]
    assert rewards["Mercator_01"].tolist() == [1.0]
    assert env._episode_group_reward.tolist() == [1.0]
    assert env._carrying_food.tolist() == [[False, False]]
    assert env.last_deliveries.tolist() == [1.0]

    env._reset_idx([0])
    assert env.completed_deliveries.tolist() == [1.0]
    assert env.completed_pickups.tolist() == [1.0]
    assert env.completed_carrying.tolist() == [0.0]
    assert env._episode_group_reward.tolist() == [0.0]
    assert env._episode_pickups.tolist() == [0.0]
    assert not bool(env._carrying_food.any())


def test_environment_ground_and_center_metrics_use_different_nest_rules():
    module = load_env_with_stubs()
    env = make_contract_env(module.MercatorForagingEnv)
    points = torch.tensor([[[0.0, -2.35], [0.0, -2.351]]])
    ground = env._ground_scalar_at(points)
    assert ground.tolist() == [[0.5, 1.0]]

    env.agent_pos = points
    on_food, in_scoring_nest = env._zone_counts_from_centers()
    assert on_food.tolist() == [0.0]
    assert in_scoring_nest.tolist() == [2.0]
