from __future__ import annotations

import importlib.util
from pathlib import Path
from types import ModuleType, SimpleNamespace
import sys

import torch


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT / "source" / "SwarmACB_isaac" / "SwarmACB_isaac" / "tasks" / "direct"
)
MISSION_DIR = SOURCE / "missions" / "mercator_grid_exploration2"
PACKAGE = "SwarmACB_isaac.tasks.direct.missions.mercator_grid_exploration2"


def package(name: str, path: Path | None = None) -> ModuleType:
    module = sys.modules.get(name)
    if module is None:
        module = ModuleType(name)
        module.__path__ = [] if path is None else [str(path)]
        sys.modules[name] = module
    return module


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_env_with_stubs():
    prefix = "SwarmACB_isaac.tasks.direct"
    for name in list(sys.modules):
        if name.startswith(prefix + ".missions.mercator_grid") or name.startswith(
            prefix + ".missions.mercator_aggregation2"
        ) or name.startswith(prefix + ".mercator_light"):
            sys.modules.pop(name, None)

    packages = {
        "SwarmACB_isaac": SOURCE.parents[2],
        "SwarmACB_isaac.tasks": SOURCE.parents[1],
        "SwarmACB_isaac.tasks.direct": SOURCE,
        "SwarmACB_isaac.tasks.direct.mercator_light": SOURCE / "mercator_light",
        "SwarmACB_isaac.tasks.direct.missions": SOURCE / "missions",
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2": SOURCE / "missions" / "mercator_aggregation2",
        "SwarmACB_isaac.tasks.direct.missions.mercator_grid_exploration": SOURCE / "missions" / "mercator_grid_exploration",
        PACKAGE: MISSION_DIR,
    }
    for name, path in packages.items():
        package(name, path)

    package("isaaclab")
    sim = ModuleType("isaaclab.sim")
    sys.modules["isaaclab.sim"] = sim

    load(
        "SwarmACB_isaac.tasks.direct.mercator_light.arena_geometry",
        SOURCE / "mercator_light" / "arena_geometry.py",
    )
    load(
        "SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2.mercator_aggregation2_arena",
        SOURCE / "missions" / "mercator_aggregation2" / "mercator_aggregation2_arena.py",
    )

    parent_name = (
        "SwarmACB_isaac.tasks.direct.missions.mercator_grid_exploration."
        "mercator_grid_exploration_env"
    )
    parent = ModuleType(parent_name)

    class FakeGridEnv:
        pass

    parent.MercatorGridExplorationEnv = FakeGridEnv
    sys.modules[parent_name] = parent

    cfg_name = f"{PACKAGE}.mercator_grid_exploration2_env_cfg"
    cfg_module = ModuleType(cfg_name)
    cfg_module.MercatorGridExploration2EnvCfg = type(
        "MercatorGridExploration2EnvCfg", (), {}
    )
    sys.modules[cfg_name] = cfg_module

    load(
        f"{PACKAGE}.mercator_grid_exploration2_model",
        MISSION_DIR / "mercator_grid_exploration2_model.py",
    )
    return load(
        f"{PACKAGE}.mercator_grid_exploration2_env",
        MISSION_DIR / "mercator_grid_exploration2_env.py",
    )


def make_env(env_class):
    env = env_class.__new__(env_class)
    env.cfg = SimpleNamespace(
        grid_arena_size=2.65,
        grid_size=10,
        possible_agents=["Mercator_00", "Mercator_01", "Mercator_02"],
        arena_side_length=0.70,
        arena_wall_thickness=0.01,
        arena_wall_height=0.08,
    )
    env.device = torch.device("cpu")
    env.num_envs = 1
    env.agent_pos = torch.tensor([[[-1.0, -1.0], [1.0, 1.0], [1.0, 1.0]]])
    env._grid_ages = torch.zeros(1, 10, 10, dtype=torch.long)
    env._ever_visited = torch.zeros(1, 10, 10, dtype=torch.bool)
    env._episode_visited_cell_events = torch.zeros(1)
    env._episode_group_reward = torch.zeros(1)
    env.last_n_black = torch.zeros(1)
    env.last_n_white = torch.zeros(1)
    env.last_grid_total_age = torch.zeros(1)
    env.last_grid_mean_age = torch.zeros(1)
    env.last_grid_max_age = torch.zeros(1)
    env.last_grid_visited_cells = torch.zeros(1)
    env.last_grid_coverage = torch.zeros(1)
    return env


def test_grid2_environment_reward_floor_and_small_arena_without_isaac():
    module = load_env_with_stubs()
    env = make_env(module.MercatorGridExploration2Env)

    rewards = env._get_rewards()
    assert rewards["Mercator_00"].tolist() == [0.0]
    assert rewards["Mercator_02"].tolist() == [0.0]
    assert env.last_grid_visited_cells.tolist() == [2.0]
    torch.testing.assert_close(env.last_grid_coverage, torch.tensor([0.02]))

    rewards = env._get_rewards()
    torch.testing.assert_close(rewards["Mercator_00"], torch.tensor([-0.98]))
    torch.testing.assert_close(env._episode_group_reward, torch.tensor([-0.98]))
    assert env.last_grid_total_age.tolist() == [98.0]
    assert env._episode_visited_cell_events.tolist() == [4.0]

    points = torch.tensor([[[0.0, 0.0], [1.2, -1.2]]])
    assert env._ground_scalar_at(points).tolist() == [[0.5, 0.5]]

    arena = env._build_arena_geometry(env.cfg)
    assert len(arena.wall_centers) == 12
    assert arena.wall_side_length == 0.70
    assert arena.inradius < 1.3123
    assert arena.circumradius < 1.5
