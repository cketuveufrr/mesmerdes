#!/usr/bin/env python3
"""Exporte les boxplots des campagnes FSM Mercator/tmercator.

Le script recherche récursivement les CSV ``*episodes*.csv`` produits par
``scripts/mercator_fsm.py`` et le lanceur de campagnes. Il crée, pour chaque
mission :

1. un boxplot des scores d'épisodes, par FSM et profil ;
2. un boxplot des scores moyens par run/seed, par FSM et profil ;
3. un boxplot des scores médians par run/seed, par FSM et profil ;
4. un boxplot global des moyennes par FSM, comparant les profils ;
5. un boxplot global des médianes par FSM, comparant les profils.

Par défaut, le script prend la campagne la plus récente située sous
``results/mercator_fsm_boxplots`` et écrit les sorties dans ``output``.

Exemples :

    python export_mercator_boxplots.py
    python export_mercator_boxplots.py --input results/mercator_fsm_boxplots/MACAMPAGNE
    python export_mercator_boxplots.py --campaign all
    python export_mercator_boxplots.py --missions AAC2,FOR2 --profiles tmercator
    python export_mercator_boxplots.py --format png,pdf --dpi 220
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
import re
import sys
from typing import Iterable, Sequence

import matplotlib

# Backend non interactif : fonctionne en SSH/headless.
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


MISSION_ORDER = ["AAC", "AAC2", "FOR", "FOR2", "GRID", "GRID2"]
MISSION_TITLES = {
    "AAC": "Aggregation — Experiment 1",
    "AAC2": "Aggregation — Experiment 2",
    "FOR": "Foraging — Experiment 1",
    "FOR2": "Foraging — Experiment 2",
    "GRID": "Grid Exploration — Experiment 1",
    "GRID2": "Grid Exploration — Experiment 2",
}
PROFILE_ORDER = ["mercator", "tmercator"]
PROFILE_LABELS = {
    "mercator": "Mercator",
    "tmercator": "tmercator",
}
PROFILE_LINESTYLES = ["-", "--", ":", "-."]
PROFILE_MARKERS = ["o", "s", "^", "D", "v", "P"]

EPISODE_FILE_RE = re.compile(r"episodes.*\.csv$", re.IGNORECASE)
RUN_NAME_RE = re.compile(
    r"^(AAC2?|FOR2?|GRID2?)_(mercator|tmercator)(?:_|$)", re.IGNORECASE
)


@dataclass(frozen=True)
class FigureRecord:
    mission: str
    statistic: str
    path: Path
    rows_used: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Génère les boxplots Mercator/tmercator à partir des CSV "
            "d'épisodes du lanceur de campagnes."
        )
    )
    parser.add_argument(
        "--input",
        default="results/mercator_fsm_boxplots",
        help=(
            "Campagne ou racine contenant les campagnes. "
            "Défaut: results/mercator_fsm_boxplots"
        ),
    )
    parser.add_argument(
        "--campaign",
        default="latest",
        help=(
            "Campagne à traiter lorsque --input est une racine: latest, all, "
            "ou nom exact d'un dossier. Défaut: latest"
        ),
    )
    parser.add_argument(
        "--output",
        default="output",
        help="Dossier racine des figures. Défaut: output",
    )
    parser.add_argument(
        "--missions",
        default="all",
        help="Missions séparées par des virgules, ou all.",
    )
    parser.add_argument(
        "--profiles",
        default="all",
        help="Profils séparés par des virgules, ou all.",
    )
    parser.add_argument(
        "--format",
        dest="formats",
        default="png",
        help="Formats séparés par des virgules: png,pdf,svg. Défaut: png",
    )
    parser.add_argument(
        "--dpi",
        type=int,
        default=220,
        help="Résolution des PNG. Défaut: 220",
    )
    parser.add_argument(
        "--title-suffix",
        default="",
        help="Texte facultatif ajouté à la fin des titres.",
    )
    parser.add_argument(
        "--include-partial",
        action="store_true",
        help=(
            "Inclut également les CSV qui ne contiennent pas toutes les FSM "
            "présentes dans les autres runs."
        ),
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Réduit les messages affichés.",
    )
    return parser.parse_args()


def split_selection(value: str, allowed: Sequence[str], kind: str) -> list[str]:
    if value.strip().lower() == "all":
        return list(allowed)
    result: list[str] = []
    allowed_upper = {item.upper(): item for item in allowed}
    allowed_lower = {item.lower(): item for item in allowed}
    for raw in value.split(","):
        raw = raw.strip()
        if not raw:
            continue
        if kind == "mission":
            canonical = allowed_upper.get(raw.upper())
        else:
            canonical = allowed_lower.get(raw.lower())
        if canonical is None:
            raise ValueError(
                f"{kind} inconnu {raw!r}; valeurs: {', '.join(allowed)}"
            )
        if canonical not in result:
            result.append(canonical)
    if not result:
        raise ValueError(f"sélection {kind} vide")
    return result


def split_formats(value: str) -> list[str]:
    allowed = {"png", "pdf", "svg"}
    formats: list[str] = []
    for raw in value.split(","):
        fmt = raw.strip().lower().lstrip(".")
        if not fmt:
            continue
        if fmt not in allowed:
            raise ValueError(
                f"format inconnu {fmt!r}; formats acceptés: png, pdf, svg"
            )
        if fmt not in formats:
            formats.append(fmt)
    if not formats:
        raise ValueError("aucun format de figure sélectionné")
    return formats


def is_campaign_dir(path: Path) -> bool:
    if not path.is_dir():
        return False
    if (path / "manifest.tsv").exists() or (path / "campaign_metadata.txt").exists():
        return True
    return any(
        child.is_file() and EPISODE_FILE_RE.search(child.name)
        for child in path.rglob("*.csv")
    )


def campaign_dirs(input_path: Path, campaign: str) -> list[Path]:
    if not input_path.exists():
        raise FileNotFoundError(f"dossier d'entrée introuvable: {input_path}")

    # Si l'utilisateur passe directement un dossier de campagne, on le garde.
    if (input_path / "manifest.tsv").exists() or (
        input_path / "campaign_metadata.txt"
    ).exists():
        return [input_path]

    direct_csvs = [
        p for p in input_path.glob("*.csv") if EPISODE_FILE_RE.search(p.name)
    ]
    if direct_csvs:
        return [input_path]

    candidates = [p for p in input_path.iterdir() if p.is_dir() and is_campaign_dir(p)]
    if not candidates:
        # Accepte aussi une arborescence personnalisée sans manifest.
        if any(EPISODE_FILE_RE.search(p.name) for p in input_path.rglob("*.csv")):
            return [input_path]
        raise FileNotFoundError(
            f"aucune campagne ni CSV d'épisodes trouvé sous {input_path}"
        )

    if campaign.lower() == "all":
        return sorted(candidates, key=lambda p: (p.stat().st_mtime, p.name))
    if campaign.lower() == "latest":
        return [max(candidates, key=lambda p: (p.stat().st_mtime, p.name))]

    selected = input_path / campaign
    if selected not in candidates and not is_campaign_dir(selected):
        names = ", ".join(sorted(p.name for p in candidates))
        raise FileNotFoundError(
            f"campagne {campaign!r} introuvable sous {input_path}. Disponibles: {names}"
        )
    return [selected]


def infer_mission_profile(path: Path) -> tuple[str | None, str | None]:
    for parent in [path.parent, *path.parents]:
        match = RUN_NAME_RE.match(parent.name)
        if match:
            return match.group(1).upper(), match.group(2).lower()
    lower = str(path).lower()
    profile = "tmercator" if "tmercator" in lower else None
    mission = None
    # Ordre long -> court pour ne pas confondre AAC2 avec AAC.
    for candidate in ["AAC2", "FOR2", "GRID2", "AAC", "FOR", "GRID"]:
        if re.search(rf"(^|[/_\-]){candidate.lower()}([/_\-]|$)", lower):
            mission = candidate
            break
    return mission, profile


def read_metadata(path: Path) -> dict[str, str]:
    metadata_path = path.parent / "metadata.txt"
    if not metadata_path.exists():
        return {}
    metadata: dict[str, str] = {}
    for line in metadata_path.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        metadata[key.strip()] = value.strip()
    return metadata


def normalize_mission(value: object) -> str | None:
    if value is None or pd.isna(value):
        return None
    text = str(value).strip().upper().replace("-", "").replace("_", "")
    aliases = {
        "AAC": "AAC",
        "AAC1": "AAC",
        "AGG": "AAC",
        "AGG1": "AAC",
        "AAC2": "AAC2",
        "AGG2": "AAC2",
        "FOR": "FOR",
        "FORAGING": "FOR",
        "FOR1": "FOR",
        "FOR2": "FOR2",
        "GRID": "GRID",
        "GRID1": "GRID",
        "GEX": "GRID",
        "GRID2": "GRID2",
        "GEX2": "GRID2",
    }
    return aliases.get(text)


def normalize_profile(value: object) -> str | None:
    if value is None or pd.isna(value):
        return None
    text = str(value).strip().lower().replace("-", "").replace("_", "")
    aliases = {
        "mercator": "mercator",
        "native": "mercator",
        "tmercator": "tmercator",
        "transferability": "tmercator",
    }
    return aliases.get(text)


def read_episode_csv(path: Path, campaign_name: str) -> pd.DataFrame:
    try:
        frame = pd.read_csv(path)
    except Exception as exc:
        raise RuntimeError(f"lecture impossible de {path}: {exc}") from exc

    required = {"fsm_index", "score"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(
            f"{path} ignoré: colonnes manquantes {sorted(missing)}"
        )
    if frame.empty:
        raise ValueError(f"{path} ignoré: CSV vide")

    inferred_mission, inferred_profile = infer_mission_profile(path)
    metadata = read_metadata(path)

    if "mission" in frame.columns:
        missions = frame["mission"].map(normalize_mission)
    else:
        missions = pd.Series([None] * len(frame), index=frame.index)
    metadata_mission = normalize_mission(metadata.get("mission"))
    mission = next(
        (
            value
            for value in [
                missions.dropna().iloc[0] if not missions.dropna().empty else None,
                metadata_mission,
                inferred_mission,
            ]
            if value is not None
        ),
        None,
    )

    if "robot_profile" in frame.columns:
        profiles = frame["robot_profile"].map(normalize_profile)
    else:
        profiles = pd.Series([None] * len(frame), index=frame.index)
    metadata_profile = normalize_profile(metadata.get("robot_profile"))
    profile = next(
        (
            value
            for value in [
                profiles.dropna().iloc[0] if not profiles.dropna().empty else None,
                metadata_profile,
                inferred_profile,
            ]
            if value is not None
        ),
        None,
    )

    if mission is None:
        raise ValueError(f"mission impossible à déterminer pour {path}")
    if profile is None:
        raise ValueError(f"profil impossible à déterminer pour {path}")

    result = frame.copy()
    result["mission"] = mission
    result["robot_profile"] = profile
    result["fsm_index"] = pd.to_numeric(result["fsm_index"], errors="coerce")
    result["score"] = pd.to_numeric(result["score"], errors="coerce")
    if "episode" in result.columns:
        result["episode"] = pd.to_numeric(result["episode"], errors="coerce")
    else:
        result["episode"] = np.arange(1, len(result) + 1)
    if "seed" in result.columns:
        result["seed"] = pd.to_numeric(result["seed"], errors="coerce")
    else:
        seed_value = metadata.get("seed", "0")
        result["seed"] = pd.to_numeric(seed_value, errors="coerce")

    result = result.dropna(subset=["fsm_index", "score", "seed"]).copy()
    result["fsm_index"] = result["fsm_index"].astype(int)
    result["seed"] = result["seed"].astype(int)
    result["campaign"] = campaign_name
    result["source_file"] = str(path.resolve())
    result["run_name"] = path.parent.name
    # Un identifiant de réplication : chaque CSV/seed/FSM est une observation
    # indépendante pour les boxplots de moyennes et médianes.
    result["replicate_id"] = (
        result["campaign"].astype(str)
        + "::"
        + result["run_name"].astype(str)
        + "::"
        + result["source_file"].astype(str)
        + "::seed="
        + result["seed"].astype(str)
    )
    return result


def discover_episode_files(campaigns: Sequence[Path]) -> list[tuple[Path, str]]:
    found: list[tuple[Path, str]] = []
    seen: set[Path] = set()
    for campaign in campaigns:
        for path in sorted(campaign.rglob("*.csv")):
            if not EPISODE_FILE_RE.search(path.name):
                continue
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            found.append((path, campaign.name))
    return found


def load_all_data(
    campaigns: Sequence[Path],
    missions: Sequence[str],
    profiles: Sequence[str],
    quiet: bool,
) -> tuple[pd.DataFrame, list[str]]:
    frames: list[pd.DataFrame] = []
    warnings: list[str] = []
    files = discover_episode_files(campaigns)
    if not files:
        raise FileNotFoundError("aucun fichier *episodes*.csv trouvé")

    for path, campaign_name in files:
        try:
            frame = read_episode_csv(path, campaign_name)
        except (ValueError, RuntimeError) as exc:
            warnings.append(str(exc))
            continue
        frame = frame[
            frame["mission"].isin(missions)
            & frame["robot_profile"].isin(profiles)
        ]
        if not frame.empty:
            frames.append(frame)
            if not quiet:
                print(
                    f"[lu] {path}: {len(frame)} épisodes, "
                    f"{frame['mission'].iloc[0]}/{frame['robot_profile'].iloc[0]}"
                )

    if not frames:
        details = "\n".join(f"  - {item}" for item in warnings)
        raise RuntimeError(
            "aucune donnée exploitable après filtrage"
            + (f"\nFichiers ignorés:\n{details}" if details else "")
        )

    data = pd.concat(frames, ignore_index=True, sort=False)
    data = data.drop_duplicates(
        subset=[
            "source_file",
            "mission",
            "robot_profile",
            "fsm_index",
            "seed",
            "episode",
            "score",
        ]
    ).reset_index(drop=True)
    return data, warnings


def profile_sort_key(profile: str) -> tuple[int, str]:
    try:
        return PROFILE_ORDER.index(profile), profile
    except ValueError:
        return len(PROFILE_ORDER), profile


def mission_sort_key(mission: str) -> tuple[int, str]:
    try:
        return MISSION_ORDER.index(mission), mission
    except ValueError:
        return len(MISSION_ORDER), mission


def common_fsm_filter(data: pd.DataFrame, include_partial: bool) -> pd.DataFrame:
    if include_partial or data.empty:
        return data
    groups = data.groupby(["mission", "robot_profile", "replicate_id"])["fsm_index"]
    fsm_sets = [set(values.astype(int).tolist()) for _, values in groups]
    if not fsm_sets:
        return data
    common = set.intersection(*fsm_sets)
    if not common:
        return data
    return data[data["fsm_index"].isin(sorted(common))].copy()


def run_level_summary(data: pd.DataFrame) -> pd.DataFrame:
    grouped = data.groupby(
        [
            "campaign",
            "run_name",
            "source_file",
            "replicate_id",
            "mission",
            "robot_profile",
            "seed",
            "fsm_index",
        ],
        as_index=False,
        sort=True,
    )
    return grouped["score"].agg(
        score_mean="mean",
        score_median="median",
        score_std="std",
        score_min="min",
        score_max="max",
        episodes="count",
    )


def aggregate_summary(data: pd.DataFrame, runs: pd.DataFrame) -> pd.DataFrame:
    episode_summary = (
        data.groupby(["mission", "robot_profile", "fsm_index"], as_index=False)[
            "score"
        ]
        .agg(
            episode_score_mean="mean",
            episode_score_median="median",
            episode_score_std="std",
            episode_score_min="min",
            episode_score_max="max",
            total_episodes="count",
        )
    )
    run_summary = (
        runs.groupby(["mission", "robot_profile", "fsm_index"], as_index=False)
        .agg(
            run_mean_mean=("score_mean", "mean"),
            run_mean_median=("score_mean", "median"),
            run_median_mean=("score_median", "mean"),
            run_median_median=("score_median", "median"),
            replicates=("replicate_id", "nunique"),
            seeds=("seed", "nunique"),
        )
    )
    return episode_summary.merge(
        run_summary,
        on=["mission", "robot_profile", "fsm_index"],
        how="outer",
    )


def configure_axes(ax: plt.Axes, mission: str, subtitle: str, suffix: str) -> None:
    title = f"{MISSION_TITLES.get(mission, mission)} — {subtitle}"
    if suffix:
        title += f" — {suffix}"
    ax.set_title(title)
    ax.set_xlabel("FSM")
    ax.set_ylabel("Score de mission (plus élevé = meilleur)")
    ax.grid(axis="y", linestyle=":", alpha=0.45)
    ax.axhline(0.0, linewidth=0.8, linestyle=":")


def grouped_boxplot(
    ax: plt.Axes,
    frame: pd.DataFrame,
    value_column: str,
    fsm_indices: Sequence[int],
    profiles: Sequence[str],
    show_points: bool,
) -> None:
    if not fsm_indices or not profiles:
        raise ValueError("boxplot impossible: catégorie vide")

    centers = np.arange(1, len(fsm_indices) + 1, dtype=float)
    total_width = min(0.78, 0.22 * max(1, len(profiles)))
    box_width = total_width / max(1, len(profiles))
    offsets = (
        np.arange(len(profiles), dtype=float) - (len(profiles) - 1) / 2.0
    ) * box_width

    legend_handles: list[Line2D] = []
    for profile_index, profile in enumerate(profiles):
        subset = frame[frame["robot_profile"] == profile]
        datasets: list[np.ndarray] = []
        positions: list[float] = []
        for fsm_position, fsm_index in zip(centers, fsm_indices):
            values = subset.loc[
                subset["fsm_index"] == int(fsm_index), value_column
            ].dropna().to_numpy(dtype=float)
            # Matplotlib refuse les datasets complètement vides. Un NaN permet
            # de garder l'alignement et produit simplement une boîte absente.
            datasets.append(values if len(values) else np.array([np.nan]))
            positions.append(float(fsm_position + offsets[profile_index]))

        linestyle = PROFILE_LINESTYLES[profile_index % len(PROFILE_LINESTYLES)]
        marker = PROFILE_MARKERS[profile_index % len(PROFILE_MARKERS)]
        box = ax.boxplot(
            datasets,
            positions=positions,
            widths=max(0.05, box_width * 0.82),
            manage_ticks=False,
            showmeans=True,
            meanline=False,
            showfliers=True,
            patch_artist=False,
        )
        for artist in box["boxes"]:
            artist.set_linestyle(linestyle)
            artist.set_linewidth(1.3)
        for artist in box["whiskers"] + box["caps"]:
            artist.set_linestyle(linestyle)
        for artist in box["medians"]:
            artist.set_linewidth(1.5)
        for artist in box["means"]:
            artist.set_marker(marker)

        if show_points:
            for pos, values in zip(positions, datasets):
                finite = values[np.isfinite(values)]
                if not len(finite):
                    continue
                if len(finite) == 1:
                    jitter = np.zeros(1)
                else:
                    jitter = np.linspace(
                        -box_width * 0.18, box_width * 0.18, len(finite)
                    )
                ax.plot(
                    np.full(len(finite), pos) + jitter,
                    finite,
                    linestyle="none",
                    marker=marker,
                    markersize=3.5,
                    alpha=0.6,
                )

        legend_handles.append(
            Line2D(
                [],
                [],
                linestyle=linestyle,
                marker=marker,
                label=PROFILE_LABELS.get(profile, profile),
            )
        )

    ax.set_xticks(centers)
    ax.set_xticklabels([str(index) for index in fsm_indices])
    ax.legend(handles=legend_handles, title="Profil", loc="best")


def profile_boxplot(
    ax: plt.Axes,
    frame: pd.DataFrame,
    value_column: str,
    profiles: Sequence[str],
) -> None:
    datasets = [
        frame.loc[frame["robot_profile"] == profile, value_column]
        .dropna()
        .to_numpy(dtype=float)
        for profile in profiles
    ]
    datasets = [values if len(values) else np.array([np.nan]) for values in datasets]
    positions = np.arange(1, len(profiles) + 1, dtype=float)
    box = ax.boxplot(
        datasets,
        positions=positions,
        widths=0.55,
        showmeans=True,
        meanline=False,
        patch_artist=False,
    )
    for artist in box["boxes"]:
        artist.set_linewidth(1.4)
    ax.set_xticks(positions)
    ax.set_xticklabels([PROFILE_LABELS.get(p, p) for p in profiles])
    ax.set_xlabel("Profil")
    ax.set_ylabel("Score de mission (plus élevé = meilleur)")
    ax.grid(axis="y", linestyle=":", alpha=0.45)
    ax.axhline(0.0, linewidth=0.8, linestyle=":")

    # Affiche chaque FSM comme point, utile même avec un seul run/seed.
    for position, values in zip(positions, datasets):
        finite = values[np.isfinite(values)]
        if not len(finite):
            continue
        jitter = (
            np.zeros(1)
            if len(finite) == 1
            else np.linspace(-0.11, 0.11, len(finite))
        )
        ax.plot(
            np.full(len(finite), position) + jitter,
            finite,
            linestyle="none",
            marker="o",
            markersize=4,
            alpha=0.7,
        )


def safe_stem(text: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9._-]+", "_", text.strip())
    return normalized.strip("_") or "figure"


def save_figure(
    fig: plt.Figure,
    base_path: Path,
    formats: Sequence[str],
    dpi: int,
) -> list[Path]:
    paths: list[Path] = []
    fig.tight_layout()
    for fmt in formats:
        path = base_path.with_suffix(f".{fmt}")
        kwargs = {"bbox_inches": "tight"}
        if fmt == "png":
            kwargs["dpi"] = dpi
        fig.savefig(path, **kwargs)
        paths.append(path)
    plt.close(fig)
    return paths


def generate_mission_figures(
    mission: str,
    episodes: pd.DataFrame,
    runs: pd.DataFrame,
    output_dir: Path,
    formats: Sequence[str],
    dpi: int,
    title_suffix: str,
) -> list[FigureRecord]:
    mission_dir = output_dir / safe_stem(mission)
    mission_dir.mkdir(parents=True, exist_ok=True)
    profiles = sorted(
        episodes["robot_profile"].dropna().unique().tolist(),
        key=profile_sort_key,
    )
    fsm_indices = sorted(episodes["fsm_index"].dropna().astype(int).unique().tolist())
    records: list[FigureRecord] = []

    # 1. Distribution brute des scores d'épisode.
    fig, ax = plt.subplots(figsize=(max(10.0, len(fsm_indices) * 1.05), 6.4))
    grouped_boxplot(
        ax,
        episodes,
        value_column="score",
        fsm_indices=fsm_indices,
        profiles=profiles,
        show_points=False,
    )
    configure_axes(ax, mission, "scores des épisodes par FSM", title_suffix)
    paths = save_figure(
        fig,
        mission_dir / f"{mission}_01_boxplot_scores_episodes_par_fsm",
        formats,
        dpi,
    )
    records.extend(
        FigureRecord(mission, "episode_scores_by_fsm", path, len(episodes))
        for path in paths
    )

    # 2. Une moyenne par run/seed/FSM, puis boxplot entre réplications.
    fig, ax = plt.subplots(figsize=(max(10.0, len(fsm_indices) * 1.05), 6.4))
    grouped_boxplot(
        ax,
        runs,
        value_column="score_mean",
        fsm_indices=fsm_indices,
        profiles=profiles,
        show_points=True,
    )
    configure_axes(ax, mission, "scores moyens par FSM", title_suffix)
    paths = save_figure(
        fig,
        mission_dir / f"{mission}_02_boxplot_scores_moyens_par_fsm",
        formats,
        dpi,
    )
    records.extend(
        FigureRecord(mission, "mean_scores_by_fsm", path, len(runs))
        for path in paths
    )

    # 3. Une médiane par run/seed/FSM.
    fig, ax = plt.subplots(figsize=(max(10.0, len(fsm_indices) * 1.05), 6.4))
    grouped_boxplot(
        ax,
        runs,
        value_column="score_median",
        fsm_indices=fsm_indices,
        profiles=profiles,
        show_points=True,
    )
    configure_axes(ax, mission, "scores médians par FSM", title_suffix)
    paths = save_figure(
        fig,
        mission_dir / f"{mission}_03_boxplot_scores_medians_par_fsm",
        formats,
        dpi,
    )
    records.extend(
        FigureRecord(mission, "median_scores_by_fsm", path, len(runs))
        for path in paths
    )

    # 4. Distribution des moyennes des FSM, profil contre profil.
    fig, ax = plt.subplots(figsize=(8.2, 6.2))
    profile_boxplot(ax, runs, "score_mean", profiles)
    title = f"{MISSION_TITLES.get(mission, mission)} — distribution des moyennes des FSM"
    if title_suffix:
        title += f" — {title_suffix}"
    ax.set_title(title)
    paths = save_figure(
        fig,
        mission_dir / f"{mission}_04_boxplot_moyennes_des_fsm_par_profil",
        formats,
        dpi,
    )
    records.extend(
        FigureRecord(mission, "fsm_means_by_profile", path, len(runs))
        for path in paths
    )

    # 5. Distribution des médianes des FSM, profil contre profil.
    fig, ax = plt.subplots(figsize=(8.2, 6.2))
    profile_boxplot(ax, runs, "score_median", profiles)
    title = f"{MISSION_TITLES.get(mission, mission)} — distribution des médianes des FSM"
    if title_suffix:
        title += f" — {title_suffix}"
    ax.set_title(title)
    paths = save_figure(
        fig,
        mission_dir / f"{mission}_05_boxplot_medianes_des_fsm_par_profil",
        formats,
        dpi,
    )
    records.extend(
        FigureRecord(mission, "fsm_medians_by_profile", path, len(runs))
        for path in paths
    )

    return records


def write_index(records: Sequence[FigureRecord], output_dir: Path) -> Path:
    path = output_dir / "index_boxplots.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["mission", "statistic", "path", "rows_used"],
        )
        writer.writeheader()
        for record in records:
            writer.writerow(
                {
                    "mission": record.mission,
                    "statistic": record.statistic,
                    "path": str(record.path),
                    "rows_used": record.rows_used,
                }
            )
    return path


def write_report(
    output_dir: Path,
    campaigns: Sequence[Path],
    episodes: pd.DataFrame,
    runs: pd.DataFrame,
    records: Sequence[FigureRecord],
    warnings: Sequence[str],
) -> Path:
    path = output_dir / "rapport_boxplots.txt"
    missions = sorted(episodes["mission"].unique().tolist(), key=mission_sort_key)
    profiles = sorted(
        episodes["robot_profile"].unique().tolist(), key=profile_sort_key
    )
    lines = [
        "EXPORT BOXPLOTS MERCATOR / TMERCATOR",
        "====================================",
        "",
        "Campagnes analysées:",
        *[f"  - {campaign.resolve()}" for campaign in campaigns],
        "",
        f"Épisodes chargés: {len(episodes)}",
        f"Réplications run/seed/FSM: {len(runs)}",
        f"Missions: {', '.join(missions)}",
        f"Profils: {', '.join(profiles)}",
        f"Figures exportées: {len(records)}",
        "",
        "Définition des statistiques:",
        "  - score épisode: chaque valeur de la colonne score",
        "  - score moyen: moyenne des épisodes pour un run/seed/FSM",
        "  - score médian: médiane des épisodes pour un run/seed/FSM",
        "  - graphiques globaux: distribution des valeurs des FSM par profil",
        "",
    ]
    if warnings:
        lines.extend(["Avertissements:", *[f"  - {item}" for item in warnings], ""])
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def main() -> int:
    args = parse_args()
    try:
        missions = split_selection(args.missions, MISSION_ORDER, "mission")
        profiles = split_selection(args.profiles, PROFILE_ORDER, "profile")
        formats = split_formats(args.formats)
        if args.dpi <= 0:
            raise ValueError("--dpi doit être strictement positif")

        input_path = Path(args.input).expanduser().resolve()
        campaigns = campaign_dirs(input_path, args.campaign)
        episodes, warnings = load_all_data(
            campaigns, missions, profiles, quiet=args.quiet
        )
        episodes = common_fsm_filter(episodes, args.include_partial)
        if episodes.empty:
            raise RuntimeError("aucune donnée après filtrage des FSM communes")
        runs = run_level_summary(episodes)
        aggregate = aggregate_summary(episodes, runs)

        campaign_label = (
            campaigns[0].name
            if len(campaigns) == 1
            else f"{len(campaigns)}_campagnes"
        )
        output_root = Path(args.output).expanduser().resolve()
        output_dir = output_root / safe_stem(campaign_label)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Tables réutilisables pour analyses complémentaires.
        episodes.to_csv(output_dir / "scores_episodes_consolides.csv", index=False)
        runs.to_csv(output_dir / "scores_moyens_medians_par_run_fsm.csv", index=False)
        aggregate.to_csv(output_dir / "resume_scores_par_mission_profil_fsm.csv", index=False)

        records: list[FigureRecord] = []
        present_missions = sorted(
            episodes["mission"].unique().tolist(), key=mission_sort_key
        )
        for mission in present_missions:
            mission_episodes = episodes[episodes["mission"] == mission].copy()
            mission_runs = runs[runs["mission"] == mission].copy()
            records.extend(
                generate_mission_figures(
                    mission=mission,
                    episodes=mission_episodes,
                    runs=mission_runs,
                    output_dir=output_dir,
                    formats=formats,
                    dpi=args.dpi,
                    title_suffix=args.title_suffix.strip(),
                )
            )
            if not args.quiet:
                print(
                    f"[ok] {mission}: "
                    f"{mission_episodes['fsm_index'].nunique()} FSM, "
                    f"{len(mission_episodes)} épisodes"
                )

        index_path = write_index(records, output_dir)
        report_path = write_report(
            output_dir, campaigns, episodes, runs, records, warnings
        )

        print("\nExport terminé.")
        print(f"Dossier : {output_dir}")
        print(f"Figures : {len(records)}")
        print(f"Index   : {index_path}")
        print(f"Rapport : {report_path}")
        if warnings:
            print(f"Avertissements : {len(warnings)} (voir le rapport)")
        return 0
    except (FileNotFoundError, RuntimeError, ValueError) as exc:
        print(f"ERREUR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
