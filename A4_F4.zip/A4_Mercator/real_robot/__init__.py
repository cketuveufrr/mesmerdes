"""Realistic Mercator pseudo-reality runtime for A4_Mercator.

The package contains the full USD robot asset, local RTX-LiDAR/TeraRanger
sensors, collision-enabled differential-drive execution, mission setup files,
and standalone evaluation tools used by :mod:`launch_real`.
"""

from .runtime.config import RealRobotConfig, load_real_robot_config

__all__ = ["RealRobotConfig", "load_real_robot_config"]
