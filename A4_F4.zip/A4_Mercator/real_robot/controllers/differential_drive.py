from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np
from isaacsim.core.experimental.prims import RigidPrim


def _to_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


def yaw_from_quat_wxyz(quat_wxyz: np.ndarray) -> float:
    """Extrait le yaw d'un quaternion Isaac/USD au format [w, x, y, z]."""
    w, x, y, z = [float(v) for v in quat_wxyz]
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return math.atan2(siny_cosp, cosy_cosp)


@dataclass
class DifferentialDriveCommand:
    """Commande différentielle exprimée en vitesses tangentielles m/s."""

    left_speed: float = 0.0
    right_speed: float = 0.0


class DifferentialDriveController:
    """
    Contrôleur cinématique différentiel appliqué à un `RigidPrim`.

    Formules :
        v = (v_left + v_right) / 2
        omega = (v_right - v_left) / track_width
    """

    def __init__(self, robot_path: str, track_width: float = 0.147):
        self.robot_path = robot_path
        self.track_width = float(track_width)
        self.command = DifferentialDriveCommand()
        self._robot: RigidPrim | None = None

    @property
    def robot(self) -> RigidPrim | None:
        return self._robot

    def start(self) -> None:
        self._robot = RigidPrim(paths=self.robot_path)
        if not self._robot.valid:
            raise RuntimeError(f"RigidPrim invalide ou introuvable : {self.robot_path}")
        self.stop()

    def set_speeds(self, left_speed: float, right_speed: float) -> None:
        self.command.left_speed = float(left_speed)
        self.command.right_speed = float(right_speed)

    def stop(self) -> None:
        self.command = DifferentialDriveCommand()
        if self._robot is not None and self._robot.valid:
            self._robot.set_velocities(
                linear_velocities=np.zeros((1, 3), dtype=np.float32),
                angular_velocities=np.zeros((1, 3), dtype=np.float32),
            )

    def apply(self) -> None:
        """Applique la commande courante. À appeler à chaque step physique."""
        if self._robot is None or not self._robot.valid:
            return

        _, orientations = self._robot.get_world_poses()
        quat = _to_numpy(orientations)[0]
        yaw = yaw_from_quat_wxyz(quat)

        v_left = self.command.left_speed
        v_right = self.command.right_speed
        v_linear = 0.5 * (v_left + v_right)
        omega = (v_right - v_left) / self.track_width

        linear_velocity = np.array(
            [[v_linear * math.cos(yaw), v_linear * math.sin(yaw), 0.0]],
            dtype=np.float32,
        )
        angular_velocity = np.array([[0.0, 0.0, omega]], dtype=np.float32)

        self._robot.set_velocities(
            linear_velocities=linear_velocity,
            angular_velocities=angular_velocity,
        )
