"""Isaac-independent Experiment-1 mission geometry and score updates.

These functions mirror the tensor mission models used by A4_Mercator but are
kept local so ``launch_real.py`` does not import Gymnasium or Isaac-Lab task
registration machinery merely to compute a score.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
import math

import torch


_SOURCE_MAX_DIM = 4.7957
_SOURCE_WALL_CENTER = 4.1562
_SOURCE_WALL_LENGTH = 2.57
_SOURCE_WALL_WIDTH = 0.01
_SOURCE_DIAGONAL_DROP = math.sin(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
DEFAULT_NEST_LIMIT_Y = -2.35
NEST_FLOOR_POLYGON = (
    (-_SOURCE_WALL_CENTER - _SOURCE_WALL_WIDTH, DEFAULT_NEST_LIMIT_Y),
    (_SOURCE_WALL_CENTER + _SOURCE_WALL_WIDTH, DEFAULT_NEST_LIMIT_Y),
    (
        _SOURCE_WALL_CENTER
        - math.cos(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
        + _SOURCE_WALL_WIDTH,
        DEFAULT_NEST_LIMIT_Y - _SOURCE_DIAGONAL_DROP - _SOURCE_WALL_WIDTH,
    ),
    (_SOURCE_WALL_LENGTH / 2.0 + _SOURCE_WALL_WIDTH, -_SOURCE_MAX_DIM),
    (-(_SOURCE_WALL_LENGTH / 2.0 + _SOURCE_WALL_WIDTH), -_SOURCE_MAX_DIM),
    (
        -_SOURCE_WALL_CENTER
        + math.cos(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
        - _SOURCE_WALL_WIDTH,
        DEFAULT_NEST_LIMIT_Y - _SOURCE_DIAGONAL_DROP - _SOURCE_WALL_WIDTH,
    ),
)


def food_membership(
    points: torch.Tensor,
    food_centers: Sequence[Sequence[float]],
    food_radius: float,
) -> torch.Tensor:
    centers = torch.as_tensor(food_centers, dtype=points.dtype, device=points.device)
    delta = points.unsqueeze(-2) - centers
    return delta.square().sum(dim=-1) <= float(food_radius) ** 2


def score_nest_membership(points: torch.Tensor, nest_limit_y: float) -> torch.Tensor:
    return points[..., 1] <= float(nest_limit_y)


@dataclass(frozen=True)
class ForagingStep:
    carrying: torch.Tensor
    pickup_mask: torch.Tensor
    delivery_mask: torch.Tensor
    in_food: torch.Tensor
    in_nest: torch.Tensor


def update_carrying_state(
    agent_positions: torch.Tensor,
    carrying: torch.Tensor,
    *,
    food_centers: Sequence[Sequence[float]],
    food_radius: float,
    nest_limit_y: float,
) -> ForagingStep:
    if agent_positions.shape[:-1] != carrying.shape or agent_positions.shape[-1] != 2:
        raise ValueError("agent_positions must match carrying and end with XY")
    carrying_before = carrying.to(dtype=torch.bool)
    in_food = food_membership(agent_positions, food_centers, food_radius).any(dim=-1)
    in_nest = score_nest_membership(agent_positions, nest_limit_y)
    pickup_mask = in_food & ~carrying_before
    carrying_after_pickup = carrying_before | in_food
    delivery_mask = in_nest & carrying_after_pickup
    return ForagingStep(
        carrying=carrying_after_pickup & ~delivery_mask,
        pickup_mask=pickup_mask,
        delivery_mask=delivery_mask,
        in_food=in_food,
        in_nest=in_nest,
    )


@dataclass(frozen=True)
class GridExplorationStep:
    ages: torch.Tensor
    reward: torch.Tensor
    total_age: torch.Tensor
    mean_age: torch.Tensor
    max_age: torch.Tensor
    visited_cells: torch.Tensor
    visited_mask: torch.Tensor


def update_grid_ages(
    ages: torch.Tensor,
    agent_positions: torch.Tensor,
    *,
    arena_size: float,
    grid_size: int,
) -> GridExplorationStep:
    size = int(grid_size)
    if ages.ndim != 3 or ages.shape[1:] != (size, size):
        raise ValueError(f"ages must have shape [env,{size},{size}]")
    if agent_positions.ndim != 3 or agent_positions.shape[0] != ages.shape[0] or agent_positions.shape[-1] != 2:
        raise ValueError("agent_positions must have shape [env,robot,2]")

    scaled = float(size) * (agent_positions / float(arena_size) + 0.5)
    x_index = torch.floor(scaled[..., 0]).to(torch.long)
    y_index = torch.floor(scaled[..., 1]).to(torch.long)
    valid = (
        (x_index >= 0)
        & (x_index < size)
        & (y_index >= 0)
        & (y_index < size)
    )
    linear = (x_index * size + y_index).clamp(0, size * size - 1)
    visit_counts = torch.zeros(
        ages.shape[0], size * size, dtype=torch.long, device=ages.device
    )
    visit_counts.scatter_add_(1, linear, valid.to(torch.long))
    visited_mask = visit_counts.view(ages.shape[0], size, size) > 0
    reset_ages = torch.where(visited_mask, torch.zeros_like(ages), ages)
    total_age = reset_ages.sum(dim=(1, 2))
    mean_age = total_age.to(torch.float32) / float(size * size)
    return GridExplorationStep(
        ages=reset_ages + 1,
        reward=-mean_age,
        total_age=total_age.to(torch.float32),
        mean_age=mean_age,
        max_age=reset_ages.amax(dim=(1, 2)).to(torch.float32),
        visited_cells=visited_mask.sum(dim=(1, 2)).to(torch.float32),
        visited_mask=visited_mask,
    )
