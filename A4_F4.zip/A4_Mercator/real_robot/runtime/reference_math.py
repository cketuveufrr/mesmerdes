"""Isaac-independent control-law reference for the realistic Mercator.

The realistic runtime and the parity tests share these functions.  Keeping the
canonical module equations here avoids a silent divergence between tests and
the code that drives the full USD robot.
"""

from __future__ import annotations

import math
from typing import Iterable

import numpy as np


TAU = 2.0 * math.pi
_EPS = 1.0e-12


def wheels_from_vector_np(
    dx: float,
    dy: float,
    max_speed: float,
) -> tuple[float, float]:
    """Port of AutoMoDe ``ComputeWheelsVelocityFromVector``.

    ``dx`` points forward and ``dy`` points left in the robot frame.
    """

    dx = float(dx)
    dy = float(dy)
    if not math.isfinite(dx) or not math.isfinite(dy):
        return 0.0, 0.0
    if abs(dx) <= _EPS and abs(dy) <= _EPS:
        return 0.0, 0.0

    angle = math.atan2(dy, dx) % TAU
    cos_a = math.cos(angle)
    if angle < math.pi:
        left, right = cos_a, 1.0
    else:
        left, right = 1.0, cos_a

    factor = float(max_speed) / max(abs(left), abs(right), _EPS)
    return float(factor * left), float(factor * right)


def forward_fallback(
    vector: Iterable[float],
    threshold: float = 0.10,
) -> np.ndarray:
    value = np.asarray(vector, dtype=np.float64).reshape(2)
    norm = float(np.linalg.norm(value))
    if not math.isfinite(norm) or norm < float(threshold):
        return np.asarray([1.0, 0.0], dtype=np.float64)
    return value


def canonical_target_vector(
    module_id: int,
    *,
    proximity_xy: Iterable[float] = (0.0, 0.0),
    beacon_unit_xy: Iterable[float] = (0.0, 0.0),
    neighbor_base_xy: Iterable[float] = (0.0, 0.0),
    phototaxis_proximity_gain: float = 5.0,
    anti_phototaxis_proximity_gain: float = 5.0,
    attraction_proximity_gain: float = 6.0,
    repulsion_proximity_gain: float = 5.0,
    attraction_alpha: float = 5.0,
    repulsion_alpha: float = 5.0,
    fallback_threshold: float = 0.10,
) -> np.ndarray:
    """Return the canonical target vector for deterministic modules 1..5.

    ``neighbor_base_xy`` is the reference-model vector constructed with
    ``alpha=1`` and distance expressed in centimetres.  The Mercator C++
    repulsion behavior asks the DAO for an already scaled vector and multiplies
    it by ``-rep`` once more, hence the ``-rep**2`` factor.
    """

    module_id = int(module_id)
    proximity = np.asarray(proximity_xy, dtype=np.float64).reshape(2)
    beacon = np.asarray(beacon_unit_xy, dtype=np.float64).reshape(2)
    neighbor = np.asarray(neighbor_base_xy, dtype=np.float64).reshape(2)

    if module_id == 1:  # stop
        return np.zeros(2, dtype=np.float64)
    if module_id == 2:  # phototaxis
        raw = beacon - float(phototaxis_proximity_gain) * proximity
    elif module_id == 3:  # anti-phototaxis
        raw = -beacon - float(anti_phototaxis_proximity_gain) * proximity
    elif module_id == 4:  # attraction
        raw = float(attraction_alpha) * neighbor - float(attraction_proximity_gain) * proximity
    elif module_id == 5:  # repulsion
        raw = -(float(repulsion_alpha) ** 2) * neighbor - float(repulsion_proximity_gain) * proximity
    else:
        raise ValueError(f"canonical_target_vector supports deterministic modules 1..5, got {module_id}")
    return forward_fallback(raw, fallback_threshold)


def canonical_module_wheels(
    module_id: int,
    *,
    proximity_xy: Iterable[float] = (0.0, 0.0),
    beacon_unit_xy: Iterable[float] = (0.0, 0.0),
    neighbor_base_xy: Iterable[float] = (0.0, 0.0),
    max_speed: float = 0.30,
    phototaxis_proximity_gain: float = 5.0,
    anti_phototaxis_proximity_gain: float = 5.0,
    attraction_proximity_gain: float = 6.0,
    repulsion_proximity_gain: float = 5.0,
    attraction_alpha: float = 5.0,
    repulsion_alpha: float = 5.0,
    fallback_threshold: float = 0.10,
) -> tuple[float, float]:
    module_id = int(module_id)
    if module_id == 1:
        return 0.0, 0.0
    target = canonical_target_vector(
        module_id,
        proximity_xy=proximity_xy,
        beacon_unit_xy=beacon_unit_xy,
        neighbor_base_xy=neighbor_base_xy,
        phototaxis_proximity_gain=phototaxis_proximity_gain,
        anti_phototaxis_proximity_gain=anti_phototaxis_proximity_gain,
        attraction_proximity_gain=attraction_proximity_gain,
        repulsion_proximity_gain=repulsion_proximity_gain,
        attraction_alpha=attraction_alpha,
        repulsion_alpha=repulsion_alpha,
        fallback_threshold=fallback_threshold,
    )
    return wheels_from_vector_np(target[0], target[1], max_speed)


def expected_horizontal_hits(
    *,
    tower_diameter_m: float,
    center_distance_m: float,
    samples_per_second: float,
    scan_rate_hz: float,
) -> float:
    """Ideal horizontal LiDAR returns on a circular tower cross-section."""

    radius = 0.5 * float(tower_diameter_m)
    distance = float(center_distance_m)
    if radius <= 0.0 or distance <= radius:
        raise ValueError("Expected 0 < tower radius < center distance")
    samples_per_turn = float(samples_per_second) / float(scan_rate_hz)
    angular_width = 2.0 * math.asin(radius / distance)
    return samples_per_turn * angular_width / TAU
