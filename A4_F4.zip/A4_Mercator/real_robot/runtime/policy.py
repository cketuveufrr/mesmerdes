from __future__ import annotations

from pathlib import Path
from typing import Any

import torch


def load_checkpoint(path: str | Path, map_location: Any = "cpu") -> dict[str, Any]:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {source}")
    try:
        value = torch.load(source, map_location=map_location, weights_only=False)
    except TypeError:
        value = torch.load(source, map_location=map_location)
    if not isinstance(value, dict):
        raise TypeError(f"Checkpoint must contain a dictionary, got {type(value).__name__}")
    return value


def checkpoint_raw_obs_dim(checkpoint: dict[str, Any]) -> int:
    if bool(checkpoint.get("previous_state_actor_only", False)) or int(
        checkpoint.get("cyclamen_ps_version", 0)
    ) > 0:
        return int(checkpoint.get("raw_obs_dim", 2))
    return int(checkpoint.get("obs_dim", 2))


class CheckpointPolicy:
    """Standalone actor-only playback for POCA and fixed-option checkpoints."""

    def __init__(
        self,
        checkpoint: dict[str, Any],
        *,
        num_agents: int,
        device: torch.device | str,
        deterministic: bool,
    ) -> None:
        from SwarmACB_isaac.tasks.direct.agents.poca_networks import (
            Actor,
            DiscreteActor,
            RecurrentDiscreteActor,
            checkpoint_memory_size,
        )
        from SwarmACB_isaac.tasks.direct.agents.option_critic_networks import (
            FixedOptionManager,
        )

        self.checkpoint = checkpoint
        self.device = torch.device(device)
        self.num_agents = int(num_agents)
        self.deterministic = bool(deterministic)
        self.trainer_type = str(checkpoint.get("trainer_type", "poca"))
        self.discrete = bool(checkpoint.get("discrete", False))
        self.recurrent = bool(checkpoint.get("recurrent", False))
        self.hidden_dim = int(checkpoint.get("hidden_dim", 256))
        self.num_layers = int(checkpoint.get("num_layers", 2))
        self.num_actions = int(checkpoint.get("num_actions", 6))
        self.num_options = int(checkpoint.get("num_options", self.num_actions))
        self.act_dim = int(checkpoint.get("act_dim", 2))
        self.memory_size = int(checkpoint_memory_size(checkpoint))
        self.cyclamen_ps = bool(checkpoint.get("previous_state_actor_only", False)) or int(
            checkpoint.get("cyclamen_ps_version", 0)
        ) > 0
        self.raw_obs_dim = checkpoint_raw_obs_dim(checkpoint)
        self.actor_obs_dim = int(checkpoint.get("obs_dim", self.raw_obs_dim))

        if self.cyclamen_ps:
            try:
                from poca_alt.poca_opti_ps.poca_networks import (
                    PreviousStateRecurrentDiscreteActor,
                )
            except ImportError as exc:
                raise ImportError(
                    "Cyclamen-PS playback requires poca_alt/poca_opti_ps at project root"
                ) from exc
            if not self.discrete or not self.recurrent:
                raise ValueError("Cyclamen-PS checkpoint must be recurrent and discrete")
            expected = self.raw_obs_dim + self.num_actions
            if self.actor_obs_dim != expected:
                raise ValueError(
                    f"Cyclamen-PS obs_dim={self.actor_obs_dim}; expected {expected}"
                )
            self.model = PreviousStateRecurrentDiscreteActor(
                raw_obs_dim=self.raw_obs_dim,
                num_actions=self.num_actions,
                hidden=self.hidden_dim,
                num_layers=self.num_layers,
                memory_size=self.memory_size,
            ).to(self.device)
            self.model.load_state_dict(checkpoint["actor"], strict=True)
            self.memory_h, self.memory_c = self.model.initial_state(
                self.num_agents, self.device
            )
            self.previous_module = torch.zeros(
                self.num_agents,
                self.num_actions,
                dtype=torch.float32,
                device=self.device,
            )
            self.current_options = None
        elif self.trainer_type == "option_critic":
            self.model = FixedOptionManager(
                self.raw_obs_dim,
                self.num_options,
                self.hidden_dim,
                self.num_layers,
                self.memory_size,
            ).to(self.device)
            self.model.load_state_dict(checkpoint["manager"], strict=True)
            self.memory_h, self.memory_c = self.model.initial_state(
                self.num_agents, self.device
            )
            self.current_options = torch.full(
                (self.num_agents,), -1, dtype=torch.long, device=self.device
            )
            self.previous_module = None
        elif self.discrete:
            if self.recurrent:
                self.model = RecurrentDiscreteActor(
                    self.raw_obs_dim,
                    self.num_actions,
                    self.hidden_dim,
                    self.num_layers,
                    self.memory_size,
                ).to(self.device)
                self.memory_h, self.memory_c = self.model.initial_state(
                    self.num_agents, self.device
                )
            else:
                self.model = DiscreteActor(
                    self.raw_obs_dim,
                    self.num_actions,
                    self.hidden_dim,
                    self.num_layers,
                ).to(self.device)
                self.memory_h = self.memory_c = None
            self.model.load_state_dict(checkpoint["actor"], strict=True)
            self.current_options = None
            self.previous_module = None
        else:
            if self.recurrent:
                raise ValueError("Recurrent continuous actor playback is unsupported")
            self.model = Actor(
                self.raw_obs_dim,
                self.act_dim,
                self.hidden_dim,
                self.num_layers,
            ).to(self.device)
            self.model.load_state_dict(checkpoint["actor"], strict=True)
            self.memory_h = self.memory_c = None
            self.current_options = None
            self.previous_module = None
        self.model.eval()

    @property
    def label(self) -> str:
        if self.trainer_type == "option_critic":
            action = f"options({self.num_options})"
        elif self.discrete:
            action = f"discrete({self.num_actions})"
        else:
            action = f"continuous({self.act_dim})"
        recurrence = "recurrent" if self.recurrent or self.trainer_type == "option_critic" else "feed-forward"
        prefix = "cyclamen_ps, " if self.cyclamen_ps else ""
        return f"{prefix}{self.trainer_type}, {recurrence}, {action}, obs={self.raw_obs_dim}"

    @torch.no_grad()
    def act(self, observation: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor | None]:
        obs = observation.to(device=self.device, dtype=torch.float32)
        if obs.shape != (self.num_agents, self.raw_obs_dim):
            raise ValueError(
                f"Observation shape must be {(self.num_agents, self.raw_obs_dim)}, got {tuple(obs.shape)}"
            )
        actor_obs = obs
        if self.cyclamen_ps:
            actor_obs = torch.cat((obs, self.previous_module), dim=-1)

        if self.trainer_type == "option_critic":
            option_logits, termination_logits, state = self.model.step(
                actor_obs, (self.memory_h, self.memory_c)
            )
            self.memory_h, self.memory_c = state[0].detach(), state[1].detach()
            distribution = torch.distributions.Categorical(logits=option_logits)
            proposed = distribution.probs.argmax(dim=-1) if self.deterministic else distribution.sample()
            force_new = self.current_options < 0
            current = self.current_options.clamp_min(0)
            beta_logits = termination_logits.gather(-1, current.unsqueeze(-1)).squeeze(-1)
            if self.deterministic:
                terminate = torch.sigmoid(beta_logits) > 0.5
            else:
                terminate = torch.distributions.Bernoulli(logits=beta_logits).sample().bool()
            self.current_options = torch.where(terminate | force_new, proposed, self.current_options)
            return self.current_options.clone(), self.current_options.clone()

        if self.discrete:
            if self.recurrent:
                logits, state = self.model.step(actor_obs, (self.memory_h, self.memory_c))
                self.memory_h, self.memory_c = state[0].detach(), state[1].detach()
                distribution = torch.distributions.Categorical(logits=logits)
            else:
                distribution = self.model.get_dist(actor_obs)
            actions = distribution.probs.argmax(dim=-1) if self.deterministic else distribution.sample()
            if self.cyclamen_ps:
                self.previous_module = torch.nn.functional.one_hot(
                    actions.long(), num_classes=self.num_actions
                ).to(torch.float32)
            return actions.long(), actions.long()

        distribution = self.model.get_dist(actor_obs)
        action = distribution.mean if self.deterministic else distribution.sample()
        # Same playback transform as launch_ps.py, followed by env max-speed scaling.
        normalized = action.clamp(-3.0, 3.0) / 3.0
        return normalized, None

    def reset(self) -> None:
        if self.current_options is not None:
            self.current_options.fill_(-1)
        if self.previous_module is not None:
            self.previous_module.zero_()
        if self.memory_h is not None:
            self.memory_h.zero_()
        if self.memory_c is not None:
            self.memory_c.zero_()
