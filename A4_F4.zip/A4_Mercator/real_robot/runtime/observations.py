from __future__ import annotations

import math
from typing import Any

import numpy as np

from .mission import MissionRuntime


def cyclamen_ztilde(neighbor_count: int) -> float:
    return float(math.tanh(0.5 * float(neighbor_count)))


def _proximity_values(record: Any) -> np.ndarray:
    frame = record.automode.explorer.read_terarangers()
    values = np.asarray(frame.proximities, dtype=np.float32).reshape(-1)
    if values.size != 8:
        raise ValueError(f"Expected 8 TeraRanger proximity values, got {values.size}")
    std = float(record.automode.proximity_noise_std)
    if std > 0.0:
        values = np.clip(values + record.rng.normal(0.0, std, size=values.shape), 0.0, 1.0)
    return values.astype(np.float32)


def _light_values(record: Any) -> np.ndarray:
    light = record.automode._read_light()
    values = np.asarray(light.values, dtype=np.float32).reshape(-1)
    if values.size != 8:
        raise ValueError(f"Expected 8 light-sector values, got {values.size}")
    return values


def _rab_projection(neighbors: Any) -> np.ndarray:
    vector = np.asarray(neighbors.attraction_vector_xy, dtype=np.float32).reshape(2)
    x, y = float(vector[0]), float(vector[1])
    return np.asarray([x, y, -x, -y], dtype=np.float32)


def build_actor_observations(
    world: Any,
    mission: MissionRuntime,
    obs_dim: int,
) -> tuple[np.ndarray, list[Any], np.ndarray, np.ndarray]:
    """Build decentralized observations from each robot's local sensors only.

    The reduced Mercator actor contract is exactly
    ``[ground_scalar, tanh(0.5 * local_lidar_neighbor_count)]``.
    The full contract matches the vectorized Mercator implementation:
    8 proximity + 8 light + ground + ztilde + 4 RAB projections = 22.
    """

    n = len(world.records)
    observations = np.zeros((n, int(obs_dim)), dtype=np.float32)
    neighbor_snapshots: list[Any] = []
    ground_values = np.zeros(n, dtype=np.float32)
    counts = np.zeros(n, dtype=np.int32)

    for index, record in enumerate(world.records):
        ground = mission.ground_scalar_from_sensor(record.ground_sensor.read(), record.rng)
        neighbors = world.noisy_neighbors(record)
        count = int(neighbors.neighbors_count)
        ztilde = cyclamen_ztilde(count)
        neighbor_snapshots.append(neighbors)
        ground_values[index] = ground
        counts[index] = count

        if int(obs_dim) == 2:
            observations[index] = (ground, ztilde)
        elif int(obs_dim) == 22:
            observations[index] = np.concatenate(
                (
                    _proximity_values(record),
                    _light_values(record),
                    np.asarray([ground, ztilde], dtype=np.float32),
                    _rab_projection(neighbors),
                )
            )
        else:
            raise ValueError(
                f"Unsupported Mercator actor observation width {obs_dim}; expected 2 or 22"
            )

    return observations, neighbor_snapshots, ground_values, counts
