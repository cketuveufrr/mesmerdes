from __future__ import annotations

import csv
from dataclasses import asdict
from datetime import datetime
import json
import math
from pathlib import Path
import statistics
import sys
import time
from typing import Any

import numpy as np
import torch

from .config import RealRobotConfig, load_real_robot_config
from .mission import MissionRuntime
from .observations import build_actor_observations
from .policy import CheckpointPolicy, checkpoint_raw_obs_dim, load_checkpoint
from .scene import RealRobotWorld


DEFAULT_FSMS = {
    "AAC": "configs/mercator/fsms/fsm_mercator_aggregation_experiment1.txt",
    "FOR": "configs/mercator/fsms/fsm_mercator_foraging_experiment1.txt",
    "GRID": "configs/mercator/fsms/fsm_mercator_grid_exploration_experiment1.txt",
}


class RealEvaluator:
    def __init__(self, args: Any, simulation_app: Any, project_root: Path):
        self.args = args
        self.simulation_app = simulation_app
        self.project_root = Path(project_root).resolve()
        self.cfg = load_real_robot_config(args.config)
        if self.cfg.mission_key != args.mission:
            raise ValueError(
                f"--mission {args.mission} does not match YAML mission {self.cfg.mission_key}"
            )
        self.device = torch.device(
            args.device
            if str(args.device).startswith("cuda") and torch.cuda.is_available()
            else "cpu"
        )
        self.world = RealRobotWorld(self.cfg, self.project_root, simulation_app)

    def close(self) -> None:
        self.world.close()

    @staticmethod
    def _seed_torch(seed: int) -> None:
        torch.manual_seed(int(seed))
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(int(seed))

    def _controller_label(self, checkpoint: Path | None, fsm_index: int | None) -> str:
        if checkpoint is not None:
            return f"checkpoint:{checkpoint.name}"
        return f"fsm:{fsm_index}"

    def _fsm_runtime(self, fsm: Any) -> Any:
        from mercator_chocolate_fsm import BatchedChocolateRuntime

        return BatchedChocolateRuntime(fsm, 1, self.cfg.robot.count, "cpu")

    def _apply_discrete_modules(
        self,
        module_ids: np.ndarray,
        neighbor_snapshots: list[Any],
        *,
        exploration_tau: np.ndarray | None = None,
        attraction_alpha: np.ndarray | None = None,
        repulsion_alpha: np.ndarray | None = None,
        state_entry: np.ndarray | None = None,
    ) -> None:
        for index, (record, module_id, neighbors) in enumerate(
            zip(self.world.records, module_ids.tolist(), neighbor_snapshots)
        ):
            if exploration_tau is not None:
                record.automode.exploration_tau = max(0, int(exploration_tau[index]))
            if attraction_alpha is not None:
                record.automode.attraction_alpha_parameter = float(attraction_alpha[index])
            if repulsion_alpha is not None:
                record.automode.repulsion_alpha_parameter = float(repulsion_alpha[index])
            if state_entry is not None and bool(state_entry[index]):
                # AutoMoDe resets the behavior object on every state entry, even
                # when two states use the same behavior module.
                record.automode.previous_module_id = -1
            info = record.automode.update(int(module_id), neighbors=neighbors)
            self.world.apply_wheels(record, info.left_speed, info.right_speed)
            record.last_module = int(module_id)

    def _apply_continuous_wheels(self, normalized: np.ndarray) -> None:
        if normalized.shape != (self.cfg.robot.count, 2):
            raise ValueError(
                f"Continuous actions must have shape {(self.cfg.robot.count, 2)}, "
                f"got {normalized.shape}"
            )
        for record, action in zip(self.world.records, normalized):
            left = float(action[0]) * self.cfg.robot.max_wheel_speed
            right = float(action[1]) * self.cfg.robot.max_wheel_speed
            self.world.apply_wheels(record, left, right)
            record.last_module = -1

    def run_checkpoint_episode(
        self,
        checkpoint_path: Path,
        checkpoint: dict[str, Any],
        policy: CheckpointPolicy,
        *,
        episode: int,
        seed: int,
    ) -> dict[str, Any]:
        self._seed_torch(seed)
        self.world.reset(seed)
        policy.reset()
        mission = MissionRuntime(self.cfg)
        decision_period = max(1, int(checkpoint.get("decision_period", 1)))
        module_counts = np.zeros(max(6, policy.num_actions), dtype=np.int64)
        current_action: torch.Tensor | None = None
        current_modules: torch.Tensor | None = None
        start = time.perf_counter()

        for step in range(1, self.cfg.control_steps + 1):
            obs_np, neighbors, _ground, _counts = build_actor_observations(
                self.world, mission, policy.raw_obs_dim
            )
            if current_action is None or (step - 1) % decision_period == 0:
                current_action, current_modules = policy.act(
                    torch.as_tensor(obs_np, dtype=torch.float32, device=self.device)
                )

            if current_modules is not None:
                ids = current_modules.detach().cpu().numpy().astype(np.int64)
                module_counts += np.bincount(ids, minlength=module_counts.size)
                self._apply_discrete_modules(ids, neighbors)
            else:
                normalized = current_action.detach().cpu().numpy().astype(np.float32)
                self._apply_continuous_wheels(normalized)

            self.world.step_physics()
            poses = self.world.poses()
            result = mission.step(poses)

            if self.args.print_every > 0 and (
                step == 1
                or step % self.args.print_every == 0
                or step == self.cfg.control_steps
            ):
                details = " ".join(f"{k}={v:.3f}" for k, v in result.fields.items())
                print(
                    f"[real {self.cfg.mission_key} checkpoint] "
                    f"episode={episode} step={step}/{self.cfg.control_steps} "
                    f"score={mission.score:.3f} {details}",
                    flush=True,
                )

            if self.args.observe and not self.simulation_app.is_running():
                break

        record = mission.episode_record(
            seed=seed,
            controller=self._controller_label(checkpoint_path, None),
            episode=episode,
        )
        record.update(
            {
                "checkpoint": str(checkpoint_path),
                "policy": policy.label,
                "deterministic": bool(self.args.deterministic),
                "decision_period": decision_period,
                "wall_seconds": time.perf_counter() - start,
                "module_counts": module_counts.tolist(),
            }
        )
        return record

    def run_fsm_episode(
        self,
        fsm: Any,
        *,
        fsm_index: int,
        episode: int,
        seed: int,
    ) -> dict[str, Any]:
        self._seed_torch(seed)
        self.world.reset(seed)
        mission = MissionRuntime(self.cfg)
        runtime = self._fsm_runtime(fsm)
        transition_count = 0
        state_counts = np.zeros(fsm.num_states, dtype=np.int64)
        module_counts = np.zeros(6, dtype=np.int64)
        start = time.perf_counter()

        for step in range(1, self.cfg.control_steps + 1):
            # FSM transition conditions and social modules share the exact same
            # local LiDAR snapshot on this control tick.
            _obs, neighbors, ground_values, counts = build_actor_observations(
                self.world, mission, 2
            )
            controller_step = runtime.step(
                torch.as_tensor(ground_values, dtype=torch.float32).unsqueeze(0),
                torch.as_tensor(counts, dtype=torch.float32).unsqueeze(0),
            )
            ids = controller_step.module_ids[0].cpu().numpy().astype(np.int64)
            states = controller_step.state_ids[0].cpu().numpy().astype(np.int64)
            entries = controller_step.state_entry_mask[0].cpu().numpy().astype(bool)
            tau = controller_step.exploration_tau[0].cpu().numpy()
            att = controller_step.attraction_alpha[0].cpu().numpy()
            rep = controller_step.repulsion_alpha[0].cpu().numpy()
            transition_count += int(controller_step.transitioned[0].sum().item())
            state_counts += np.bincount(states, minlength=fsm.num_states)
            module_counts += np.bincount(ids, minlength=6)
            self._apply_discrete_modules(
                ids,
                neighbors,
                exploration_tau=tau,
                attraction_alpha=att,
                repulsion_alpha=rep,
                state_entry=entries,
            )
            self.world.step_physics()
            result = mission.step(self.world.poses())

            if self.args.print_every > 0 and (
                step == 1
                or step % self.args.print_every == 0
                or step == self.cfg.control_steps
            ):
                details = " ".join(f"{k}={v:.3f}" for k, v in result.fields.items())
                print(
                    f"[real {self.cfg.mission_key} FSM {fsm_index}] "
                    f"episode={episode} step={step}/{self.cfg.control_steps} "
                    f"score={mission.score:.3f} transitions={transition_count} {details}",
                    flush=True,
                )

            if self.args.observe and not self.simulation_app.is_running():
                break

        record = mission.episode_record(
            seed=seed,
            controller=self._controller_label(None, fsm_index),
            episode=episode,
        )
        total_robot_steps = max(1, mission.steps * self.cfg.robot.count)
        record.update(
            {
                "fsm_index": fsm_index,
                "fsm": fsm.source,
                "transitions_total": transition_count,
                "transitions_per_robot": transition_count / self.cfg.robot.count,
                "module_counts": module_counts.tolist(),
                "wall_seconds": time.perf_counter() - start,
            }
        )
        for index, count in enumerate(state_counts):
            record[f"state_{index}_fraction"] = int(count) / total_robot_steps
        return record


def summarize_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    scores = [float(row["score"]) for row in records]
    std = statistics.stdev(scores) if len(scores) > 1 else 0.0
    summary: dict[str, Any] = {
        "mission": records[0]["mission"],
        "controller": records[0]["controller"],
        "episodes": len(records),
        "score_mean": statistics.mean(scores),
        "score_std": std,
        "score_ci95_half_width": 1.96 * std / math.sqrt(len(scores)) if scores else 0.0,
        "score_min": min(scores),
        "score_max": max(scores),
        "wall_seconds_mean": statistics.mean(float(row["wall_seconds"]) for row in records),
    }
    numeric_keys = set.intersection(
        *[
            {key for key, value in row.items() if isinstance(value, (int, float, bool))}
            for row in records
        ]
    )
    for key in sorted(numeric_keys):
        if key in {"episode", "seed", "steps", "score", "wall_seconds"}:
            continue
        summary[f"{key}_mean"] = statistics.mean(float(row[key]) for row in records)
    return summary


def write_outputs(
    output_dir: Path,
    records: list[dict[str, Any]],
    summaries: list[dict[str, Any]],
    cfg: RealRobotConfig,
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = f"{cfg.mission_key.lower()}_real_robot"
    episode_path = output_dir / f"{prefix}_episodes_{stamp}.csv"
    summary_csv = output_dir / f"{prefix}_summary_{stamp}.csv"
    summary_json = output_dir / f"{prefix}_summary_{stamp}.json"

    fields = sorted({key for row in records for key in row})
    with episode_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in records:
            writer.writerow(
                {
                    key: json.dumps(value) if isinstance(value, (list, dict)) else value
                    for key, value in row.items()
                }
            )

    summary_fields = sorted({key for row in summaries for key in row})
    with summary_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=summary_fields)
        writer.writeheader()
        writer.writerows(summaries)

    payload = {
        "configuration": asdict(cfg),
        "summaries": summaries,
    }
    payload["configuration"]["source_path"] = str(cfg.source_path)
    summary_json.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return [episode_path, summary_csv, summary_json]


def run(args: Any, simulation_app: Any, project_root: Path) -> int:
    root = Path(project_root).resolve()
    source_root = root / "source" / "SwarmACB_isaac"
    scripts_root = root / "scripts"
    real_root = root / "real_robot"
    for path in (source_root, scripts_root, real_root, root):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))

    evaluator = RealEvaluator(args, simulation_app, root)
    records: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    try:
        if args.checkpoint:
            checkpoint_path = Path(args.checkpoint).expanduser().resolve()
            checkpoint = load_checkpoint(checkpoint_path, "cpu")
            policy = CheckpointPolicy(
                checkpoint,
                num_agents=evaluator.cfg.robot.count,
                device=evaluator.device,
                deterministic=args.deterministic,
            )
            print(f"Checkpoint policy: {policy.label}")
            if policy.raw_obs_dim not in (2, 22):
                raise ValueError(
                    f"Checkpoint requires obs_dim={policy.raw_obs_dim}; the real Mercator runtime supports 2 or 22"
                )
            configured = str(evaluator.cfg.control.observation).strip().lower()
            if configured != "auto" and policy.raw_obs_dim != int(configured):
                raise ValueError(
                    f"Checkpoint obs_dim={policy.raw_obs_dim} does not match "
                    f"YAML control.observation={configured}"
                )
            for episode in range(1, args.episodes + 1):
                records.append(
                    evaluator.run_checkpoint_episode(
                        checkpoint_path,
                        checkpoint,
                        policy,
                        episode=episode,
                        seed=args.seed + episode - 1,
                    )
                )
            summaries.append(summarize_records(records))
        else:
            from mercator_chocolate_fsm import load_fsm_file

            fsm_path = Path(args.fsm_file or (root / DEFAULT_FSMS[args.mission])).resolve()
            fsms = load_fsm_file(fsm_path)
            if args.all_fsms:
                selected = list(enumerate(fsms, start=1))
            else:
                if not 1 <= args.fsm_index <= len(fsms):
                    raise ValueError(f"--fsm-index must be in [1, {len(fsms)}]")
                selected = [(args.fsm_index, fsms[args.fsm_index - 1])]
            for fsm_index, fsm in selected:
                fsm_records: list[dict[str, Any]] = []
                print(f"\nFSM {fsm_index}/{len(fsms)}\n{fsm.describe()}")
                for episode in range(1, args.episodes + 1):
                    row = evaluator.run_fsm_episode(
                        fsm,
                        fsm_index=fsm_index,
                        episode=episode,
                        seed=args.seed + episode - 1,
                    )
                    fsm_records.append(row)
                    records.append(row)
                summaries.append(summarize_records(fsm_records))

        for summary in summaries:
            print(
                f"{summary['controller']}: score={summary['score_mean']:.3f} "
                f"± {summary['score_std']:.3f} over {summary['episodes']} episode(s)"
            )
        if args.score:
            output_dir = Path(args.output_dir or evaluator.cfg.output.directory)
            if not output_dir.is_absolute():
                output_dir = root / output_dir
            paths = write_outputs(output_dir, records, summaries, evaluator.cfg)
            print("Outputs:")
            for path in paths:
                print(f"  {path}")
        return 0
    finally:
        evaluator.close()
