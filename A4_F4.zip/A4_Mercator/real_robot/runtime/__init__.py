"""Runtime components for the realistic Mercator evaluator."""
