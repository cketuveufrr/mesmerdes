from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from .config import RealRobotConfig
from .noise import apply_lidar_point_noise, apply_wheel_noise


TAU = 2.0 * math.pi


def quat_wxyz_from_yaw(yaw: float) -> tuple[float, float, float, float]:
    return math.cos(0.5 * yaw), 0.0, 0.0, math.sin(0.5 * yaw)


def yaw_from_wxyz(quat: Iterable[float]) -> float:
    w, x, y, z = [float(v) for v in quat]
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def dodecagon_vertices_from_side(side: float, n: int = 12) -> list[tuple[float, float]]:
    radius = float(side) / (2.0 * math.sin(math.pi / n))
    return [
        (
            radius * math.cos(TAU * i / n + math.pi / n),
            radius * math.sin(TAU * i / n + math.pi / n),
        )
        for i in range(n)
    ]


def inside_convex_polygon_with_margin(
    x: float,
    y: float,
    vertices: list[tuple[float, float]],
    margin: float,
) -> bool:
    for index, (ax, ay) in enumerate(vertices):
        bx, by = vertices[(index + 1) % len(vertices)]
        ex, ey = bx - ax, by - ay
        signed_distance = (ex * (y - ay) - ey * (x - ax)) / max(
            1.0e-12, math.hypot(ex, ey)
        )
        if signed_distance < float(margin):
            return False
    return True


def sample_collision_free_poses(
    cfg: RealRobotConfig,
    seed: int,
) -> list[tuple[float, float, float]]:
    if cfg.spawn.mode != "argos_uniform_box_rejection":
        raise ValueError(
            f"Unsupported real-robot spawn.mode={cfg.spawn.mode!r}; "
            "expected argos_uniform_box_rejection"
        )
    rng = np.random.default_rng(int(seed))
    vertices = dodecagon_vertices_from_side(cfg.arena.wall_side_length)
    boundary_margin = max(
        cfg.robot.collision_radius,
        0.5 * math.hypot(cfg.robot.length, cfg.robot.width),
    )
    pair_distance = 2.0 * cfg.robot.collision_radius + cfg.spawn.separation_margin_m
    poses: list[tuple[float, float, float]] = []
    for _robot_index in range(cfg.robot.count):
        for _ in range(cfg.spawn.max_trials):
            x = float(rng.uniform(-cfg.spawn.half_range, cfg.spawn.half_range))
            y = float(rng.uniform(-cfg.spawn.half_range, cfg.spawn.half_range))
            if not inside_convex_polygon_with_margin(x, y, vertices, boundary_margin):
                continue
            if any(math.hypot(x - px, y - py) < pair_distance for px, py, _ in poses):
                continue
            poses.append((x, y, float(rng.uniform(0.0, TAU))))
            break
        else:
            raise RuntimeError(
                f"Could not sample {cfg.robot.count} non-overlapping Mercators "
                f"after {cfg.spawn.max_trials} trials per robot"
            )
    return poses


@dataclass
class RobotRecord:
    name: str
    robot: Any
    paths: Any
    ground_sensor: Any
    automode: Any
    rng: np.random.Generator
    last_neighbors: Any | None = None
    last_module: int = 1
    last_wheels: tuple[float, float] = (0.0, 0.0)


class RealRobotWorld:
    """One collision-enabled Isaac scene containing the full Mercator swarm."""

    def __init__(self, cfg: RealRobotConfig, project_root: Path, simulation_app: Any):
        self.cfg = cfg
        self.project_root = Path(project_root).resolve()
        self.real_root = self.project_root / "real_robot"
        self.simulation_app = simulation_app
        self.records: list[RobotRecord] = []
        self._vertices = dodecagon_vertices_from_side(cfg.arena.wall_side_length)
        self._timeline = None
        self._build_world()

    # Isaac imports deliberately occur after SimulationApp creation.
    def _build_world(self) -> None:
        import carb
        import omni.timeline
        import omni.usd
        from pxr import Gf, PhysxSchema, Sdf, UsdGeom, UsdLux, UsdPhysics

        self.omni_usd = omni.usd
        self.UsdGeom = UsdGeom
        self.Gf = Gf
        self.Sdf = Sdf
        self.UsdPhysics = UsdPhysics

        settings = carb.settings.get_settings()
        settings.set("/app/player/useFixedTimeStepping", True)
        settings.set("/app/runLoops/main/rateLimitEnabled", False)
        settings.set("/app/runLoops/present/rateLimitEnabled", False)
        settings.set("/app/runLoops/rendering_0/rateLimitEnabled", False)

        stage = omni.usd.get_context().get_stage()
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
        stage.DefinePrim("/World", "Xform")
        stage.DefinePrim("/World/Arena", "Xform")
        stage.DefinePrim("/World/Arena/Walls", "Xform")
        stage.DefinePrim("/World/Arena/Floor", "Xform")
        stage.DefinePrim("/World/Robots", "Xform")
        physics_scene = UsdPhysics.Scene.Define(stage, "/World/physicsScene")
        physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene.GetPrim())
        physx_scene.CreateTimeStepsPerSecondAttr().Set(
            int(round(self.cfg.control.physics_frequency_hz))
        )

        self._create_floor_and_walls()
        self._create_mission_visuals()
        self._create_lights_and_camera()
        self.ground_map = self._build_ground_map()
        initial = sample_collision_free_poses(self.cfg, seed=0)
        self._spawn_robots(initial)

        self._timeline = omni.timeline.get_timeline_interface()
        self._timeline.set_play_every_frame(True)
        self._timeline.play()
        # Let referenced USD/PhysX prims settle before creating RigidPrim and
        # RTX annotator handles. The first public point-cloud read initializes
        # each annotator; only then can the warm-up rotations be meaningful.
        for _ in range(10):
            self.simulation_app.update()
        for record in self.records:
            record.automode.start()
            record.automode.stop_motion()
            record.automode.apply()
            record.automode.neighbor_detector.lidar.get_point_cloud()
        warmup_steps = max(
            30,
            int(
                math.ceil(
                    2.0
                    * self.cfg.control.physics_frequency_hz
                    / self.cfg.lidar.scan_rate_hz
                )
            ),
        )
        for _ in range(warmup_steps):
            self.simulation_app.update()
        for record in self.records:
            record.automode.stop_motion()
            record.automode.apply()

    def _set_color(self, prim: Any, rgb: tuple[float, float, float], opacity: float = 1.0) -> None:
        gprim = self.UsdGeom.Gprim(prim)
        gprim.CreateDisplayColorAttr([self.Gf.Vec3f(*[float(v) for v in rgb])])
        gprim.CreateDisplayOpacityAttr([float(opacity)])

    def _cube(
        self,
        path: str,
        center: tuple[float, float, float],
        size: tuple[float, float, float],
        color: tuple[float, float, float],
        *,
        collision: bool = False,
        yaw: float = 0.0,
    ) -> Any:
        stage = self.omni_usd.get_context().get_stage()
        cube = self.UsdGeom.Cube.Define(stage, path)
        cube.CreateSizeAttr(1.0)
        prim = cube.GetPrim()
        xform = self.UsdGeom.Xformable(prim)
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set(self.Gf.Vec3d(*[float(v) for v in center]))
        xform.AddOrientOp().Set(
            self.Gf.Quatf(
                float(math.cos(0.5 * yaw)),
                self.Gf.Vec3f(0.0, 0.0, float(math.sin(0.5 * yaw))),
            )
        )
        xform.AddScaleOp().Set(self.Gf.Vec3f(*[float(v) for v in size]))
        self._set_color(prim, color)
        if collision:
            self.UsdPhysics.CollisionAPI.Apply(prim)
        return prim

    def _disk(
        self,
        path: str,
        center: tuple[float, float],
        radius: float,
        color: tuple[float, float, float],
        z: float = 0.012,
        segments: int = 96,
    ) -> Any:
        stage = self.omni_usd.get_context().get_stage()
        cx, cy = center
        points = [self.Gf.Vec3f(float(cx), float(cy), float(z))]
        for index in range(segments):
            angle = TAU * index / segments
            points.append(
                self.Gf.Vec3f(
                    float(cx + radius * math.cos(angle)),
                    float(cy + radius * math.sin(angle)),
                    float(z),
                )
            )
        counts = [3] * segments
        indices: list[int] = []
        for index in range(segments):
            indices.extend([0, 1 + index, 1 + ((index + 1) % segments)])
        mesh = self.UsdGeom.Mesh.Define(stage, path)
        mesh.CreatePointsAttr(points)
        mesh.CreateFaceVertexCountsAttr(counts)
        mesh.CreateFaceVertexIndicesAttr(indices)
        mesh.CreateDoubleSidedAttr(True)
        self._set_color(mesh.GetPrim(), color)
        return mesh.GetPrim()

    def _polygon(
        self,
        path: str,
        vertices: Iterable[tuple[float, float]],
        color: tuple[float, float, float],
        z: float = 0.013,
    ) -> Any:
        stage = self.omni_usd.get_context().get_stage()
        verts = list(vertices)
        center = (
            sum(p[0] for p in verts) / len(verts),
            sum(p[1] for p in verts) / len(verts),
        )
        points = [self.Gf.Vec3f(float(center[0]), float(center[1]), float(z))]
        points.extend(self.Gf.Vec3f(float(x), float(y), float(z)) for x, y in verts)
        counts = [3] * len(verts)
        indices: list[int] = []
        for index in range(len(verts)):
            indices.extend([0, 1 + index, 1 + ((index + 1) % len(verts))])
        mesh = self.UsdGeom.Mesh.Define(stage, path)
        mesh.CreatePointsAttr(points)
        mesh.CreateFaceVertexCountsAttr(counts)
        mesh.CreateFaceVertexIndicesAttr(indices)
        mesh.CreateDoubleSidedAttr(True)
        self._set_color(mesh.GetPrim(), color)
        return mesh.GetPrim()

    def _create_floor_and_walls(self) -> None:
        cfg = self.cfg
        self._cube(
            "/World/Arena/Floor/GreyPhysicalFloor",
            (0.0, 0.0, -0.025),
            (cfg.arena.floor_size, cfg.arena.floor_size, 0.05),
            (0.45, 0.45, 0.45),
            collision=True,
        )
        for index, (ax, ay) in enumerate(self._vertices):
            bx, by = self._vertices[(index + 1) % len(self._vertices)]
            length = math.hypot(bx - ax, by - ay)
            self._cube(
                f"/World/Arena/Walls/OuterWall_{index:02d}",
                ((ax + bx) * 0.5, (ay + by) * 0.5, cfg.arena.wall_height * 0.5),
                (length, cfg.arena.wall_thickness, cfg.arena.wall_height),
                (0.70, 0.62, 0.42),
                collision=True,
                yaw=math.atan2(by - ay, bx - ax),
            )

    def _create_mission_visuals(self) -> None:
        mission = self.cfg.mission
        if self.cfg.mission_key == "AAC":
            assert mission.black_center is not None
            assert mission.white_center is not None
            assert mission.zone_radius is not None
            self._disk(
                "/World/Arena/Floor/BlackSpot",
                mission.black_center,
                mission.zone_radius,
                (0.02, 0.02, 0.02),
            )
            self._disk(
                "/World/Arena/Floor/WhiteSpot",
                mission.white_center,
                mission.zone_radius,
                (0.96, 0.96, 0.92),
                z=0.014,
            )
        elif self.cfg.mission_key == "FOR":
            assert mission.food_radius is not None
            for index, center in enumerate(mission.food_centers):
                self._disk(
                    f"/World/Arena/Floor/Food_{index}",
                    center,
                    mission.food_radius,
                    (0.02, 0.02, 0.02),
                )
            from .mission_models import NEST_FLOOR_POLYGON

            self._polygon(
                "/World/Arena/Floor/WhiteNest",
                NEST_FLOOR_POLYGON,
                (0.96, 0.96, 0.92),
                z=0.014,
            )

    def _create_lights_and_camera(self) -> None:
        from pxr import UsdLux

        stage = self.omni_usd.get_context().get_stage()
        lx, ly, lz = self.cfg.mission.light_position
        light = UsdLux.SphereLight.Define(stage, "/World/MissionLight")
        light.CreateIntensityAttr(5000.0)
        light.CreateRadiusAttr(0.10)
        xform = self.UsdGeom.Xformable(light.GetPrim())
        xform.AddTranslateOp().Set(self.Gf.Vec3d(float(lx), float(ly), float(lz)))
        sun = UsdLux.DistantLight.Define(stage, "/World/Sun")
        sun.CreateIntensityAttr(3500.0)

        camera = self.UsdGeom.Camera.Define(stage, "/World/Camera")
        camera.CreateFocalLengthAttr(18.0)
        cxf = self.UsdGeom.Xformable(camera.GetPrim())
        cxf.AddTranslateOp().Set(self.Gf.Vec3d(0.0, -7.5, 12.5))
        cxf.AddRotateXYZOp().Set(self.Gf.Vec3f(28.0, 0.0, 0.0))
        try:
            import omni.kit.viewport.utility as viewport_utility

            viewport = viewport_utility.get_active_viewport()
            if viewport is not None:
                viewport.set_active_camera("/World/Camera")
        except Exception:
            pass

    def _build_ground_map(self) -> Any:
        from sensors import GroundMap, PolygonZone

        gm = GroundMap(default="gray")
        mission = self.cfg.mission
        if self.cfg.mission_key == "AAC":
            assert mission.black_center and mission.white_center and mission.zone_radius
            gm.add_circle(
                "black", mission.black_center, mission.zone_radius, name="aac_black", priority=100
            )
            gm.add_circle(
                "white", mission.white_center, mission.zone_radius, name="aac_white", priority=100
            )
        elif self.cfg.mission_key == "FOR":
            assert mission.food_radius is not None
            for index, center in enumerate(mission.food_centers):
                gm.add_circle(
                    "black",
                    center,
                    mission.food_radius,
                    name=f"food_{index}",
                    priority=100,
                )
            from .mission_models import NEST_FLOOR_POLYGON

            gm.add_zone(
                PolygonZone(
                    label="white",
                    vertices=tuple(NEST_FLOOR_POLYGON),
                    name="foraging_nest",
                    priority=90,
                )
            )
        return gm

    def _configure_lidar_prim(self, lidar_prim_path: str) -> None:
        """Apply YAML timing/range settings to the referenced RTX LiDAR prim."""

        stage = self.omni_usd.get_context().get_stage()
        prim = stage.GetPrimAtPath(lidar_prim_path)
        if not prim or not prim.IsValid():
            raise RuntimeError(f"LiDAR prim not found: {lidar_prim_path}")
        values = {
            "omni:sensor:Core:nearRangeM": float(self.cfg.lidar.min_range),
            "omni:sensor:Core:scanRateBaseHz": int(round(self.cfg.lidar.scan_rate_hz)),
            "omni:sensor:Core:reportRateBaseHz": int(round(self.cfg.lidar.samples_per_second)),
            "omni:sensor:Core:azimuthErrorMean": float(self.cfg.noise.lidar.azimuth_bias_deg),
            "omni:sensor:Core:azimuthErrorStd": float(self.cfg.noise.lidar.azimuth_gaussian_std_deg),
            "omni:sensor:Core:elevationErrorMean": float(self.cfg.noise.lidar.elevation_bias_deg),
            "omni:sensor:Core:elevationErrorStd": float(self.cfg.noise.lidar.elevation_gaussian_std_deg),
        }
        for name, value in values.items():
            attr = prim.GetAttribute(name)
            if not attr or not attr.IsValid():
                raise RuntimeError(f"RTX LiDAR attribute missing on {lidar_prim_path}: {name}")
            attr.Set(value)

    def _spawn_robots(self, poses: list[tuple[float, float, float]]) -> None:
        from automode import AutoMoDeMercatorModules
        from sensors import AnalyticGroundSensor
        from utils.mercator_full_stage import add_mercator_full

        usd_path = (self.real_root / self.cfg.robot.usd).resolve()
        if not usd_path.is_file():
            raise FileNotFoundError(f"Mercator USD not found: {usd_path}")

        for index, (x, y, yaw) in enumerate(poses):
            name = f"Mercator_{index:02d}"
            robot, paths = add_mercator_full(
                name,
                usd_path=str(usd_path),
                position=(x, y, 0.0),
                orientation_wxyz=quat_wxyz_from_yaw(yaw),
            )
            self._configure_lidar_prim(paths.lidar_prim_path)
            ground_sensor = AnalyticGroundSensor(paths.ground_sensor_path, self.ground_map)
            automode = AutoMoDeMercatorModules(
                robot_prim_path=paths.body_path,
                teraranger_root_path=paths.teraranger_root_path,
                lidar_prim_path=paths.lidar_prim_path,
                light_position_xy=self.cfg.mission.light_position[:2],
                max_speed=self.cfg.robot.max_wheel_speed,
                track_width=self.cfg.robot.track_width,
                proximity_threshold=self.cfg.control.proximity_threshold,
                exploration_tau=self.cfg.control.exploration_tau,
                teraranger_max_range=2.0,
                neighbor_min_range=self.cfg.lidar.min_range,
                neighbor_max_range=self.cfg.lidar.max_range,
                neighbor_alpha=1.0,
                neighbor_cluster_distance_epsilon=self.cfg.lidar.cluster_distance_epsilon_m,
                min_cluster_points=self.cfg.lidar.min_cluster_points,
                neighbor_target_radius_m=0.5 * self.cfg.lidar.tower_diameter_m,
                phototaxis_proximity_gain=self.cfg.control.phototaxis_proximity_gain,
                anti_phototaxis_proximity_gain=self.cfg.control.anti_phototaxis_proximity_gain,
                attraction_proximity_gain=self.cfg.control.attraction_proximity_gain,
                repulsion_proximity_gain=self.cfg.control.repulsion_proximity_gain,
                attraction_alpha_parameter=self.cfg.control.attraction_alpha,
                repulsion_alpha_parameter=self.cfg.control.repulsion_alpha,
                fallback_vector_threshold=self.cfg.control.fallback_vector_threshold,
                proximity_noise_std=self.cfg.noise.sensors.proximity_gaussian_std,
                light_noise_std=self.cfg.noise.sensors.light_gaussian_std,
                seed=index,
                debug=False,
            )
            detector = automode.neighbor_detector
            detector.cluster_angle_epsilon_rad = self.cfg.lidar.cluster_angle_epsilon_rad
            detector.reject_wide_clusters = self.cfg.lidar.reject_wide_clusters
            detector.min_physical_width = self.cfg.lidar.min_physical_width_m
            detector.max_physical_width = self.cfg.lidar.max_physical_width_m
            self.records.append(
                RobotRecord(
                    name=name,
                    robot=robot,
                    paths=paths,
                    ground_sensor=ground_sensor,
                    automode=automode,
                    rng=np.random.default_rng(index),
                )
            )

    def set_poses(
        self,
        poses: list[tuple[float, float, float]],
        *,
        seed: int = 0,
    ) -> None:
        if len(poses) != len(self.records):
            raise ValueError(
                f"Expected {len(self.records)} poses, received {len(poses)}"
            )
        for index, (record, pose) in enumerate(zip(self.records, poses)):
            x, y, yaw = pose
            positions = np.asarray([[x, y, 0.0]], dtype=np.float32)
            orientations = np.asarray([quat_wxyz_from_yaw(yaw)], dtype=np.float32)
            record.robot.set_world_poses(positions=positions, orientations=orientations)
            record.robot.set_velocities(
                linear_velocities=np.zeros((1, 3), dtype=np.float32),
                angular_velocities=np.zeros((1, 3), dtype=np.float32),
            )
            record.automode.stop_motion()
            record.automode.previous_module_id = -1
            record.automode._reset_exploration_state()
            record.last_neighbors = None
            record.last_module = 1
            record.last_wheels = (0.0, 0.0)
            local_seed = int(seed) * 1009 + index
            record.rng = np.random.default_rng(local_seed)
            record.automode.rng.seed(local_seed)
            record.automode.noise_rng = np.random.default_rng(local_seed)
            if hasattr(record.automode.explorer, "rng"):
                record.automode.explorer.rng.seed(local_seed)
        # Wait for two complete 7 Hz rotations after teleporting so the local
        # point cloud cannot mix pre-reset and post-reset geometry.
        settle_steps = max(5, int(math.ceil(2.0 * self.cfg.control.physics_frequency_hz / self.cfg.lidar.scan_rate_hz)))
        for _ in range(settle_steps):
            self.simulation_app.update()

    def reset(self, seed: int) -> list[tuple[float, float, float]]:
        poses = sample_collision_free_poses(self.cfg, seed)
        self.set_poses(poses, seed=seed)
        return poses

    def poses(self) -> np.ndarray:
        result = np.zeros((len(self.records), 3), dtype=np.float32)
        for index, record in enumerate(self.records):
            positions, orientations = record.robot.get_world_poses()
            pos = positions.numpy() if hasattr(positions, "numpy") else np.asarray(positions)
            quat = orientations.numpy() if hasattr(orientations, "numpy") else np.asarray(orientations)
            result[index, :2] = pos[0, :2]
            result[index, 2] = yaw_from_wxyz(quat[0])
        return result

    def noisy_neighbors(self, record: RobotRecord) -> Any:
        points = record.automode.neighbor_detector.lidar.get_point_cloud()
        points = apply_lidar_point_noise(points, self.cfg.noise.lidar, record.rng)
        observation = record.automode.neighbor_detector.compute_from_points(points)
        record.last_neighbors = observation
        return observation

    def apply_wheels(self, record: RobotRecord, left: float, right: float) -> tuple[float, float]:
        left, right = apply_wheel_noise(
            left,
            right,
            self.cfg.noise.wheels,
            record.rng,
            max_speed=self.cfg.robot.max_wheel_speed,
        )
        record.automode.controller.set_speeds(left, right)
        record.last_wheels = (left, right)
        return left, right

    def step_physics(self) -> None:
        for _ in range(self.cfg.physics_steps_per_control):
            for record in self.records:
                record.automode.apply()
            self.simulation_app.update()

    def close(self) -> None:
        for record in self.records:
            try:
                record.automode.stop_motion()
                record.automode.apply()
                record.automode.stop()
            except Exception:
                pass
        if self._timeline is not None:
            try:
                self._timeline.stop()
            except Exception:
                pass
