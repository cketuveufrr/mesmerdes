from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

import yaml


MISSION_ALIASES = {
    "AAC": "AAC",
    "AAC1": "AAC",
    "AGG": "AAC",
    "AGGREGATION": "AAC",
    "FOR": "FOR",
    "FOR1": "FOR",
    "FORAGING": "FOR",
    "GRID": "GRID",
    "GEX": "GRID",
    "GRIDEXPLORATION": "GRID",
    "GRID_EXPLORATION": "GRID",
}


def normalize_mission(value: str) -> str:
    key = str(value).strip().upper().replace("-", "_").replace(" ", "_")
    compact = key.replace("_", "")
    if key in MISSION_ALIASES:
        return MISSION_ALIASES[key]
    if compact in MISSION_ALIASES:
        return MISSION_ALIASES[compact]
    raise ValueError(f"Unknown real-robot mission {value!r}; choose AAC, FOR, or GRID")


@dataclass(frozen=True)
class WheelNoiseConfig:
    std_fraction: float = 0.0
    bias_left_fraction: float = 0.0
    bias_right_fraction: float = 0.0


@dataclass(frozen=True)
class LidarNoiseConfig:
    range_uniform_m: float = 0.0
    range_gaussian_std_m: float = 0.0
    dropout_probability: float = 0.0
    azimuth_bias_deg: float = 0.0
    azimuth_gaussian_std_deg: float = 0.0
    elevation_bias_deg: float = 0.0
    elevation_gaussian_std_deg: float = 0.0


@dataclass(frozen=True)
class SensorNoiseConfig:
    proximity_gaussian_std: float = 0.0
    light_gaussian_std: float = 0.0
    ground_flip_probability: float = 0.0


@dataclass(frozen=True)
class NoiseConfig:
    wheels: WheelNoiseConfig = field(default_factory=WheelNoiseConfig)
    lidar: LidarNoiseConfig = field(default_factory=LidarNoiseConfig)
    sensors: SensorNoiseConfig = field(default_factory=SensorNoiseConfig)


@dataclass(frozen=True)
class RobotConfig:
    count: int = 20
    usd: str = "assets/MercatorLiteOfficial_rtx_lidar_ground_clean.usda"
    length: float = 0.26
    width: float = 0.25
    height: float = 0.20
    collision_radius: float = 0.135
    track_width: float = 0.147
    max_wheel_speed: float = 0.30
    ground_sensor_offset: tuple[float, float] = (0.05619, 0.0)


@dataclass(frozen=True)
class LidarConfig:
    min_range: float = 0.12
    max_range: float = 0.75
    scan_rate_hz: float = 7.0
    samples_per_second: float = 5000.0
    cluster_distance_epsilon_m: float = 0.02
    cluster_angle_epsilon_rad: float = 0.175
    min_cluster_points: int = 5
    tower_diameter_m: float = 0.065
    reject_wide_clusters: bool = False
    min_physical_width_m: float = 0.02
    max_physical_width_m: float = 0.12


@dataclass(frozen=True)
class ControlConfig:
    frequency_hz: float = 10.0
    physics_frequency_hz: float = 60.0
    episode_length_s: float = 120.0
    observation: int | str = 2
    exploration_tau: int = 5
    proximity_threshold: float = 0.10
    phototaxis_proximity_gain: float = 5.0
    anti_phototaxis_proximity_gain: float = 5.0
    attraction_proximity_gain: float = 6.0
    repulsion_proximity_gain: float = 5.0
    attraction_alpha: float = 5.0
    repulsion_alpha: float = 5.0
    fallback_vector_threshold: float = 0.10


@dataclass(frozen=True)
class SpawnConfig:
    mode: str = "argos_uniform_box_rejection"
    half_range: float = 4.6
    max_trials: int = 20000
    separation_margin_m: float = 0.01


@dataclass(frozen=True)
class ArenaConfig:
    wall_side_length: float = 2.57
    wall_thickness: float = 0.01
    wall_height: float = 0.08
    floor_size: float = 10.0


@dataclass(frozen=True)
class MissionConfig:
    name: str
    light_position: tuple[float, float, float]
    black_center: tuple[float, float] | None = None
    white_center: tuple[float, float] | None = None
    zone_radius: float | None = None
    food_centers: tuple[tuple[float, float], ...] = ()
    food_radius: float | None = None
    nest_limit_y: float | None = None
    grid_arena_size: float | None = None
    grid_size: int | None = None


@dataclass(frozen=True)
class OutputConfig:
    directory: str = "results/real_robot"
    save_step_csv: bool = False


@dataclass(frozen=True)
class RealRobotConfig:
    mission: MissionConfig
    robot: RobotConfig = field(default_factory=RobotConfig)
    lidar: LidarConfig = field(default_factory=LidarConfig)
    control: ControlConfig = field(default_factory=ControlConfig)
    spawn: SpawnConfig = field(default_factory=SpawnConfig)
    arena: ArenaConfig = field(default_factory=ArenaConfig)
    noise: NoiseConfig = field(default_factory=NoiseConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    source_path: Path | None = None

    @property
    def mission_key(self) -> str:
        return normalize_mission(self.mission.name)

    @property
    def control_steps(self) -> int:
        return int(round(self.control.episode_length_s * self.control.frequency_hz))

    @property
    def physics_steps_per_control(self) -> int:
        ratio = self.control.physics_frequency_hz / self.control.frequency_hz
        rounded = int(round(ratio))
        if rounded < 1 or abs(ratio - rounded) > 1.0e-6:
            raise ValueError(
                "physics_frequency_hz must be an integer multiple of control frequency_hz"
            )
        return rounded


def _section(data: Mapping[str, Any], key: str) -> dict[str, Any]:
    value = data.get(key, {})
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise TypeError(f"YAML section {key!r} must be a mapping")
    return dict(value)


def _tuple2(value: Any, name: str) -> tuple[float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError(f"{name} must contain exactly two numbers")
    return float(value[0]), float(value[1])


def _tuple3(value: Any, name: str) -> tuple[float, float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError(f"{name} must contain exactly three numbers")
    return float(value[0]), float(value[1]), float(value[2])


def _mission_from_dict(data: Mapping[str, Any]) -> MissionConfig:
    name = normalize_mission(str(data.get("name", "")))
    light = _tuple3(data.get("light_position", [0.0, -5.0, 0.2]), "light_position")
    food_centers = tuple(
        _tuple2(item, "food_centers entry") for item in data.get("food_centers", [])
    )
    return MissionConfig(
        name=name,
        light_position=light,
        black_center=(
            _tuple2(data["black_center"], "black_center")
            if "black_center" in data
            else None
        ),
        white_center=(
            _tuple2(data["white_center"], "white_center")
            if "white_center" in data
            else None
        ),
        zone_radius=(float(data["zone_radius"]) if "zone_radius" in data else None),
        food_centers=food_centers,
        food_radius=(float(data["food_radius"]) if "food_radius" in data else None),
        nest_limit_y=(float(data["nest_limit_y"]) if "nest_limit_y" in data else None),
        grid_arena_size=(
            float(data["grid_arena_size"]) if "grid_arena_size" in data else None
        ),
        grid_size=(int(data["grid_size"]) if "grid_size" in data else None),
    )


def _construct_config(raw: Mapping[str, Any], source_path: Path) -> RealRobotConfig:
    mission = _mission_from_dict(_section(raw, "mission"))
    robot_data = _section(raw, "robot")
    lidar_data = _section(raw, "lidar")
    control_data = _section(raw, "control")
    spawn_data = _section(raw, "spawn")
    arena_data = _section(raw, "arena")
    output_data = _section(raw, "output")
    noise_data = _section(raw, "noise")

    wheel_noise = WheelNoiseConfig(**_section(noise_data, "wheels"))
    lidar_noise = LidarNoiseConfig(**_section(noise_data, "lidar"))
    sensor_noise = SensorNoiseConfig(**_section(noise_data, "sensors"))

    if "ground_sensor_offset" in robot_data:
        robot_data["ground_sensor_offset"] = _tuple2(
            robot_data["ground_sensor_offset"], "ground_sensor_offset"
        )

    cfg = RealRobotConfig(
        mission=mission,
        robot=RobotConfig(**robot_data),
        lidar=LidarConfig(**lidar_data),
        control=ControlConfig(**control_data),
        spawn=SpawnConfig(**spawn_data),
        arena=ArenaConfig(**arena_data),
        noise=NoiseConfig(wheels=wheel_noise, lidar=lidar_noise, sensors=sensor_noise),
        output=OutputConfig(**output_data),
        source_path=source_path,
    )
    validate_real_robot_config(cfg)
    return cfg


def validate_real_robot_config(cfg: RealRobotConfig) -> None:
    if cfg.robot.count < 1:
        raise ValueError("robot.count must be positive")
    if cfg.robot.track_width <= 0.0:
        raise ValueError("robot.track_width must be positive")
    if cfg.robot.max_wheel_speed <= 0.0:
        raise ValueError("robot.max_wheel_speed must be positive")
    if cfg.control.frequency_hz <= 0.0 or cfg.control.physics_frequency_hz <= 0.0:
        raise ValueError("control frequencies must be positive")
    if cfg.control.episode_length_s <= 0.0:
        raise ValueError("control.episode_length_s must be positive")
    observation = str(cfg.control.observation).strip().lower()
    if observation != "auto":
        try:
            observation_width = int(observation)
        except ValueError as exc:
            raise ValueError("control.observation must be auto, 2, or 22") from exc
        if observation_width not in (2, 22):
            raise ValueError("control.observation must be auto, 2, or 22")
    _ = cfg.physics_steps_per_control
    if not (0.0 <= cfg.lidar.min_range < cfg.lidar.max_range):
        raise ValueError("lidar range must satisfy 0 <= min_range < max_range")
    if cfg.lidar.scan_rate_hz <= 0.0 or cfg.lidar.samples_per_second <= 0.0:
        raise ValueError("LiDAR rates must be positive")
    if cfg.lidar.min_cluster_points < 1:
        raise ValueError("lidar.min_cluster_points must be >= 1")
    if cfg.lidar.tower_diameter_m <= 0.0:
        raise ValueError("lidar.tower_diameter_m must be positive")
    if 0.5 * cfg.lidar.tower_diameter_m >= cfg.lidar.max_range:
        raise ValueError("LiDAR tower radius must be smaller than lidar.max_range")
    if cfg.arena.wall_height >= 0.17545:
        raise ValueError(
            "The real-robot setup assumes walls remain below the 0.17545 m LiDAR plane"
        )
    for name, value in (
        ("wheel std", cfg.noise.wheels.std_fraction),
        ("lidar uniform", cfg.noise.lidar.range_uniform_m),
        ("lidar gaussian", cfg.noise.lidar.range_gaussian_std_m),
        ("lidar dropout", cfg.noise.lidar.dropout_probability),
        ("lidar azimuth gaussian", cfg.noise.lidar.azimuth_gaussian_std_deg),
        ("lidar elevation gaussian", cfg.noise.lidar.elevation_gaussian_std_deg),
        ("proximity gaussian", cfg.noise.sensors.proximity_gaussian_std),
        ("light gaussian", cfg.noise.sensors.light_gaussian_std),
        ("ground flip", cfg.noise.sensors.ground_flip_probability),
    ):
        if value < 0.0:
            raise ValueError(f"{name} noise must be non-negative")
    if cfg.noise.lidar.dropout_probability > 1.0:
        raise ValueError("lidar.dropout_probability must be <= 1")
    if cfg.noise.sensors.ground_flip_probability > 1.0:
        raise ValueError("ground_flip_probability must be <= 1")

    key = cfg.mission_key
    if key == "AAC":
        if cfg.mission.black_center is None or cfg.mission.white_center is None:
            raise ValueError("AAC requires black_center and white_center")
        if cfg.mission.zone_radius is None or cfg.mission.zone_radius <= 0.0:
            raise ValueError("AAC requires a positive zone_radius")
    elif key == "FOR":
        if len(cfg.mission.food_centers) != 2:
            raise ValueError("FOR requires exactly two food_centers")
        if cfg.mission.food_radius is None or cfg.mission.food_radius <= 0.0:
            raise ValueError("FOR requires a positive food_radius")
        if cfg.mission.nest_limit_y is None:
            raise ValueError("FOR requires nest_limit_y")
    elif key == "GRID":
        if cfg.mission.grid_arena_size is None or cfg.mission.grid_arena_size <= 0.0:
            raise ValueError("GRID requires a positive grid_arena_size")
        if cfg.mission.grid_size is None or cfg.mission.grid_size <= 0:
            raise ValueError("GRID requires a positive grid_size")


def load_real_robot_config(path: str | Path) -> RealRobotConfig:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Real-robot YAML not found: {source}")
    raw = yaml.safe_load(source.read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping):
        raise TypeError(f"Real-robot YAML must contain a mapping: {source}")
    return _construct_config(raw, source)
