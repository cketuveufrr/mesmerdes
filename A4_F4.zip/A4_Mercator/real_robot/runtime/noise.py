"""Pure noise transforms used by the realistic runtime and unit tests."""

from __future__ import annotations

import numpy as np

from .config import LidarNoiseConfig, WheelNoiseConfig


def apply_wheel_noise(
    left: float,
    right: float,
    cfg: WheelNoiseConfig,
    rng: np.random.Generator,
    *,
    max_speed: float,
) -> tuple[float, float]:
    left_value = float(left) * (1.0 + float(cfg.bias_left_fraction))
    right_value = float(right) * (1.0 + float(cfg.bias_right_fraction))
    if cfg.std_fraction > 0.0:
        left_value *= 1.0 + float(rng.normal(0.0, cfg.std_fraction))
        right_value *= 1.0 + float(rng.normal(0.0, cfg.std_fraction))
    limit = float(max_speed)
    return (
        float(np.clip(left_value, -limit, limit)),
        float(np.clip(right_value, -limit, limit)),
    )


def apply_lidar_point_noise(
    points: np.ndarray,
    cfg: LidarNoiseConfig,
    rng: np.random.Generator,
) -> np.ndarray:
    """Apply dropout and radial range noise without changing ray bearings."""

    value = np.asarray(points, dtype=np.float32)
    if value.ndim != 2 or value.shape[1] < 3:
        return np.empty((0, 3), dtype=np.float32)
    value = value[:, :3].copy()
    if value.shape[0] == 0:
        return value

    if cfg.dropout_probability > 0.0:
        keep = rng.random(value.shape[0]) >= cfg.dropout_probability
        value = value[keep]
    if value.shape[0] == 0:
        return value

    if cfg.range_uniform_m > 0.0 or cfg.range_gaussian_std_m > 0.0:
        ranges = np.linalg.norm(value[:, :2], axis=1)
        valid = ranges > 1.0e-9
        delta = np.zeros_like(ranges)
        if cfg.range_uniform_m > 0.0:
            delta += rng.uniform(-cfg.range_uniform_m, cfg.range_uniform_m, size=ranges.shape)
        if cfg.range_gaussian_std_m > 0.0:
            delta += rng.normal(0.0, cfg.range_gaussian_std_m, size=ranges.shape)
        new_ranges = np.clip(ranges + delta, 0.0, None)
        scale = np.ones_like(ranges)
        scale[valid] = new_ranges[valid] / ranges[valid]
        value[:, 0] *= scale
        value[:, 1] *= scale
    return value.astype(np.float32, copy=False)
