from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch

from .config import RealRobotConfig


def _ground_label_to_scalar(label: Any) -> float:
    value = int(label)
    # GroundColor enum: black=0, gray=1, white=2 in this repository.
    if value == 0:
        return 0.0
    if value == 2:
        return 1.0
    return 0.5


@dataclass
class MissionStep:
    reward: float
    fields: dict[str, float]


class MissionRuntime:
    """Exact Experiment-1 scoring state for AAC, FOR, or GRID."""

    def __init__(self, cfg: RealRobotConfig):
        self.cfg = cfg
        self.key = cfg.mission_key
        self.num_robots = cfg.robot.count
        self.reset()

    def reset(self) -> None:
        self.score = 0.0
        self.steps = 0
        self.last_fields: dict[str, float] = {}
        if self.key == "FOR":
            self.carrying = torch.zeros((1, self.num_robots), dtype=torch.bool)
            self.pickups = 0
            self.deliveries = 0
        elif self.key == "GRID":
            size = int(self.cfg.mission.grid_size or 10)
            self.ages = torch.zeros((1, size, size), dtype=torch.long)
            self.visited_ever = torch.zeros((1, size, size), dtype=torch.bool)
            self.max_age_episode = 0.0

    def ground_scalar_from_sensor(self, reading: Any, rng: np.random.Generator) -> float:
        scalar = _ground_label_to_scalar(reading.label)
        probability = self.cfg.noise.sensors.ground_flip_probability
        if probability > 0.0 and float(rng.random()) < probability:
            choices = [0.0, 0.5, 1.0]
            choices.remove(scalar)
            scalar = float(choices[int(rng.integers(0, len(choices)))])
        return scalar

    def step(self, poses: np.ndarray) -> MissionStep:
        positions = torch.as_tensor(poses[:, :2], dtype=torch.float32).unsqueeze(0)
        self.steps += 1

        if self.key == "AAC":
            mission = self.cfg.mission
            assert mission.black_center is not None
            assert mission.white_center is not None
            assert mission.zone_radius is not None
            black = torch.as_tensor(mission.black_center, dtype=torch.float32)
            white = torch.as_tensor(mission.white_center, dtype=torch.float32)
            radius_sq = float(mission.zone_radius) ** 2
            n_black = int(((positions[0] - black).square().sum(dim=-1) <= radius_sq).sum())
            n_white = int(((positions[0] - white).square().sum(dim=-1) <= radius_sq).sum())
            reward = float(n_black)
            self.score += reward
            self.last_fields = {
                "n_black": float(n_black),
                "n_white": float(n_white),
                "mean_black": self.score / self.steps,
            }
            return MissionStep(reward, dict(self.last_fields))

        if self.key == "FOR":
            from .mission_models import update_carrying_state

            mission = self.cfg.mission
            result = update_carrying_state(
                positions,
                self.carrying,
                food_centers=mission.food_centers,
                food_radius=float(mission.food_radius),
                nest_limit_y=float(mission.nest_limit_y),
            )
            self.carrying = result.carrying
            pickups = int(result.pickup_mask.sum().item())
            deliveries = int(result.delivery_mask.sum().item())
            self.pickups += pickups
            self.deliveries += deliveries
            reward = float(deliveries)
            self.score += reward
            self.last_fields = {
                "deliveries": float(self.deliveries),
                "pickups": float(self.pickups),
                "carrying": float(self.carrying.sum().item()),
                "in_food": float(result.in_food.sum().item()),
                "in_nest": float(result.in_nest.sum().item()),
                "delivery_efficiency": (
                    float(self.deliveries) / self.pickups if self.pickups else 0.0
                ),
            }
            return MissionStep(reward, dict(self.last_fields))

        from .mission_models import update_grid_ages

        mission = self.cfg.mission
        result = update_grid_ages(
            self.ages,
            positions,
            arena_size=float(mission.grid_arena_size),
            grid_size=int(mission.grid_size),
        )
        self.ages = result.ages
        self.visited_ever |= result.visited_mask
        self.max_age_episode = max(self.max_age_episode, float(result.max_age.item()))
        reward = float(result.reward.item())
        self.score += reward
        self.last_fields = {
            "mean_grid_age": float(result.mean_age.item()),
            "max_grid_age": float(result.max_age.item()),
            "visited_cells_tick": float(result.visited_cells.item()),
            "coverage": float(self.visited_ever.float().mean().item()),
            "max_grid_age_episode": float(self.max_age_episode),
        }
        return MissionStep(reward, dict(self.last_fields))

    def episode_record(self, *, seed: int, controller: str, episode: int) -> dict[str, Any]:
        row: dict[str, Any] = {
            "mission": self.key,
            "controller": controller,
            "episode": int(episode),
            "seed": int(seed),
            "steps": int(self.steps),
            "score": float(self.score),
        }
        row.update(self.last_fields)
        if self.key == "AAC":
            row["normalized_score"] = self.score / max(1, self.steps * self.num_robots)
        elif self.key == "FOR":
            row["deliveries_per_robot"] = self.deliveries / self.num_robots
            row["carrying_at_end"] = int(self.carrying.sum().item())
        else:
            row["final_grid_mean_age"] = float(self.ages.float().mean().item())
            row["final_grid_max_age"] = float(self.ages.max().item())
            row["final_grid_coverage"] = float(self.visited_ever.float().mean().item())
        return row
