# Vérification du rendu

Vérifications exécutées depuis la racine de `A4_Mercator` avant empaquetage :

```bash
python -m compileall -q launch_real.py real_robot
pytest -q real_robot/tests
python launch_real.py --mission AAC  --score --fsm-index 1 --validate-only
python launch_real.py --mission FOR  --score --fsm-index 1 --validate-only
python launch_real.py --mission GRID --score --fsm-index 1 --validate-only
python real_robot/tests/run_vector_real_gap.py --help
```

Résultat de la suite propre au rendu :

```text
36 passed
```

Les validations sans Isaac confirment les trois YAML, l'asset USD, les paramètres LiDAR, l'absence nominale de bruit et le chargement des fichiers FSM.

Le test dynamique `run_vector_real_gap.py` nécessite Isaac Sim 6.0. Le conteneur de préparation ne contient pas le module `isaacsim`; le script a donc été compilé et son interface a été vérifiée, mais la scène RTX/PhysX complète ne pouvait pas être exécutée dans ce conteneur. Il est conçu pour être lancé sur la machine Isaac avec la commande décrite dans `README.md`.

À noter dans le projet A4 fourni : le fichier existant `fsm_mercator_foraging_experiment1.txt` contient 11 FSM selon le parseur Chocolate, alors que les fichiers AAC et GRID en contiennent 10. Le launcher ne modifie ni ne tronque ce fichier source.
