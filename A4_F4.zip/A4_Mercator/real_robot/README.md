# Mercator `real_robot`

Ce dossier ajoute à `A4_Mercator` un environnement d'évaluation Isaac Sim fondé sur le modèle USD complet du Mercator. Il est destiné au déploiement sans réentraînement des contrôleurs POCA/SwarmACB et des FSM Chocolate conçus dans le simulateur vectorisé.

## Installation

Copier à la racine de `A4_Mercator` :

```text
A4_Mercator/
├── launch_real.py
└── real_robot/
```

Le dossier utilise les éléments déjà présents dans `A4_Mercator` :

- `source/SwarmACB_isaac` pour les architectures des acteurs ;
- `scripts/mercator_chocolate_fsm.py` pour le parseur et le runtime Chocolate ;
- `configs/mercator/fsms` pour les FSM par défaut ;
- `poca_alt/poca_opti_ps` seulement pour les checkpoints Cyclamen-PS.

## Contrat nominal livré

Les trois YAML livrés sont dans `real_robot/configs` :

- `AAC_real.yaml` ;
- `FOR_real.yaml` ;
- `GRID_real.yaml`.

Ils fixent notamment :

- 20 Mercators ;
- empattement de 0,147 m ;
- capteur de sol décalé de 0,05619 m vers l'avant ;
- LiDAR local de 0,12 à 0,75 m, à 7 Hz et 5000 retours/s ;
- regroupement LiDAR avec au moins 5 points, `epsilon=0,02 m` et `0,175 rad` ;
- reconstruction de la distance centre-à-centre par `distance_surface_min + rayon_tour`, avec un diamètre de tour de 0,065 m ;
- contrôle à 10 Hz et physique à 60 Hz ;
- observation Cyclamen réduite exactement à `[ground, tanh(0.5 * n_local)]` ;
- murs de 0,08 m, donc sous le plan LiDAR à 0,17545 m ;
- tous les bruits artificiels désactivés.

L'acteur n'accède à aucune pose globale. Les poses Isaac ne servent qu'au score des missions et aux rapports de test.

## Lancement

Validation statique, sans démarrer Isaac Sim :

```bash
python launch_real.py --mission AAC --score --fsm-index 1 --validate-only
```

Observer une FSM :

```bash
python launch_real.py --mission AAC --observe --fsm-index 1
```

Évaluer une FSM :

```bash
python launch_real.py --mission FOR --score --fsm-index 1 --episodes 10
```

Évaluer toutes les FSM du fichier par défaut :

```bash
python launch_real.py --mission GRID --score --all-fsms --episodes 10
```

Observer un checkpoint :

```bash
python launch_real.py --mission AAC --observe \
  --checkpoint checkpoints/AAC_mercator_cyclamen/poca_final.pt \
  --deterministic
```

Évaluer un checkpoint :

```bash
python launch_real.py --mission FOR --score \
  --checkpoint checkpoints/FOR_mercator_cyclamen/poca_final.pt \
  --episodes 10 --deterministic
```

Le launcher accepte les acteurs continus, les acteurs discrets de sélection de modules, les acteurs récurrents Cyclamen, Cyclamen-PS et les gestionnaires Option-Critic enregistrés selon le format du projet.

## Bruits configurables

Les perturbations sont toutes contrôlées par YAML et valent zéro dans le rendu nominal :

```yaml
noise:
  wheels:
    std_fraction: 0.0
    bias_left_fraction: 0.0
    bias_right_fraction: 0.0
  lidar:
    range_uniform_m: 0.0
    range_gaussian_std_m: 0.0
    dropout_probability: 0.0
    azimuth_bias_deg: 0.0
    azimuth_gaussian_std_deg: 0.0
    elevation_bias_deg: 0.0
    elevation_gaussian_std_deg: 0.0
  sensors:
    proximity_gaussian_std: 0.0
    light_gaussian_std: 0.0
    ground_flip_probability: 0.0
```

`std_fraction` applique un bruit multiplicatif indépendant aux deux roues. Les bruits de portée LiDAR sont appliqués radialement. Les erreurs angulaires RTX en azimut et en élévation sont également pilotées par le YAML et surchargent les attributs de l'asset. Les lectures de proximité et de lumière sont bornées dans `[0,1]`. Le bruit du sol remplace aléatoirement une catégorie par l'une des deux autres.

## Tests ordinaires

Depuis la racine de `A4_Mercator` :

```bash
pytest -q real_robot/tests
```

Cette suite vérifie notamment :

- les contrats des YAML et de l'asset USD ;
- l'identité de la conversion vecteur-vers-roues avec le modèle vectorisé ;
- l'identité des cinq modules déterministes pour des entrées canoniques communes ;
- le clustering LiDAR et la convention de distance en centimètres ;
- l'identité des fonctions de score FOR et GRID avec les modèles vectorisés ;
- l'identité exacte du système lorsque les bruits sont nuls ;
- la validation des FSM et checkpoints sans Isaac Sim.

## Test d'écart vectorisé versus USD/LiDAR/collisions

Le test d'intégration suivant doit être lancé dans l'environnement Python Isaac Sim 6.0 :

```bash
python real_robot/tests/run_vector_real_gap.py \
  --all-modules --steps 100 --robots 3 --headless
```

Il place les mêmes robots aux mêmes poses dans :

1. le Mercator tensoriel vectorisé ;
2. le Mercator USD complet, avec TeraRanger, RTX LiDAR et collisions PhysX.

Il applique successivement les comportements déterministes `stop`, `phototaxis`, `anti_phototaxis`, `attraction` et `repulsion`, puis écrit :

- l'erreur de trajectoire ;
- l'erreur angulaire ;
- l'écart de commande des roues ;
- l'écart de nombre de voisins locaux ;
- un CSV détaillé et un résumé JSON.

Ce test mesure volontairement l'écart produit par la géométrie, les distances aux surfaces, le LiDAR à 7 Hz et les collisions. Il ne cherche pas à imposer une égalité trajectoire-par-trajectoire entre les deux modèles.
