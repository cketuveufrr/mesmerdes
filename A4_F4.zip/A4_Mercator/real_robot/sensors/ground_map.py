"""
Carte sémantique de sol pour le ground sensor Mercator.

Idée clé : la vérité du sol ne doit pas dépendre de milliers de patchs USD ni
de displayColor. Elle est représentée ici par une carte logique de zones
black/white/gray. Les meshes USD servent seulement à visualiser cette carte.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Iterable, Sequence

import numpy as np


class GroundColor(IntEnum):
    UNKNOWN = -1
    GRAY = 0
    BLACK = 1
    WHITE = 2


LABEL_TO_COLOR = {
    "unknown": GroundColor.UNKNOWN,
    "gray": GroundColor.GRAY,
    "grey": GroundColor.GRAY,
    "black": GroundColor.BLACK,
    "white": GroundColor.WHITE,
}

COLOR_TO_LABEL = {
    GroundColor.UNKNOWN: "unknown",
    GroundColor.GRAY: "gray",
    GroundColor.BLACK: "black",
    GroundColor.WHITE: "white",
}

COLOR_TO_RGB = {
    GroundColor.UNKNOWN: np.array([1.0, 0.0, 1.0], dtype=np.float32),
    GroundColor.GRAY: np.array([0.55, 0.55, 0.55], dtype=np.float32),
    GroundColor.BLACK: np.array([0.0, 0.0, 0.0], dtype=np.float32),
    GroundColor.WHITE: np.array([1.0, 1.0, 1.0], dtype=np.float32),
}


def normalize_color(value: GroundColor | str | int) -> GroundColor:
    if isinstance(value, GroundColor):
        return value
    if isinstance(value, str):
        key = value.strip().lower()
        if key not in LABEL_TO_COLOR:
            raise ValueError(f"Label de sol inconnu : {value!r}")
        return LABEL_TO_COLOR[key]
    return GroundColor(int(value))


def color_label(value: GroundColor | str | int) -> str:
    return COLOR_TO_LABEL[normalize_color(value)]


def color_rgb(value: GroundColor | str | int) -> np.ndarray:
    return COLOR_TO_RGB[normalize_color(value)].copy()


def color_one_hot(value: GroundColor | str | int, include_unknown: bool = False) -> np.ndarray:
    color = normalize_color(value)
    if include_unknown:
        # [unknown, gray, black, white]
        out = np.zeros((4,), dtype=np.float32)
        index = {GroundColor.UNKNOWN: 0, GroundColor.GRAY: 1, GroundColor.BLACK: 2, GroundColor.WHITE: 3}[color]
        out[index] = 1.0
        return out
    # [gray, black, white]. Unknown -> zéro partout.
    out = np.zeros((3,), dtype=np.float32)
    if color in (GroundColor.GRAY, GroundColor.BLACK, GroundColor.WHITE):
        out[int(color)] = 1.0
    return out


@dataclass
class GroundZone:
    label: GroundColor | str | int
    name: str = "zone"
    priority: int = 0

    def contains(self, x: float, y: float) -> bool:
        raise NotImplementedError

    def signed_distance_to_boundary(self, x: float, y: float) -> float:
        """
        Distance signée approximative à la frontière.
        Valeur positive à l'intérieur, négative à l'extérieur.
        Utile pour ajouter du bruit près des frontières.
        """
        return -float("inf")

    @property
    def color(self) -> GroundColor:
        return normalize_color(self.label)


@dataclass
class CircleZone(GroundZone):
    center: tuple[float, float] = (0.0, 0.0)
    radius: float = 0.25

    def contains(self, x: float, y: float) -> bool:
        dx = float(x) - self.center[0]
        dy = float(y) - self.center[1]
        return dx * dx + dy * dy <= self.radius * self.radius

    def signed_distance_to_boundary(self, x: float, y: float) -> float:
        return self.radius - math.hypot(float(x) - self.center[0], float(y) - self.center[1])


@dataclass
class RectangleZone(GroundZone):
    center: tuple[float, float] = (0.0, 0.0)
    size: tuple[float, float] = (1.0, 1.0)
    yaw: float = 0.0

    def _local(self, x: float, y: float) -> tuple[float, float]:
        dx = float(x) - self.center[0]
        dy = float(y) - self.center[1]
        c = math.cos(-self.yaw)
        s = math.sin(-self.yaw)
        return c * dx - s * dy, s * dx + c * dy

    def contains(self, x: float, y: float) -> bool:
        lx, ly = self._local(x, y)
        return abs(lx) <= 0.5 * self.size[0] and abs(ly) <= 0.5 * self.size[1]

    def signed_distance_to_boundary(self, x: float, y: float) -> float:
        lx, ly = self._local(x, y)
        dx = 0.5 * self.size[0] - abs(lx)
        dy = 0.5 * self.size[1] - abs(ly)
        return min(dx, dy)


@dataclass
class PolygonZone(GroundZone):
    vertices: Sequence[tuple[float, float]] = field(default_factory=list)

    def contains(self, x: float, y: float) -> bool:
        # Algorithme ray crossing.
        inside = False
        px, py = float(x), float(y)
        verts = list(self.vertices)
        n = len(verts)
        if n < 3:
            return False
        j = n - 1
        for i in range(n):
            xi, yi = verts[i]
            xj, yj = verts[j]
            if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / ((yj - yi) + 1e-12) + xi):
                inside = not inside
            j = i
        return inside


@dataclass
class GroundReading:
    label: GroundColor
    label_name: str
    label_id: int
    one_hot: np.ndarray
    rgb: np.ndarray
    position_xy: np.ndarray
    noisy: bool = False
    source: str = "analytic"


class GroundMap:
    """Carte de zones sémantiques avec priorité."""

    def __init__(self, default: GroundColor | str | int = GroundColor.GRAY):
        self.default = normalize_color(default)
        self.zones: list[GroundZone] = []

    def add_zone(self, zone: GroundZone) -> GroundZone:
        self.zones.append(zone)
        self.zones.sort(key=lambda z: z.priority)
        return zone

    def add_circle(
        self,
        label: GroundColor | str | int,
        center: tuple[float, float],
        radius: float,
        *,
        name: str | None = None,
        priority: int = 10,
    ) -> CircleZone:
        return self.add_zone(CircleZone(label=label, center=center, radius=radius, name=name or f"circle_{color_label(label)}", priority=priority))

    def add_rectangle(
        self,
        label: GroundColor | str | int,
        center: tuple[float, float],
        size: tuple[float, float],
        *,
        yaw: float = 0.0,
        name: str | None = None,
        priority: int = 10,
    ) -> RectangleZone:
        return self.add_zone(RectangleZone(label=label, center=center, size=size, yaw=yaw, name=name or f"rect_{color_label(label)}", priority=priority))

    def query_color(self, x: float, y: float) -> GroundColor:
        # Les priorités les plus grandes écrasent les zones de priorité faible.
        result = self.default
        for zone in self.zones:
            if zone.contains(x, y):
                result = zone.color
        return result

    def query_label(self, x: float, y: float) -> str:
        return color_label(self.query_color(x, y))

    def query_rgb(self, x: float, y: float) -> np.ndarray:
        return color_rgb(self.query_color(x, y))

    def query_one_hot(self, x: float, y: float, include_unknown: bool = False) -> np.ndarray:
        return color_one_hot(self.query_color(x, y), include_unknown=include_unknown)

    def query_many(self, xy: np.ndarray, include_unknown: bool = False) -> np.ndarray:
        xy = np.asarray(xy, dtype=np.float32)
        out = np.zeros((xy.shape[0], 4 if include_unknown else 3), dtype=np.float32)
        for i, (x, y) in enumerate(xy[:, :2]):
            out[i] = self.query_one_hot(float(x), float(y), include_unknown=include_unknown)
        return out

    def signed_distance_to_nearest_boundary(self, x: float, y: float) -> float:
        distances = [abs(zone.signed_distance_to_boundary(x, y)) for zone in self.zones]
        return min(distances) if distances else float("inf")

    @staticmethod
    def demo_map() -> "GroundMap":
        """Carte de test avec zones typiques black/white/gray."""
        gm = GroundMap(default="gray")
        gm.add_circle("black", center=(-0.55, 0.0), radius=0.28, name="black_goal_left", priority=10)
        gm.add_circle("black", center=(0.55, 0.0), radius=0.28, name="black_goal_right", priority=10)
        gm.add_rectangle("white", center=(0.0, 0.75), size=(0.55, 0.32), name="white_nest", priority=20)
        gm.add_rectangle("black", center=(0.0, -0.75), size=(0.22, 0.90), name="black_corridor", priority=15)
        return gm
