from __future__ import annotations

from .lidar_helper import RtxLidarHelper


class LidarPointCloudVisualizer(RtxLidarHelper):
    """Visualisation optionnelle du RTX LiDAR. À éviter en RL/benchmark."""

    def __init__(self, lidar_prim_path: str, **kwargs):
        kwargs.setdefault("debug_draw", True)
        kwargs.setdefault("disable_usd_debug_draw", False)
        super().__init__(lidar_prim_path, **kwargs)

    def enable(self):
        self._ensure_initialized()
        return self

    def disable(self):
        self.detach()
