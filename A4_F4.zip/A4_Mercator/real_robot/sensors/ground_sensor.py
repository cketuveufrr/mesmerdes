"""
Ground sensor Mercator pour Isaac Sim 6.0.

Backend recommandé : AnalyticGroundSensor
    pose du prim ground_sensor -> position XY -> GroundMap -> label discret.

Backend de debug : RaycastGroundSensor
    rayon court vers le bas -> prim touché -> attribut ground:label ou displayColor.

L'API conserve `get_ground_color()` pour compatibilité avec CLC, mais expose en
plus `get_label()` et `get_one_hot()` pour le RL.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import numpy as np

from .ground_map import (
    GroundColor,
    GroundMap,
    GroundReading,
    color_label,
    color_one_hot,
    color_rgb,
    normalize_color,
)


def _to_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


@dataclass
class LabelNoiseModel:
    """
    Bruit discret optionnel sous forme de matrice de confusion.

    Par défaut, le modèle est quasi parfait. Il peut être utilisé pour domain
    randomization : plus tard on pourra augmenter les erreurs aux frontières.
    """

    confusion: Mapping[GroundColor, Mapping[GroundColor, float]] | None = None
    boundary_width: float = 0.02
    boundary_error_probability: float = 0.0
    seed: int | None = None

    def __post_init__(self) -> None:
        self.rng = np.random.default_rng(self.seed)
        if self.confusion is None:
            self.confusion = {
                GroundColor.GRAY: {GroundColor.GRAY: 1.0},
                GroundColor.BLACK: {GroundColor.BLACK: 1.0},
                GroundColor.WHITE: {GroundColor.WHITE: 1.0},
                GroundColor.UNKNOWN: {GroundColor.UNKNOWN: 1.0},
            }

    def sample(self, true_color: GroundColor, *, distance_to_boundary: float = float("inf")) -> tuple[GroundColor, bool]:
        color = normalize_color(true_color)
        dist = abs(float(distance_to_boundary))
        if dist < self.boundary_width and self.boundary_error_probability > 0.0:
            if self.rng.random() < self.boundary_error_probability:
                # Confusion simple près des frontières : on retourne gray si la
                # zone est black/white ; sinon une des couleurs fortes.
                if color == GroundColor.BLACK or color == GroundColor.WHITE:
                    return GroundColor.GRAY, True
                if color == GroundColor.GRAY:
                    return self.rng.choice([GroundColor.BLACK, GroundColor.WHITE]).item(), True

        choices = self.confusion.get(color, {color: 1.0})
        labels = list(choices.keys())
        probs = np.array([choices[k] for k in labels], dtype=np.float64)
        probs = probs / probs.sum()
        sampled = labels[int(self.rng.choice(len(labels), p=probs))]
        return normalize_color(sampled), sampled != color


class AnalyticGroundSensor:
    """
    Capteur de sol recommandé pour le RL.

    Il lit la position monde du prim `ground_sensor`, projette en XY, puis
    interroge une GroundMap. Aucune collision, aucun raycast, aucun patch USD.
    """

    def __init__(
        self,
        sensor_prim_path: str,
        ground_map: GroundMap,
        *,
        default_color: GroundColor | str | int = GroundColor.GRAY,
        noise_model: LabelNoiseModel | None = None,
        include_unknown_in_one_hot: bool = False,
        verbose: bool = False,
    ):
        self.sensor_prim_path = sensor_prim_path
        self.ground_map = ground_map
        self.default_color = normalize_color(default_color)
        self.noise_model = noise_model
        self.include_unknown_in_one_hot = bool(include_unknown_in_one_hot)
        self.verbose = bool(verbose)

        import omni.usd
        from pxr import UsdGeom

        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.xform_cache = UsdGeom.XformCache()
        self.sensor_prim = self.stage.GetPrimAtPath(sensor_prim_path)
        if not self.sensor_prim or not self.sensor_prim.IsValid():
            raise RuntimeError(f"Prim ground_sensor introuvable : {sensor_prim_path}")
        if self.verbose:
            print(f"[AnalyticGroundSensor] {sensor_prim_path}")

    def get_sensor_world_position(self) -> np.ndarray:
        self.xform_cache.Clear()
        world_tf = self.xform_cache.GetLocalToWorldTransform(self.sensor_prim)
        p = world_tf.ExtractTranslation()
        return np.array([float(p[0]), float(p[1]), float(p[2])], dtype=np.float32)

    def read(self) -> GroundReading:
        pos = self.get_sensor_world_position()
        x, y = float(pos[0]), float(pos[1])
        true_color = self.ground_map.query_color(x, y)
        noisy = False
        color = true_color
        if self.noise_model is not None:
            dist = self.ground_map.signed_distance_to_nearest_boundary(x, y)
            color, noisy = self.noise_model.sample(true_color, distance_to_boundary=dist)
        return GroundReading(
            label=color,
            label_name=color_label(color),
            label_id=int(color),
            one_hot=color_one_hot(color, include_unknown=self.include_unknown_in_one_hot),
            rgb=color_rgb(color),
            position_xy=np.array([x, y], dtype=np.float32),
            noisy=noisy,
            source="analytic",
        )

    def get_label(self) -> str:
        return self.read().label_name

    def get_label_id(self) -> int:
        return self.read().label_id

    def get_one_hot(self) -> np.ndarray:
        return self.read().one_hot

    def get_rgb(self) -> np.ndarray:
        return self.read().rgb

    def get_ground_color(self):
        """
        Compatibilité CLC.

        Retourne :
            (rgb_tuple, sensor_pos_tuple, origin_tuple)
        `origin` n'a pas de sens en analytique ; on renvoie la position capteur.
        """
        reading = self.read()
        pos3 = self.get_sensor_world_position()
        rgb_tuple = tuple(float(v) for v in reading.rgb)
        pos_tuple = tuple(float(v) for v in pos3)
        return rgb_tuple, pos_tuple, pos_tuple


class RaycastGroundSensor:
    """
    Backend de debug proche CLC, mais corrigé.

    Le rayon part légèrement au-dessus du capteur et pointe vers le bas. Le hit
    lit d'abord `ground:label`, puis retombe éventuellement sur displayColor.
    """

    def __init__(
        self,
        sensor_prim_path: str,
        robot_root_path: str,
        *,
        max_distance: float = 0.40,
        origin_z_offset: float = 0.08,
        default_color: GroundColor | str | int = GroundColor.GRAY,
        verbose: bool = False,
    ):
        import carb
        from omni.physx import get_physx_scene_query_interface

        self.carb = carb
        self.query = get_physx_scene_query_interface()
        self.sensor_prim_path = sensor_prim_path
        self.robot_root_path = robot_root_path.rstrip("/")
        self.max_distance = float(max_distance)
        self.origin_z_offset = float(origin_z_offset)
        self.default_color = normalize_color(default_color)
        self.verbose = bool(verbose)

        import omni.usd
        from pxr import UsdGeom

        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.xform_cache = UsdGeom.XformCache()
        self.sensor_prim = self.stage.GetPrimAtPath(sensor_prim_path)
        if not self.sensor_prim or not self.sensor_prim.IsValid():
            raise RuntimeError(f"Prim ground_sensor introuvable : {sensor_prim_path}")

    def get_sensor_world_position(self) -> np.ndarray:
        self.xform_cache.Clear()
        world_tf = self.xform_cache.GetLocalToWorldTransform(self.sensor_prim)
        p = world_tf.ExtractTranslation()
        return np.array([float(p[0]), float(p[1]), float(p[2])], dtype=np.float32)

    def _read_label_from_prim(self, prim) -> GroundColor | None:
        attr = prim.GetAttribute("ground:label")
        if attr and attr.IsValid() and attr.HasValue():
            return normalize_color(attr.Get())
        id_attr = prim.GetAttribute("ground:id")
        if id_attr and id_attr.IsValid() and id_attr.HasValue():
            return normalize_color(int(id_attr.Get()))
        return None

    def _read_display_color_from_prim(self, prim) -> GroundColor | None:
        gprim = self.UsdGeom.Gprim(prim)
        attr = gprim.GetDisplayColorAttr() if gprim else None
        if not attr or not attr.HasValue():
            return None
        colors = attr.Get()
        if not colors:
            return None
        rgb = np.array([float(colors[0][0]), float(colors[0][1]), float(colors[0][2])], dtype=np.float32)
        # Conversion nearest-neighbor vers gray/black/white.
        candidates = [GroundColor.GRAY, GroundColor.BLACK, GroundColor.WHITE]
        dists = [float(np.linalg.norm(rgb - color_rgb(c))) for c in candidates]
        return candidates[int(np.argmin(dists))]

    def read(self) -> GroundReading:
        pos = self.get_sensor_world_position()
        origin = self.carb.Float3(float(pos[0]), float(pos[1]), float(pos[2] + self.origin_z_offset))
        direction = self.carb.Float3(0.0, 0.0, -1.0)
        hits = []
        self.query.raycast_all(origin, direction, self.max_distance, lambda h: (hits.append(h) or True))
        hits.sort(key=lambda h: h.distance)

        color = self.default_color
        for hit in hits:
            path = hit.collision or hit.rigid_body
            if not path:
                continue
            if str(path).startswith(self.robot_root_path):
                continue
            prim = self.stage.GetPrimAtPath(path)
            if not prim or not prim.IsValid():
                continue
            color = self._read_label_from_prim(prim) or self._read_display_color_from_prim(prim) or self.default_color
            break

        return GroundReading(
            label=color,
            label_name=color_label(color),
            label_id=int(color),
            one_hot=color_one_hot(color),
            rgb=color_rgb(color),
            position_xy=np.array([float(pos[0]), float(pos[1])], dtype=np.float32),
            noisy=False,
            source="raycast",
        )

    def get_label(self) -> str:
        return self.read().label_name

    def get_label_id(self) -> int:
        return self.read().label_id

    def get_one_hot(self) -> np.ndarray:
        return self.read().one_hot

    def get_rgb(self) -> np.ndarray:
        return self.read().rgb

    def get_ground_color(self):
        reading = self.read()
        pos = self.get_sensor_world_position()
        origin = (float(pos[0]), float(pos[1]), float(pos[2] + self.origin_z_offset))
        return tuple(float(v) for v in reading.rgb), tuple(float(v) for v in pos), origin


# Nom court recommandé.
GroundSensor = AnalyticGroundSensor
