"""Visualisation USD des rayons TeraRanger."""

from __future__ import annotations

import re
from typing import Iterable

import numpy as np

from .teraranger_helper import TeraRangerArrayHelper, TeraRangerFrame


def _safe_usd_name(name: str) -> str:
    out = re.sub(r"[^A-Za-z0-9_]", "_", str(name))
    return out if out else "sensor"


class TeraRangerDebugVisualizer:
    """
    Dessine dans le stage :
      - une ligne par rayon ;
      - une petite sphère sur chaque origine ;
      - une petite sphère sur chaque hit.

    Bleu = pas de hit, vert = hit.
    """

    def __init__(
        self,
        helper: TeraRangerArrayHelper,
        *,
        root_path: str = "/World/DebugTeraRangers",
        ray_width: float = 0.012,
        origin_radius: float = 0.018,
        hit_radius: float = 0.026,
    ):
        self.helper = helper
        self.root_path = root_path.rstrip("/")
        self.ray_width = float(ray_width)
        self.origin_radius = float(origin_radius)
        self.hit_radius = float(hit_radius)

        import omni.usd
        from pxr import Gf, UsdGeom

        self.Gf = Gf
        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.stage.DefinePrim(self.root_path, "Xform")

    def clear(self) -> None:
        prim = self.stage.GetPrimAtPath(self.root_path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(self.root_path)
        self.stage.DefinePrim(self.root_path, "Xform")

    def _delete_if_exists(self, path: str) -> None:
        prim = self.stage.GetPrimAtPath(path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(path)

    def _set_display_color(self, prim, rgb: tuple[float, float, float], opacity: float = 1.0) -> None:
        gprim = self.UsdGeom.Gprim(prim)
        gprim.CreateDisplayColorAttr([self.Gf.Vec3f(float(rgb[0]), float(rgb[1]), float(rgb[2]))])
        gprim.CreateDisplayOpacityAttr([float(opacity)])

    def _draw_line(self, path: str, a: Iterable[float], b: Iterable[float], *, color: tuple[float, float, float]) -> None:
        self._delete_if_exists(path)
        a = np.asarray(a, dtype=np.float32)
        b = np.asarray(b, dtype=np.float32)
        curves = self.UsdGeom.BasisCurves.Define(self.stage, path)
        curves.CreateTypeAttr("linear")
        curves.CreateBasisAttr("bezier")
        curves.CreateCurveVertexCountsAttr([2])
        curves.CreatePointsAttr([self.Gf.Vec3f(float(a[0]), float(a[1]), float(a[2])), self.Gf.Vec3f(float(b[0]), float(b[1]), float(b[2]))])
        w = float(self.ray_width)
        curves.CreateWidthsAttr([w, w])
        try:
            curves.SetWidthsInterpolation(self.UsdGeom.Tokens.vertex)
        except Exception:
            pass
        self._set_display_color(curves.GetPrim(), color)

    def _draw_sphere(self, path: str, position: Iterable[float], *, radius: float, color: tuple[float, float, float]) -> None:
        self._delete_if_exists(path)
        p = np.asarray(position, dtype=np.float32)
        sphere = self.UsdGeom.Sphere.Define(self.stage, path)
        sphere.CreateRadiusAttr(float(radius))
        xform = self.UsdGeom.Xformable(sphere.GetPrim())
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set(self.Gf.Vec3d(float(p[0]), float(p[1]), float(p[2])))
        self._set_display_color(sphere.GetPrim(), color)

    def update(self, frame: TeraRangerFrame | None = None) -> TeraRangerFrame:
        frame = frame or self.helper.read()
        self.stage.DefinePrim(self.root_path, "Xform")

        for reading in frame.readings:
            name = _safe_usd_name(reading.name)
            sensor_root = f"{self.root_path}/{name}"
            self.stage.DefinePrim(sensor_root, "Xform")
            color = (0.0, 1.0, 0.0) if reading.hit else (0.1, 0.25, 1.0)
            self._draw_line(f"{sensor_root}/ray", reading.origin, reading.endpoint, color=color)
            self._draw_sphere(f"{sensor_root}/origin", reading.origin, radius=self.origin_radius, color=(1.0, 1.0, 1.0))
            if reading.hit:
                self._draw_sphere(f"{sensor_root}/hit", reading.endpoint, radius=self.hit_radius, color=(0.0, 1.0, 0.0))
            else:
                self._delete_if_exists(f"{sensor_root}/hit")
        return frame
