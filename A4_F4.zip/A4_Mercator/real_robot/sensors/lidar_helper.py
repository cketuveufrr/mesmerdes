"""
Helper RTX LiDAR Isaac Sim 6.0 pour le Mercator-Lite.

Objectif : conserver l'interface fonctionnelle de CLC (`get_point_cloud`,
`get_min_distance`, etc.) tout en utilisant un backend Isaac 6.0 plus propre.

Backend principal : Replicator + `IsaacExtractRTXSensorPointCloud` sur le prim
`OmniLidar` déjà présent dans le USD.

Fallbacks :
- `isaacsim.sensors.experimental.rtx.LidarSensor` + generic-model-output ;
- ancien `LidarRtx` + `IsaacComputeRTXLidarFlatScan`, uniquement pour
  compatibilité/debug.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

import math
import numpy as np


@dataclass
class LidarFrame:
    points: np.ndarray
    raw: Any | None = None
    sensor_to_world: np.ndarray | None = None


def _to_numpy(value: Any) -> np.ndarray:
    if value is None:
        return np.array([])
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


def _as_mapping(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "_asdict"):
        return dict(value._asdict())
    if hasattr(value, "__dict__"):
        return dict(value.__dict__)
    return {}


def _first_existing(mapping: Mapping[str, Any], keys: Iterable[str]) -> Any | None:
    for key in keys:
        if key in mapping:
            return mapping[key]
    return None


def _normalize_points(points: Any) -> np.ndarray:
    arr = _to_numpy(points).astype(np.float32, copy=False)
    if arr.size == 0:
        return np.empty((0, 3), dtype=np.float32)
    if arr.ndim == 1:
        if arr.size % 3 != 0:
            return np.empty((0, 3), dtype=np.float32)
        arr = arr.reshape((-1, 3))
    if arr.ndim > 2 and arr.shape[-1] == 3:
        arr = arr.reshape((-1, 3))
    if arr.ndim != 2 or arr.shape[1] < 3:
        return np.empty((0, 3), dtype=np.float32)
    arr = arr[:, :3]
    valid = np.isfinite(arr).all(axis=1)
    return arr[valid] if np.any(valid) else np.empty((0, 3), dtype=np.float32)


class RtxLidarHelper:
    def __init__(
        self,
        lidar_prim_path: str,
        *,
        min_valid_range: float = 0.12,
        max_valid_range: float = 10.0,
        disable_usd_debug_draw: bool = True,
        debug_draw: bool = False,
        tick_rate: float | None = None,
        use_point_cloud_annotator: bool = True,
        verbose: bool = False,
    ):
        self.lidar_prim_path = lidar_prim_path
        self.min_valid_range = float(min_valid_range)
        self.max_valid_range = float(max_valid_range)
        self.disable_usd_debug_draw = bool(disable_usd_debug_draw)
        self.debug_draw = bool(debug_draw)
        self.tick_rate = tick_rate
        self.use_point_cloud_annotator = bool(use_point_cloud_annotator)
        self.verbose = bool(verbose)

        self._initialized = False
        self._backend_name: str | None = None
        self._render_product = None
        self._annotator = None
        self._lidar_authoring = None
        self._lidar_sensor = None
        self._parse_gmo = None
        self._legacy_sensor = None

    def _enable_extension(self, ext_name: str) -> None:
        try:
            import omni.kit.app

            manager = omni.kit.app.get_app().get_extension_manager()
            manager.set_extension_enabled_immediate(ext_name, True)
        except Exception as exc:
            if self.verbose:
                print(f"[lidar] extension non activée explicitement {ext_name}: {exc}")

    def _get_stage_and_prim(self):
        import omni.usd

        stage = omni.usd.get_context().get_stage()
        prim = stage.GetPrimAtPath(self.lidar_prim_path)
        if not prim or not prim.IsValid():
            raise RuntimeError(f"LiDAR introuvable : {self.lidar_prim_path}")
        return stage, prim

    def _set_attr_if_possible(self, prim, name: str, value: Any, sdf_type: Any | None = None) -> None:
        attr = prim.GetAttribute(name)
        if not attr or not attr.IsValid():
            if sdf_type is None:
                return
            attr = prim.CreateAttribute(name, sdf_type, custom=False)
        attr.Set(value)

    def _configure_lidar_prim(self) -> None:
        from pxr import Sdf

        _, prim = self._get_stage_and_prim()
        if self.disable_usd_debug_draw:
            self._set_attr_if_possible(prim, "rtx:lidar:drawPoints", False)
            self._set_attr_if_possible(prim, "rtx:lidar:drawLines", False)

        scan_rate_attr = prim.GetAttribute("omni:sensor:Core:scanRateBaseHz")
        scan_rate = scan_rate_attr.Get() if scan_rate_attr and scan_rate_attr.IsValid() else None
        effective_tick_rate = self.tick_rate if self.tick_rate is not None else scan_rate
        if effective_tick_rate is not None:
            self._set_attr_if_possible(prim, "omni:sensor:tickRate", float(effective_tick_rate), Sdf.ValueTypeNames.Float)
        self._set_attr_if_possible(prim, "omni:sensor:Core:accumulateOutputs", True, Sdf.ValueTypeNames.Bool)

    def _init_point_cloud_annotator(self) -> bool:
        try:
            self._enable_extension("omni.replicator.core")
            self._enable_extension("isaacsim.sensors.rtx.nodes")
            import omni.replicator.core as rep

            self._render_product = rep.create.render_product(
                self.lidar_prim_path,
                resolution=(1, 1),
                name=f"rp_{self.lidar_prim_path.strip('/').replace('/', '_')}",
            )
            render_product_path = getattr(self._render_product, "path", self._render_product)
            self._annotator = rep.AnnotatorRegistry.get_annotator("IsaacExtractRTXSensorPointCloud")
            self._annotator.attach([render_product_path])
            self._backend_name = "IsaacExtractRTXSensorPointCloud"
            return True
        except Exception as exc:
            if self.verbose:
                print(f"[lidar] échec backend point-cloud annotator: {exc}")
            self._render_product = None
            self._annotator = None
            return False

    def _init_lidar_sensor_gmo(self) -> bool:
        try:
            self._enable_extension("isaacsim.sensors.experimental.rtx")
            from isaacsim.sensors.experimental.rtx import Lidar, LidarSensor, parse_generic_model_output_data

            self._lidar_authoring = Lidar(self.lidar_prim_path)
            writers = ["draw-point-cloud"] if self.debug_draw else []
            self._lidar_sensor = LidarSensor(
                self._lidar_authoring,
                annotators=["generic-model-output"],
                writers=writers,
            )
            self._parse_gmo = parse_generic_model_output_data
            self._backend_name = "LidarSensor/generic-model-output"
            return True
        except Exception as exc:
            if self.verbose:
                print(f"[lidar] échec backend LidarSensor/GMO: {exc}")
            return False

    def _init_legacy_lidarrtx(self) -> bool:
        try:
            from isaacsim.sensors.rtx import LidarRtx

            self._legacy_sensor = LidarRtx(prim_path=self.lidar_prim_path)
            self._legacy_sensor.initialize()
            self._legacy_sensor.attach_annotator("IsaacComputeRTXLidarFlatScan")
            self._backend_name = "legacy/LidarRtx/IsaacComputeRTXLidarFlatScan"
            return True
        except Exception as exc:
            if self.verbose:
                print(f"[lidar] échec backend legacy LidarRtx: {exc}")
            return False

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        self._configure_lidar_prim()
        ok = self._init_point_cloud_annotator() if self.use_point_cloud_annotator else False
        ok = ok or self._init_lidar_sensor_gmo() or self._init_legacy_lidarrtx()
        if not ok:
            raise RuntimeError("Impossible d'initialiser le RTX LiDAR. Lance le script dans Isaac Sim 6.0 après SimulationApp.")
        self._initialized = True
        if self.verbose:
            print(f"[lidar] {self.lidar_prim_path} initialisé avec {self._backend_name}")

    def _read_point_cloud_annotator(self) -> LidarFrame:
        raw = self._annotator.get_data()
        mapping = _as_mapping(raw)
        point_candidates = ["data", "points", "pointCloud", "point_cloud", "pointcloud", "xyz", "coords", "coordinates"]
        points = _normalize_points(_first_existing(mapping, point_candidates))
        transform_candidates = ["transform", "sensorToWorld", "sensor_to_world", "sensorTransform", "sensor_to_world_transform"]
        transform_raw = _first_existing(mapping, transform_candidates)
        transform = None
        if transform_raw is not None:
            t = _to_numpy(transform_raw).astype(np.float32, copy=False)
            if t.size == 16:
                transform = t.reshape(4, 4)
        return LidarFrame(points=points, raw=raw, sensor_to_world=transform)

    def _read_lidar_sensor_gmo(self) -> LidarFrame:
        data, info = self._lidar_sensor.get_data("generic-model-output")
        parsed = self._parse_gmo(data)
        mapping = _as_mapping(parsed)
        point_candidates = ["data", "points", "pointCloud", "point_cloud", "pointcloud", "xyz", "coords", "coordinates"]
        points = _normalize_points(_first_existing(mapping, point_candidates))
        if points.shape[0] == 0:
            for value in mapping.values():
                nested = _as_mapping(value)
                if nested:
                    points = _normalize_points(_first_existing(nested, point_candidates))
                    if points.shape[0] > 0:
                        break
        return LidarFrame(points=points, raw={"data": data, "info": info, "parsed": parsed})

    def _read_legacy_flat_scan(self) -> LidarFrame:
        frame = self._legacy_sensor.get_current_frame()
        if "IsaacComputeRTXLidarFlatScan" not in frame:
            return LidarFrame(points=np.empty((0, 3), dtype=np.float32), raw=frame)
        lidar_data = frame["IsaacComputeRTXLidarFlatScan"]
        depths = np.array(lidar_data.get("linearDepthData", []), dtype=np.float32)
        azimuth_range = np.array(lidar_data.get("azimuthRange", [0.0, 0.0]), dtype=np.float32)
        resolution = float(lidar_data.get("horizontalResolution", 0.0))
        if depths.size == 0:
            return LidarFrame(points=np.empty((0, 3), dtype=np.float32), raw=lidar_data)
        angles = float(azimuth_range[0]) + np.arange(depths.size, dtype=np.float32) * resolution
        angles_rad = np.radians(angles)
        valid = np.isfinite(depths) & (depths > 0.0)
        points = np.stack([depths * np.cos(angles_rad), depths * np.sin(angles_rad), np.zeros_like(depths)], axis=1)
        return LidarFrame(points=points[valid].astype(np.float32), raw=lidar_data)

    def get_frame(self) -> LidarFrame:
        self._ensure_initialized()
        if self._backend_name == "IsaacExtractRTXSensorPointCloud":
            frame = self._read_point_cloud_annotator()
        elif self._backend_name == "LidarSensor/generic-model-output":
            frame = self._read_lidar_sensor_gmo()
        else:
            frame = self._read_legacy_flat_scan()
        frame.points = self._filter_points(frame.points)
        return frame

    def _filter_points(self, points: np.ndarray) -> np.ndarray:
        points = _normalize_points(points)
        if points.shape[0] == 0:
            return points
        ranges = np.linalg.norm(points[:, :2], axis=1)
        valid = np.isfinite(ranges) & (ranges >= self.min_valid_range) & (ranges <= self.max_valid_range)
        return points[valid]

    def get_point_cloud(self) -> np.ndarray:
        return self.get_frame().points

    def get_min_distance(self) -> float:
        points = self.get_point_cloud()
        if points.shape[0] == 0:
            return float("inf")
        return float(np.min(np.linalg.norm(points[:, :2], axis=1)))

    def get_raw_scans(self) -> dict[str, np.ndarray | float]:
        points = self.get_point_cloud()
        if points.shape[0] == 0:
            return {"linearDepthData": np.empty((0,), dtype=np.float32), "azimuthRange": np.array([0.0, 0.0], dtype=np.float32), "horizontalResolution": 0.0}
        depths = np.linalg.norm(points[:, :2], axis=1).astype(np.float32)
        azimuths = np.degrees(np.arctan2(points[:, 1], points[:, 0])).astype(np.float32)
        order = np.argsort(azimuths)
        depths, azimuths = depths[order], azimuths[order]
        resolution = float(np.median(np.diff(azimuths))) if azimuths.size > 1 else 0.0
        return {"linearDepthData": depths, "azimuthRange": np.array([azimuths[0], azimuths[-1]], dtype=np.float32), "horizontalResolution": resolution}

    def get_sector_observation(self, num_sectors: int = 36, max_range: float | None = None, fill_value: float = 1.0) -> np.ndarray:
        if max_range is None:
            max_range = self.max_valid_range
        obs = np.full((num_sectors,), float(fill_value), dtype=np.float32)
        points = self.get_point_cloud()
        if points.shape[0] == 0:
            return obs
        ranges = np.linalg.norm(points[:, :2], axis=1)
        angles = np.arctan2(points[:, 1], points[:, 0])
        normalized = np.clip(ranges / float(max_range), 0.0, 1.0)
        sector_ids = np.floor((angles + math.pi) / (2.0 * math.pi) * num_sectors).astype(int)
        sector_ids = np.clip(sector_ids, 0, num_sectors - 1)
        for sector_id, value in zip(sector_ids, normalized):
            if value < obs[sector_id]:
                obs[sector_id] = float(value)
        return obs

    def detach(self) -> None:
        try:
            if self._annotator is not None:
                self._annotator.detach()
        except Exception:
            pass


LidarHelper = RtxLidarHelper
