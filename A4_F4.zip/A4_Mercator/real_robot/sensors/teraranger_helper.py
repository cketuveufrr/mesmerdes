"""
TeraRanger Multiflex logique pour Mercator / Isaac Sim 6.0.

Le modèle est volontairement simple et rapide pour le RL : chaque TeraRanger est
un Xform déjà présent dans l'USD, et son axe local +X définit la direction du
rayon. Le helper ne hardcode donc pas la géométrie du robot : il lit les poses
monde des Xform, lance des raycasts PhysX, puis renvoie 8 scalaires.

Prim attendu :
    /World/<RobotName>/MercatorLite/base_link/terarangers

Xforms actuels dans l'asset :
    p0, p1_2, p1_1, p2, p3, p4, p6, p7

Remarque importante : il n'y a volontairement pas de p5 arrière pur. Le devant
est composé de deux capteurs distincts, p1_1 et p1_2.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

import numpy as np


DEFAULT_TERARANGER_NAMES: tuple[str, ...] = ("p0", "p1_2", "p1_1", "p2", "p3", "p4", "p6", "p7")


def _to_numpy3(value: Any) -> np.ndarray:
    if hasattr(value, "numpy"):
        value = value.numpy()
    arr = np.asarray(value, dtype=np.float32)
    if arr.shape != (3,):
        arr = arr.reshape(3)
    return arr.astype(np.float32, copy=False)


def _normalize(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=np.float32)
    n = float(np.linalg.norm(v))
    if n <= 1e-9 or not np.isfinite(n):
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    return (v / n).astype(np.float32, copy=False)

def rvr_dao_proximity_from_distance(distance: float) -> float:
    """Reproduit la normalisation de ReferenceModel1Dot2::GetProximityReading.

    distance en mètres.
    Sortie :
        0.0 = pas d'obstacle significatif
        1.0 = obstacle très proche dans la plage utile
    """
    d = float(distance)
    if not np.isfinite(d):
        return 0.0

    # Même fenêtre que demiurge-rvr-dao :
    # valeurs hors portée -> 0
    if d < 0.05 or d > 0.40:
        return 0.0

    # Même loi que le DAO RVR :
    p = ((1.0 / d) - 2.5) / 17.5

    # Sécurité numérique côté Python / Isaac
    return float(np.clip(p, 0.0, 1.0))


def _hit_field(hit: Any, name: str, default: Any = None) -> Any:
    if isinstance(hit, Mapping):
        return hit.get(name, default)
    return getattr(hit, name, default)


@dataclass(frozen=True)
class TeraRangerRayPose:
    name: str
    prim_path: str
    origin: np.ndarray
    direction: np.ndarray


@dataclass(frozen=True)
class TeraRangerReading:
    name: str
    distance: float
    proximity: float
    hit: bool
    hit_path: str | None
    origin: np.ndarray
    direction: np.ndarray
    endpoint: np.ndarray


@dataclass(frozen=True)
class TeraRangerFrame:
    names: tuple[str, ...]
    distances: np.ndarray
    proximities: np.ndarray
    hits: np.ndarray
    readings: tuple[TeraRangerReading, ...]

    def as_named_distances(self) -> dict[str, float]:
        return {name: float(value) for name, value in zip(self.names, self.distances)}

    def as_named_proximities(self) -> dict[str, float]:
        return {name: float(value) for name, value in zip(self.names, self.proximities)}

    def as_observation(self, *, mode: str = "proximity") -> np.ndarray:
        if mode == "proximity":
            return self.proximities.astype(np.float32, copy=True)
        if mode in ("distance", "range"):
            return self.distances.astype(np.float32, copy=True)
        if mode in ("normalized_distance", "normalized_range"):
            # distances déjà bornées dans [0, max_range] côté helper ; le helper
            # expose cette variante via get_observation() car il connaît max_range.
            raise ValueError("Utilise TeraRangerArrayHelper.get_observation('normalized_distance').")
        raise ValueError(f"mode inconnu: {mode}")


class TeraRangerArrayHelper:
    """
    Ceinture TeraRanger basée sur les Xform de l'USD.

    Sortie RL recommandée : `get_proximities()`.
        0.0 = rien ou loin
        1.0 = obstacle à min_range ou plus proche

    Si tu veux une distance normalisée, utilise :
        get_observation(mode="normalized_distance")
        0.0 = obstacle proche
        1.0 = rien ou max_range
    """

    def __init__(
        self,
        sensor_root_path: str,
        *,
        robot_root_path: str | None = None,
        sensor_names: Sequence[str] | None = DEFAULT_TERARANGER_NAMES,
        min_range: float = 0.02,
        max_range: float = 1.1,
        origin_offset: float = 0.005,
        ignore_self_hits: bool = True,
        verbose: bool = False,
    ):
        self.sensor_root_path = sensor_root_path.rstrip("/")
        self.robot_root_path = robot_root_path.rstrip("/") if robot_root_path else self._infer_robot_root_path(self.sensor_root_path)
        self.sensor_names = tuple(sensor_names) if sensor_names is not None else None
        self.min_range = float(min_range)
        self.max_range = float(max_range)
        self.origin_offset = float(origin_offset)
        self.ignore_self_hits = bool(ignore_self_hits)
        self.verbose = bool(verbose)

        if self.max_range <= 0.0:
            raise ValueError("max_range doit être strictement positif")
        if self.min_range < 0.0:
            raise ValueError("min_range doit être positif ou nul")
        if self.min_range >= self.max_range:
            raise ValueError("min_range doit être inférieur à max_range")

        import carb
        import omni.usd
        from omni.physx import get_physx_scene_query_interface
        from pxr import Gf, UsdGeom

        self.carb = carb
        self.Gf = Gf
        self.UsdGeom = UsdGeom
        self.query = get_physx_scene_query_interface()
        self.stage = omni.usd.get_context().get_stage()
        self.xform_cache = UsdGeom.XformCache()

        self.sensor_root_prim = self.stage.GetPrimAtPath(self.sensor_root_path)
        if not self.sensor_root_prim or not self.sensor_root_prim.IsValid():
            raise RuntimeError(f"Racine TeraRanger introuvable : {self.sensor_root_path}")

        self.sensor_prims = self._resolve_sensor_prims()
        self.names = tuple(name for name, _prim in self.sensor_prims)
        if self.verbose:
            print(f"[TeraRangerArrayHelper] {self.sensor_root_path}")
            print(f"  robot_root_path = {self.robot_root_path}")
            print(f"  sensors         = {', '.join(self.names)}")

    @staticmethod
    def root_path_for_robot(robot_name: str) -> str:
        return f"/World/{robot_name}/MercatorLite/base_link/terarangers"

    @staticmethod
    def body_path_for_robot(robot_name: str) -> str:
        return f"/World/{robot_name}/MercatorLite"

    @staticmethod
    def _infer_robot_root_path(sensor_root_path: str) -> str:
        marker = "/base_link/terarangers"
        if marker in sensor_root_path:
            return sensor_root_path.split(marker)[0]
        parts = sensor_root_path.rstrip("/").split("/")
        if len(parts) >= 4:
            return "/".join(parts[:4])
        return sensor_root_path.rstrip("/")

    def _resolve_sensor_prims(self) -> list[tuple[str, Any]]:
        if self.sensor_names is None:
            out = []
            for child in self.sensor_root_prim.GetChildren():
                if child.IsA(self.UsdGeom.Xform):
                    out.append((child.GetName(), child))
            if not out:
                raise RuntimeError(f"Aucun Xform enfant trouvé dans {self.sensor_root_path}")
            return out

        out = []
        missing = []
        for name in self.sensor_names:
            path = f"{self.sensor_root_path}/{name}"
            prim = self.stage.GetPrimAtPath(path)
            if prim and prim.IsValid():
                out.append((str(name), prim))
            else:
                missing.append(str(name))
        if missing:
            raise RuntimeError(
                f"Xform TeraRanger manquants dans {self.sensor_root_path}: {missing}. "
                f"Disponibles: {[c.GetName() for c in self.sensor_root_prim.GetChildren()]}"
            )
        return out

    def get_ray_poses(self) -> tuple[TeraRangerRayPose, ...]:
        self.xform_cache.Clear()
        poses: list[TeraRangerRayPose] = []
        for name, prim in self.sensor_prims:
            world_tf = self.xform_cache.GetLocalToWorldTransform(prim)
            p = world_tf.ExtractTranslation()
            d = world_tf.TransformDir(self.Gf.Vec3d(1.0, 0.0, 0.0))
            origin = np.array([float(p[0]), float(p[1]), float(p[2])], dtype=np.float32)
            direction = _normalize(np.array([float(d[0]), float(d[1]), float(d[2])], dtype=np.float32))
            if self.origin_offset != 0.0:
                origin = origin + direction * float(self.origin_offset)
            poses.append(TeraRangerRayPose(name=name, prim_path=prim.GetPath().pathString, origin=origin, direction=direction))
        return tuple(poses)

    def _is_self_hit(self, path: str | None) -> bool:
        if not path or not self.ignore_self_hits:
            return False
        return str(path).startswith(self.robot_root_path)

    def _raycast_first_non_self(self, origin: np.ndarray, direction: np.ndarray):
        hits: list[Any] = []
        o = self.carb.Float3(float(origin[0]), float(origin[1]), float(origin[2]))
        d = self.carb.Float3(float(direction[0]), float(direction[1]), float(direction[2]))
        self.query.raycast_all(o, d, self.max_range, lambda h: (hits.append(h) or True))
        hits.sort(key=lambda h: float(_hit_field(h, "distance", self.max_range)))
        for hit in hits:
            path = _hit_field(hit, "collision") or _hit_field(hit, "rigid_body")
            path = str(path) if path else None
            if self._is_self_hit(path):
                continue
            return hit, path
        return None, None

    def read(self) -> TeraRangerFrame:
        readings: list[TeraRangerReading] = []
        for pose in self.get_ray_poses():
            hit, path = self._raycast_first_non_self(pose.origin, pose.direction)
            if hit is None:
                distance = self.max_range
                hit_flag = False
            else:
                distance = float(_hit_field(hit, "distance", self.max_range))
                distance = float(np.clip(distance, 0.0, self.max_range))
                hit_flag = True

            # Distance normalisée sur [min_range, max_range]. En proximité : 1 = proche.
            #normalized_distance = np.clip((distance - self.min_range) / max(self.max_range - self.min_range, 1e-9), 0.0, 1.0)
            #proximity = float(1.0 - normalized_distance) if hit_flag else 0.0
            proximity = rvr_dao_proximity_from_distance(distance) if hit_flag else 0.0
            
            endpoint = pose.origin + pose.direction * distance
            readings.append(
                TeraRangerReading(
                    name=pose.name,
                    distance=distance,
                    proximity=proximity,
                    hit=hit_flag,
                    hit_path=path,
                    origin=pose.origin.astype(np.float32, copy=True),
                    direction=pose.direction.astype(np.float32, copy=True),
                    endpoint=endpoint.astype(np.float32, copy=True),
                )
            )

        names = tuple(r.name for r in readings)
        distances = np.array([r.distance for r in readings], dtype=np.float32)
        proximities = np.array([r.proximity for r in readings], dtype=np.float32)
        hits = np.array([r.hit for r in readings], dtype=bool)
        return TeraRangerFrame(names=names, distances=distances, proximities=proximities, hits=hits, readings=tuple(readings))

    def get_distances(self) -> np.ndarray:
        return self.read().distances

    def get_proximities(self) -> np.ndarray:
        return self.read().proximities

    def get_named_distances(self) -> dict[str, float]:
        return self.read().as_named_distances()

    def get_named_proximities(self) -> dict[str, float]:
        return self.read().as_named_proximities()

    def get_observation(self, mode: str = "proximity") -> np.ndarray:
        frame = self.read()
        if mode == "proximity":
            return frame.proximities.astype(np.float32, copy=True)
        if mode in ("distance", "range"):
            return frame.distances.astype(np.float32, copy=True)
        if mode in ("normalized_distance", "normalized_range"):
            return np.clip(frame.distances / self.max_range, 0.0, 1.0).astype(np.float32, copy=True)
        if mode == "hit":
            return frame.hits.astype(np.float32)
        raise ValueError(f"mode inconnu: {mode}")


TeraRangerHelper = TeraRangerArrayHelper
