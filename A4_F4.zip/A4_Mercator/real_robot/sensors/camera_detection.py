"""
Caméra parfaite / logique pour Mercator Isaac Sim 6.0.

Principe général
----------------
En réalité, la caméra OAK-D du Mercator ne donne pas directement une observation RL :
elle produit une image, puis un pipeline embarqué, par exemple le blob de Said, renvoie
une liste de détections. Dans la simulation RL, on ne veut pas rendre une image RGB et
faire tourner YOLO. On veut simuler la sortie du pipeline de perception.

Ce module fournit donc un capteur de détection parfait :

    poses connues dans Isaac
        -> projection géométrique dans le repère caméra logique
        -> filtrage champ de vision / portée / occlusion optionnelle
        -> CameraDetection, au même niveau d'abstraction qu'un blob YOLO/OAK-D

Convention des repères
----------------------
Pour éviter les ambiguïtés des conventions optiques USD, on définit ici une caméra logique
alignée avec le robot :

    x caméra : vers l'avant du robot
    y caméra : vers la gauche du robot
    z caméra : vers le haut

La projection image suit ensuite la convention image habituelle :

    u augmente vers la droite de l'image
    v augmente vers le bas de l'image

Comme y caméra positif signifie gauche, on projette avec un signe moins sur u :

    u = cx - fx * y / x
    v = cy - fy * z / x

Le prim caméra recommandé est :

    /World/<RobotName>/MercatorLite/base_link/oak_d_camera

Il s'agit d'un Xform logique, pas forcément d'une vraie caméra RTX. Pour le RL, c'est
suffisant et beaucoup plus rapide.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

import numpy as np


def _to_numpy(value: Any) -> np.ndarray:
    """Convertit des valeurs USD/Gf/Torch éventuelles en numpy."""
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


def _safe_array3(value: Sequence[float], *, dtype=np.float32) -> np.ndarray:
    arr = np.asarray(value, dtype=dtype)
    if arr.shape != (3,):
        raise ValueError(f"Vecteur 3D attendu, reçu shape={arr.shape}")
    return arr


def _clip_bbox_xyxy(bbox: np.ndarray, width: int, height: int) -> np.ndarray:
    out = np.asarray(bbox, dtype=np.float32).copy()
    out[0] = np.clip(out[0], 0.0, float(width - 1))
    out[2] = np.clip(out[2], 0.0, float(width - 1))
    out[1] = np.clip(out[1], 0.0, float(height - 1))
    out[3] = np.clip(out[3], 0.0, float(height - 1))
    return out


def bbox_xyxy_to_cxcywh(bbox_xyxy: Sequence[float]) -> np.ndarray:
    xmin, ymin, xmax, ymax = [float(v) for v in bbox_xyxy]
    return np.array(
        [0.5 * (xmin + xmax), 0.5 * (ymin + ymax), max(0.0, xmax - xmin), max(0.0, ymax - ymin)],
        dtype=np.float32,
    )


def _identity4() -> np.ndarray:
    return np.eye(4, dtype=np.float64)


def _invert_transform(matrix: np.ndarray) -> np.ndarray:
    return np.linalg.inv(np.asarray(matrix, dtype=np.float64))


def _transform_point(matrix: np.ndarray, point_xyz: Sequence[float]) -> np.ndarray:
    point = np.asarray([point_xyz[0], point_xyz[1], point_xyz[2], 1.0], dtype=np.float64)
    return (np.asarray(matrix, dtype=np.float64) @ point)[:3].astype(np.float32)


def _transform_points(matrix: np.ndarray, points_xyz: np.ndarray) -> np.ndarray:
    points = np.asarray(points_xyz, dtype=np.float64)
    ones = np.ones((points.shape[0], 1), dtype=np.float64)
    hom = np.concatenate([points, ones], axis=1)
    return (np.asarray(matrix, dtype=np.float64) @ hom.T).T[:, :3].astype(np.float32)


def get_prim_world_transform(prim_path: str) -> np.ndarray:
    """
    Lit la matrice monde d'un prim USD.

    Import tardif de `omni.usd` et `pxr` pour que ce module reste importable dans
    des tests purement Python, hors Isaac Sim. L'appel à cette fonction nécessite
    évidemment un stage Isaac/USD actif.
    """
    import omni.usd
    from pxr import Usd, UsdGeom

    stage = omni.usd.get_context().get_stage()
    prim = stage.GetPrimAtPath(prim_path)
    if not prim or not prim.IsValid():
        raise RuntimeError(f"Prim introuvable : {prim_path}")
    xformable = UsdGeom.Xformable(prim)
    matrix = xformable.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    return np.array(matrix, dtype=np.float64).T


# Pose logique par défaut de l'OAK-D W sur le Mercator, en mètres et degrés.
# Ces valeurs correspondent à la Xform que tu as indiquée dans Isaac :
#   translate = (0.05211, -0.00494, 0.12559)
#   rotateXYZ = (0, -30, 0)
# On garde ces constantes dans le code pour créer le prim si un ancien USD ne
# contient pas encore `/base_link/oak_d_camera`. Le fonctionnement du détecteur
# reste logiciel : ce prim ne rend aucune image.
DEFAULT_OAKD_CAMERA_TRANSLATION = (0.05211, -0.00494, 0.12559)
DEFAULT_OAKD_CAMERA_ROTATION_XYZ_DEG = (0.0, -30.0, 0.0)


@dataclass(frozen=True)
class CameraIntrinsics:
    """Paramètres d'une caméra logique type OAK-D input réseau.

    Par défaut, on modélise la caméra RGB centrale de l'OAK-D W / OAK-D Pro W,
    utilisée par un blob YOLO : image réseau 256x256, HFOV 95 degrés, VFOV
    72 degrés, DFOV 120 degrés.

    Les caméras mono stéréo ont un champ plus large ; voir
    `oak_d_w_stereo_pair()` si on veut approximer une observation de profondeur
    issue de la paire stéréo plutôt que la sortie RGB du blob.
    """

    width: int = 256
    height: int = 256
    horizontal_fov_deg: float = 95.0
    vertical_fov_deg: float = 72.0

    @classmethod
    def oak_d_w_rgb(cls, width: int = 256, height: int = 256) -> "CameraIntrinsics":
        """Preset OAK-D W couleur RGB centrale : DFOV/HFOV/VFOV = 120/95/72."""
        return cls(width=width, height=height, horizontal_fov_deg=95.0, vertical_fov_deg=72.0)

    @classmethod
    def oak_d_w_stereo_pair(cls, width: int = 256, height: int = 256) -> "CameraIntrinsics":
        """Preset paire stéréo wide : DFOV/HFOV/VFOV environ 150/127/79.5."""
        return cls(width=width, height=height, horizontal_fov_deg=127.0, vertical_fov_deg=79.5)

    @property
    def cx(self) -> float:
        return 0.5 * float(self.width - 1)

    @property
    def cy(self) -> float:
        return 0.5 * float(self.height - 1)

    @property
    def fx(self) -> float:
        return (0.5 * float(self.width)) / math.tan(math.radians(self.horizontal_fov_deg) * 0.5)

    @property
    def fy(self) -> float:
        return (0.5 * float(self.height)) / math.tan(math.radians(self.vertical_fov_deg) * 0.5)

    @property
    def half_hfov_rad(self) -> float:
        return math.radians(self.horizontal_fov_deg) * 0.5

    @property
    def half_vfov_rad(self) -> float:
        return math.radians(self.vertical_fov_deg) * 0.5


@dataclass(frozen=True)
class TargetSpec:
    """
    Description d'une cible détectable.

    path
        Prim dont la pose monde sert à localiser la cible.
    class_name / class_id
        Classe de détection compatible avec une sortie de réseau de type YOLO.
    size_xyz
        Dimensions approximatives de la boîte 3D dans le repère local du prim.
        Pour un Mercator-Lite : environ longueur 0.185, largeur 0.216, hauteur 0.170.
    center_offset_xyz
        Décalage local du centre de la boîte 3D par rapport au prim `path`.
        Le body du Mercator est à z=0, donc son centre visuel/collision est autour de z=0.085.
    """

    path: str
    class_name: str
    class_id: int
    size_xyz: tuple[float, float, float]
    center_offset_xyz: tuple[float, float, float] = (0.0, 0.0, 0.0)
    metadata: dict[str, Any] = field(default_factory=dict)

    def local_bbox_corners(self) -> np.ndarray:
        sx, sy, sz = [float(v) for v in self.size_xyz]
        cx, cy, cz = [float(v) for v in self.center_offset_xyz]
        xs = [cx - 0.5 * sx, cx + 0.5 * sx]
        ys = [cy - 0.5 * sy, cy + 0.5 * sy]
        zs = [cz - 0.5 * sz, cz + 0.5 * sz]
        return np.array([[x, y, z] for x in xs for y in ys for z in zs], dtype=np.float32)


@dataclass
class CameraDetection:
    """Sortie commune entre caméra parfaite simulée et futur blob réel."""

    class_id: int
    class_name: str
    confidence: float
    bbox_xyxy: np.ndarray
    bbox_cxcywh: np.ndarray
    bearing: float
    elevation: float
    distance: float
    ground_distance: float
    position_camera: np.ndarray
    position_robot: np.ndarray
    target_path: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self, include_debug_path: bool = True) -> dict[str, Any]:
        data = {
            "class_id": int(self.class_id),
            "class_name": str(self.class_name),
            "confidence": float(self.confidence),
            "bbox_xyxy": self.bbox_xyxy.astype(float).tolist(),
            "bbox_cxcywh": self.bbox_cxcywh.astype(float).tolist(),
            "bearing": float(self.bearing),
            "elevation": float(self.elevation),
            "distance": float(self.distance),
            "ground_distance": float(self.ground_distance),
            "position_camera": self.position_camera.astype(float).tolist(),
            "position_robot": self.position_robot.astype(float).tolist(),
            "metadata": dict(self.metadata),
        }
        if include_debug_path:
            data["target_path"] = self.target_path
        return data


@dataclass
class CameraNoiseModel:
    """
    Bruit optionnel, désactivé par défaut.

    Il ne doit pas être utilisé pour les premiers tests RL. Il est prévu pour la suite
    sim-to-real : faux négatifs, jitter de bbox, jitter de position et bruit de confiance.
    """

    false_negative_prob: float = 0.0
    bbox_jitter_px: float = 0.0
    bearing_jitter_rad: float = 0.0
    distance_jitter_std_m: float = 0.0
    confidence_mean: float = 1.0
    confidence_std: float = 0.0
    seed: int | None = None

    def __post_init__(self) -> None:
        self._rng = np.random.default_rng(self.seed)
        self._py_rng = random.Random(self.seed)

    def apply(self, detection: CameraDetection, intrinsics: CameraIntrinsics) -> CameraDetection | None:
        if self.false_negative_prob > 0.0 and self._py_rng.random() < self.false_negative_prob:
            return None

        det = CameraDetection(
            class_id=detection.class_id,
            class_name=detection.class_name,
            confidence=detection.confidence,
            bbox_xyxy=detection.bbox_xyxy.copy(),
            bbox_cxcywh=detection.bbox_cxcywh.copy(),
            bearing=detection.bearing,
            elevation=detection.elevation,
            distance=detection.distance,
            ground_distance=detection.ground_distance,
            position_camera=detection.position_camera.copy(),
            position_robot=detection.position_robot.copy(),
            target_path=detection.target_path,
            metadata=dict(detection.metadata),
        )

        if self.bbox_jitter_px > 0.0:
            jitter = self._rng.normal(0.0, self.bbox_jitter_px, size=4).astype(np.float32)
            det.bbox_xyxy = _clip_bbox_xyxy(det.bbox_xyxy + jitter, intrinsics.width, intrinsics.height)
            det.bbox_cxcywh = bbox_xyxy_to_cxcywh(det.bbox_xyxy)

        if self.bearing_jitter_rad > 0.0:
            det.bearing = float(det.bearing + self._rng.normal(0.0, self.bearing_jitter_rad))

        if self.distance_jitter_std_m > 0.0:
            noisy_distance = max(0.0, float(det.distance + self._rng.normal(0.0, self.distance_jitter_std_m)))
            scale = noisy_distance / max(det.distance, 1e-6)
            det.distance = noisy_distance
            det.ground_distance = max(0.0, float(det.ground_distance * scale))
            det.position_camera = det.position_camera * scale
            det.position_robot = det.position_robot * scale

        if self.confidence_std > 0.0 or self.confidence_mean != 1.0:
            det.confidence = float(np.clip(self._rng.normal(self.confidence_mean, self.confidence_std), 0.0, 1.0))

        return det


class PerfectCameraDetector:
    """
    Caméra parfaite qui retourne directement des détections.

    Cette classe est le backend simulation principal. Elle ne crée pas d'image et n'utilise
    pas de caméra RTX. Elle lit seulement les poses USD, ce qui est beaucoup plus rapide et
    correspond mieux à l'interface réellement fournie au contrôleur après traitement par le
    blob de vision.
    """

    def __init__(
        self,
        camera_prim_path: str,
        robot_body_path: str,
        targets: Sequence[TargetSpec],
        *,
        intrinsics: CameraIntrinsics | None = None,
        min_range: float = 0.15,
        max_range: float = 4.0,
        min_bbox_area_px: float = 4.0,
        confidence: float = 1.0,
        occlusion_mode: str = "none",
        noise_model: CameraNoiseModel | None = None,
        debug: bool = False,
    ):
        self.camera_prim_path = camera_prim_path
        self.robot_body_path = robot_body_path
        self.targets = list(targets)
        self.intrinsics = intrinsics or CameraIntrinsics()
        self.min_range = float(min_range)
        self.max_range = float(max_range)
        self.min_bbox_area_px = float(min_bbox_area_px)
        self.confidence = float(confidence)
        self.occlusion_mode = str(occlusion_mode)
        self.noise_model = noise_model
        self.debug = bool(debug)

        if self.occlusion_mode not in {"none", "center_raycast"}:
            raise ValueError("occlusion_mode doit être 'none' ou 'center_raycast'")

    # ------------------------------------------------------------------
    # Chemins utilitaires
    # ------------------------------------------------------------------
    @staticmethod
    def camera_path_for_robot(robot_name: str) -> str:
        return f"/World/{robot_name}/MercatorLite/base_link/oak_d_camera"

    @staticmethod
    def body_path_for_robot(robot_name: str) -> str:
        return f"/World/{robot_name}/MercatorLite"

    # ------------------------------------------------------------------
    # Projection géométrique
    # ------------------------------------------------------------------
    def _project_camera_points(self, points_camera: np.ndarray) -> np.ndarray:
        """Projette des points exprimés dans le repère caméra logique."""
        pts = np.asarray(points_camera, dtype=np.float32)
        x = pts[:, 0]
        y = pts[:, 1]
        z = pts[:, 2]
        valid = x > max(self.min_range * 0.25, 1e-4)
        uv = np.full((pts.shape[0], 2), np.nan, dtype=np.float32)
        uv[valid, 0] = self.intrinsics.cx - self.intrinsics.fx * (y[valid] / x[valid])
        uv[valid, 1] = self.intrinsics.cy - self.intrinsics.fy * (z[valid] / x[valid])
        return uv

    def _target_visible_by_fov(self, center_camera: np.ndarray) -> tuple[bool, float, float, float, float]:
        x, y, z = [float(v) for v in center_camera]
        distance = math.sqrt(x * x + y * y + z * z)
        ground_distance = math.sqrt(x * x + y * y)
        if distance < self.min_range or distance > self.max_range:
            return False, 0.0, 0.0, distance, ground_distance
        if x <= 0.0:
            return False, 0.0, 0.0, distance, ground_distance
        bearing = math.atan2(y, x)
        elevation = math.atan2(z, max(ground_distance, 1e-9))
        visible = abs(bearing) <= self.intrinsics.half_hfov_rad and abs(elevation) <= self.intrinsics.half_vfov_rad
        return visible, bearing, elevation, distance, ground_distance

    def _bbox_from_corners(self, corners_camera: np.ndarray) -> np.ndarray | None:
        uv = self._project_camera_points(corners_camera)
        valid = np.isfinite(uv).all(axis=1)
        if not np.any(valid):
            return None
        uv = uv[valid]
        xmin, ymin = np.min(uv, axis=0)
        xmax, ymax = np.max(uv, axis=0)

        # Rejet si la boîte est totalement hors image.
        if xmax < 0.0 or xmin >= self.intrinsics.width or ymax < 0.0 or ymin >= self.intrinsics.height:
            return None

        bbox = _clip_bbox_xyxy(np.array([xmin, ymin, xmax, ymax], dtype=np.float32), self.intrinsics.width, self.intrinsics.height)
        area = max(0.0, float(bbox[2] - bbox[0])) * max(0.0, float(bbox[3] - bbox[1]))
        if area < self.min_bbox_area_px:
            return None
        return bbox

    def _is_occluded(self, camera_world: np.ndarray, target_world: np.ndarray, target_path: str) -> bool:
        """
        Occlusion optionnelle via raycast central.

        Le mode par défaut est `none`. Ce raycast est seulement une approximation : il sert
        à éviter de voir à travers un mur ou un bloc, mais il n'est pas nécessaire pour la
        première version RL parfaite.
        """
        if self.occlusion_mode == "none":
            return False
        try:
            import carb
            from omni.physx import get_physx_scene_query_interface
            import omni.usd

            direction = np.asarray(target_world - camera_world, dtype=np.float32)
            distance = float(np.linalg.norm(direction))
            if distance <= 1e-6:
                return False
            direction = direction / distance
            origin = carb.Float3(float(camera_world[0]), float(camera_world[1]), float(camera_world[2]))
            ray_dir = carb.Float3(float(direction[0]), float(direction[1]), float(direction[2]))
            hit = get_physx_scene_query_interface().raycast_closest(origin, ray_dir, distance)
            if not hit or not hit.get("hit", False):
                return False
            hit_path = str(hit.get("rigidBody", "") or hit.get("collision", "") or hit.get("primPath", ""))
            if not hit_path:
                return False
            return target_path not in hit_path and hit_path not in target_path
        except Exception as exc:
            if self.debug:
                print(f"[PerfectCameraDetector] occlusion ignorée: {exc}")
            return False

    def _make_detection_for_target(
        self,
        target: TargetSpec,
        world_to_camera: np.ndarray,
        world_to_robot: np.ndarray,
        camera_world_position: np.ndarray,
    ) -> CameraDetection | None:
        target_to_world = get_prim_world_transform(target.path)
        center_world = _transform_point(target_to_world, target.center_offset_xyz)
        center_camera = _transform_point(world_to_camera, center_world)
        visible, bearing, elevation, distance, ground_distance = self._target_visible_by_fov(center_camera)
        if not visible:
            return None

        if self._is_occluded(camera_world_position, center_world, target.path):
            return None

        corners_local = target.local_bbox_corners()
        corners_world = _transform_points(target_to_world, corners_local)
        corners_camera = _transform_points(world_to_camera, corners_world)
        bbox = self._bbox_from_corners(corners_camera)
        if bbox is None:
            return None

        center_robot = _transform_point(world_to_robot, center_world)
        det = CameraDetection(
            class_id=int(target.class_id),
            class_name=str(target.class_name),
            confidence=self.confidence,
            bbox_xyxy=bbox,
            bbox_cxcywh=bbox_xyxy_to_cxcywh(bbox),
            bearing=float(bearing),
            elevation=float(elevation),
            distance=float(distance),
            ground_distance=float(ground_distance),
            position_camera=center_camera.astype(np.float32),
            position_robot=center_robot.astype(np.float32),
            target_path=target.path,
            metadata=dict(target.metadata),
        )
        if self.noise_model is not None:
            return self.noise_model.apply(det, self.intrinsics)
        return det

    def get_detections(self, targets: Sequence[TargetSpec] | None = None) -> list[CameraDetection]:
        """Retourne les détections visibles, triées par distance croissante."""
        target_list = list(targets) if targets is not None else self.targets
        camera_to_world = get_prim_world_transform(self.camera_prim_path)
        robot_to_world = get_prim_world_transform(self.robot_body_path)
        world_to_camera = _invert_transform(camera_to_world)
        world_to_robot = _invert_transform(robot_to_world)
        camera_world_position = camera_to_world[:3, 3].astype(np.float32)

        detections: list[CameraDetection] = []
        for target in target_list:
            try:
                det = self._make_detection_for_target(target, world_to_camera, world_to_robot, camera_world_position)
                if det is not None:
                    detections.append(det)
            except Exception as exc:
                if self.debug:
                    print(f"[PerfectCameraDetector] target ignorée {target.path}: {exc}")
        detections.sort(key=lambda d: d.distance)
        return detections

    def get_fixed_observation(
        self,
        *,
        max_detections: int = 4,
        class_names: Sequence[str] = ("robot", "item"),
        max_range: float | None = None,
    ) -> np.ndarray:
        detections = self.get_detections()
        return detections_to_fixed_observation(
            detections,
            max_detections=max_detections,
            class_names=class_names,
            image_width=self.intrinsics.width,
            image_height=self.intrinsics.height,
            max_range=max_range or self.max_range,
        )

    def get_summary_observation(self, *, max_range: float | None = None) -> np.ndarray:
        detections = self.get_detections()
        return detections_to_summary_observation(detections, max_range=max_range or self.max_range)


class RealOakDBlobAdapter:
    """
    Adaptateur pour le futur pipeline réel OAK-D/blob.

    Cette classe ne dépend pas de DepthAI. Elle donne seulement un point d'entrée propre :
    le code réel pourra convertir les sorties du blob de Said en `CameraDetection`, puis le
    reste de la stack consommera exactement la même interface que la simulation.
    """

    def __init__(self, class_names: Sequence[str] = ("robot", "item")):
        self.class_names = list(class_names)
        self._last_detections: list[CameraDetection] = []

    def update_from_dicts(self, raw_detections: Sequence[Mapping[str, Any]]) -> None:
        detections: list[CameraDetection] = []
        for raw in raw_detections:
            class_id = int(raw.get("class_id", 0))
            class_name = str(raw.get("class_name", self.class_names[class_id] if class_id < len(self.class_names) else class_id))
            bbox_xyxy = np.asarray(raw.get("bbox_xyxy", [0, 0, 0, 0]), dtype=np.float32)
            detections.append(
                CameraDetection(
                    class_id=class_id,
                    class_name=class_name,
                    confidence=float(raw.get("confidence", 1.0)),
                    bbox_xyxy=bbox_xyxy,
                    bbox_cxcywh=bbox_xyxy_to_cxcywh(bbox_xyxy),
                    bearing=float(raw.get("bearing", 0.0)),
                    elevation=float(raw.get("elevation", 0.0)),
                    distance=float(raw.get("distance", float("inf"))),
                    ground_distance=float(raw.get("ground_distance", raw.get("distance", float("inf")))),
                    position_camera=np.asarray(raw.get("position_camera", [0, 0, 0]), dtype=np.float32),
                    position_robot=np.asarray(raw.get("position_robot", [0, 0, 0]), dtype=np.float32),
                    target_path=None,
                    metadata=dict(raw.get("metadata", {})),
                )
            )
        detections.sort(key=lambda d: d.distance)
        self._last_detections = detections

    def get_detections(self) -> list[CameraDetection]:
        return list(self._last_detections)


# Alias explicite pour l'interface de haut niveau.
CameraDetectionSensor = PerfectCameraDetector


def make_robot_target_specs(
    robot_names: Sequence[str],
    *,
    exclude_robot_name: str | None = None,
    class_id: int = 0,
    class_name: str = "robot",
    size_xyz: tuple[float, float, float] = (0.185, 0.216, 0.170),
) -> list[TargetSpec]:
    """Crée des TargetSpec pour des Mercator-Lite dans `/World/<name>/MercatorLite`."""
    targets: list[TargetSpec] = []
    for name in robot_names:
        if exclude_robot_name is not None and name == exclude_robot_name:
            continue
        targets.append(
            TargetSpec(
                path=f"/World/{name}/MercatorLite",
                class_name=class_name,
                class_id=class_id,
                size_xyz=size_xyz,
                center_offset_xyz=(0.0, 0.0, 0.5 * size_xyz[2]),
                metadata={"robot_name": name},
            )
        )
    return targets


def make_box_target_spec(
    path: str,
    *,
    class_id: int = 1,
    class_name: str = "item",
    size_xyz: tuple[float, float, float] = (0.25, 0.25, 0.20),
    name: str | None = None,
) -> TargetSpec:
    """Crée une TargetSpec pour un cube/bloc dynamique dont le prim est centré sur l'objet."""
    metadata = {}
    if name is not None:
        metadata["name"] = name
    return TargetSpec(
        path=path,
        class_id=class_id,
        class_name=class_name,
        size_xyz=size_xyz,
        center_offset_xyz=(0.0, 0.0, 0.0),
        metadata=metadata,
    )


def detections_to_fixed_observation(
    detections: Sequence[CameraDetection],
    *,
    max_detections: int = 4,
    class_names: Sequence[str] = ("robot", "item"),
    image_width: int = 256,
    image_height: int = 256,
    max_range: float = 4.0,
) -> np.ndarray:
    """
    Convertit une liste variable de détections en vecteur fixe pour RL.

    Pour chaque slot, les features sont :

        valid flag
        one-hot classe
        distance normalisée
        sin(bearing)
        cos(bearing)
        surface bbox normalisée
        confiance

    Les détections les plus proches sont gardées, les autres ignorées. Les slots vides
    restent à zéro.
    """
    class_names = list(class_names)
    per_detection_dim = 1 + len(class_names) + 1 + 2 + 1 + 1
    obs = np.zeros((max_detections, per_detection_dim), dtype=np.float32)

    sorted_dets = sorted(detections, key=lambda d: d.distance)[:max_detections]
    image_area = max(1.0, float(image_width * image_height))
    for row, det in enumerate(sorted_dets):
        col = 0
        obs[row, col] = 1.0
        col += 1
        if det.class_name in class_names:
            obs[row, col + class_names.index(det.class_name)] = 1.0
        col += len(class_names)
        obs[row, col] = np.clip(det.distance / max(max_range, 1e-6), 0.0, 1.0)
        col += 1
        obs[row, col] = math.sin(det.bearing)
        obs[row, col + 1] = math.cos(det.bearing)
        col += 2
        area = max(0.0, float(det.bbox_xyxy[2] - det.bbox_xyxy[0])) * max(0.0, float(det.bbox_xyxy[3] - det.bbox_xyxy[1]))
        obs[row, col] = np.clip(area / image_area, 0.0, 1.0)
        col += 1
        obs[row, col] = np.clip(det.confidence, 0.0, 1.0)
    return obs.reshape(-1)


def detections_to_summary_observation(
    detections: Sequence[CameraDetection], *, max_range: float = 4.0) -> np.ndarray:
    """
    Observation compacte : statistiques de robots et d'items visibles.

    Format :
        [n_robots_norm,
         nearest_robot_dist_norm, sin, cos,
         robot_com_dist_norm, sin, cos,
         n_items_norm,
         nearest_item_dist_norm, sin, cos]
    """
    def group_stats(class_name: str) -> list[float]:
        group = [d for d in detections if d.class_name == class_name]
        if not group:
            return [0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0]
        nearest = min(group, key=lambda d: d.distance)
        positions = np.array([d.position_robot for d in group], dtype=np.float32)
        com = np.mean(positions, axis=0)
        com_dist = float(np.linalg.norm(com[:2]))
        com_bearing = math.atan2(float(com[1]), float(com[0])) if com_dist > 1e-6 else 0.0
        return [
            np.clip(len(group) / 10.0, 0.0, 1.0),
            np.clip(nearest.distance / max(max_range, 1e-6), 0.0, 1.0),
            math.sin(nearest.bearing),
            math.cos(nearest.bearing),
            np.clip(com_dist / max(max_range, 1e-6), 0.0, 1.0),
            math.sin(com_bearing),
            math.cos(com_bearing),
        ]

    robot = group_stats("robot")
    item_full = group_stats("item")
    # Pour les items, on garde count + nearest seulement dans ce résumé compact.
    item = item_full[:4]
    return np.asarray(robot + item, dtype=np.float32)
