from __future__ import annotations

import re
from typing import Iterable

import numpy as np


def _safe_usd_name(name: str) -> str:
    """
    Retourne un identifiant USD sûr.

    USD n'accepte pas certains noms de prim :
    - pas de nom qui commence par un chiffre ;
    - pas d'espaces ;
    - pas de caractères spéciaux.
    """
    out = re.sub(r"[^A-Za-z0-9_]", "_", str(name))
    out = out if out else "beacon"

    if not re.match(r"^[A-Za-z_]", out):
        out = f"beacon_{out}"

    return out


class BeaconDebugVisualizer:
    """
    Visualisation du capteur beacon Xform.

    Dessine :
    - une sphère blanche à l'origine du détecteur ;
    - une ligne verte vers chaque beacon visible ;
    - une ligne grise vers chaque beacon non visible / rejeté ;
    - une ligne jaune pour le vecteur agrégé ;
    - une sphère jaune au bout du vecteur agrégé.

    Le helper reste indépendant de cette visualisation.
    """

    def __init__(
        self,
        helper,
        *,
        root_path: str = "/World/DebugBeaconSensor",
        ray_width: float = 0.06,
        origin_radius: float = 0.12,
        beacon_marker_radius: float = 0.12,
        aggregate_tip_radius: float = 0.10,
        aggregate_length: float = 1.0,
    ) -> None:
        import omni.usd
        from pxr import Gf, UsdGeom

        self.helper = helper
        self.root_path = root_path.rstrip("/")

        if not self.root_path.startswith("/"):
            raise ValueError(f"root_path doit être absolu, reçu: {root_path!r}")

        if self.root_path in ("", "/"):
            raise ValueError(f"root_path invalide: {root_path!r}")

        self.ray_width = float(ray_width)
        self.origin_radius = float(origin_radius)
        self.beacon_marker_radius = float(beacon_marker_radius)
        self.aggregate_tip_radius = float(aggregate_tip_radius)
        self.aggregate_length = float(aggregate_length)

        self.Gf = Gf
        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()

        self.stage.DefinePrim(self.root_path, "Xform")

    def clear(self) -> None:
        prim = self.stage.GetPrimAtPath(self.root_path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(self.root_path)

        self.stage.DefinePrim(self.root_path, "Xform")

    def _delete_if_exists(self, path: str) -> None:
        prim = self.stage.GetPrimAtPath(path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(path)

    def _set_display_color(
        self,
        prim,
        rgb: tuple[float, float, float],
        opacity: float = 1.0,
    ) -> None:
        gprim = self.UsdGeom.Gprim(prim)
        gprim.CreateDisplayColorAttr(
            [self.Gf.Vec3f(float(rgb[0]), float(rgb[1]), float(rgb[2]))]
        )
        gprim.CreateDisplayOpacityAttr([float(opacity)])

    def _draw_line(
        self,
        path: str,
        a: Iterable[float],
        b: Iterable[float],
        *,
        color: tuple[float, float, float],
        width: float | None = None,
    ) -> None:
        self._delete_if_exists(path)

        a = np.asarray(a, dtype=np.float32)
        b = np.asarray(b, dtype=np.float32)

        curves = self.UsdGeom.BasisCurves.Define(self.stage, path)
        curves.CreateTypeAttr("linear")
        curves.CreateCurveVertexCountsAttr([2])
        curves.CreatePointsAttr(
            [
                self.Gf.Vec3f(float(a[0]), float(a[1]), float(a[2])),
                self.Gf.Vec3f(float(b[0]), float(b[1]), float(b[2])),
            ]
        )

        w = self.ray_width if width is None else float(width)
        curves.CreateWidthsAttr([w, w])
        try:
            curves.SetWidthsInterpolation(self.UsdGeom.Tokens.vertex)
        except Exception:
            pass
        self._set_display_color(curves.GetPrim(), color)

    def _draw_sphere(
        self,
        path: str,
        position: Iterable[float],
        *,
        radius: float,
        color: tuple[float, float, float],
    ) -> None:
        self._delete_if_exists(path)

        p = np.asarray(position, dtype=np.float32)

        sphere = self.UsdGeom.Sphere.Define(self.stage, path)
        sphere.CreateRadiusAttr(float(radius))

        xform = self.UsdGeom.Xformable(sphere.GetPrim())
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set(
            self.Gf.Vec3d(float(p[0]), float(p[1]), float(p[2]))
        )

        self._set_display_color(sphere.GetPrim(), color)

    def update(self, reading=None):
        reading = reading or self.helper.read()

        self.stage.DefinePrim(self.root_path, "Xform")

        origin = np.asarray(reading.detector_world_position, dtype=np.float32)

        self._draw_sphere(
            f"{self.root_path}/detector_origin",
            origin,
            radius=self.origin_radius,
            color=(1.0, 1.0, 1.0),
        )

        for i, candidate in enumerate(reading.candidates):
            raw_name = candidate.prim_path.split("/")[-1] or f"beacon_{i}"
            safe_name = _safe_usd_name(raw_name)

            item_root = f"{self.root_path}/beacon_{i:02d}_{safe_name}"

            if not item_root.startswith("/"):
                raise RuntimeError(f"Chemin USD non absolu généré: {item_root!r}")

            self.stage.DefinePrim(item_root, "Xform")

            if candidate.valid:
                if candidate.visible:
                    color = (0.0, 1.0, 0.0)
                else:
                    color = (0.35, 0.35, 0.35)

                self._draw_line(
                    f"{item_root}/line",
                    origin,
                    candidate.world_position,
                    color=color,
                    width=self.ray_width,
                )

                self._draw_sphere(
                    f"{item_root}/marker",
                    candidate.world_position,
                    radius=self.beacon_marker_radius,
                    color=color,
                )
            else:
                self._delete_if_exists(f"{item_root}/line")
                self._delete_if_exists(f"{item_root}/marker")

        if reading.seen:
            direction_world = self.helper.local_xy_direction_to_world(
                (np.cos(reading.angle), np.sin(reading.angle))
            )
            direction_world = np.asarray(direction_world, dtype=np.float32)

            end = origin + direction_world * self.aggregate_length

            self._draw_line(
                f"{self.root_path}/aggregate_vector",
                origin,
                end,
                color=(1.0, 0.85, 0.0),
                width=self.ray_width * 1.8,
            )

            self._draw_sphere(
                f"{self.root_path}/aggregate_tip",
                end,
                radius=self.aggregate_tip_radius,
                color=(1.0, 0.85, 0.0),
            )
        else:
            self._delete_if_exists(f"{self.root_path}/aggregate_vector")
            self._delete_if_exists(f"{self.root_path}/aggregate_tip")

        return reading