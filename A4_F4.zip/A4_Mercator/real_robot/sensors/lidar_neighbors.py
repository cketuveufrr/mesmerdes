"""
Détection de voisins AutoMoDe-like à partir du RTX LiDAR.

Important : ce module ne regarde jamais les poses des robots, leurs bounding boxes,
leurs AABB/OBB ou des métadonnées de scène. Il travaille uniquement à partir du nuage
RTX LiDAR réellement renvoyé par Isaac, donc à partir de ce que le capteur touche dans
le rendu/RTX.

Convention du repère LiDAR/robot :
    x local : avant du robot
    y local : gauche du robot
    z local : haut
    angle 0 rad      : devant
    angle +pi/2 rad  : gauche
    angle -pi/2 rad  : droite
    angle +/-pi rad  : arrière
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Iterable, Sequence

import numpy as np

from .lidar_helper import LidarHelper, RtxLidarHelper


TAU = 2.0 * math.pi # sc4a


def wrap_to_pi(angle: float | np.ndarray) -> float | np.ndarray:
    """Ramène un angle ou un tableau d'angles dans [-pi, +pi]."""
    return (angle + math.pi) % TAU - math.pi


def angular_difference(a: float, b: float) -> float:
    """Plus petite différence absolue entre deux angles."""
    return abs(float(wrap_to_pi(a - b)))


def circular_mean(angles: Sequence[float]) -> float:
    if len(angles) == 0:
        return 0.0
    s = float(np.sum(np.sin(angles)))
    c = float(np.sum(np.cos(angles)))
    if abs(s) < 1e-12 and abs(c) < 1e-12:
        return 0.0
    return float(math.atan2(s, c))


def circular_width(angles: Sequence[float]) -> float:
    """
    Largeur angulaire minimale contenant le cluster.

    On calcule le plus grand trou sur le cercle, puis la largeur est le complément.
    Cela marche aussi pour un cluster à cheval sur -pi/+pi.
    """
    if len(angles) <= 1:
        return 0.0
    a = np.sort((np.asarray(angles, dtype=np.float64) + TAU) % TAU)
    gaps = np.diff(np.concatenate([a, a[:1] + TAU]))
    return float(TAU - np.max(gaps))


@dataclass(slots=True)
class LidarNeighborCluster:
    """Un cluster LiDAR interprété comme un voisin possible."""

    cluster_id: int
    points: np.ndarray
    # Canonical center-to-center estimate used by the vectorized RM contract.
    mean_distance: float
    # Nearest LiDAR return on the visible tower surface.
    surface_distance: float
    mean_angle: float
    point_count: int
    angular_width: float
    physical_width: float
    accepted: bool = True
    reject_reason: str = ""

    @property
    def center_xy(self) -> np.ndarray:
        return np.array(
            [
                self.mean_distance * math.cos(self.mean_angle),
                self.mean_distance * math.sin(self.mean_angle),
            ],
            dtype=np.float32,
        )


@dataclass(slots=True)
class LidarNeighborObservation:
    """Sortie compacte destinée aux modules attraction / repulsion / neighbor-count."""

    clusters: list[LidarNeighborCluster] = field(default_factory=list)
    rejected_clusters: list[LidarNeighborCluster] = field(default_factory=list)
    candidate_points: np.ndarray = field(default_factory=lambda: np.empty((0, 3), dtype=np.float32))
    raw_points_count: int = 0
    candidate_points_count: int = 0
    attraction_vector_xy: np.ndarray = field(default_factory=lambda: np.zeros((2,), dtype=np.float32))
    alpha: float = 1.0

    @property
    def neighbors_count(self) -> int:
        return len(self.clusters)

    @property
    def vector_norm(self) -> float:
        return float(np.linalg.norm(self.attraction_vector_xy))

    @property
    def vector_angle(self) -> float:
        if self.vector_norm <= 1e-12:
            return 0.0
        return float(math.atan2(float(self.attraction_vector_xy[1]), float(self.attraction_vector_xy[0])))

    def as_rm11_polar(self, *, default_if_empty: bool = True) -> tuple[float, float]:
        """
        Retourne une forme polaire proche RM 1.1.

        Le vecteur interne de ce module vaut zéro si aucun voisin n'est détecté, ce
        qui est pratique pour attraction/repulsion. Si `default_if_empty=True`, on
        expose aussi la convention documentaire RM 1.1 : pas de voisin -> (1, 0).
        """
        if self.neighbors_count == 0 and default_if_empty:
            return 1.0, 0.0
        return self.vector_norm, self.vector_angle


class LidarNeighborDetector:
    """
    Convertit un nuage RTX LiDAR en voisins AutoMoDe-like.

    Règles fidèles au portage RVR discuté :
      - point candidat si la distance de surface est dans la fenêtre configurée ;
      - même cluster si deux points consécutifs ont moins de 0.02 m d'écart en
        distance et moins de 0.175 rad d'écart angulaire ;
      - fusion optionnelle premier/dernier cluster autour de -pi/+pi ;
      - le nombre de voisins est le nombre de clusters acceptés.

    L'option `reject_wide_clusters` est désactivée par défaut, car elle n'appartient
    pas au comportement AutoMoDe brut. Elle sert seulement si les murs visibles au
    LiDAR génèrent trop de faux voisins dans Isaac.
    """

    def __init__(
        self,
        lidar_prim_path: str,
        *,
        lidar_helper: RtxLidarHelper | None = None,
        neighbor_min_range: float = 0.10,
        neighbor_max_range: float = 0.75,
        cluster_distance_epsilon: float = 0.02,
        cluster_angle_epsilon_rad: float = 0.175,
        min_cluster_points: int = 5,
        reject_wide_clusters: bool = False,
        min_physical_width: float = 0.02,
        max_physical_width: float = 0.45,
        target_radius_m: float = 0.0,
        alpha: float = 1.0,
        verbose: bool = False,
    ):
        self.lidar_prim_path = lidar_prim_path
        self.neighbor_min_range = float(neighbor_min_range)
        self.neighbor_max_range = float(neighbor_max_range)
        self.cluster_distance_epsilon = float(cluster_distance_epsilon)
        self.cluster_angle_epsilon_rad = float(cluster_angle_epsilon_rad)
        self.min_cluster_points = int(min_cluster_points)
        self.reject_wide_clusters = bool(reject_wide_clusters)
        self.min_physical_width = float(min_physical_width)
        self.max_physical_width = float(max_physical_width)
        self.target_radius_m = float(target_radius_m)
        if self.target_radius_m < 0.0:
            raise ValueError("target_radius_m must be non-negative")
        self.alpha = float(alpha)
        self.verbose = bool(verbose)

        self.lidar = lidar_helper or LidarHelper(
            lidar_prim_path,
            # Le nearRange physique reste défini dans l'USD/YAML. Le helper ne
            # rajoute pas une seconde coupure avant le filtrage local ci-dessous.
            min_valid_range=0.0,
            max_valid_range=max(10.0, self.neighbor_max_range),
            disable_usd_debug_draw=True,
            debug_draw=False,
            verbose=verbose,
        )

    def detach(self) -> None:
        self.lidar.detach()

    def read(self) -> LidarNeighborObservation:
        """Lit le LiDAR et retourne l'observation de voisins."""
        points = self.lidar.get_point_cloud()
        return self.compute_from_points(points)

    def compute_from_points(self, points: np.ndarray | Iterable[Iterable[float]]) -> LidarNeighborObservation:
        points = self._normalize_points(points)
        candidates = self._candidate_points(points)
        raw_clusters = self._cluster_candidate_points(candidates)
        clusters, rejected = self._make_clusters(raw_clusters)
        vector = self._compute_attraction_vector(clusters)
        return LidarNeighborObservation(
            clusters=clusters,
            rejected_clusters=rejected,
            candidate_points=candidates,
            raw_points_count=int(points.shape[0]),
            candidate_points_count=int(candidates.shape[0]),
            attraction_vector_xy=vector.astype(np.float32),
            alpha=self.alpha,
        )

    def _normalize_points(self, points: np.ndarray | Iterable[Iterable[float]]) -> np.ndarray:
        arr = np.asarray(points, dtype=np.float32)
        if arr.size == 0:
            return np.empty((0, 3), dtype=np.float32)
        if arr.ndim == 1:
            if arr.size % 3 != 0:
                return np.empty((0, 3), dtype=np.float32)
            arr = arr.reshape((-1, 3))
        if arr.ndim > 2 and arr.shape[-1] == 3:
            arr = arr.reshape((-1, 3))
        if arr.ndim != 2 or arr.shape[1] < 3:
            return np.empty((0, 3), dtype=np.float32)
        arr = arr[:, :3]
        finite = np.isfinite(arr).all(axis=1)
        return arr[finite] if np.any(finite) else np.empty((0, 3), dtype=np.float32)

    def _candidate_points(self, points: np.ndarray) -> np.ndarray:
        if points.shape[0] == 0:
            return np.empty((0, 3), dtype=np.float32)
        ranges = np.linalg.norm(points[:, :2], axis=1)
        valid = (ranges >= self.neighbor_min_range) & (ranges <= self.neighbor_max_range)
        candidates = points[valid]
        if candidates.shape[0] == 0:
            return np.empty((0, 3), dtype=np.float32)
        angles = np.arctan2(candidates[:, 1], candidates[:, 0])
        order = np.argsort(angles)
        return candidates[order].astype(np.float32, copy=False)

    def _same_cluster(self, previous_point: np.ndarray, point: np.ndarray) -> bool:
        prev_distance = float(np.linalg.norm(previous_point[:2]))
        distance = float(np.linalg.norm(point[:2]))
        if abs(distance - prev_distance) > self.cluster_distance_epsilon:
            return False
        prev_angle = math.atan2(float(previous_point[1]), float(previous_point[0]))
        angle = math.atan2(float(point[1]), float(point[0]))
        return angular_difference(angle, prev_angle) <= self.cluster_angle_epsilon_rad

    def _cluster_candidate_points(self, candidates: np.ndarray) -> list[np.ndarray]:
        if candidates.shape[0] == 0:
            return []

        clusters: list[list[np.ndarray]] = [[candidates[0]]]
        for point in candidates[1:]:
            if self._same_cluster(clusters[-1][-1], point):
                clusters[-1].append(point)
            else:
                clusters.append([point])

        # Si un voisin est derrière le robot, il peut être coupé artificiellement par
        # la discontinuité -pi/+pi. On fusionne donc le dernier et le premier cluster
        # quand leurs extrémités sont compatibles circulairement.
        if len(clusters) > 1 and self._same_cluster(clusters[-1][-1], clusters[0][0]):
            clusters[0] = clusters[-1] + clusters[0]
            clusters.pop()

        return [np.asarray(cluster, dtype=np.float32) for cluster in clusters]

    def _make_clusters(self, raw_clusters: list[np.ndarray]) -> tuple[list[LidarNeighborCluster], list[LidarNeighborCluster]]:
        accepted: list[LidarNeighborCluster] = []
        rejected: list[LidarNeighborCluster] = []

        for cluster_idx, cluster_points in enumerate(raw_clusters):
            ranges = np.linalg.norm(cluster_points[:, :2], axis=1)
            angles = np.arctan2(cluster_points[:, 1], cluster_points[:, 0])

            # Only the upper LiDAR tower intersects the horizontal scan plane.
            # The vectorized reference model uses center-to-center distances, so
            # reconstruct that canonical distance from the nearest surface hit
            # and the known tower radius. This keeps sensing local: no target
            # pose, AABB or scene metadata is queried.
            surface_distance = float(np.min(ranges))
            mean_distance = surface_distance + self.target_radius_m
            center_xy = np.mean(cluster_points[:, :2], axis=0)
            surface_centroid_distance = float(np.linalg.norm(center_xy))
            mean_angle = (
                float(math.atan2(float(center_xy[1]), float(center_xy[0])))
                if surface_centroid_distance > 1e-12
                else circular_mean(angles)
            )
            angular_w = circular_width(angles)
            physical_w = (
                float(2.0 * mean_distance * math.sin(0.5 * angular_w))
                if angular_w > 0.0
                else 0.0
            )

            cluster = LidarNeighborCluster(
                cluster_id=cluster_idx,
                points=cluster_points,
                mean_distance=mean_distance,
                surface_distance=surface_distance,
                mean_angle=wrap_to_pi(mean_angle),
                point_count=int(cluster_points.shape[0]),
                angular_width=angular_w,
                physical_width=physical_w,
            )

            reason = self._reject_reason(cluster)
            if reason:
                cluster.accepted = False
                cluster.reject_reason = reason
                rejected.append(cluster)
            else:
                cluster.cluster_id = len(accepted)
                accepted.append(cluster)

        return accepted, rejected

    def _reject_reason(self, cluster: LidarNeighborCluster) -> str:
        if cluster.mean_distance < self.neighbor_min_range:
            return f"center_too_near<{self.neighbor_min_range:.3f}m"
        if cluster.mean_distance > self.neighbor_max_range:
            return f"center_too_far>{self.neighbor_max_range:.3f}m"
        if cluster.point_count < self.min_cluster_points:
            return f"too_few_points<{self.min_cluster_points}"
        if self.reject_wide_clusters:
            if cluster.physical_width < self.min_physical_width:
                return f"too_narrow<{self.min_physical_width:.3f}m"
            if cluster.physical_width > self.max_physical_width:
                return f"too_wide>{self.max_physical_width:.3f}m"
        return ""

    def _compute_attraction_vector(self, clusters: Sequence[LidarNeighborCluster]) -> np.ndarray:
        vector = np.zeros((2,), dtype=np.float64)
        for cluster in clusters:
            distance_cm = 100.0 * max(0.0, cluster.mean_distance)
            gain = self.alpha / (1.0 + distance_cm)
            vector[0] += gain * math.cos(cluster.mean_angle)
            vector[1] += gain * math.sin(cluster.mean_angle)
        return vector
