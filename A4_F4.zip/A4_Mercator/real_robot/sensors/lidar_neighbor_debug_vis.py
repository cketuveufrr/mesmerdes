"""Visualisation USD légère du clustering de voisins LiDAR."""

from __future__ import annotations

import re
from typing import Iterable

import numpy as np

from .lidar_neighbors import LidarNeighborDetector, LidarNeighborObservation


def _safe_usd_name(name: str) -> str:
    out = re.sub(r"[^A-Za-z0-9_]", "_", str(name))
    return out if out else "item"


class LidarNeighborDebugVisualizer:
    """
    Dessine pour un robot observateur :
      - le rayon vers chaque cluster accepté ;
      - le centre de chaque cluster accepté ;
      - la flèche du vecteur attraction ;
      - optionnellement quelques points candidats bruts.

    Les voisins eux-mêmes restent les vrais modèles Mercator dans la scène. Cette
    visualisation ne sert qu'à expliquer ce que le LiDAR a mesuré.
    """

    def __init__(
        self,
        detector: LidarNeighborDetector,
        *,
        root_path: str = "/World/DebugLidarNeighbors",
        draw_candidate_points: bool = True,
        candidate_point_stride: int = 6,
        point_radius: float = 0.012,
        center_radius: float = 0.035,
        line_width: float = 0.010,
        vector_scale: float = 0.25,
    ):
        self.detector = detector
        self.root_path = root_path.rstrip("/")
        self.draw_candidate_points = bool(draw_candidate_points)
        self.candidate_point_stride = max(1, int(candidate_point_stride))
        self.point_radius = float(point_radius)
        self.center_radius = float(center_radius)
        self.line_width = float(line_width)
        self.vector_scale = float(vector_scale)

        import omni.usd
        from pxr import Gf, Usd, UsdGeom

        self.Gf = Gf
        self.Usd = Usd
        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.stage.DefinePrim(self.root_path, "Xform")

    def clear(self) -> None:
        prim = self.stage.GetPrimAtPath(self.root_path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(self.root_path)
        self.stage.DefinePrim(self.root_path, "Xform")

    def _delete_if_exists(self, path: str) -> None:
        prim = self.stage.GetPrimAtPath(path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(path)

    def _set_display_color(self, prim, rgb: tuple[float, float, float], opacity: float = 1.0) -> None:
        gprim = self.UsdGeom.Gprim(prim)
        gprim.CreateDisplayColorAttr([self.Gf.Vec3f(float(rgb[0]), float(rgb[1]), float(rgb[2]))])
        gprim.CreateDisplayOpacityAttr([float(opacity)])

    def _lidar_to_world_matrix(self):
        prim = self.stage.GetPrimAtPath(self.detector.lidar_prim_path)
        cache = self.UsdGeom.XformCache(self.Usd.TimeCode.Default())
        return cache.GetLocalToWorldTransform(prim)

    def _transform_point(self, matrix, point: Iterable[float]):
        p = np.asarray(point, dtype=np.float64)
        return matrix.Transform(self.Gf.Vec3d(float(p[0]), float(p[1]), float(p[2])))

    def _draw_sphere(self, path: str, position, *, radius: float, color: tuple[float, float, float], opacity: float = 1.0) -> None:
        self._delete_if_exists(path)
        sphere = self.UsdGeom.Sphere.Define(self.stage, path)
        sphere.CreateRadiusAttr(float(radius))
        xform = self.UsdGeom.Xformable(sphere.GetPrim())
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set(position)
        self._set_display_color(sphere.GetPrim(), color, opacity=opacity)

    def _draw_line(self, path: str, a, b, *, color: tuple[float, float, float], opacity: float = 1.0) -> None:
        self._delete_if_exists(path)
        curves = self.UsdGeom.BasisCurves.Define(self.stage, path)
        curves.CreateTypeAttr("linear")
        curves.CreateCurveVertexCountsAttr([2])
        curves.CreatePointsAttr([a, b])
        w = float(self.line_width)
        # Une largeur par vertex évite le spam `widths primvar is not valid`.
        curves.CreateWidthsAttr([w, w])
        try:
            curves.SetWidthsInterpolation(self.UsdGeom.Tokens.vertex)
        except Exception:
            pass
        self._set_display_color(curves.GetPrim(), color, opacity=opacity)

    def update(self, observation: LidarNeighborObservation | None = None) -> LidarNeighborObservation:
        obs = observation or self.detector.read()
        self.clear()
        matrix = self._lidar_to_world_matrix()
        origin = self._transform_point(matrix, (0.0, 0.0, 0.0))

        # Blanc : position du LiDAR.
        self._draw_sphere(f"{self.root_path}/lidar_origin", origin, radius=self.center_radius * 0.7, color=(1.0, 1.0, 1.0))

        # Petits points jaunes : points candidats après filtre 0.10–0.75 m. On
        # n'affiche qu'un échantillon pour ne pas saturer Hydra.
        if self.draw_candidate_points and obs.candidate_points.shape[0] > 0:
            candidates_root = f"{self.root_path}/candidate_points"
            self.stage.DefinePrim(candidates_root, "Xform")
            for i, point in enumerate(obs.candidate_points[:: self.candidate_point_stride]):
                wp = self._transform_point(matrix, point)
                self._draw_sphere(
                    f"{candidates_root}/p_{i:04d}",
                    wp,
                    radius=self.point_radius,
                    color=(1.0, 0.85, 0.05),
                    opacity=0.8,
                )

        # Vert : clusters acceptés comme voisins.
        for cluster in obs.clusters:
            name = _safe_usd_name(f"cluster_{cluster.cluster_id}")
            cluster_root = f"{self.root_path}/{name}"
            self.stage.DefinePrim(cluster_root, "Xform")
            center_local = (cluster.center_xy[0], cluster.center_xy[1], 0.0)
            center_world = self._transform_point(matrix, center_local)
            self._draw_line(f"{cluster_root}/ray", origin, center_world, color=(0.0, 1.0, 0.0))
            self._draw_sphere(f"{cluster_root}/center", center_world, radius=self.center_radius, color=(0.0, 1.0, 0.0))

        # Rouge transparent : clusters rejetés par filtre optionnel.
        for cluster in obs.rejected_clusters:
            name = _safe_usd_name(f"rejected_{cluster.cluster_id}")
            cluster_root = f"{self.root_path}/{name}"
            self.stage.DefinePrim(cluster_root, "Xform")
            center_local = (cluster.center_xy[0], cluster.center_xy[1], 0.0)
            center_world = self._transform_point(matrix, center_local)
            self._draw_line(f"{cluster_root}/ray", origin, center_world, color=(1.0, 0.0, 0.0), opacity=0.45)
            self._draw_sphere(f"{cluster_root}/center", center_world, radius=self.center_radius * 0.8, color=(1.0, 0.0, 0.0), opacity=0.55)

        # Cyan : vecteur attraction résultant.
        if obs.vector_norm > 1e-12:
            end_local = (
                float(obs.attraction_vector_xy[0]) * self.vector_scale,
                float(obs.attraction_vector_xy[1]) * self.vector_scale,
                0.0,
            )
            end_world = self._transform_point(matrix, end_local)
            self._draw_line(f"{self.root_path}/attraction_vector", origin, end_world, color=(0.0, 0.8, 1.0))
            self._draw_sphere(f"{self.root_path}/attraction_vector_tip", end_world, radius=self.center_radius * 0.85, color=(0.0, 0.8, 1.0))

        return obs
