"""
Beacon logique ultra simple pour Isaac Sim 6.0.

But : remplacer fonctionnellement la détection IRL du beacon par caméra fisheye
par un calcul géométrique direct entre deux Xform USD.

Principe :
    - un Xform côté robot sert de repère capteur ;
    - un ou plusieurs Xform dans la scène servent de beacons ;
    - le helper transforme la position monde du beacon dans le repère capteur ;
    - il retourne une lecture `value + angle`, directement utilisable par phototaxis.

Convention locale du repère capteur :
    +X = avant du robot
    +Y = gauche du robot
    angle = atan2(y_local, x_local)

Sortie recommandée pour AutoMoDe phototaxis :
    reading.value = 1.0 si au moins un beacon est visible, sinon 0.0
    reading.angle = direction relative du beacon, en radians

Ce helper ne fait volontairement pas :
    - rendu RTX ;
    - segmentation couleur ;
    - distorsion fisheye ;
    - occlusion par raycast.

C'est une abstraction de la sortie utile du pipeline de perception, pas une
simulation de caméra.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import atan2, cos, isfinite, pi, radians, sin, sqrt
from typing import Iterable, Sequence

import numpy as np


DEFAULT_BEACON_DETECTOR_NAME = "beacon_detector"


def wrap_to_pi(angle: float) -> float:
    """Ramène un angle en radians dans [-pi, pi]."""
    a = float(angle)
    while a > pi:
        a -= 2.0 * pi
    while a < -pi:
        a += 2.0 * pi
    return a


def _as_np3(v) -> np.ndarray:
    return np.array([float(v[0]), float(v[1]), float(v[2])], dtype=np.float32)


@dataclass(frozen=True)
class BeaconCandidate:
    """Information géométrique pour un beacon candidat."""

    prim_path: str
    valid: bool
    visible: bool
    distance: float
    angle: float
    world_position: np.ndarray
    local_position: np.ndarray
    reason: str = ""

    def as_unit_vector_xy(self) -> np.ndarray:
        return np.array([cos(self.angle), sin(self.angle)], dtype=np.float32)


@dataclass(frozen=True)
class BeaconReading:
    """
    Lecture finale du capteur beacon.

    value:
        0.0 si aucun beacon visible.
        1.0 si au moins un beacon visible.

    angle:
        Direction agrégée des beacons visibles dans le repère capteur.
        0 rad = devant, positif = gauche, négatif = droite.

    distance:
        Distance au beacon visible le plus proche.
        np.inf si aucun beacon visible.
    """

    value: float
    angle: float
    distance: float
    seen: bool
    seen_count: int
    closest_beacon_path: str | None
    detector_path: str
    detector_world_position: np.ndarray
    candidates: tuple[BeaconCandidate, ...]

    def as_vector_xy(self) -> np.ndarray:
        """Vecteur 2D local compatible avec les modules AutoMoDe."""
        if not self.seen or self.value <= 0.0:
            return np.zeros(2, dtype=np.float32)
        return np.array([self.value * cos(self.angle), self.value * sin(self.angle)], dtype=np.float32)

    def as_debug_dict(self) -> dict[str, float | int | bool | str | None]:
        return {
            "beacon_seen": self.seen,
            "beacon_seen_count": int(self.seen_count),
            "beacon_value": float(self.value),
            "beacon_angle_rad": float(self.angle),
            "beacon_angle_deg": float(np.degrees(self.angle)),
            "beacon_distance": float(self.distance),
            "closest_beacon_path": self.closest_beacon_path,
        }


class XformBeaconHelper:
    """
    Capteur de beacon basé uniquement sur des Xform USD.

    Exemple :
        sensor = XformBeaconHelper(
            detector_xform_path="/World/Robot1/MercatorLite/base_link/beacon_detector",
            beacon_paths=["/World/Beacons/Beacon_0"],
            max_range=5.0,
            horizontal_fov_deg=360.0,
        )
        reading = sensor.read()
        print(reading.value, reading.angle)
    """

    def __init__(
        self,
        detector_xform_path: str,
        beacon_paths: Sequence[str] | Iterable[str],
        *,
        min_range: float = 0.0,
        max_range: float = 5.0,
        horizontal_fov_deg: float = 360.0,
        aggregate_mode: str = "unit_sum",
        verbose: bool = False,
    ) -> None:
        self.detector_xform_path = str(detector_xform_path).rstrip("/")
        self.beacon_paths = tuple(str(p).rstrip("/") for p in beacon_paths)
        self.min_range = float(min_range)
        self.max_range = float(max_range)
        self.horizontal_fov_rad = radians(float(horizontal_fov_deg))
        self.aggregate_mode = str(aggregate_mode)
        self.verbose = bool(verbose)

        if self.max_range <= 0.0:
            raise ValueError("max_range doit être strictement positif")
        if self.min_range < 0.0:
            raise ValueError("min_range doit être positif ou nul")
        if self.min_range >= self.max_range:
            raise ValueError("min_range doit être inférieur à max_range")
        if self.aggregate_mode not in ("unit_sum", "nearest"):
            raise ValueError("aggregate_mode doit valoir 'unit_sum' ou 'nearest'")

        import omni.usd
        from pxr import UsdGeom

        self.omni_usd = omni.usd
        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.xform_cache = UsdGeom.XformCache()

        detector_prim = self.stage.GetPrimAtPath(self.detector_xform_path)
        if not detector_prim or not detector_prim.IsValid():
            raise RuntimeError(f"Xform détecteur beacon introuvable : {self.detector_xform_path}")

        missing = [p for p in self.beacon_paths if not self.stage.GetPrimAtPath(p).IsValid()]
        if missing and self.verbose:
            print(f"[XformBeaconHelper] beacons manquants ignorés : {missing}")

    @staticmethod
    def detector_path_for_robot(robot_name: str, detector_name: str = DEFAULT_BEACON_DETECTOR_NAME) -> str:
        return f"/World/{robot_name}/MercatorLite/base_link/{detector_name}"

    @staticmethod
    def beacons_root_path() -> str:
        return "/World/Beacons"

    @staticmethod
    def beacon_path(index: int = 0) -> str:
        return f"/World/Beacons/Beacon_{int(index)}"

    @staticmethod
    def _get_stage():
        import omni.usd

        return omni.usd.get_context().get_stage()

    @staticmethod
    def _set_xform(path: str, position: Iterable[float], rotation_xyz_deg: Iterable[float] = (0.0, 0.0, 0.0)) -> str:
        """Crée ou remplace un Xform simple avec translate + rotateXYZ."""
        from pxr import Gf, UsdGeom

        stage = XformBeaconHelper._get_stage()
        prim = stage.GetPrimAtPath(path)
        if not prim or not prim.IsValid():
            prim = UsdGeom.Xform.Define(stage, path).GetPrim()
        else:
            # On repart d'un ordre propre pour éviter les accumulations de XformOps.
            prim = UsdGeom.Xform(prim).GetPrim()

        xform = UsdGeom.Xformable(prim)
        xform.ClearXformOpOrder()
        px, py, pz = position
        rx, ry, rz = rotation_xyz_deg
        xform.AddTranslateOp().Set(Gf.Vec3d(float(px), float(py), float(pz)))
        xform.AddRotateXYZOp().Set(Gf.Vec3f(float(rx), float(ry), float(rz)))
        return path

    @staticmethod
    def ensure_detector_xform_for_robot(
        robot_name: str,
        *,
        detector_name: str = DEFAULT_BEACON_DETECTOR_NAME,
        translation: Iterable[float] = (0.0, 0.0, 0.15),
        rotation_xyz_deg: Iterable[float] = (0.0, 0.0, 0.0),
    ) -> str:
        """
        Crée un Xform `beacon_detector` sous `base_link`.

        Le helper lit ce repère comme s'il s'agissait de la sortie géométrique
        de la caméra fisheye. Comme il est enfant de `base_link`, il bouge avec
        le robot.
        """
        path = XformBeaconHelper.detector_path_for_robot(robot_name, detector_name)
        return XformBeaconHelper._set_xform(path, translation, rotation_xyz_deg)

    @staticmethod
    def create_beacon_xform(
        path: str = "/World/Beacons/Beacon_0",
        *,
        position: Iterable[float] = (1.0, 0.0, 0.15),
        rotation_xyz_deg: Iterable[float] = (0.0, 0.0, 0.0),
        visible_sphere: bool = True,
        radius: float = 0.06,
        color: tuple[float, float, float] = (1.0, 0.85, 0.0),
    ) -> str:
        """
        Crée un beacon comme Xform USD.

        Si `visible_sphere=True`, ajoute une petite sphère enfant uniquement pour
        le debug visuel. Le capteur lit le Xform parent, pas la sphère.
        """
        from pxr import Gf, Sdf, UsdGeom

        stage = XformBeaconHelper._get_stage()
        parent_path = "/".join(path.rstrip("/").split("/")[:-1])
        if parent_path:
            stage.DefinePrim(parent_path, "Xform")

        XformBeaconHelper._set_xform(path, position, rotation_xyz_deg)
        prim = stage.GetPrimAtPath(path)
        prim.CreateAttribute("mercator:is_beacon", Sdf.ValueTypeNames.Bool, custom=True).Set(True)

        if visible_sphere:
            sphere_path = f"{path}/debug_sphere"
            sphere = UsdGeom.Sphere.Define(stage, sphere_path)
            sphere.CreateRadiusAttr(float(radius))
            gprim = UsdGeom.Gprim(sphere.GetPrim())
            gprim.CreateDisplayColorAttr([Gf.Vec3f(float(color[0]), float(color[1]), float(color[2]))])
            gprim.CreateDisplayOpacityAttr([1.0])

        return path

    def _get_world_matrix(self, prim_path: str):
        prim = self.stage.GetPrimAtPath(prim_path)
        if not prim or not prim.IsValid():
            return None
        return self.xform_cache.GetLocalToWorldTransform(prim)

    def get_detector_world_position(self) -> np.ndarray:
        self.xform_cache.Clear()
        detector_world = self._get_world_matrix(self.detector_xform_path)
        if detector_world is None:
            return np.full(3, np.nan, dtype=np.float32)
        return _as_np3(detector_world.ExtractTranslation())

    def local_xy_direction_to_world(self, xy: Iterable[float]) -> np.ndarray:
        """Convertit une direction 2D locale du détecteur en direction monde 3D."""
        from pxr import Gf

        detector_world = self._get_world_matrix(self.detector_xform_path)
        if detector_world is None:
            return np.array([1.0, 0.0, 0.0], dtype=np.float32)
        x, y = xy
        d = detector_world.TransformDir(Gf.Vec3d(float(x), float(y), 0.0))
        arr = _as_np3(d)
        n = float(np.linalg.norm(arr))
        if n <= 1e-9 or not isfinite(n):
            return np.array([1.0, 0.0, 0.0], dtype=np.float32)
        return (arr / n).astype(np.float32)

    def read_candidates(self) -> tuple[BeaconCandidate, ...]:
        """Retourne l'état géométrique de chaque beacon candidat."""
        self.xform_cache.Clear()

        detector_world = self._get_world_matrix(self.detector_xform_path)
        if detector_world is None:
            return tuple(
                BeaconCandidate(
                    prim_path=p,
                    valid=False,
                    visible=False,
                    distance=float("inf"),
                    angle=0.0,
                    world_position=np.full(3, np.nan, dtype=np.float32),
                    local_position=np.full(3, np.nan, dtype=np.float32),
                    reason="detector_missing",
                )
                for p in self.beacon_paths
            )

        world_to_detector = detector_world.GetInverse()
        out: list[BeaconCandidate] = []

        for path in self.beacon_paths:
            beacon_world = self._get_world_matrix(path)
            if beacon_world is None:
                out.append(
                    BeaconCandidate(
                        prim_path=path,
                        valid=False,
                        visible=False,
                        distance=float("inf"),
                        angle=0.0,
                        world_position=np.full(3, np.nan, dtype=np.float32),
                        local_position=np.full(3, np.nan, dtype=np.float32),
                        reason="beacon_missing",
                    )
                )
                continue

            world_pos = beacon_world.ExtractTranslation()
            local_pos = world_to_detector.Transform(world_pos)
            world_np = _as_np3(world_pos)
            local_np = _as_np3(local_pos)

            x = float(local_np[0])
            y = float(local_np[1])
            distance = sqrt(x * x + y * y)
            angle = wrap_to_pi(atan2(y, x))

            visible = True
            reason = "visible"
            if distance < self.min_range:
                visible = False
                reason = "too_close"
            elif distance > self.max_range:
                visible = False
                reason = "too_far"
            elif self.horizontal_fov_rad < 2.0 * pi - 1e-6 and abs(angle) > 0.5 * self.horizontal_fov_rad:
                visible = False
                reason = "outside_fov"

            out.append(
                BeaconCandidate(
                    prim_path=path,
                    valid=True,
                    visible=visible,
                    distance=float(distance),
                    angle=float(angle),
                    world_position=world_np,
                    local_position=local_np,
                    reason=reason,
                )
            )

        return tuple(out)

    def read(self) -> BeaconReading:
        """
        Lit les beacons et renvoie une observation AutoMoDe-like.

        aggregate_mode="unit_sum" : somme les directions unitaires visibles.
        aggregate_mode="nearest"  : prend uniquement le beacon visible le plus proche.
        """
        candidates = self.read_candidates()
        detector_pos = self.get_detector_world_position()
        visible = [c for c in candidates if c.valid and c.visible]

        if not visible:
            return BeaconReading(
                value=0.0,
                angle=0.0,
                distance=float("inf"),
                seen=False,
                seen_count=0,
                closest_beacon_path=None,
                detector_path=self.detector_xform_path,
                detector_world_position=detector_pos,
                candidates=candidates,
            )

        closest = min(visible, key=lambda c: c.distance)

        if self.aggregate_mode == "nearest":
            angle = closest.angle
        else:
            sx = float(sum(cos(c.angle) for c in visible))
            sy = float(sum(sin(c.angle) for c in visible))
            norm = sqrt(sx * sx + sy * sy)
            # Si deux beacons visibles s'annulent parfaitement, on évite un angle
            # arbitraire et on retombe sur le plus proche.
            angle = closest.angle if norm <= 1e-9 else wrap_to_pi(atan2(sy, sx))

        return BeaconReading(
            value=1.0,
            angle=float(angle),
            distance=float(closest.distance),
            seen=True,
            seen_count=len(visible),
            closest_beacon_path=closest.prim_path,
            detector_path=self.detector_xform_path,
            detector_world_position=detector_pos,
            candidates=candidates,
        )

    def get_vector_xy(self) -> np.ndarray:
        """Raccourci pour les modules : retourne [x, y] local."""
        return self.read().as_vector_xy()
