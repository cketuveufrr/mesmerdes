"""Utilitaires de scène Isaac Sim 6.0 pour les tests Mercator."""

from __future__ import annotations

from typing import Any

import numpy as np
import omni.usd
from pxr import Usd, UsdGeom, UsdLux, UsdPhysics, UsdShade

import isaacsim.core.experimental.utils.stage as stage_utils
from isaacsim.core.experimental.materials import PreviewSurfaceMaterial
from isaacsim.core.experimental.objects import Cube
from isaacsim.core.experimental.prims import GeomPrim, RigidPrim
from isaacsim.storage.native import get_assets_root_path


def _to_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


def add_default_ground() -> None:
    assets_root = get_assets_root_path()
    if assets_root is None:
        raise RuntimeError("Impossible de trouver le dossier d'assets Isaac Sim.")
    stage_utils.add_reference_to_stage(
        usd_path=assets_root + "/Isaac/Environments/Grid/default_environment.usd",
        path="/World/Ground",
    )


def _define_physics_material(path: str, static_friction: float, dynamic_friction: float, restitution: float):
    stage = omni.usd.get_context().get_stage()
    material = UsdShade.Material.Define(stage, path)
    api = UsdPhysics.MaterialAPI.Apply(material.GetPrim())
    api.CreateStaticFrictionAttr(float(static_friction))
    api.CreateDynamicFrictionAttr(float(dynamic_friction))
    api.CreateRestitutionAttr(float(restitution))
    return material


def bind_zero_friction_material_to_ground() -> None:
    stage = omni.usd.get_context().get_stage()
    material = _define_physics_material("/World/PhysicsMaterials/ground_zero_friction", 0.0, 0.0, 0.0)
    ground_root = stage.GetPrimAtPath("/World/Ground")
    if not ground_root.IsValid():
        return
    for prim in Usd.PrimRange(ground_root):
        if prim.HasAPI(UsdPhysics.CollisionAPI):
            UsdShade.MaterialBindingAPI.Apply(prim).Bind(material)


def bind_zero_friction_material_to_robot(robot_root_path: str) -> None:
    stage = omni.usd.get_context().get_stage()
    material = _define_physics_material(
        f"/World/PhysicsMaterials/{robot_root_path.strip('/').replace('/', '_')}_zero_friction",
        0.0,
        0.0,
        0.0,
    )
    collider_candidates = [
        f"{robot_root_path}/MercatorLite/collision/body_box",
        f"{robot_root_path}/Root/MercatorLite/collision/body_box",
    ]
    collider = None
    for path in collider_candidates:
        prim = stage.GetPrimAtPath(path)
        if prim.IsValid():
            collider = prim
            break
    if collider is None:
        root = stage.GetPrimAtPath(robot_root_path)
        if root.IsValid():
            for prim in Usd.PrimRange(root):
                if prim.GetName() == "body_box" and "collision" in prim.GetPath().pathString:
                    collider = prim
                    break
    if collider is not None:
        UsdShade.MaterialBindingAPI.Apply(collider).Bind(material)


def add_mercator_lite(
    robot_name: str,
    usd_path: str,
    position: tuple[float, float, float] | list[float] | np.ndarray = (0.0, 0.0, 0.0),
    orientation_wxyz: tuple[float, float, float, float] | list[float] | np.ndarray = (1.0, 0.0, 0.0, 0.0),
) -> RigidPrim:
    root_path = f"/World/{robot_name}"
    body_path = f"{root_path}/MercatorLite"
    stage_utils.add_reference_to_stage(usd_path=usd_path, path=root_path)
    bind_zero_friction_material_to_robot(root_path)
    robot = RigidPrim(
        paths=body_path,
        positions=np.asarray([position], dtype=np.float32),
        orientations=np.asarray([orientation_wxyz], dtype=np.float32),
        reset_xform_op_properties=True,
    )
    robot.set_velocities(
        linear_velocities=np.zeros((1, 3), dtype=np.float32),
        angular_velocities=np.zeros((1, 3), dtype=np.float32),
    )
    return robot


def create_dynamic_block(
    path: str,
    position: tuple[float, float, float],
    scale: tuple[float, float, float] = (0.25, 0.25, 0.20),
    mass: float = 0.40,
    color: tuple[float, float, float] = (0.8, 0.1, 0.1),
) -> RigidPrim:
    material = PreviewSurfaceMaterial(f"/World/Materials/{path.strip('/').replace('/', '_')}_mat")
    material.set_input_values("diffuseColor", list(color))
    shape = Cube(
        paths=path,
        positions=np.asarray([position], dtype=np.float32),
        sizes=[1.0],
        scales=np.asarray([scale], dtype=np.float32),
        reset_xform_op_properties=True,
    )
    GeomPrim(paths=shape.paths, apply_collision_apis=True)
    rigid = RigidPrim(paths=shape.paths, masses=[float(mass)])
    shape.apply_visual_materials(material)
    return rigid


def add_light_and_camera() -> None:
    stage = omni.usd.get_context().get_stage()
    light = UsdLux.DistantLight.Define(stage, "/World/Sun")
    light.CreateIntensityAttr(3500.0)
    light.CreateAngleAttr(0.5)
    camera = UsdGeom.Camera.Define(stage, "/World/Camera")
    xform = UsdGeom.Xformable(camera.GetPrim())
    xform.AddTranslateOp().Set((1.8, -2.0, 1.2))
    xform.AddRotateXYZOp().Set((60.0, 0.0, 42.0))
    camera.CreateFocalLengthAttr(20.0)


def get_rigid_position(rigid: RigidPrim) -> np.ndarray:
    positions, _ = rigid.get_world_poses()
    return _to_numpy(positions)[0]


# Même défaut que dans sensors/camera_detection.py. On duplique ces constantes ici
# pour éviter d'importer tout le module sensors depuis les utilitaires de stage.
DEFAULT_OAKD_CAMERA_TRANSLATION = (0.05211, -0.00494, 0.12559)
DEFAULT_OAKD_CAMERA_ROTATION_XYZ_DEG = (0.0, -30.0, 0.0)


def ensure_logical_oakd_camera(
    robot_name: str,
    *,
    translation: tuple[float, float, float] = DEFAULT_OAKD_CAMERA_TRANSLATION,
    rotation_xyz_deg: tuple[float, float, float] = DEFAULT_OAKD_CAMERA_ROTATION_XYZ_DEG,
    force_update: bool = False,
) -> str:
    """
    Vérifie/crée le prim logique de caméra OAK-D pour un robot.

    Le capteur caméra parfait n'a pas besoin d'une vraie caméra RTX : il a besoin d'un
    repère géométrique stable. Si l'asset USD contient déjà
    `/World/<robot>/MercatorLite/base_link/oak_d_camera`, cette fonction ne change
    rien, sauf si `force_update=True`.

    Convention locale : x avant, y gauche, z haut.

    Défaut actuel du montage Mercator :
        translation       = (0.05211, -0.00494, 0.12559) m
        rotation XYZ deg  = (0, -30, 0)

    Pour changer le setup sans éditer l'USD, appeler par exemple :
        ensure_logical_oakd_camera(
            "Robot1",
            translation=(...),
            rotation_xyz_deg=(...),
            force_update=True,
        )
    """
    from pxr import Gf

    stage = omni.usd.get_context().get_stage()
    path = f"/World/{robot_name}/MercatorLite/base_link/oak_d_camera"
    prim = stage.GetPrimAtPath(path)
    if prim.IsValid() and not force_update:
        return path

    camera = UsdGeom.Xform.Define(stage, path)
    xform = UsdGeom.Xformable(camera.GetPrim())
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(translation[0]), float(translation[1]), float(translation[2])))
    # On utilise RotateXYZ pour que les valeurs correspondent directement aux champs
    # visibles dans l'UI Isaac : X, Y, Z en degrés.
    xform.AddRotateXYZOp().Set(Gf.Vec3f(float(rotation_xyz_deg[0]), float(rotation_xyz_deg[1]), float(rotation_xyz_deg[2])))
    xform.AddScaleOp().Set(Gf.Vec3d(1.0, 1.0, 1.0))
    return path
