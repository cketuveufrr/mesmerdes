"""Helpers de scène pour le Mercator full.

Le fichier USD fourni dans ce dépôt conserve, pour l'instant, un nom historique
`MercatorLiteOfficial_rtx_lidar_ground_clean.usda` et un prim interne
`MercatorLite`. Son mesh visuel référence cependant `assets/mercator_full/3DModel.usd`.
Ce module expose donc des noms explicites `full` côté Python, sans renommer l'USD
ni casser les chemins de capteurs déjà validés.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import omni.usd
import isaacsim.core.experimental.utils.stage as stage_utils
from isaacsim.core.experimental.prims import RigidPrim

from .stage_setup import bind_zero_friction_material_to_robot


def _to_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


@dataclass(frozen=True)
class MercatorRobotPaths:
    """Chemins USD d'un Mercator instancié dans `/World/<robot_name>`.

    Les propriétés ne supposent pas que le prim interne s'appelle réellement
    `MercatorFull`. Elles sont résolues depuis la scène, ce qui permet de garder
    l'asset actuel tel quel.
    """

    robot_name: str
    root_path: str
    body_path: str

    @property
    def base_link_path(self) -> str:
        return f"{self.body_path}/base_link"

    @property
    def teraranger_root_path(self) -> str:
        return f"{self.base_link_path}/terarangers"

    @property
    def lidar_prim_path(self) -> str:
        return f"{self.base_link_path}/lidar_link/ydlidar_X4"

    @property
    def ground_sensor_path(self) -> str:
        return f"{self.base_link_path}/ground_sensor"

    @property
    def collision_box_path(self) -> str:
        return f"{self.body_path}/collision/body_box"


def default_mercator_full_usd_path(project_root: str | os.PathLike[str] | None = None) -> str:
    """Retourne le chemin de l'asset Mercator full déjà présent dans ce dépôt."""
    if project_root is None:
        project_root = Path(__file__).resolve().parents[1]
    project_root = Path(project_root)
    return str(project_root / "assets" / "MercatorLiteOfficial_rtx_lidar_ground_clean.usda")


def resolve_mercator_paths(robot_name: str, *, root_path: str | None = None) -> MercatorRobotPaths:
    """Résout les chemins de capteurs et de body depuis la scène USD courante."""
    root_path = (root_path or f"/World/{robot_name}").rstrip("/")
    stage = omni.usd.get_context().get_stage()

    preferred = [
        f"{root_path}/MercatorFull",
        f"{root_path}/Mercator",
        f"{root_path}/MercatorLite",
        f"{root_path}/Root/MercatorFull",
        f"{root_path}/Root/Mercator",
        f"{root_path}/Root/MercatorLite",
    ]
    for body_path in preferred:
        prim = stage.GetPrimAtPath(body_path)
        if prim and prim.IsValid():
            return MercatorRobotPaths(robot_name=robot_name, root_path=root_path, body_path=body_path)

    root_prim = stage.GetPrimAtPath(root_path)
    if root_prim and root_prim.IsValid():
        # Dernier recours : chercher un descendant qui possède `base_link`.
        from pxr import Usd

        for prim in Usd.PrimRange(root_prim):
            base = stage.GetPrimAtPath(f"{prim.GetPath().pathString}/base_link")
            if base and base.IsValid():
                return MercatorRobotPaths(robot_name=robot_name, root_path=root_path, body_path=prim.GetPath().pathString)

    raise RuntimeError(
        f"Impossible de résoudre le body Mercator pour {robot_name}. "
        f"Root inspecté : {root_path}"
    )


def add_mercator_full(
    robot_name: str,
    usd_path: str | None = None,
    position: tuple[float, float, float] | list[float] | np.ndarray = (0.0, 0.0, 0.0),
    orientation_wxyz: tuple[float, float, float, float] | list[float] | np.ndarray = (1.0, 0.0, 0.0, 0.0),
) -> tuple[RigidPrim, MercatorRobotPaths]:
    """Ajoute un Mercator full dans la scène et retourne `(RigidPrim, paths)`.

    Le modèle, sa collision et sa bounding box restent ceux de l'USD fourni.
    """
    if usd_path is None:
        usd_path = default_mercator_full_usd_path()
    root_path = f"/World/{robot_name}"
    stage_utils.add_reference_to_stage(usd_path=str(usd_path), path=root_path)
    paths = resolve_mercator_paths(robot_name, root_path=root_path)
    bind_zero_friction_material_to_robot(root_path)
    robot = RigidPrim(
        paths=paths.body_path,
        positions=np.asarray([position], dtype=np.float32),
        orientations=np.asarray([orientation_wxyz], dtype=np.float32),
        reset_xform_op_properties=True,
    )
    robot.set_velocities(
        linear_velocities=np.zeros((1, 3), dtype=np.float32),
        angular_velocities=np.zeros((1, 3), dtype=np.float32),
    )
    return robot, paths
