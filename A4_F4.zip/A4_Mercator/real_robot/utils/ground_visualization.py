"""Création USD légère pour visualiser une GroundMap.

Important : la vérité du ground sensor analytique reste `GroundMap`.
Les prims créés ici servent à rendre les zones visibles dans Isaac. Ils peuvent
optionnellement recevoir une collision pour tester le backend raycast de debug.
"""

from __future__ import annotations

import math
import re

from pxr import Gf, Sdf, UsdGeom, UsdPhysics
import omni.usd

from sensors.ground_map import CircleZone, GroundMap, RectangleZone, PolygonZone, color_label, color_rgb


_VALID_TOKEN_RE = re.compile(r"[^A-Za-z0-9_]")


def _safe_token(value: object, fallback: str) -> str:
    """Convertit un nom arbitraire en identifiant USD sûr."""
    token = str(value) if value is not None else ""
    token = _VALID_TOKEN_RE.sub("_", token.strip())
    token = token.strip("_")
    if not token:
        token = fallback
    if token[0].isdigit():
        token = "z_" + token
    return token


def _child_path(parent: str | Sdf.Path, child: object, fallback: str) -> Sdf.Path:
    """Construit un chemin USD absolu robuste."""
    parent_path = parent if isinstance(parent, Sdf.Path) else Sdf.Path(str(parent))
    if parent_path.isEmpty or not parent_path.IsAbsolutePath():
        raise ValueError(f"root_path USD invalide : {parent!r}")
    return parent_path.AppendChild(_safe_token(child, fallback))


def _set_display_color(prim, rgb) -> None:
    gprim = UsdGeom.Gprim(prim)
    gprim.CreateDisplayColorAttr().Set([Gf.Vec3f(float(rgb[0]), float(rgb[1]), float(rgb[2]))])


def _add_ground_attrs(prim, label) -> None:
    color_name = color_label(label)
    prim.CreateAttribute("ground:label", Sdf.ValueTypeNames.String, custom=True).Set(color_name)
    prim.CreateAttribute("ground:id", Sdf.ValueTypeNames.Int, custom=True).Set({"gray": 0, "black": 1, "white": 2}.get(color_name, -1))


def _apply_collision_if_requested(prim, apply_collision: bool) -> None:
    if apply_collision:
        UsdPhysics.CollisionAPI.Apply(prim)


def _define_disk_mesh(stage, path: Sdf.Path, *, center: tuple[float, float], radius: float, z: float, segments: int = 64):
    """Crée un disque plat par Mesh plutôt que par Cylinder.

    Sur certains builds Isaac/USD, `UsdGeom.Cylinder.Define(stage, path)` peut
    échouer avec un path vide côté binding Python. Le mesh explicite est plus
    robuste et suffit largement pour visualiser une zone circulaire au sol.
    """
    segments = max(12, int(segments))
    mesh = UsdGeom.Mesh.Define(stage, path)
    points = [Gf.Vec3f(float(center[0]), float(center[1]), float(z))]
    for k in range(segments):
        a = 2.0 * math.pi * k / segments
        points.append(Gf.Vec3f(float(center[0] + radius * math.cos(a)), float(center[1] + radius * math.sin(a)), float(z)))

    # Triangle fan : chaque face est [centre, point k, point k+1].
    face_vertex_counts = []
    face_vertex_indices = []
    for k in range(segments):
        face_vertex_counts.append(3)
        face_vertex_indices.extend([0, 1 + k, 1 + ((k + 1) % segments)])

    mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr(face_vertex_counts)
    mesh.CreateFaceVertexIndicesAttr(face_vertex_indices)
    mesh.CreateDoubleSidedAttr(True)
    return mesh


def create_ground_visualization(
    ground_map: GroundMap,
    *,
    root_path: str = "/World/SemanticGround",
    extent: tuple[float, float, float, float] = (-1.5, 1.5, -1.5, 1.5),
    z: float = 0.004,
    thickness: float = 0.003,
    apply_collision: bool = False,
) -> str:
    """
    Crée une visualisation USD de la GroundMap.

    Par défaut, aucune collision n'est ajoutée : le capteur principal est
    analytique et n'a pas besoin de raycast. Pour tester `RaycastGroundSensor`,
    appeler avec `apply_collision=True`.
    """
    stage = omni.usd.get_context().get_stage()
    root_sdf_path = Sdf.Path(root_path)
    if root_sdf_path.isEmpty or not root_sdf_path.IsAbsolutePath():
        raise ValueError(f"root_path USD invalide : {root_path!r}")

    UsdGeom.Xform.Define(stage, root_sdf_path)

    min_x, max_x, min_y, max_y = extent
    base = UsdGeom.Cube.Define(stage, _child_path(root_sdf_path, "Base_gray", "Base_gray"))
    base.AddTranslateOp().Set(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, z))
    base.AddScaleOp().Set(((max_x - min_x) * 0.5, (max_y - min_y) * 0.5, thickness * 0.5))
    _set_display_color(base.GetPrim(), color_rgb(ground_map.default))
    _add_ground_attrs(base.GetPrim(), ground_map.default)
    _apply_collision_if_requested(base.GetPrim(), apply_collision)

    for i, zone in enumerate(ground_map.zones):
        safe_name = f"z_{i:03d}_{_safe_token(zone.name, 'zone')}"
        path = _child_path(root_sdf_path, safe_name, f"zone_{i:03d}")
        zone_z = z + 0.002 + i * 1e-5

        if isinstance(zone, CircleZone):
            geom = _define_disk_mesh(stage, path, center=zone.center, radius=float(zone.radius), z=zone_z)
            _set_display_color(geom.GetPrim(), color_rgb(zone.color))
            _add_ground_attrs(geom.GetPrim(), zone.color)
            _apply_collision_if_requested(geom.GetPrim(), apply_collision)

        elif isinstance(zone, RectangleZone):
            geom = UsdGeom.Cube.Define(stage, path)
            geom.AddTranslateOp().Set((zone.center[0], zone.center[1], zone_z))
            geom.AddRotateZOp().Set(math.degrees(zone.yaw))
            geom.AddScaleOp().Set((zone.size[0] * 0.5, zone.size[1] * 0.5, thickness * 0.5))
            _set_display_color(geom.GetPrim(), color_rgb(zone.color))
            _add_ground_attrs(geom.GetPrim(), zone.color)
            _apply_collision_if_requested(geom.GetPrim(), apply_collision)

        elif isinstance(zone, PolygonZone):
            xs = [p[0] for p in zone.vertices]
            ys = [p[1] for p in zone.vertices]
            if not xs or not ys:
                continue
            geom = UsdGeom.Cube.Define(stage, path)
            geom.AddTranslateOp().Set(((min(xs) + max(xs)) * 0.5, (min(ys) + max(ys)) * 0.5, zone_z))
            geom.AddScaleOp().Set(((max(xs) - min(xs)) * 0.5, (max(ys) - min(ys)) * 0.5, thickness * 0.5))
            _set_display_color(geom.GetPrim(), color_rgb(zone.color))
            _add_ground_attrs(geom.GetPrim(), zone.color)
            _apply_collision_if_requested(geom.GetPrim(), apply_collision)

    return str(root_sdf_path)
