"""Visualisation USD commune pour les modules AutoMoDe Mercator."""

from __future__ import annotations

import math
import re
from typing import Iterable

import numpy as np

from controllers import yaw_from_quat_wxyz
from .automode_modules import AutoMoDeMercatorModules, AutoMoDeModuleID


def _safe_usd_name(name: str) -> str:
    out = re.sub(r"[^A-Za-z0-9_]", "_", str(name))
    return out if out else "module"


class AutoMoDeModuleDebugVisualizer:
    """Dessine le vecteur cible utilisé par le module courant.

    Couleurs :
        gris  = avant robot ;
        vert  = vecteur cible finalement envoyé au steering ;
        jaune = lumière agrégée ;
        cyan  = vecteur de voisins LiDAR ;
        rouge = vecteur obstacle TeraRanger.
    """

    def __init__(
        self,
        modules: AutoMoDeMercatorModules,
        *,
        root_path: str = "/World/DebugAutoMoDeModules",
        robot_debug_name: str = "Robot",
        vector_scale: float = 0.45,
        line_width: float = 0.018,
        z_offset: float = 0.16,
    ):
        self.modules = modules
        self.root_path = f"{root_path.rstrip('/')}/{_safe_usd_name(robot_debug_name)}"
        self.vector_scale = float(vector_scale)
        self.line_width = float(line_width)
        self.z_offset = float(z_offset)

        import omni.usd
        from pxr import Gf, UsdGeom

        self.Gf = Gf
        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.stage.DefinePrim(root_path.rstrip("/"), "Xform")
        self.stage.DefinePrim(self.root_path, "Xform")

    def clear(self) -> None:
        prim = self.stage.GetPrimAtPath(self.root_path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(self.root_path)
        self.stage.DefinePrim(self.root_path, "Xform")

    def _delete_if_exists(self, path: str) -> None:
        prim = self.stage.GetPrimAtPath(path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(path)

    def _set_display_color(self, prim, rgb: tuple[float, float, float], opacity: float = 1.0) -> None:
        gprim = self.UsdGeom.Gprim(prim)
        gprim.CreateDisplayColorAttr([self.Gf.Vec3f(float(rgb[0]), float(rgb[1]), float(rgb[2]))])
        gprim.CreateDisplayOpacityAttr([float(opacity)])

    def _draw_line(self, path: str, a: Iterable[float], b: Iterable[float], *, color: tuple[float, float, float], width: float | None = None, opacity: float = 1.0) -> None:
        self._delete_if_exists(path)
        a = np.asarray(a, dtype=np.float32)
        b = np.asarray(b, dtype=np.float32)
        curves = self.UsdGeom.BasisCurves.Define(self.stage, path)
        curves.CreateTypeAttr("linear")
        curves.CreateCurveVertexCountsAttr([2])
        curves.CreatePointsAttr([
            self.Gf.Vec3f(float(a[0]), float(a[1]), float(a[2])),
            self.Gf.Vec3f(float(b[0]), float(b[1]), float(b[2])),
        ])
        w = float(width if width is not None else self.line_width)
        # Hydra interprète souvent `widths` en interpolation vertex par défaut.
        # Une largeur par vertex évite le spam `widths primvar is not valid`.
        curves.CreateWidthsAttr([w, w])
        try:
            curves.SetWidthsInterpolation(self.UsdGeom.Tokens.vertex)
        except Exception:
            pass
        self._set_display_color(curves.GetPrim(), color, opacity=opacity)

    def _draw_sphere(self, path: str, position: Iterable[float], *, radius: float, color: tuple[float, float, float], opacity: float = 1.0) -> None:
        self._delete_if_exists(path)
        p = np.asarray(position, dtype=np.float32)
        sphere = self.UsdGeom.Sphere.Define(self.stage, path)
        sphere.CreateRadiusAttr(float(radius))
        xform = self.UsdGeom.Xformable(sphere.GetPrim())
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set(self.Gf.Vec3d(float(p[0]), float(p[1]), float(p[2])))
        self._set_display_color(sphere.GetPrim(), color, opacity=opacity)

    def _robot_pose_xy_yaw(self) -> tuple[np.ndarray, float]:
        robot = self.modules.controller.robot
        if robot is None or not robot.valid:
            return np.zeros(3, dtype=np.float32), 0.0
        positions, orientations = robot.get_world_poses()
        pos = positions.numpy()[0] if hasattr(positions, "numpy") else np.asarray(positions)[0]
        quat = orientations.numpy()[0] if hasattr(orientations, "numpy") else np.asarray(orientations)[0]
        return np.asarray(pos, dtype=np.float32), yaw_from_quat_wxyz(np.asarray(quat, dtype=np.float32))

    @staticmethod
    def _body_vec_to_world(yaw: float, vec_xy: Iterable[float], scale: float) -> np.ndarray:
        v = np.asarray(vec_xy, dtype=np.float32).reshape(2)
        norm = float(np.linalg.norm(v))
        if norm <= 1e-9:
            return np.zeros(3, dtype=np.float32)
        # On limite la longueur visuelle pour garder un debug lisible.
        length = min(1.0, norm) * float(scale)
        angle = math.atan2(float(v[1]), float(v[0])) + yaw
        return np.array([math.cos(angle) * length, math.sin(angle) * length, 0.0], dtype=np.float32)

    def _draw_vector(self, name: str, origin: np.ndarray, yaw: float, vec_xy: Iterable[float], color: tuple[float, float, float], *, scale: float | None = None, opacity: float = 1.0) -> None:
        delta = self._body_vec_to_world(yaw, vec_xy, self.vector_scale if scale is None else scale)
        if float(np.linalg.norm(delta)) <= 1e-9:
            self._delete_if_exists(f"{self.root_path}/{name}")
            self._delete_if_exists(f"{self.root_path}/{name}_tip")
            return
        end = origin + delta
        self._draw_line(f"{self.root_path}/{name}", origin, end, color=color, opacity=opacity)
        self._draw_sphere(f"{self.root_path}/{name}_tip", end, radius=self.line_width * 1.8, color=color, opacity=opacity)

    def update(self) -> None:
        self.stage.DefinePrim(self.root_path, "Xform")
        pos, yaw = self._robot_pose_xy_yaw()
        origin = pos.astype(np.float32, copy=True)
        origin[2] += self.z_offset

        info = self.modules.last_info

        self._draw_vector("forward", origin, yaw, (1.0, 0.0), (0.72, 0.72, 0.72), scale=self.vector_scale * 0.75, opacity=0.9)
        self._draw_vector("target_vector", origin, yaw, info.target_vector_xy, (0.0, 1.0, 0.1), scale=self.vector_scale, opacity=1.0)

        prox_vec = (info.proximity.x, info.proximity.y)
        self._draw_vector("proximity_vector", origin, yaw, prox_vec, (1.0, 0.0, 0.0), scale=self.vector_scale * 0.85, opacity=0.8)

        if info.light is not None:
            self._draw_vector("light_vector", origin, yaw, info.light.vector_xy, (1.0, 0.9, 0.0), scale=self.vector_scale * 0.9, opacity=0.9)
            # 8 petits rayons fixes montrant les valeurs sectorielles.
            for i, value in enumerate(info.light.values):
                angle = i * (2.0 * math.pi / max(1, len(info.light.values)))
                if angle > math.pi:
                    angle -= 2.0 * math.pi
                length = 0.08 + 0.22 * float(value)
                vec = (math.cos(angle) * length, math.sin(angle) * length)
                self._draw_vector(f"light_sector_{i}", origin, yaw, vec, (1.0, 0.75, 0.0), scale=1.0, opacity=0.45)
        else:
            for i in range(8):
                self._delete_if_exists(f"{self.root_path}/light_sector_{i}")
                self._delete_if_exists(f"{self.root_path}/light_sector_{i}_tip")
            self._delete_if_exists(f"{self.root_path}/light_vector")
            self._delete_if_exists(f"{self.root_path}/light_vector_tip")

        if info.neighbors is not None and info.neighbors.vector_norm > 1e-9:
            self._draw_vector("neighbors_vector", origin, yaw, info.neighbors.attraction_vector_xy, (0.0, 0.85, 1.0), scale=self.vector_scale, opacity=0.9)
        else:
            self._delete_if_exists(f"{self.root_path}/neighbors_vector")
            self._delete_if_exists(f"{self.root_path}/neighbors_vector_tip")
