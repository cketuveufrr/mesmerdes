"""AutoMoDe modules for the realistic Mercator USD model.

This file is the sensor/actuator adaptation layer between the realistic Isaac
implementation and the vectorized ``MercatorBehaviorModules`` implementation.
It intentionally keeps the realistic sensors (TeraRanger raycasts, RTX LiDAR
clustering and robot pose based light sensing), but exposes the same canonical
vectors and applies the same behavior equations, fallback rule, wheel mapping
and exploration timing.

Module IDs
----------
0: exploration
1: stop
2: phototaxis
3: anti-phototaxis
4: attraction
5: repulsion

Functional-equivalence scope
----------------------------
For the same canonical proximity, beacon and neighbor vectors, the realistic
and vectorized implementations produce the same wheel commands. Trajectories
can still differ because the two environments do not generate identical sensor
measurements, contacts, delays or noise.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Iterable, Sequence

import numpy as np

from controllers import DifferentialDriveController, yaw_from_quat_wxyz
from sensors import (
    DEFAULT_TERARANGER_NAMES,
    LidarNeighborDetector,
    LidarNeighborObservation,
    TeraRangerFrame,
)
from real_robot.runtime.reference_math import (
    canonical_target_vector,
    wheels_from_vector_np,
)
from .automode_exploration import (
    AutoMoDeExploration,
    ExplorationState,
    ProximityVector,
)


TAU = 2.0 * math.pi
_EPS = 1.0e-12


def wrap_to_pi(angle: float) -> float:
    return float((float(angle) + math.pi) % TAU - math.pi)


def _to_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "numpy"):
        return value.numpy()
    return np.asarray(value)


def compute_wheels_from_vector_np(
    dx: float,
    dy: float,
    max_speed: float,
) -> tuple[float, float]:
    """Compatibility wrapper around the shared Isaac-independent reference."""

    return wheels_from_vector_np(dx, dy, max_speed)


class AutoMoDeModuleID(IntEnum):
    EXPLORATION = 0
    STOP = 1
    PHOTOTAXIS = 2
    ANTI_PHOTOTAXIS = 3
    ATTRACTION = 4
    REPULSION = 5


MODULE_NAME_TO_ID: dict[str, AutoMoDeModuleID] = {
    "exploration": AutoMoDeModuleID.EXPLORATION,
    "stop": AutoMoDeModuleID.STOP,
    "phototaxis": AutoMoDeModuleID.PHOTOTAXIS,
    "photo": AutoMoDeModuleID.PHOTOTAXIS,
    "anti_phototaxis": AutoMoDeModuleID.ANTI_PHOTOTAXIS,
    "antiphototaxis": AutoMoDeModuleID.ANTI_PHOTOTAXIS,
    "anti-photo": AutoMoDeModuleID.ANTI_PHOTOTAXIS,
    "attraction": AutoMoDeModuleID.ATTRACTION,
    "repulsion": AutoMoDeModuleID.REPULSION,
}


def normalize_module_id(
    module: int | str | AutoMoDeModuleID,
) -> AutoMoDeModuleID:
    if isinstance(module, AutoMoDeModuleID):
        return module
    if isinstance(module, str):
        key = module.strip().lower().replace("-", "_").replace(" ", "_")
        if key not in MODULE_NAME_TO_ID:
            raise ValueError(
                f"Unknown module {module!r}; expected one of "
                f"{sorted(MODULE_NAME_TO_ID)}"
            )
        return MODULE_NAME_TO_ID[key]
    return AutoMoDeModuleID(int(module))


@dataclass(frozen=True)
class LightRingObservation:
    values: np.ndarray
    value: float
    angle: float
    vector_xy: np.ndarray
    distance: float
    light_position_xy: np.ndarray

    @property
    def dominant_sector(self) -> int:
        if self.values.size == 0:
            return -1
        return int(np.argmax(self.values))


class VirtualLightRingHelper:
    """Eight virtual light sectors around the realistic Mercator.

    Sector zero points forward. Positive angles rotate towards the robot's
    left. The raw observation keeps distance-dependent intensities for debug,
    while behavior modules convert the resulting vector to the DAO-compatible
    zero-or-unit beacon vector.
    """

    def __init__(
        self,
        robot_prim_path: str,
        *,
        light_position_xy: Sequence[float] = (0.0, -1.35),
        num_sensors: int = 8,
        max_distance: float = 12.0,
        angular_power: float = 1.0,
        distance_power: float = 1.0,
    ):
        self.robot_prim_path = robot_prim_path
        self.light_position_xy = np.asarray(
            light_position_xy, dtype=np.float32
        ).reshape(2)
        self.num_sensors = int(num_sensors)
        self.max_distance = float(max_distance)
        self.angular_power = float(angular_power)
        self.distance_power = float(distance_power)
        self._robot = None

        self._sector_angles = (
            np.arange(self.num_sensors, dtype=np.float32)
            * (TAU / self.num_sensors)
        )
        self._sector_angles = np.where(
            self._sector_angles > math.pi,
            self._sector_angles - TAU,
            self._sector_angles,
        )

    def start(self) -> None:
        from isaacsim.core.experimental.prims import RigidPrim

        self._robot = RigidPrim(paths=self.robot_prim_path)
        if not self._robot.valid:
            raise RuntimeError(
                "Invalid RigidPrim for VirtualLightRingHelper: "
                f"{self.robot_prim_path}"
            )

    def _robot_pose_xy_yaw(self) -> tuple[np.ndarray, float]:
        if self._robot is None or not self._robot.valid:
            return np.zeros(2, dtype=np.float32), 0.0
        positions, orientations = self._robot.get_world_poses()
        pos = _to_numpy(positions)[0]
        quat = _to_numpy(orientations)[0]
        return (
            np.asarray(pos[:2], dtype=np.float32),
            yaw_from_quat_wxyz(np.asarray(quat, dtype=np.float32)),
        )

    def read(self) -> LightRingObservation:
        pos_xy, yaw = self._robot_pose_xy_yaw()
        to_light_world = self.light_position_xy - pos_xy
        distance = float(np.linalg.norm(to_light_world))

        if distance <= _EPS or not math.isfinite(distance):
            angle = 0.0
        else:
            world_angle = math.atan2(
                float(to_light_world[1]), float(to_light_world[0])
            )
            angle = wrap_to_pi(world_angle - yaw)

        dist_gain = max(
            0.0,
            1.0
            - min(distance, self.max_distance)
            / max(self.max_distance, _EPS),
        )
        if self.distance_power != 1.0:
            dist_gain = dist_gain**self.distance_power

        values: list[float] = []
        for sector_angle in self._sector_angles:
            delta = wrap_to_pi(angle - float(sector_angle))
            angular_gain = max(0.0, math.cos(delta))
            if self.angular_power != 1.0:
                angular_gain = angular_gain**self.angular_power
            values.append(float(dist_gain * angular_gain))
        values_arr = np.asarray(values, dtype=np.float32)

        sx = float(
            np.sum(values_arr * np.cos(self._sector_angles))
        )
        sy = float(
            np.sum(values_arr * np.sin(self._sector_angles))
        )
        norm = math.hypot(sx, sy)
        if norm <= _EPS or not math.isfinite(norm):
            value = 0.0
            aggregate_angle = 0.0
            vector = np.zeros(2, dtype=np.float32)
        else:
            value = float(min(norm, 1.0))
            aggregate_angle = float(math.atan2(sy, sx))
            vector = np.asarray([sx, sy], dtype=np.float32)

        return LightRingObservation(
            values=values_arr,
            value=value,
            angle=aggregate_angle,
            vector_xy=vector,
            distance=distance,
            light_position_xy=self.light_position_xy.astype(
                np.float32, copy=True
            ),
        )


@dataclass
class AutoMoDeStepInfo:
    module: AutoMoDeModuleID
    left_speed: float
    right_speed: float
    target_vector_xy: np.ndarray = field(
        default_factory=lambda: np.zeros(2, dtype=np.float32)
    )
    target_label: str = ""
    proximity: ProximityVector = field(
        default_factory=lambda: ProximityVector(0.0, 0.0, 0.0, 0.0)
    )
    light: LightRingObservation | None = None
    neighbors: LidarNeighborObservation | None = None
    teraranger_frame: TeraRangerFrame | None = None


class AutoMoDeMercatorModules:
    """Execute the six AutoMoDe modules on one realistic Mercator robot.

    The constructor remains compatible with the previous implementation. The
    default constants now match the vectorized Mercator module implementation.
    """

    def __init__(
        self,
        *,
        robot_prim_path: str,
        teraranger_root_path: str,
        lidar_prim_path: str,
        light_position_xy: Sequence[float] = (0.0, -1.35),
        max_speed: float = 0.30,
        turn_speed: float | None = None,
        track_width: float = 0.147,
        proximity_threshold: float = 0.10,
        exploration_tau: int = 5,
        teraranger_max_range: float = 1.10,
        neighbor_min_range: float = 0.10,
        neighbor_max_range: float = 0.75,
        neighbor_alpha: float = 1.0,
        neighbor_cluster_distance_epsilon: float = 0.02,
        min_cluster_points: int = 5,
        neighbor_target_radius_m: float = 0.0,
        phototaxis_proximity_gain: float = 5.0,
        anti_phototaxis_proximity_gain: float = 5.0,
        attraction_proximity_gain: float = 6.0,
        repulsion_proximity_gain: float = 5.0,
        attraction_alpha_parameter: float = 5.0,
        repulsion_alpha_parameter: float = 5.0,
        fallback_vector_threshold: float = 0.10,
        proximity_noise_std: float = 0.0,
        light_noise_std: float = 0.0,
        sensor_names: Sequence[str] | None = DEFAULT_TERARANGER_NAMES,
        seed: int | None = None,
        debug: bool = False,
    ):
        if abs(float(neighbor_alpha)) <= _EPS:
            raise ValueError("neighbor_alpha must be non-zero")

        self.robot_prim_path = robot_prim_path.rstrip("/")
        self.teraranger_root_path = teraranger_root_path.rstrip("/")
        self.lidar_prim_path = lidar_prim_path.rstrip("/")

        self.max_speed = float(max_speed)
        self.turn_speed = float(
            self.max_speed if turn_speed is None else turn_speed
        )
        self.track_width = float(track_width)
        self.proximity_threshold = float(proximity_threshold)
        self.exploration_tau = max(int(exploration_tau), 0)

        self.phototaxis_proximity_gain = float(
            phototaxis_proximity_gain
        )
        self.anti_phototaxis_proximity_gain = float(
            anti_phototaxis_proximity_gain
        )
        self.attraction_proximity_gain = float(
            attraction_proximity_gain
        )
        self.repulsion_proximity_gain = float(
            repulsion_proximity_gain
        )
        self.attraction_alpha_parameter = float(
            attraction_alpha_parameter
        )
        self.repulsion_alpha_parameter = float(
            repulsion_alpha_parameter
        )
        self.fallback_vector_threshold = float(
            fallback_vector_threshold
        )
        self.debug = bool(debug)
        self.rng = random.Random(seed)
        self.noise_rng = np.random.default_rng(seed)
        self.proximity_noise_std = max(0.0, float(proximity_noise_std))
        self.light_noise_std = max(0.0, float(light_noise_std))

        # Reuse this object only as a realistic TeraRanger + differential-drive
        # hardware adapter. Its old exploration state machine is deliberately not
        # called; the equivalent state machine is implemented below.
        self.explorer = AutoMoDeExploration(
            robot_prim_path=self.robot_prim_path,
            teraranger_root_path=self.teraranger_root_path,
            forward_speed=self.max_speed,
            turn_speed=self.turn_speed,
            proximity_threshold=self.proximity_threshold,
            track_width=self.track_width,
            tau=self.exploration_tau,
            front_half_angle_deg=90.0,
            teraranger_max_range=float(teraranger_max_range),
            sensor_names=sensor_names,
            seed=seed,
            debug=debug,
        )
        self.controller: DifferentialDriveController = self.explorer.controller

        self.neighbor_detector = LidarNeighborDetector(
            self.lidar_prim_path,
            neighbor_min_range=float(neighbor_min_range),
            neighbor_max_range=float(neighbor_max_range),
            cluster_distance_epsilon=float(neighbor_cluster_distance_epsilon),
            min_cluster_points=int(min_cluster_points),
            target_radius_m=float(neighbor_target_radius_m),
            alpha=float(neighbor_alpha),
            verbose=debug,
        )
        self.light = VirtualLightRingHelper(
            self.robot_prim_path,
            light_position_xy=light_position_xy,
            num_sensors=8,
        )

        # Scalar counterpart of the vectorized exploration state.
        self.turn_steps_remaining = 0
        self.turn_sign = 0.0
        self.is_turning = False
        self.previous_module_id = -1

        self.last_info = AutoMoDeStepInfo(
            module=AutoMoDeModuleID.STOP,
            left_speed=0.0,
            right_speed=0.0,
        )
        self._sync_explorer_debug_state(command_was_turn=False)

    # ------------------------------------------------------------------
    # Lifecycle and state
    # ------------------------------------------------------------------

    def start(self) -> None:
        self.explorer.start()
        self.light.start()
        self.previous_module_id = -1
        self._reset_exploration_state()
        self.stop_motion()

    def stop(self) -> None:
        try:
            self.neighbor_detector.detach()
        except Exception:
            pass
        self.explorer.stop()

    def apply(self) -> None:
        self.controller.apply()

    def stop_motion(self) -> None:
        self.controller.set_speeds(0.0, 0.0)

    def _reset_exploration_state(self) -> None:
        self.turn_steps_remaining = 0
        self.turn_sign = 0.0
        self.is_turning = False
        self._sync_explorer_debug_state(command_was_turn=False)

    def _sync_explorer_debug_state(
        self,
        *,
        command_was_turn: bool,
    ) -> None:
        """Keep existing debug visualizers compatible with the new state."""

        self.explorer.turn_steps_remaining = int(
            self.turn_steps_remaining
        )
        self.explorer.turn_sign = int(self.turn_sign)
        self.explorer.current_state = (
            ExplorationState.TURN
            if self.is_turning
            else ExplorationState.FORWARD
        )
        if command_was_turn:
            self.explorer.last_turn_steps = max(
                int(self.explorer.last_turn_steps),
                int(self.turn_steps_remaining),
            )

    # ------------------------------------------------------------------
    # Canonical sensor adapters
    # ------------------------------------------------------------------

    def _read_proximity(
        self,
    ) -> tuple[TeraRangerFrame | None, ProximityVector]:
        try:
            frame = self.explorer.read_terarangers()
            prox = self.explorer.proximity_vector_from_frame(frame)
            if self.proximity_noise_std > 0.0:
                noisy_value = float(np.clip(
                    prox.value + self.noise_rng.normal(0.0, self.proximity_noise_std),
                    0.0,
                    1.0,
                ))
                prox = ProximityVector(
                    value=noisy_value,
                    angle=float(prox.angle),
                    x=noisy_value * math.cos(float(prox.angle)),
                    y=noisy_value * math.sin(float(prox.angle)),
                )
            self.explorer.last_proximity_vector = prox
            self.explorer.last_obstacle_detected = (
                self.explorer._is_obstacle_in_front(prox)
            )
            self.explorer.last_danger_angle = (
                prox.angle
                if self.explorer.last_obstacle_detected
                else None
            )
            return frame, prox
        except Exception as exc:
            if self.debug:
                print(
                    "[AutoMoDeMercatorModules] TeraRanger read failed: "
                    f"{exc}"
                )
            return None, ProximityVector(0.0, 0.0, 0.0, 0.0)

    @staticmethod
    def _dao_proximity_vector(
        prox: ProximityVector,
    ) -> np.ndarray:
        """RM 1.2 aggregate proximity vector with norm capped at one."""

        value = float(np.clip(prox.value, 0.0, 1.0))
        return np.asarray(
            [
                value * math.cos(float(prox.angle)),
                value * math.sin(float(prox.angle)),
            ],
            dtype=np.float64,
        )


    def _read_light(self) -> LightRingObservation:
        light = self.light.read()
        if self.light_noise_std <= 0.0:
            return light
        values = np.clip(
            np.asarray(light.values, dtype=np.float32)
            + self.noise_rng.normal(0.0, self.light_noise_std, size=light.values.shape),
            0.0,
            1.0,
        ).astype(np.float32)
        sectors = self.light._sector_angles
        sx = float(np.sum(values * np.cos(sectors)))
        sy = float(np.sum(values * np.sin(sectors)))
        norm = math.hypot(sx, sy)
        if norm <= _EPS or not math.isfinite(norm):
            value, angle = 0.0, 0.0
            vector = np.zeros(2, dtype=np.float32)
        else:
            value = float(min(norm, 1.0))
            angle = float(math.atan2(sy, sx))
            vector = np.asarray([sx, sy], dtype=np.float32)
        return LightRingObservation(
            values=values,
            value=value,
            angle=angle,
            vector_xy=vector,
            distance=float(light.distance),
            light_position_xy=np.asarray(light.light_position_xy, dtype=np.float32),
        )

    @staticmethod
    def _dao_beacon_vector(
        light: LightRingObservation,
    ) -> np.ndarray:
        """DAO-compatible beacon vector: zero if absent, unit if detected."""

        vector = np.asarray(light.vector_xy, dtype=np.float64).reshape(2)
        norm = float(np.linalg.norm(vector))
        if norm <= _EPS or not math.isfinite(norm):
            return np.zeros(2, dtype=np.float64)
        return vector / norm

    @staticmethod
    def _dao_neighbor_vector(
        neighbors: LidarNeighborObservation,
        alpha: float,
    ) -> np.ndarray:
        """Rescale LiDAR output to vectorized ``alpha / (1 + distance_cm)`` semantics."""

        detector_alpha = float(neighbors.alpha)
        if abs(detector_alpha) <= _EPS:
            raise ValueError("LidarNeighborObservation.alpha must be non-zero")
        base = np.asarray(
            neighbors.attraction_vector_xy, dtype=np.float64
        ).reshape(2)
        return base * (float(alpha) / detector_alpha)

    def _with_forward_fallback(
        self,
        vector: Iterable[float],
    ) -> np.ndarray:
        result = np.asarray(vector, dtype=np.float64).reshape(2)
        norm = float(np.linalg.norm(result))
        if not math.isfinite(norm) or norm < self.fallback_vector_threshold:
            return np.asarray([1.0, 0.0], dtype=np.float64)
        return result

    # ------------------------------------------------------------------
    # Output and exploration
    # ------------------------------------------------------------------

    def _set_and_store(
        self,
        module: AutoMoDeModuleID,
        left: float,
        right: float,
        *,
        target_vector_xy: Iterable[float] = (0.0, 0.0),
        target_label: str = "",
        proximity: ProximityVector | None = None,
        light: LightRingObservation | None = None,
        neighbors: LidarNeighborObservation | None = None,
        teraranger_frame: TeraRangerFrame | None = None,
    ) -> AutoMoDeStepInfo:
        left = float(np.clip(left, -self.max_speed, self.max_speed))
        right = float(np.clip(right, -self.max_speed, self.max_speed))
        self.controller.set_speeds(left, right)

        info = AutoMoDeStepInfo(
            module=module,
            left_speed=left,
            right_speed=right,
            target_vector_xy=np.asarray(
                target_vector_xy, dtype=np.float32
            ).reshape(2),
            target_label=target_label,
            proximity=(
                proximity
                if proximity is not None
                else ProximityVector(0.0, 0.0, 0.0, 0.0)
            ),
            light=light,
            neighbors=neighbors,
            teraranger_frame=teraranger_frame,
        )
        self.last_info = info
        return info

    def _exploration_step(self) -> AutoMoDeStepInfo:
        """Scalar port of vectorized AutoMoDe exploration timing."""

        entering = self.previous_module_id != int(
            AutoMoDeModuleID.EXPLORATION
        )
        if entering:
            self._reset_exploration_state()

        self.explorer.total_steps += 1
        was_turning = bool(self.is_turning)

        if was_turning:
            # Match vectorized implementation: decrement first, command the
            # rotation for this tick, then mark the maneuver finished.
            self.turn_steps_remaining -= 1
            left = -self.turn_sign * self.turn_speed
            right = self.turn_sign * self.turn_speed

            if self.turn_steps_remaining <= 0:
                self.is_turning = False
                self.turn_sign = 0.0

            self._sync_explorer_debug_state(command_was_turn=True)
            prox = self.explorer.last_proximity_vector
            return self._set_and_store(
                AutoMoDeModuleID.EXPLORATION,
                left,
                right,
                target_vector_xy=(
                    math.cos(float(prox.angle)) * float(prox.value),
                    math.sin(float(prox.angle)) * float(prox.value),
                ),
                target_label="exploration/TURN",
                proximity=prox,
                teraranger_frame=self.explorer.last_frame,
            )

        frame, prox = self._read_proximity()
        obstacle_in_front = (
            prox.value >= self.proximity_threshold
            and -math.pi / 2.0 <= prox.angle <= math.pi / 2.0
        )

        if obstacle_in_front:
            # Python randint is inclusive at both ends, matching torch.randint
            # with high=tau+1 in the vectorized implementation.
            sampled_steps = self.rng.randint(0, self.exploration_tau)
            self.turn_steps_remaining = int(sampled_steps)
            self.explorer.last_turn_steps = int(sampled_steps)

            # Exact vectorized/DAO rule:
            # angle < 0  -> LEFT  (-v,+v)
            # otherwise  -> RIGHT (+v,-v)
            self.turn_sign = 1.0 if prox.angle < 0.0 else -1.0
            self.is_turning = True

        # On the obstacle-detection tick the command remains forward. A sampled
        # duration of zero still results in one rotation tick on the next call.
        self._sync_explorer_debug_state(command_was_turn=False)
        return self._set_and_store(
            AutoMoDeModuleID.EXPLORATION,
            self.max_speed,
            self.max_speed,
            target_vector_xy=(
                math.cos(float(prox.angle)) * float(prox.value),
                math.sin(float(prox.angle)) * float(prox.value),
            ),
            target_label="exploration/FORWARD",
            proximity=prox,
            teraranger_frame=frame,
        )

    # ------------------------------------------------------------------
    # Public behavior computation
    # ------------------------------------------------------------------

    def update(
        self,
        module: int | str | AutoMoDeModuleID,
        *,
        neighbors: LidarNeighborObservation | None = None,
    ) -> AutoMoDeStepInfo:
        module_id = normalize_module_id(module)

        if module_id == AutoMoDeModuleID.EXPLORATION:
            result = self._exploration_step()
            self.previous_module_id = int(module_id)
            return result

        frame, prox = self._read_proximity()
        proximity = self._dao_proximity_vector(prox)

        if module_id == AutoMoDeModuleID.STOP:
            result = self._set_and_store(
                module_id,
                0.0,
                0.0,
                target_label="stop",
                proximity=prox,
                teraranger_frame=frame,
            )
            self.previous_module_id = int(module_id)
            return result

        if module_id == AutoMoDeModuleID.PHOTOTAXIS:
            light = self._read_light()
            beacon = self._dao_beacon_vector(light)
            target = canonical_target_vector(
                int(module_id),
                proximity_xy=proximity,
                beacon_unit_xy=beacon,
                neighbor_base_xy=(0.0, 0.0),
                phototaxis_proximity_gain=self.phototaxis_proximity_gain,
                anti_phototaxis_proximity_gain=self.anti_phototaxis_proximity_gain,
                attraction_proximity_gain=self.attraction_proximity_gain,
                repulsion_proximity_gain=self.repulsion_proximity_gain,
                attraction_alpha=self.attraction_alpha_parameter,
                repulsion_alpha=self.repulsion_alpha_parameter,
                fallback_threshold=self.fallback_vector_threshold,
            )
            left, right = compute_wheels_from_vector_np(
                target[0], target[1], self.max_speed
            )
            result = self._set_and_store(
                module_id,
                left,
                right,
                target_vector_xy=target,
                target_label=(
                    "unit_beacon - "
                    f"{self.phototaxis_proximity_gain:g}*proximity"
                ),
                proximity=prox,
                light=light,
                teraranger_frame=frame,
            )
            self.previous_module_id = int(module_id)
            return result

        if module_id == AutoMoDeModuleID.ANTI_PHOTOTAXIS:
            light = self._read_light()
            beacon = self._dao_beacon_vector(light)
            target = canonical_target_vector(
                int(module_id),
                proximity_xy=proximity,
                beacon_unit_xy=beacon,
                neighbor_base_xy=(0.0, 0.0),
                phototaxis_proximity_gain=self.phototaxis_proximity_gain,
                anti_phototaxis_proximity_gain=self.anti_phototaxis_proximity_gain,
                attraction_proximity_gain=self.attraction_proximity_gain,
                repulsion_proximity_gain=self.repulsion_proximity_gain,
                attraction_alpha=self.attraction_alpha_parameter,
                repulsion_alpha=self.repulsion_alpha_parameter,
                fallback_threshold=self.fallback_vector_threshold,
            )
            left, right = compute_wheels_from_vector_np(
                target[0], target[1], self.max_speed
            )
            result = self._set_and_store(
                module_id,
                left,
                right,
                target_vector_xy=target,
                target_label=(
                    "-unit_beacon - "
                    f"{self.anti_phototaxis_proximity_gain:g}*proximity"
                ),
                proximity=prox,
                light=light,
                teraranger_frame=frame,
            )
            self.previous_module_id = int(module_id)
            return result

        if module_id == AutoMoDeModuleID.ATTRACTION:
            neighbors = neighbors if neighbors is not None else self.neighbor_detector.read()
            neighbor_base = self._dao_neighbor_vector(neighbors, 1.0)
            target = canonical_target_vector(
                int(module_id),
                proximity_xy=proximity,
                beacon_unit_xy=(0.0, 0.0),
                neighbor_base_xy=neighbor_base,
                phototaxis_proximity_gain=self.phototaxis_proximity_gain,
                anti_phototaxis_proximity_gain=self.anti_phototaxis_proximity_gain,
                attraction_proximity_gain=self.attraction_proximity_gain,
                repulsion_proximity_gain=self.repulsion_proximity_gain,
                attraction_alpha=self.attraction_alpha_parameter,
                repulsion_alpha=self.repulsion_alpha_parameter,
                fallback_threshold=self.fallback_vector_threshold,
            )
            left, right = compute_wheels_from_vector_np(
                target[0], target[1], self.max_speed
            )
            result = self._set_and_store(
                module_id,
                left,
                right,
                target_vector_xy=target,
                target_label=(
                    f"neighbors(alpha={self.attraction_alpha_parameter:g}) "
                    f"- {self.attraction_proximity_gain:g}*proximity"
                ),
                proximity=prox,
                neighbors=neighbors,
                teraranger_frame=frame,
            )
            self.previous_module_id = int(module_id)
            return result

        if module_id == AutoMoDeModuleID.REPULSION:
            neighbors = neighbors if neighbors is not None else self.neighbor_detector.read()
            neighbor_base = self._dao_neighbor_vector(neighbors, 1.0)
            target = canonical_target_vector(
                int(module_id),
                proximity_xy=proximity,
                beacon_unit_xy=(0.0, 0.0),
                neighbor_base_xy=neighbor_base,
                phototaxis_proximity_gain=self.phototaxis_proximity_gain,
                anti_phototaxis_proximity_gain=self.anti_phototaxis_proximity_gain,
                attraction_proximity_gain=self.attraction_proximity_gain,
                repulsion_proximity_gain=self.repulsion_proximity_gain,
                attraction_alpha=self.attraction_alpha_parameter,
                repulsion_alpha=self.repulsion_alpha_parameter,
                fallback_threshold=self.fallback_vector_threshold,
            )
            left, right = compute_wheels_from_vector_np(
                target[0], target[1], self.max_speed
            )
            result = self._set_and_store(
                module_id,
                left,
                right,
                target_vector_xy=target,
                target_label=(
                    f"-{self.repulsion_alpha_parameter:g}*"
                    f"neighbors(alpha={self.repulsion_alpha_parameter:g}) "
                    f"- {self.repulsion_proximity_gain:g}*proximity"
                ),
                proximity=prox,
                neighbors=neighbors,
                teraranger_frame=frame,
            )
            self.previous_module_id = int(module_id)
            return result

        raise ValueError(f"Unsupported module: {module!r}")

    def get_state_info(self) -> dict[str, Any]:
        info = self.last_info
        light_values = (
            info.light.values.tolist()
            if info.light is not None
            else []
        )
        target_norm = float(np.linalg.norm(info.target_vector_xy))

        return {
            "module": info.module.name.lower(),
            "module_id": int(info.module),
            "left_speed": float(info.left_speed),
            "right_speed": float(info.right_speed),
            "target_label": info.target_label,
            "target_vector_xy": tuple(
                float(v) for v in info.target_vector_xy
            ),
            "target_norm": target_norm,
            "target_angle_deg": (
                math.degrees(
                    math.atan2(
                        float(info.target_vector_xy[1]),
                        float(info.target_vector_xy[0]),
                    )
                )
                if target_norm > _EPS
                else 0.0
            ),
            "proximity_value": float(info.proximity.value),
            "proximity_angle_deg": math.degrees(
                float(info.proximity.angle)
            ),
            "light_value": (
                float(info.light.value)
                if info.light is not None
                else 0.0
            ),
            "light_angle_deg": (
                math.degrees(float(info.light.angle))
                if info.light is not None
                else 0.0
            ),
            "light_sector_values": light_values,
            "light_dominant_sector": (
                info.light.dominant_sector
                if info.light is not None
                else -1
            ),
            "neighbors_count": (
                info.neighbors.neighbors_count
                if info.neighbors is not None
                else 0
            ),
            "neighbors_vector_norm": (
                info.neighbors.vector_norm
                if info.neighbors is not None
                else 0.0
            ),
            "neighbors_vector_angle_deg": (
                math.degrees(info.neighbors.vector_angle)
                if info.neighbors is not None
                else 0.0
            ),
            "exploration_is_turning": bool(self.is_turning),
            "exploration_turn_sign": float(self.turn_sign),
            "exploration_turn_steps_remaining": int(
                self.turn_steps_remaining
            ),
            "exploration_tau": int(self.exploration_tau),
            "phototaxis_proximity_gain": float(
                self.phototaxis_proximity_gain
            ),
            "anti_phototaxis_proximity_gain": float(
                self.anti_phototaxis_proximity_gain
            ),
            "attraction_alpha_parameter": float(
                self.attraction_alpha_parameter
            ),
            "attraction_proximity_gain": float(
                self.attraction_proximity_gain
            ),
            "repulsion_alpha_parameter": float(
                self.repulsion_alpha_parameter
            ),
            "repulsion_proximity_gain": float(
                self.repulsion_proximity_gain
            ),
            "fallback_vector_threshold": float(
                self.fallback_vector_threshold
            ),
        }