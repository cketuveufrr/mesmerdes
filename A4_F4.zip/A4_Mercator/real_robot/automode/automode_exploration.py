"""Module AutoMoDe ``exploration`` branché sur les TeraRangers.

Le comportement reproduit l'idée du module exploration / randomwalk d'AutoMoDe :
le robot avance en ligne droite tant qu'aucun obstacle n'est perçu dans son demi-plan
avant ; dès qu'un obstacle est vu, il tourne sur place pendant un nombre aléatoire de
steps, puis reprend l'avance.

Différence importante avec l'ancienne version de ce dépôt : la perception d'obstacle ne
vient plus du RTX LiDAR. Elle vient de la ceinture TeraRanger, qui est le capteur court
terme prévu pour l'évitement local sur Mercator.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional, Sequence, Tuple

import numpy as np

from controllers import DifferentialDriveController, yaw_from_quat_wxyz
from sensors import DEFAULT_TERARANGER_NAMES, TeraRangerArrayHelper, TeraRangerFrame


class ExplorationState(Enum):
    FORWARD = 1
    TURN = 2


@dataclass(frozen=True)
class ProximityVector:
    """Vecteur obstacle reconstruit depuis les proximités.

    Convention du repère robot :
        +x = avant du robot
        +y = gauche du robot

    ``value`` est bornée dans [0, 1], comme dans l'esprit du reference model :
        0 = rien de significatif
        1 = obstacle fort / proche

    ``angle`` pointe vers l'obstacle, pas vers l'échappatoire.
    """

    value: float
    angle: float
    x: float
    y: float


class AutoMoDeExploration:
    def __init__(
        self,
        robot_prim_path: str,
        teraranger_root_path: str | None = None,
        *,
        # Compatibilité avec l'ancien code : si quelqu'un passe encore
        # ``lidar_prim_path=...``, on l'utilise comme chemin TeraRanger si
        # ``teraranger_root_path`` n'est pas fourni. Le nom reste accepté pour
        # éviter de casser les anciens scripts, mais le module n'utilise plus le
        # LiDAR.
        lidar_prim_path: str | None = None,
        forward_speed: float = 0.25,
        turn_speed: float = 0.25,
        proximity_threshold: float = 0.10,
        track_width: float = 0.147,
        tau: int = 10,
        control_dt: float = 0.1,
        front_half_angle_deg: float = 90.0,
        teraranger_min_range: float = 0.02,
        teraranger_max_range: float = 1.10,
        sensor_names: Sequence[str] | None = DEFAULT_TERARANGER_NAMES,
        ignore_self_hits: bool = True,
        seed: int | None = None,
        debug: bool = False,
    ):
        self.robot_prim_path = robot_prim_path.rstrip("/")
        self.teraranger_root_path = (teraranger_root_path or lidar_prim_path or "").rstrip("/")
        if not self.teraranger_root_path:
            raise ValueError(
                "AutoMoDeExploration demande maintenant `teraranger_root_path`. "
                "Exemple : TeraRangerArrayHelper.root_path_for_robot('Robot1')."
            )

        self.forward_speed = float(forward_speed)
        self.turn_speed = float(turn_speed)
        self.track_width = float(track_width)
        self.proximity_threshold = float(proximity_threshold)
        self.front_half_angle = math.radians(float(front_half_angle_deg))
        self.teraranger_min_range = float(teraranger_min_range)
        self.teraranger_max_range = float(teraranger_max_range)
        self.tau = int(tau)
        self.control_dt = float(control_dt)
        self.debug = bool(debug)
        self.rng = random.Random(seed)

        robot_root_for_self_filter = self._infer_robot_reference_root(self.robot_prim_path)
        self.terarangers = TeraRangerArrayHelper(
            self.teraranger_root_path,
            robot_root_path=robot_root_for_self_filter,
            sensor_names=sensor_names,
            min_range=self.teraranger_min_range,
            max_range=self.teraranger_max_range,
            ignore_self_hits=ignore_self_hits,
            verbose=debug,
        )
        self.controller = DifferentialDriveController(self.robot_prim_path, track_width=self.track_width)

        self.current_state = ExplorationState.FORWARD
        self.turn_sign = 0
        self.turn_steps_remaining = 0
        self.total_steps = 0
        self.last_turn_steps = 0

        self.last_frame: TeraRangerFrame | None = None
        self.last_proximity_vector = ProximityVector(value=0.0, angle=0.0, x=0.0, y=0.0)
        self.last_obstacle_detected = False
        self.last_danger_angle: float | None = None
        self.last_min_distance = self.teraranger_max_range
        self.last_max_proximity = 0.0
        self.last_dominant_sensor: str | None = None

    @staticmethod
    def root_path_for_robot(robot_name: str) -> str:
        return TeraRangerArrayHelper.root_path_for_robot(robot_name)

    @staticmethod
    def body_path_for_robot(robot_name: str) -> str:
        return TeraRangerArrayHelper.body_path_for_robot(robot_name)

    @staticmethod
    def _infer_robot_reference_root(robot_prim_path: str) -> str:
        """Retourne le root à ignorer pour les self-hits PhysX.

        Le RigidPrim est généralement ``/World/RobotX/MercatorLite``. Pour filtrer
        toutes les collisions internes, il faut ignorer ``/World/RobotX`` plutôt
        que seulement le body.
        """
        parts = robot_prim_path.rstrip("/").split("/")
        if len(parts) >= 3 and parts[1] == "World":
            return "/".join(parts[:3])
        return robot_prim_path.rstrip("/")

    def start(self) -> None:
        self.controller.start()
        self.controller.set_speeds(0.0, 0.0)

    def stop(self) -> None:
        self.controller.stop()

    def apply(self) -> None:
        self.controller.apply()

    def read_terarangers(self) -> TeraRangerFrame:
        frame = self.terarangers.read()
        self.last_frame = frame
        if len(frame.distances) > 0:
            self.last_min_distance = float(np.min(frame.distances))
            self.last_max_proximity = float(np.max(frame.proximities))
            max_idx = int(np.argmax(frame.proximities))
            self.last_dominant_sensor = str(frame.names[max_idx]) if self.last_max_proximity > 0.0 else None
        else:
            self.last_min_distance = self.teraranger_max_range
            self.last_max_proximity = 0.0
            self.last_dominant_sensor = None
        return frame

    def get_teraranger_observation(self, *, mode: str = "proximity") -> np.ndarray:
        """Observation brute utilisable par un futur policy / logger."""
        return self.terarangers.get_observation(mode=mode)

    def _robot_yaw(self) -> float:
        robot = self.controller.robot
        if robot is None or not robot.valid:
            return 0.0
        _, orientations = robot.get_world_poses()
        quat = orientations.numpy()[0] if hasattr(orientations, "numpy") else np.asarray(orientations)[0]
        return yaw_from_quat_wxyz(np.asarray(quat, dtype=np.float32))

    @staticmethod
    def _angle_from_world_direction_in_robot_frame(direction_world_xy: np.ndarray, robot_yaw: float) -> float:
        direction_world_xy = np.asarray(direction_world_xy, dtype=np.float32)
        norm = float(np.linalg.norm(direction_world_xy))
        if norm <= 1e-9 or not np.isfinite(norm):
            return 0.0
        d = direction_world_xy / norm
        forward = np.array([math.cos(robot_yaw), math.sin(robot_yaw)], dtype=np.float32)
        left = np.array([-math.sin(robot_yaw), math.cos(robot_yaw)], dtype=np.float32)
        x_body = float(np.dot(d, forward))
        y_body = float(np.dot(d, left))
        return math.atan2(y_body, x_body)

    def proximity_vector_from_frame(self, frame: TeraRangerFrame) -> ProximityVector:
        """Agrège les 8 TeraRangers en un vecteur obstacle.

        On n'assume pas une disposition circulaire parfaite. Pour chaque capteur,
        on utilise sa vraie direction USD lue par le helper, puis on reprojette cette
        direction dans le repère du robot au moment courant.
        """
        robot_yaw = self._robot_yaw()
        sx = 0.0
        sy = 0.0
        for reading in frame.readings:
            p = float(reading.proximity)
            if p <= 0.0:
                continue
            direction_xy = np.asarray([reading.direction[0], reading.direction[1]], dtype=np.float32)
            angle = self._angle_from_world_direction_in_robot_frame(direction_xy, robot_yaw)
            sx += p * math.cos(angle)
            sy += p * math.sin(angle)

        raw_norm = math.hypot(sx, sy)
        if raw_norm <= 1e-9 or not np.isfinite(raw_norm):
            return ProximityVector(value=0.0, angle=0.0, x=0.0, y=0.0)
        value = float(min(raw_norm, 1.0))
        angle = float(math.atan2(sy, sx))
        return ProximityVector(value=value, angle=angle, x=float(sx), y=float(sy))

    def _is_obstacle_in_front(self, prox: ProximityVector) -> bool:
        return prox.value >= self.proximity_threshold and abs(prox.angle) <= self.front_half_angle

    def _danger_from_terarangers(self) -> Tuple[bool, Optional[float]]:
        try:
            frame = self.read_terarangers()
        except Exception as exc:
            if self.debug:
                print(f"[AutoMoDeExploration] lecture TeraRanger échouée: {exc}")
            self.last_frame = None
            self.last_proximity_vector = ProximityVector(value=0.0, angle=0.0, x=0.0, y=0.0)
            self.last_obstacle_detected = False
            self.last_danger_angle = None
            return False, None

        prox = self.proximity_vector_from_frame(frame)
        self.last_proximity_vector = prox
        detected = self._is_obstacle_in_front(prox)
        self.last_obstacle_detected = detected
        self.last_danger_angle = prox.angle if detected else None
        return detected, self.last_danger_angle

    def _sample_turn_steps(self) -> int:
        return self.rng.randint(0, max(0, self.tau))

    def _apply_forward_motion(self) -> None:
        self.controller.set_speeds(self.forward_speed, self.forward_speed)

    def _apply_turn_motion(self) -> None:
        if self.turn_sign > 0:
            # omega positif : rotation gauche.
            self.controller.set_speeds(-self.turn_speed, self.turn_speed)
        elif self.turn_sign < 0:
            # omega négatif : rotation droite.
            self.controller.set_speeds(self.turn_speed, -self.turn_speed)
        else:
            self.controller.set_speeds(0.0, 0.0)

    def update(self) -> None:
        self.total_steps += 1

        if self.current_state == ExplorationState.FORWARD:
            obstacle_detected, danger_angle = self._danger_from_terarangers()
            if not obstacle_detected:
                self._apply_forward_motion()
                return

            # L'angle pointe vers l'obstacle. Obstacle à gauche => tourner à droite,
            # obstacle à droite => tourner à gauche. Si pile devant, on choisit au hasard.
            if danger_angle is None or abs(danger_angle) < 1e-6:
                self.turn_sign = self.rng.choice([-1, +1])
            elif danger_angle > 0.0:
                self.turn_sign = -1
            else:
                self.turn_sign = +1

            self.turn_steps_remaining = self._sample_turn_steps()
            self.last_turn_steps = self.turn_steps_remaining
            if self.turn_steps_remaining <= 0:
                self._apply_forward_motion()
                return

            self.current_state = ExplorationState.TURN
            self._apply_turn_motion()
            return

        if self.current_state == ExplorationState.TURN:
            # Pendant la rotation on garde le comportement AutoMoDe classique : on
            # n'interrompt pas la manoeuvre avec une nouvelle lecture capteur.
            self.turn_steps_remaining -= 1
            if self.turn_steps_remaining <= 0:
                self.current_state = ExplorationState.FORWARD
                self.turn_sign = 0
                self._apply_forward_motion()
                return
            self._apply_turn_motion()

    def get_state_info(self) -> Dict[str, object]:
        frame = self.last_frame
        named_proximities = frame.as_named_proximities() if frame is not None else {}
        named_distances = frame.as_named_distances() if frame is not None else {}
        return {
            "state": self.current_state.name,
            "turn_sign": self.turn_sign,
            "turn_steps_remaining": self.turn_steps_remaining,
            "last_turn_steps": self.last_turn_steps,
            "total_steps": self.total_steps,
            "obstacle_detected": self.last_obstacle_detected,
            "proximity_value": self.last_proximity_vector.value,
            "proximity_angle_rad": self.last_proximity_vector.angle,
            "proximity_angle_deg": math.degrees(self.last_proximity_vector.angle),
            "proximity_vector_xy": (self.last_proximity_vector.x, self.last_proximity_vector.y),
            "last_danger_angle": self.last_danger_angle,
            "min_teraranger_distance": self.last_min_distance,
            "max_teraranger_proximity": self.last_max_proximity,
            "dominant_teraranger": self.last_dominant_sensor,
            "teraranger_names": tuple(self.terarangers.names),
            "named_proximities": named_proximities,
            "named_distances": named_distances,
        }
