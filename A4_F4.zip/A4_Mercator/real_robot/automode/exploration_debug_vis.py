"""Visualisation USD du module exploration AutoMoDe/TeraRanger."""

from __future__ import annotations

import math
import re
from typing import Iterable

import numpy as np

from controllers import yaw_from_quat_wxyz
from .automode_exploration import AutoMoDeExploration


def _safe_usd_name(name: str) -> str:
    out = re.sub(r"[^A-Za-z0-9_]", "_", str(name))
    return out if out else "robot"


class ExplorationDebugVisualizer:
    """
    Dessine trois informations qui ne sont pas visibles dans les rayons bruts :

    - vecteur avant du robot ;
    - vecteur obstacle agrégé reconstruit depuis les TeraRangers ;
    - limites du demi-plan avant utilisé pour décider ``obstacle devant``.

    Les rayons TeraRanger eux-mêmes restent dessinés par ``TeraRangerDebugVisualizer``.
    """

    def __init__(
        self,
        explorer: AutoMoDeExploration,
        *,
        root_path: str = "/World/DebugAutoMoDeExploration",
        robot_debug_name: str | None = None,
        vector_length: float = 0.45,
        line_width: float = 0.018,
        z_offset: float = 0.08,
    ):
        self.explorer = explorer
        robot_debug_name = robot_debug_name or explorer.robot_prim_path.strip("/").replace("/", "_")
        self.root_path = f"{root_path.rstrip('/')}/{_safe_usd_name(robot_debug_name)}"
        self.vector_length = float(vector_length)
        self.line_width = float(line_width)
        self.z_offset = float(z_offset)

        import omni.usd
        from pxr import Gf, UsdGeom

        self.Gf = Gf
        self.UsdGeom = UsdGeom
        self.stage = omni.usd.get_context().get_stage()
        self.stage.DefinePrim(root_path.rstrip("/"), "Xform")
        self.stage.DefinePrim(self.root_path, "Xform")

    def clear(self) -> None:
        prim = self.stage.GetPrimAtPath(self.root_path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(self.root_path)

    def _delete_if_exists(self, path: str) -> None:
        prim = self.stage.GetPrimAtPath(path)
        if prim and prim.IsValid():
            self.stage.RemovePrim(path)

    def _set_display_color(self, prim, rgb: tuple[float, float, float], opacity: float = 1.0) -> None:
        gprim = self.UsdGeom.Gprim(prim)
        gprim.CreateDisplayColorAttr([self.Gf.Vec3f(float(rgb[0]), float(rgb[1]), float(rgb[2]))])
        gprim.CreateDisplayOpacityAttr([float(opacity)])

    def _draw_line(self, path: str, a: Iterable[float], b: Iterable[float], *, color: tuple[float, float, float], width: float | None = None) -> None:
        self._delete_if_exists(path)
        a = np.asarray(a, dtype=np.float32)
        b = np.asarray(b, dtype=np.float32)
        curves = self.UsdGeom.BasisCurves.Define(self.stage, path)
        curves.CreateTypeAttr("linear")
        curves.CreateCurveVertexCountsAttr([2])
        curves.CreatePointsAttr([
            self.Gf.Vec3f(float(a[0]), float(a[1]), float(a[2])),
            self.Gf.Vec3f(float(b[0]), float(b[1]), float(b[2])),
        ])
        w = float(width if width is not None else self.line_width)
        # Une largeur par vertex évite les warnings Hydra sur les BasisCurves.
        curves.CreateWidthsAttr([w, w])
        try:
            curves.SetWidthsInterpolation(self.UsdGeom.Tokens.vertex)
        except Exception:
            pass
        self._set_display_color(curves.GetPrim(), color)

    def _draw_sphere(self, path: str, position: Iterable[float], *, radius: float, color: tuple[float, float, float]) -> None:
        self._delete_if_exists(path)
        p = np.asarray(position, dtype=np.float32)
        sphere = self.UsdGeom.Sphere.Define(self.stage, path)
        sphere.CreateRadiusAttr(float(radius))
        xform = self.UsdGeom.Xformable(sphere.GetPrim())
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set(self.Gf.Vec3d(float(p[0]), float(p[1]), float(p[2])))
        self._set_display_color(sphere.GetPrim(), color)

    @staticmethod
    def _yaw_to_world_vector(yaw: float, angle_in_robot_frame: float, length: float) -> np.ndarray:
        a = yaw + angle_in_robot_frame
        return np.array([math.cos(a) * length, math.sin(a) * length, 0.0], dtype=np.float32)

    def _robot_pose_xy_yaw(self) -> tuple[np.ndarray, float]:
        robot = self.explorer.controller.robot
        if robot is None or not robot.valid:
            return np.zeros(3, dtype=np.float32), 0.0
        positions, orientations = robot.get_world_poses()
        pos = positions.numpy()[0] if hasattr(positions, "numpy") else np.asarray(positions)[0]
        quat = orientations.numpy()[0] if hasattr(orientations, "numpy") else np.asarray(orientations)[0]
        return np.asarray(pos, dtype=np.float32), yaw_from_quat_wxyz(np.asarray(quat, dtype=np.float32))

    def update(self) -> None:
        self.stage.DefinePrim(self.root_path, "Xform")
        pos, yaw = self._robot_pose_xy_yaw()
        origin = pos.astype(np.float32, copy=True)
        origin[2] += self.z_offset

        # Avant robot : gris clair.
        forward_end = origin + self._yaw_to_world_vector(yaw, 0.0, self.vector_length)
        self._draw_line(f"{self.root_path}/robot_forward", origin, forward_end, color=(0.75, 0.75, 0.75), width=self.line_width * 0.75)

        # Cône/demi-plan utilisé pour l'obstacle devant : orange.
        left_bound = origin + self._yaw_to_world_vector(yaw, self.explorer.front_half_angle, self.vector_length * 0.85)
        right_bound = origin + self._yaw_to_world_vector(yaw, -self.explorer.front_half_angle, self.vector_length * 0.85)
        self._draw_line(f"{self.root_path}/front_limit_left", origin, left_bound, color=(1.0, 0.65, 0.05), width=self.line_width * 0.5)
        self._draw_line(f"{self.root_path}/front_limit_right", origin, right_bound, color=(1.0, 0.65, 0.05), width=self.line_width * 0.5)

        # Vecteur obstacle agrégé : rouge si l'exploration réagit, bleu sinon.
        prox = self.explorer.last_proximity_vector
        if prox.value > 0.0:
            length = max(0.08, self.vector_length * float(prox.value))
            obstacle_end = origin + self._yaw_to_world_vector(yaw, float(prox.angle), length)
            color = (1.0, 0.0, 0.0) if self.explorer.last_obstacle_detected else (0.15, 0.35, 1.0)
            self._draw_line(f"{self.root_path}/proximity_vector", origin, obstacle_end, color=color, width=self.line_width)
            self._draw_sphere(f"{self.root_path}/proximity_tip", obstacle_end, radius=self.line_width * 1.6, color=color)
        else:
            self._delete_if_exists(f"{self.root_path}/proximity_vector")
            self._delete_if_exists(f"{self.root_path}/proximity_tip")
