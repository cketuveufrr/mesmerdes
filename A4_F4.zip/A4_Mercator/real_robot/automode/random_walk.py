from __future__ import annotations

from .automode_exploration import AutoMoDeExploration


class RandomWalkExplorer(AutoMoDeExploration):
    """Nom compatible CLC : random walk = exploration AutoMoDe isolée."""

    def __init__(
        self,
        robot_prim_path: str,
        lidar_prim_path: str,
        forward_speed: float = 0.25,
        proximity_threshold: float = 0.45,
        track_width: float = 0.147,
        max_turn_steps: int = 10,
        **kwargs,
    ):
        super().__init__(
            robot_prim_path=robot_prim_path,
            lidar_prim_path=lidar_prim_path,
            forward_speed=forward_speed,
            turn_speed=kwargs.pop("turn_speed", forward_speed),
            proximity_threshold=proximity_threshold,
            track_width=track_width,
            tau=max_turn_steps,
            **kwargs,
        )
