from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
import types


ROOT = Path(__file__).resolve().parents[2]
DIRECT = ROOT / "source" / "SwarmACB_isaac" / "SwarmACB_isaac" / "tasks" / "direct"
LIGHT = DIRECT / "mercator_light"


def ensure_package(name: str, path: Path) -> None:
    if name in sys.modules:
        return
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    sys.modules[name] = module


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {name} from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_vector_light_modules() -> dict[str, object]:
    for name, path in {
        "SwarmACB_isaac": DIRECT.parents[2],
        "SwarmACB_isaac.tasks": DIRECT.parents[1],
        "SwarmACB_isaac.tasks.direct": DIRECT,
        "SwarmACB_isaac.tasks.direct.mercator_light": LIGHT,
    }.items():
        ensure_package(name, path)

    loaded: dict[str, object] = {}
    for short in (
        "mercator_geometry",
        "mercator_sensors",
        "mercator_behavior_modules",
        "arena_geometry",
        "mercator_tensor_env",
    ):
        canonical = f"SwarmACB_isaac.tasks.direct.mercator_light.{short}"
        if canonical in sys.modules:
            loaded[short] = sys.modules[canonical]
            continue
        loaded[short] = load_module(canonical, LIGHT / f"{short}.py")
    return loaded
