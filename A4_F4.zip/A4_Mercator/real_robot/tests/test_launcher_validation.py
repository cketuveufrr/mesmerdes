from __future__ import annotations

from pathlib import Path
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[2]
LAUNCHER = ROOT / "launch_real.py"


@pytest.mark.parametrize("mission", ["AAC", "FOR", "GRID"])
def test_fsm_validation_mode_needs_no_isaac(mission: str) -> None:
    process = subprocess.run(
        [
            sys.executable,
            str(LAUNCHER),
            "--mission",
            mission,
            "--score",
            "--fsm-index",
            "1",
            "--validate-only",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    assert "Validation successful." in process.stdout
    assert "wheel_std=0" in process.stdout


def test_launcher_rejects_invalid_observation_setup(tmp_path: Path) -> None:
    source = ROOT / "real_robot" / "configs" / "AAC_real.yaml"
    text = source.read_text(encoding="utf-8").replace("wall_height: 0.08", "wall_height: 0.20")
    broken = tmp_path / "broken.yaml"
    broken.write_text(text, encoding="utf-8")
    process = subprocess.run(
        [
            sys.executable,
            str(LAUNCHER),
            "--mission",
            "AAC",
            "--score",
            "--fsm-index",
            "1",
            "--config",
            str(broken),
            "--validate-only",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert process.returncode != 0
    assert "walls remain below" in process.stderr


def test_checkpoint_validation_mode_needs_no_isaac(tmp_path: Path) -> None:
    import torch

    checkpoint = tmp_path / "dummy_checkpoint.pt"
    torch.save(
        {
            "trainer_type": "poca",
            "discrete": True,
            "recurrent": True,
            "obs_dim": 2,
            "num_actions": 6,
            "decision_period": 1,
        },
        checkpoint,
    )
    process = subprocess.run(
        [
            sys.executable,
            str(LAUNCHER),
            "--mission",
            "AAC",
            "--score",
            "--checkpoint",
            str(checkpoint),
            "--validate-only",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    assert "Checkpoint:" in process.stdout
    assert "obs=2" in process.stdout
    assert "Validation successful." in process.stdout
