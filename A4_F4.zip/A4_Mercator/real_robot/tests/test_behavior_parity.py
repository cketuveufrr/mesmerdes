from __future__ import annotations

import numpy as np
import pytest
import torch

from real_robot.runtime.reference_math import canonical_module_wheels, wheels_from_vector_np
from real_robot.tests._vector_loader import load_vector_light_modules


def _batch(sensors_module, *, envs: int = 4, agents: int = 7, seed: int = 19):
    generator = torch.Generator().manual_seed(seed)
    shape = (envs, agents)
    proximity_value = torch.rand(shape, generator=generator)
    proximity_angle = (2.0 * torch.rand(shape, generator=generator) - 1.0) * torch.pi
    proximity_vector = torch.stack(
        (proximity_value * torch.cos(proximity_angle), proximity_value * torch.sin(proximity_angle)),
        dim=-1,
    )
    light_vector = torch.randn((*shape, 2), generator=generator)
    zero_light = torch.rand(shape, generator=generator) < 0.15
    light_vector[zero_light] = 0.0
    neighbor_vector = 0.20 * torch.randn((*shape, 2), generator=generator)
    zeros8 = torch.zeros((*shape, 8))
    zeros4 = torch.zeros((*shape, 4))
    zeros = torch.zeros(shape)
    return sensors_module.MercatorSensorBatch(
        proximity_values=zeros8,
        proximity_vector=proximity_vector,
        proximity_value=proximity_value,
        proximity_angle=proximity_angle,
        light_values=zeros8,
        light_vector=light_vector,
        light_value=zeros,
        light_angle=zeros,
        neighbor_vector=neighbor_vector,
        neighbor_count=zeros.to(torch.long),
        ztilde=zeros,
        rab_projection=zeros4,
    )


def test_vector_to_wheels_matches_vectorized_implementation_on_10000_cases() -> None:
    modules = load_vector_light_modules()
    behavior = modules["mercator_behavior_modules"]
    generator = torch.Generator().manual_seed(1234)
    vectors = torch.randn((10000, 2), generator=generator)
    expected = behavior.MercatorBehaviorModules.wheels_from_vector(vectors, 0.30).numpy()
    actual = np.asarray([wheels_from_vector_np(x, y, 0.30) for x, y in vectors.numpy()])
    np.testing.assert_allclose(actual, expected, atol=2e-7, rtol=0.0)


@pytest.mark.parametrize("module_id", [1, 2, 3, 4, 5])
def test_deterministic_modules_match_vectorized_control_laws(module_id: int) -> None:
    modules = load_vector_light_modules()
    behavior_module = modules["mercator_behavior_modules"]
    sensors_module = modules["mercator_sensors"]
    sensors = _batch(sensors_module)
    controller = behavior_module.MercatorBehaviorModules(
        max_speed=0.30,
        phototaxis_proximity_gain=5.0,
        anti_phototaxis_proximity_gain=5.0,
        attraction_proximity_gain=6.0,
        repulsion_proximity_gain=5.0,
        attraction_alpha_parameter=5.0,
        repulsion_alpha_parameter=5.0,
        neighbor_vector_base_alpha=1.0,
        fallback_vector_threshold=0.10,
        device="cpu",
    )
    controller.init_state(4, 7)
    ids = torch.full((4, 7), module_id, dtype=torch.long)
    vectorized = controller.compute(ids, sensors).numpy()

    proximity = sensors.proximity_vector.numpy()
    light = sensors.light_vector.numpy()
    light_norm = np.linalg.norm(light, axis=-1, keepdims=True)
    beacon = np.divide(light, np.maximum(light_norm, 1e-12), where=np.ones_like(light, dtype=bool))
    beacon[light_norm[..., 0] <= 1e-12] = 0.0
    neighbor = sensors.neighbor_vector.numpy()
    realistic_reference = np.empty_like(vectorized)
    for env in range(vectorized.shape[0]):
        for robot in range(vectorized.shape[1]):
            realistic_reference[env, robot] = canonical_module_wheels(
                module_id,
                proximity_xy=proximity[env, robot],
                beacon_unit_xy=beacon[env, robot],
                neighbor_base_xy=neighbor[env, robot],
                max_speed=0.30,
                attraction_alpha=5.0,
                repulsion_alpha=5.0,
            )
    np.testing.assert_allclose(realistic_reference, vectorized, atol=3e-7, rtol=0.0)


def test_exploration_is_forward_without_an_obstacle_in_vectorized_model() -> None:
    modules = load_vector_light_modules()
    behavior_module = modules["mercator_behavior_modules"]
    sensors_module = modules["mercator_sensors"]
    sensors = _batch(sensors_module, envs=1, agents=3)
    sensors = sensors_module.MercatorSensorBatch(
        **{
            **sensors.__dict__,
            "proximity_value": torch.zeros((1, 3)),
            "proximity_angle": torch.zeros((1, 3)),
            "proximity_vector": torch.zeros((1, 3, 2)),
        }
    )
    controller = behavior_module.MercatorBehaviorModules(device="cpu", max_speed=0.30)
    controller.init_state(1, 3)
    output = controller.compute(torch.zeros((1, 3), dtype=torch.long), sensors)
    torch.testing.assert_close(output, torch.full((1, 3, 2), 0.30))
