from __future__ import annotations

import math
from pathlib import Path
import re

import pytest
import yaml

from real_robot.runtime.config import load_real_robot_config
from real_robot.runtime.observations import cyclamen_ztilde
from real_robot.runtime.reference_math import expected_horizontal_hits


ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / "real_robot" / "configs"
USD = ROOT / "real_robot" / "assets" / "MercatorLiteOfficial_rtx_lidar_ground_clean.usda"


@pytest.mark.parametrize("mission", ["AAC", "FOR", "GRID"])
def test_nominal_yaml_contract(mission: str) -> None:
    cfg = load_real_robot_config(CONFIGS / f"{mission}_real.yaml")
    assert cfg.mission_key == mission
    assert cfg.robot.count == 20
    assert cfg.robot.track_width == pytest.approx(0.147)
    assert cfg.robot.ground_sensor_offset == pytest.approx((0.05619, 0.0))
    assert cfg.lidar.min_range == pytest.approx(0.12)
    assert cfg.lidar.max_range == pytest.approx(0.75)
    assert cfg.lidar.scan_rate_hz == pytest.approx(7.0)
    assert cfg.lidar.samples_per_second == pytest.approx(5000.0)
    assert cfg.lidar.min_cluster_points == 5
    assert cfg.lidar.cluster_distance_epsilon_m == pytest.approx(0.02)
    assert int(cfg.control.observation) == 2
    assert cfg.control.frequency_hz == pytest.approx(10.0)
    assert cfg.control.physics_frequency_hz == pytest.approx(60.0)
    assert cfg.physics_steps_per_control == 6
    assert cfg.arena.wall_height < 0.17545

    assert cfg.noise.wheels.std_fraction == 0.0
    assert cfg.noise.wheels.bias_left_fraction == 0.0
    assert cfg.noise.wheels.bias_right_fraction == 0.0
    assert cfg.noise.lidar.range_uniform_m == 0.0
    assert cfg.noise.lidar.range_gaussian_std_m == 0.0
    assert cfg.noise.lidar.dropout_probability == 0.0
    assert cfg.noise.lidar.azimuth_bias_deg == 0.0
    assert cfg.noise.lidar.azimuth_gaussian_std_deg == 0.0
    assert cfg.noise.lidar.elevation_bias_deg == 0.0
    assert cfg.noise.lidar.elevation_gaussian_std_deg == 0.0
    assert cfg.noise.sensors.proximity_gaussian_std == 0.0
    assert cfg.noise.sensors.light_gaussian_std == 0.0
    assert cfg.noise.sensors.ground_flip_probability == 0.0


@pytest.mark.parametrize("count, expected", [(0, 0.0), (1, math.tanh(0.5)), (5, math.tanh(2.5))])
def test_cyclamen_observation_contract(count: int, expected: float) -> None:
    assert cyclamen_ztilde(count) == pytest.approx(expected)


def test_usd_contains_the_physical_sensor_setup() -> None:
    text = USD.read_text(encoding="utf-8")
    assert re.search(r"nearRangeM\s*=\s*0\.12", text)
    assert re.search(r"scanRateBaseHz\s*=\s*7", text)
    assert re.search(r"reportRateBaseHz\s*=\s*5000", text)
    assert re.search(r"azimuthErrorStd\s*=\s*0(?:\.0+)?", text)
    ground = re.search(
        r'def Xform "ground_sensor".*?xformOp:translate\s*=\s*\(([^,]+),',
        text,
        flags=re.S,
    )
    assert ground is not None
    assert float(ground.group(1)) == pytest.approx(0.05619, abs=2e-7)


def test_lidar_geometry_supports_five_point_threshold_at_075m() -> None:
    hits = expected_horizontal_hits(
        tower_diameter_m=0.065,
        center_distance_m=0.75,
        samples_per_second=5000.0,
        scan_rate_hz=7.0,
    )
    assert 9.0 < hits < 11.0
    assert 5.0 / hits < 0.56


def test_all_yaml_files_are_plain_portable_mappings() -> None:
    for path in CONFIGS.glob("*_real.yaml"):
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert isinstance(raw, dict)
        assert set(("mission", "robot", "lidar", "control", "noise")) <= set(raw)
