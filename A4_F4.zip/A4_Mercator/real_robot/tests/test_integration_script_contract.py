from __future__ import annotations

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "real_robot" / "tests" / "run_vector_real_gap.py"


def test_gap_script_help_runs_without_importing_isaac() -> None:
    process = subprocess.run(
        [sys.executable, str(SCRIPT), "--help"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert process.returncode == 0, process.stdout + process.stderr
    assert "vectorized" in process.stdout.lower()
    assert "realistic" in process.stdout.lower()
