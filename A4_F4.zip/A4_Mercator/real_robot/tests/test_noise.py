from __future__ import annotations

import numpy as np
import pytest

from real_robot.runtime.config import LidarNoiseConfig, WheelNoiseConfig
from real_robot.runtime.noise import apply_lidar_point_noise, apply_wheel_noise


def test_zero_wheel_noise_is_exact_identity() -> None:
    rng = np.random.default_rng(7)
    cfg = WheelNoiseConfig()
    assert apply_wheel_noise(0.123, -0.234, cfg, rng, max_speed=0.30) == pytest.approx(
        (0.123, -0.234), abs=0.0
    )


def test_zero_lidar_noise_is_exact_identity_copy() -> None:
    points = np.asarray([[0.2, 0.0, 0.0], [0.4, 0.1, 0.0]], dtype=np.float32)
    noisy = apply_lidar_point_noise(points, LidarNoiseConfig(), np.random.default_rng(3))
    np.testing.assert_array_equal(noisy, points)
    assert noisy is not points


def test_wheel_noise_is_reproducible_and_clipped() -> None:
    cfg = WheelNoiseConfig(std_fraction=0.15, bias_left_fraction=0.1, bias_right_fraction=-0.1)
    a = apply_wheel_noise(0.30, 0.30, cfg, np.random.default_rng(123), max_speed=0.30)
    b = apply_wheel_noise(0.30, 0.30, cfg, np.random.default_rng(123), max_speed=0.30)
    assert a == pytest.approx(b)
    assert all(-0.30 <= value <= 0.30 for value in a)


def test_lidar_radial_noise_preserves_bearing() -> None:
    points = np.asarray([[0.3, 0.4, 0.0], [-0.2, 0.2, 0.0]], dtype=np.float32)
    cfg = LidarNoiseConfig(range_uniform_m=0.05, range_gaussian_std_m=0.01)
    noisy = apply_lidar_point_noise(points, cfg, np.random.default_rng(11))
    before = np.arctan2(points[:, 1], points[:, 0])
    after = np.arctan2(noisy[:, 1], noisy[:, 0])
    np.testing.assert_allclose(after, before, atol=1e-6, rtol=0.0)
