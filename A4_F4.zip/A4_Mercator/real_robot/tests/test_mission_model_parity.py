from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import torch

from real_robot.runtime import mission_models as real_models


ROOT = Path(__file__).resolve().parents[2]
MISSIONS = (
    ROOT
    / "source"
    / "SwarmACB_isaac"
    / "SwarmACB_isaac"
    / "tasks"
    / "direct"
    / "missions"
)


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def test_foraging_state_update_is_exact_source_copy() -> None:
    source = _load(
        "_real_test_vector_foraging_model",
        MISSIONS / "mercator_foraging" / "mercator_foraging_model.py",
    )
    generator = torch.Generator().manual_seed(9271)
    positions = 9.0 * (torch.rand((11, 20, 2), generator=generator) - 0.5)
    carrying = torch.rand((11, 20), generator=generator) > 0.5

    expected = source.update_carrying_state(positions, carrying)
    actual = real_models.update_carrying_state(
        positions,
        carrying,
        food_centers=source.FOOD_CENTERS,
        food_radius=source.FOOD_RADIUS,
        nest_limit_y=source.NEST_LIMIT_Y,
    )
    for field in ("carrying", "pickup_mask", "delivery_mask", "in_food", "in_nest"):
        assert torch.equal(getattr(actual, field), getattr(expected, field))
    assert real_models.NEST_FLOOR_POLYGON == source.NEST_FLOOR_POLYGON


def test_grid_age_update_is_exact_source_copy() -> None:
    source = _load(
        "_real_test_vector_grid_model",
        MISSIONS
        / "mercator_grid_exploration"
        / "mercator_grid_exploration_model.py",
    )
    generator = torch.Generator().manual_seed(1147)
    ages = torch.randint(0, 500, (13, 10, 10), generator=generator)
    positions = 10.4 * (torch.rand((13, 20, 2), generator=generator) - 0.5)

    expected = source.update_grid_ages(ages, positions)
    actual = real_models.update_grid_ages(
        ages,
        positions,
        arena_size=source.ARENA_SIZE,
        grid_size=source.GRID_SIZE,
    )
    for field in (
        "ages",
        "reward",
        "total_age",
        "mean_age",
        "max_age",
        "visited_cells",
        "visited_mask",
    ):
        assert torch.equal(getattr(actual, field), getattr(expected, field))
