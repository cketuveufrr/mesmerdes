from __future__ import annotations

import math

import numpy as np
import pytest

from real_robot.sensors.lidar_neighbors import LidarNeighborDetector


class DummyLidar:
    def get_point_cloud(self):
        return np.empty((0, 3), dtype=np.float32)

    def detach(self):
        return None


def detector(min_points: int = 5, target_radius_m: float = 0.0) -> LidarNeighborDetector:
    return LidarNeighborDetector(
        "/unused",
        lidar_helper=DummyLidar(),
        neighbor_min_range=0.12,
        neighbor_max_range=0.75,
        cluster_distance_epsilon=0.02,
        cluster_angle_epsilon_rad=0.175,
        min_cluster_points=min_points,
        target_radius_m=target_radius_m,
        alpha=1.0,
    )


def arc_points(count: int, distance: float = 0.70, center_angle: float = 0.0) -> np.ndarray:
    angles = center_angle + np.deg2rad(np.linspace(-2.0, 2.0, count))
    return np.stack(
        (distance * np.cos(angles), distance * np.sin(angles), np.zeros(count)),
        axis=-1,
    ).astype(np.float32)


def test_five_points_are_accepted_four_are_rejected() -> None:
    accepted = detector(5).compute_from_points(arc_points(5))
    rejected = detector(5).compute_from_points(arc_points(4))
    assert accepted.neighbors_count == 1
    assert accepted.clusters[0].point_count == 5
    assert rejected.neighbors_count == 0
    assert len(rejected.rejected_clusters) == 1


def test_two_separated_towers_produce_two_neighbors() -> None:
    points = np.concatenate((arc_points(7, center_angle=-0.35), arc_points(8, center_angle=0.35)))
    observation = detector(5).compute_from_points(points)
    assert observation.neighbors_count == 2


def test_neighbor_vector_uses_centimetres_like_vectorized_model() -> None:
    observation = detector(5).compute_from_points(arc_points(8, distance=0.50))
    assert observation.neighbors_count == 1
    expected_norm = 1.0 / (1.0 + 100.0 * observation.clusters[0].mean_distance)
    assert np.linalg.norm(observation.attraction_vector_xy) == pytest.approx(expected_norm, rel=2e-6)
    assert abs(observation.vector_angle) < math.radians(0.1)


def test_minimum_and_maximum_ranges_are_enforced() -> None:
    points = np.concatenate((arc_points(8, 0.11), arc_points(8, 0.50), arc_points(8, 0.76)))
    observation = detector(5).compute_from_points(points)
    assert observation.neighbors_count == 1
    assert observation.candidate_points_count == 8


def test_known_tower_radius_reconstructs_center_distance_and_range() -> None:
    radius = 0.0325
    observation = detector(5, target_radius_m=radius).compute_from_points(
        arc_points(8, distance=0.70)
    )
    assert observation.neighbors_count == 1
    cluster = observation.clusters[0]
    assert cluster.surface_distance == pytest.approx(0.70, abs=1e-6)
    assert cluster.mean_distance == pytest.approx(0.70 + radius, abs=1e-6)

    # Surface returns can remain below 0.75 m while the target center is beyond
    # the vectorized neighborhood. The post-cluster center check must reject it.
    beyond = detector(5, target_radius_m=radius).compute_from_points(
        arc_points(8, distance=0.73)
    )
    assert beyond.neighbors_count == 0
    assert len(beyond.rejected_clusters) == 1
    assert beyond.rejected_clusters[0].reject_reason.startswith("center_too_far")
