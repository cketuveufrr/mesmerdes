#!/usr/bin/env python3
"""Measure deterministic vectorized-versus-realistic Mercator divergence.

This is an Isaac integration test, not a training script.  It places the same
robots at the same poses in:

1. the fast tensor-only Mercator model; and
2. the full USD model with TeraRanger raycasts, RTX LiDAR and PhysX collisions.

One of the five deterministic behavior modules is then applied to both models.  The
script reports per-step wheel, local-neighbor and trajectory gaps and writes a
CSV plus a JSON summary.

Run with the Isaac Sim 6.0 Python environment, for example::

    python real_robot/tests/run_vector_real_gap.py --module phototaxis --steps 120
    python real_robot/tests/run_vector_real_gap.py --all-modules --steps 80
"""

from __future__ import annotations

import argparse
from dataclasses import replace
from datetime import datetime
import csv
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
REAL_ROOT = ROOT / "real_robot"
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
SCRIPTS_ROOT = ROOT / "scripts"
for path in (ROOT, REAL_ROOT, SOURCE_ROOT, SCRIPTS_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


MODULES = {
    "stop": 1,
    "phototaxis": 2,
    "anti_phototaxis": 3,
    "attraction": 4,
    "repulsion": 5,
}


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(
        description=(
            "Evaluate the deterministic gap between the vectorized Mercator and "
            "the realistic USD/LiDAR/collision Mercator"
        )
    )
    choice = value.add_mutually_exclusive_group()
    choice.add_argument("--module", choices=tuple(MODULES), default="phototaxis")
    choice.add_argument("--all-modules", action="store_true")
    value.add_argument("--config", default=str(REAL_ROOT / "configs" / "AAC_real.yaml"))
    value.add_argument("--robots", type=int, default=3)
    value.add_argument("--steps", type=int, default=100)
    value.add_argument("--seed", type=int, default=17)
    value.add_argument("--output-dir", default=str(ROOT / "results" / "real_robot" / "parity"))
    value.add_argument("--headless", action="store_true")
    value.add_argument("--renderer", default="RaytracedLighting")
    return value


def circular_error(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return np.arctan2(np.sin(a - b), np.cos(a - b))


def deterministic_layout(count: int) -> list[tuple[float, float, float]]:
    if not 1 <= count <= 7:
        raise ValueError("The compact parity layout supports 1 to 7 robots")
    spacing = 0.56
    xs = (np.arange(count, dtype=np.float64) - 0.5 * (count - 1)) * spacing
    # Alternating headings exercise both sides of the wheel mapping while all
    # LiDAR towers remain within the 0.75 m local-neighbor range of an adjacent robot.
    return [
        (float(x), 0.0, float(0.20 * (-1 if index % 2 else 1)))
        for index, x in enumerate(xs)
    ]


def make_vector_env(real_cfg: Any, count: int):
    import torch

    from real_robot.tests._vector_loader import load_vector_light_modules

    modules = load_vector_light_modules()
    tensor = modules["mercator_tensor_env"]
    cfg = tensor.MercatorTensorEnvCfg()
    cfg.device = "cpu"
    cfg.num_agents = int(count)
    cfg.scene.num_envs = 1
    cfg.apply_overrides(
        {
            "num_envs": 1,
            "variant": "cyclamen",
            "episode_length_s": max(120.0, real_cfg.control.episode_length_s),
            "arena_side_length": real_cfg.arena.wall_side_length,
            "arena_wall_thickness": real_cfg.arena.wall_thickness,
            "arena_wall_height": real_cfg.arena.wall_height,
            "black_center": list(real_cfg.mission.black_center),
            "white_center": list(real_cfg.mission.white_center),
            "zone_radius": real_cfg.mission.zone_radius,
            "light_position": list(real_cfg.mission.light_position),
            "robot_length": real_cfg.robot.length,
            "robot_width": real_cfg.robot.width,
            "robot_height": real_cfg.robot.height,
            "collision_shape": "obb",
            "collision_radius": real_cfg.robot.collision_radius,
            "lidar_tower_diameter": real_cfg.lidar.tower_diameter_m,
            "lidar_height": 0.17545,
            "ground_sensor_offset": list(real_cfg.robot.ground_sensor_offset),
            "max_wheel_speed": real_cfg.robot.max_wheel_speed,
            "wheelbase": real_cfg.robot.track_width,
            "teraranger_layout": "native_asymmetric",
            "teraranger_max_range": 2.0,
            "neighbor_min_range": real_cfg.lidar.min_range,
            "neighbor_max_range": real_cfg.lidar.max_range,
            "cyclamen_neighbor_range": real_cfg.lidar.max_range,
            "exploration_tau": real_cfg.control.exploration_tau,
            "phototaxis_proximity_gain": real_cfg.control.phototaxis_proximity_gain,
            "anti_phototaxis_proximity_gain": real_cfg.control.anti_phototaxis_proximity_gain,
            "attraction_proximity_gain": real_cfg.control.attraction_proximity_gain,
            "repulsion_proximity_gain": real_cfg.control.repulsion_proximity_gain,
        }
    )
    env = tensor.MercatorTensorEnv(cfg)
    env.behavior_modules.reset_state()
    return env, torch


def set_vector_poses(env: Any, torch: Any, poses: list[tuple[float, float, float]]) -> None:
    positions = torch.tensor([[p[:2] for p in poses]], dtype=torch.float32)
    yaws = torch.tensor([[p[2] for p in poses]], dtype=torch.float32)
    env.agent_pos.copy_(positions)
    env.agent_yaw.copy_(yaws)
    env.behavior_modules.reset_state()


def run_one(
    *,
    module_name: str,
    steps: int,
    real_cfg: Any,
    world: Any,
    vector_env: Any,
    torch: Any,
    poses: list[tuple[float, float, float]],
    seed: int,
) -> tuple[list[dict[str, float | int | str]], dict[str, float | int | str]]:
    from real_robot.runtime.mission import MissionRuntime
    from real_robot.runtime.observations import build_actor_observations

    module_id = MODULES[module_name]
    world.set_poses(poses, seed=seed)
    set_vector_poses(vector_env, torch, poses)
    mission = MissionRuntime(real_cfg)
    actions = torch.full((1, len(poses), 1), module_id, dtype=torch.long)
    rows: list[dict[str, float | int | str]] = []

    for step in range(1, int(steps) + 1):
        _obs, neighbors, _ground, real_counts = build_actor_observations(world, mission, 2)
        vector_sensors = vector_env.sensors.compute_all(
            vector_env.agent_pos,
            vector_env.agent_yaw,
            vector_env.wall_segments,
            vector_env.light_pos,
        )
        vector_counts = vector_sensors.neighbor_count[0].cpu().numpy().astype(np.int32)

        real_wheels = np.zeros((len(poses), 2), dtype=np.float32)
        for index, (record, snapshot) in enumerate(zip(world.records, neighbors)):
            info = record.automode.update(module_id, neighbors=snapshot)
            world.apply_wheels(record, info.left_speed, info.right_speed)
            real_wheels[index] = record.last_wheels

        vector_env.step_tensor(actions)
        vector_wheels = vector_env._cached_wheels[0].cpu().numpy().copy()
        world.step_physics()
        real_pose = world.poses()
        vector_pose = np.column_stack(
            (
                vector_env.agent_pos[0].cpu().numpy(),
                vector_env.agent_yaw[0].cpu().numpy(),
            )
        )

        position_error = np.linalg.norm(real_pose[:, :2] - vector_pose[:, :2], axis=1)
        yaw_error = np.abs(circular_error(real_pose[:, 2], vector_pose[:, 2]))
        wheel_error = np.linalg.norm(real_wheels - vector_wheels, axis=1)
        count_error = np.abs(real_counts.astype(np.float32) - vector_counts.astype(np.float32))
        for robot in range(len(poses)):
            rows.append(
                {
                    "module": module_name,
                    "module_id": module_id,
                    "step": step,
                    "robot": robot,
                    "real_x": float(real_pose[robot, 0]),
                    "real_y": float(real_pose[robot, 1]),
                    "real_yaw": float(real_pose[robot, 2]),
                    "vector_x": float(vector_pose[robot, 0]),
                    "vector_y": float(vector_pose[robot, 1]),
                    "vector_yaw": float(vector_pose[robot, 2]),
                    "real_left": float(real_wheels[robot, 0]),
                    "real_right": float(real_wheels[robot, 1]),
                    "vector_left": float(vector_wheels[robot, 0]),
                    "vector_right": float(vector_wheels[robot, 1]),
                    "real_neighbors": int(real_counts[robot]),
                    "vector_neighbors": int(vector_counts[robot]),
                    "position_error_m": float(position_error[robot]),
                    "yaw_error_rad": float(yaw_error[robot]),
                    "wheel_error_mps": float(wheel_error[robot]),
                    "neighbor_count_error": float(count_error[robot]),
                }
            )

    pos = np.asarray([row["position_error_m"] for row in rows], dtype=np.float64)
    yaw = np.asarray([row["yaw_error_rad"] for row in rows], dtype=np.float64)
    wheel = np.asarray([row["wheel_error_mps"] for row in rows], dtype=np.float64)
    count = np.asarray([row["neighbor_count_error"] for row in rows], dtype=np.float64)
    summary: dict[str, float | int | str] = {
        "module": module_name,
        "module_id": module_id,
        "robots": len(poses),
        "steps": int(steps),
        "samples": len(rows),
        "position_rmse_m": float(np.sqrt(np.mean(pos**2))),
        "position_max_m": float(np.max(pos)),
        "yaw_mae_rad": float(np.mean(yaw)),
        "yaw_max_rad": float(np.max(yaw)),
        "wheel_rmse_mps": float(np.sqrt(np.mean(wheel**2))),
        "wheel_max_mps": float(np.max(wheel)),
        "neighbor_count_mae": float(np.mean(count)),
        "neighbor_count_exact_fraction": float(np.mean(count == 0.0)),
    }
    return rows, summary


def main() -> int:
    args = parser().parse_args()
    if args.steps < 1:
        raise ValueError("--steps must be positive")
    poses = deterministic_layout(args.robots)

    # Heavy imports intentionally occur after argparse so --help is usable from
    # a normal Python interpreter outside Isaac.
    from isaacsim import SimulationApp

    app = SimulationApp(
        {
            "headless": bool(args.headless),
            "renderer": str(args.renderer),
            "multi_gpu": False,
            "width": 1280,
            "height": 720,
        }
    )
    world = None
    vector_env = None
    try:
        from real_robot.runtime.config import load_real_robot_config
        from real_robot.runtime.scene import RealRobotWorld

        loaded = load_real_robot_config(args.config)
        if loaded.mission_key != "AAC":
            raise ValueError("The deterministic gap test currently uses AAC geometry")
        real_cfg = replace(loaded, robot=replace(loaded.robot, count=args.robots))
        world = RealRobotWorld(real_cfg, ROOT, app)
        vector_env, torch = make_vector_env(real_cfg, args.robots)

        selected = list(MODULES) if args.all_modules else [args.module]
        all_rows: list[dict[str, float | int | str]] = []
        summaries: list[dict[str, float | int | str]] = []
        for offset, module_name in enumerate(selected):
            rows, summary = run_one(
                module_name=module_name,
                steps=args.steps,
                real_cfg=real_cfg,
                world=world,
                vector_env=vector_env,
                torch=torch,
                poses=poses,
                seed=args.seed + offset,
            )
            all_rows.extend(rows)
            summaries.append(summary)
            print(
                f"{module_name:17s} pos_rmse={summary['position_rmse_m']:.5f} m "
                f"wheel_rmse={summary['wheel_rmse_mps']:.5f} m/s "
                f"neighbors_exact={100.0 * summary['neighbor_count_exact_fraction']:.1f}%"
            )

        output = Path(args.output_dir).expanduser().resolve()
        output.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_path = output / f"vector_real_gap_{stamp}.csv"
        json_path = output / f"vector_real_gap_{stamp}.json"
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(all_rows[0]))
            writer.writeheader()
            writer.writerows(all_rows)
        json_path.write_text(
            json.dumps(
                {
                    "config": str(Path(args.config).resolve()),
                    "seed": args.seed,
                    "initial_poses": poses,
                    "summaries": summaries,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        print(f"CSV:  {csv_path}")
        print(f"JSON: {json_path}")
        return 0
    finally:
        if vector_env is not None:
            vector_env.close()
        if world is not None:
            world.close()
        app.close()


if __name__ == "__main__":
    raise SystemExit(main())
