from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

from real_robot.runtime.config import load_real_robot_config
from real_robot.runtime.mission import MissionRuntime


ROOT = Path(__file__).resolve().parents[2]


def config(name: str):
    cfg = load_real_robot_config(ROOT / "real_robot" / "configs" / f"{name}_real.yaml")
    return replace(cfg, robot=replace(cfg.robot, count=3))


def test_aac_score_is_sum_of_black_occupancy() -> None:
    runtime = MissionRuntime(config("AAC"))
    poses = np.asarray([[0.0, 2.35, 0.0], [0.2, 2.35, 0.0], [0.0, -2.35, 0.0]])
    first = runtime.step(poses)
    second = runtime.step(poses)
    assert first.reward == 2.0
    assert second.reward == 2.0
    assert runtime.score == 4.0
    assert runtime.episode_record(seed=0, controller="x", episode=1)["normalized_score"] == pytest.approx(2 / 3)


def test_foraging_requires_food_then_nest() -> None:
    runtime = MissionRuntime(config("FOR"))
    food = np.asarray([[2.9, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    nest = np.asarray([[0.0, -3.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    assert runtime.step(food).reward == 0.0
    assert runtime.step(nest).reward == 1.0
    assert runtime.deliveries == 1


def test_grid_reward_and_ages_are_finite() -> None:
    runtime = MissionRuntime(config("GRID"))
    poses = np.asarray([[-4.0, -4.0, 0.0], [0.0, 0.0, 0.0], [4.0, 4.0, 0.0]])
    result = runtime.step(poses)
    assert np.isfinite(result.reward)
    assert runtime.ages.shape == (1, 10, 10)
    assert int(runtime.visited_ever.sum()) >= 3
