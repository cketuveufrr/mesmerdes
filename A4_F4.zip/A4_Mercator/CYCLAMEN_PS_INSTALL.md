# Cyclamen-PS overlay

Extract this archive at the `A4_Mercator` project root. It adds files only; it
does not overwrite `scripts/train_2.py`, the source package, or the existing
root-level `poca_opti` used by `train_p3.py`.

Structure:

```text
poca_alt/
  poca_opti/       optimized baseline, isolated copy
  poca_opti_ps/    child implementation for Cyclamen-PS
scripts/train_ps.py
configs/mercator/*_mercator_cyclamen_ps.yaml
```

Cyclamen-PS actor input:

```text
[ground, ztilde, one_hot(previous_executed_module)]
```

The first decision uses six zeros. The critic remains the original centralized
5D recurrent POCA critic. The previous-module projection is initialized to zero,
so the initial policy is identical to optimized Cyclamen for the same seed.

Example:

```bash
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
python scripts/train_ps.py \
  --config configs/mercator/FOR_mercator_cyclamen_ps.yaml \
  --device cuda:1 \
  --log_dir runs/FOR_mercator_cyclamen_ps \
  --checkpoint_dir checkpoints/FOR_mercator_cyclamen_ps
```

Do not resume a standard Cyclamen checkpoint: the actor schema differs.
