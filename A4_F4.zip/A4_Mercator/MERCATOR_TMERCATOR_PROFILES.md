# Mercator and tmercator embodiment profiles

The six Mercator missions can now be executed with two explicitly named robot
embodiments while keeping the mission, arena, FSM, seed and score unchanged.

## Profiles

`robot_profile: mercator` uses:

```yaml
robot_length: 0.26
robot_width: 0.25
robot_height: 0.20
robot_base_height: 0.08
lidar_tower_diameter: 0.065
lidar_tower_offset: [0.0, 0.0]
lidar_height: 0.17545
wheelbase: 0.147
ground_sensor_offset: [0.056, 0.0]
teraranger_layout: native_asymmetric
teraranger_ring_radius: 0.143
teraranger_origin_offset: 0.005
teraranger_max_range: 2.0
```

`robot_profile: tmercator` separates the RVR body box from the real circular
proximity/collision footprint:

```yaml
robot_length: 0.216
robot_width: 0.185
robot_height: 0.170
robot_base_height: 0.114
collision_shape: circle
collision_radius: 0.105
collision_ring_radius: 0.105
collision_ring_height: 0.056
collision_ring_thickness: 0.010
lidar_tower_diameter: 0.065
lidar_tower_offset: [0.0, 0.0]
lidar_height: 0.140
wheelbase: 0.147
ground_sensor_offset: [0.05, 0.0]
teraranger_layout: uniform_ring
teraranger_ring_radius: 0.105
teraranger_origin_offset: 0.0
teraranger_max_range: 2.0
```

The 0.105 m radius is exactly three times the 0.035 m e-puck body radius used
by this repository. Pairwise collision, wall collision, spawn rejection, and
inter-robot proximity ray intersections all use that circle. The 216 mm long x 185 mm wide x
114 mm high box remains the visible RVR body and the wheelbase remains 0.147 m.

If `robot_profile` is absent, the Python environment configuration keeps the
native `mercator` defaults. If a profile is declared, its complete preset is
loaded first and every field explicitly written in the YAML takes priority.
This permits controlled one-parameter ablations without adding a third profile.

## YAML files

Native configurations:

```text
AAC_mercator_cyclamen.yaml
AAC2_mercator_cyclamen.yaml
FOR_mercator_cyclamen.yaml
FOR2_mercator_cyclamen.yaml
GRID_mercator_cyclamen.yaml
GRID2_mercator_cyclamen.yaml
```

Transferability configurations:

```text
AAC_tmercator_cyclamen.yaml
AAC2_tmercator_cyclamen.yaml
FOR_tmercator_cyclamen.yaml
FOR2_tmercator_cyclamen.yaml
GRID_tmercator_cyclamen.yaml
GRID2_tmercator_cyclamen.yaml
```

Each tmercator YAML keeps the same Gym task and mission constants as its native
counterpart. Only the robot embodiment fields and run name differ.

## FSM comparison example

Native Aggregation Experiment 2:

```bash
python scripts/launch.py \
  --mission AAC2 \
  --profile mercator \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

tmercator Aggregation Experiment 2:

```bash
python scripts/launch.py \
  --mission AAC2 \
  --profile tmercator \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

The episode CSV and summary files include a `robot_profile` column. Their file
names also contain either `mercator` or `tmercator`, so both campaigns can be
combined safely for boxplots.

## Sensor layouts

`native_asymmetric` preserves the existing eight physical TeraRanger offsets
and headings. `uniform_ring` uses headings:

```text
45, 0, -45, -90, -135, 180, 135, 90 degrees
```

with all tMercator ray origins on the `0.105 m` collision ring. The existing DAO proximity conversion
and neighbour ranges are unchanged.
