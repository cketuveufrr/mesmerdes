# Mercator Grid Exploration — Experiment 2

## Mission

La tâche Gymnasium est :

```text
SwarmACB-MercatorGridExploration2-v0
```

La configuration d'entraînement est :

```text
configs/mercator/GRID2_mercator_cyclamen.yaml
```

Elle reprend la mission source Experiment 2 : trois Mercator, 120 secondes à
10 Hz, petite arène dodécagonale à côtés de 0,70 m, placement initial uniforme
dans un disque de rayon 1,2 m et sol uniformément gris.

La grille logique fait `10 x 10` sur une taille `2.65 m`. À chaque tick :

1. les cases occupées par au moins un centre de robot sont remises à zéro ;
2. les âges des 100 cases sont additionnés ;
3. toutes les cases sont incrémentées ;
4. la récompense vaut `-somme_des_âges / 100`.

La somme des récompenses d'un épisode est donc directement le score final de la
loop function ARGoS.

Le XML source met la lumière à zéro. Comme pour `AAC2` et `FOR2`, la version
Isaac la garde active à `1.0`, afin de conserver une convention cohérente pour
les petits setups.

## FSM Chocolate

Les dix FSM originales sont dans :

```text
configs/mercator/fsms/fsm_mercator_grid_exploration2_experiment2.txt
```

SHA-256 :

```text
9f992b59dea40d812df1d7ff73a917534968ce204080183e537a16d18d949aff
```

## Observer

```bash
python scripts/mercator_fsm.py \
  --mission GRID2 \
  --observe \
  --fsm-index 1
```

Coloration par module :

```bash
python scripts/mercator_fsm.py \
  --mission GRID2 \
  --observe \
  --fsm-index 1 \
  --color-by module
```

## Évaluer

Une FSM :

```bash
python scripts/mercator_fsm.py \
  --mission GRID2 \
  --score \
  --fsm-index 1 \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

Les dix FSM :

```bash
python scripts/mercator_fsm.py \
  --mission GRID2 \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

Les rapports sont écrits dans :

```text
results/mercator_grid_exploration2_fsm/
```

## Entraîner

```bash
python scripts/train.py \
  --config configs/mercator/GRID2_mercator_cyclamen.yaml \
  --headless
```
