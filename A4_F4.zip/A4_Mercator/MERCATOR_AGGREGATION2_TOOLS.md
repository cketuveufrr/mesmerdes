# Mercator Aggregation 2 — Experiment 2 small arena

This addition implements the Experiment 2 Mercator aggregation mission without
renaming or replacing the existing Experiment 1 aggregation mission.

## Naming

| Element | Experiment 1, unchanged | Experiment 2, added |
|---|---|---|
| Gym task | `SwarmACB-MercatorAggregation-v0` | `SwarmACB-MercatorAggregation2-v0` |
| YAML | `configs/mercator/AAC_mercator_cyclamen.yaml` | `configs/mercator/AAC2_mercator_cyclamen.yaml` |
| FSM file | `fsm_mercator_aggregation_experiment1.txt` | `fsm_mercator_aggregation2_experiment2.txt` |
| FSM selector | `scripts/mercator_fsm.py --mission AAC` | `scripts/mercator_fsm.py --mission AAC2` |

The requested small `2` is therefore attached to all newly introduced
Aggregation Experiment 2 identifiers, while the old names remain intact.

## Source mission reproduced

The implementation uses:

- 3 Mercator robots;
- 120 seconds at 10 control ticks per second;
- a small dodecagonal arena made from 12 wall boxes of length `0.70 m`,
  thickness `0.01 m`, and height `0.08 m`;
- a black circle centered at `(0.0, 0.63)`, radius `0.32 m`;
- a white circle centered at `(0.0, -0.63)`, radius `0.32 m`;
- group reward equal to the number of robot centers in the black circle at
  every control tick;
- a placement radius of `1.2 m`, using the exact two-uniform-number transform
  in `ChocolateBigAACLoopFunction::GetRandomPosition()` followed by collision
  rejection;
- the light position `(0.0, -2.0, 0.4)` and the project's effective intensity `1.0`, kept active because the supplied FSMs use photo/anti-phototaxis.

The light is intentionally active in this Isaac implementation. Although the ARGoS XML stores a zero intensity, the supplied controllers contain photo- and anti-phototaxis states and the effective experimental behavior requires the beacon.

## Train Aggregation 2

```bash
python scripts/train.py \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --headless
```

The run/checkpoint name is `AAC2_mercator_cyclamen_`, separate from the
Experiment 1 `AAC_mercator_cyclamen_` run.

## Generic Mercator visualizer

The existing visualizer now selects a close camera automatically for the small
arena:

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --module 0
```

With a trained checkpoint:

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/AAC2_mercator_cyclamen.yaml \
  --checkpoint checkpoints/AAC2_mercator_cyclamen_/checkpoint_latest.pt \
  --deterministic
```

Explicit `--camera_height` and `--camera_y` values still override the automatic
camera. The old Aggregation and Foraging defaults remain 13 m / -8 m.

## Combined Chocolate FSM tool

Observation and scoring are deliberately merged into one script. Exactly one
of `--observe` or `--score` is required.

### Observe one real FSM

```bash
python scripts/mercator_fsm.py \
  --mission AAC2 \
  --observe \
  --fsm-index 1
```

Color robots by current AutoMoDe module rather than FSM state:

```bash
python scripts/mercator_fsm.py \
  --mission AAC2 \
  --observe \
  --fsm-index 1 \
  --color-by module
```

`--num-episodes 0` keeps the viewer open. A positive value stops after that many
episodes. `--headless` can be used as a diagnostic observation run without a
window.

### Score one FSM

```bash
python scripts/mercator_fsm.py \
  --mission AAC2 \
  --score \
  --fsm-index 1 \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

### Score all ten FSMs

```bash
python scripts/mercator_fsm.py \
  --mission AAC2 \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

Outputs are written by default to:

```text
results/mercator_aggregation2_fsm/
```

The tool emits:

- one CSV row per episode;
- one summary CSV row per FSM;
- one detailed summary JSON file.

Metrics include score, mean robots on black, normalized score per robot-step,
final black/white occupancy, maximum black occupancy, transition counts, and
state-occupancy fractions.

## FSM provenance

The ten Experiment 2 Mercator aggregation FSMs are stored verbatim in:

```text
configs/mercator/fsms/fsm_mercator_aggregation2_experiment2.txt
```

SHA-256:

```text
9bd17a456d398fb4ec2e7f5c27191793d9e210007a4033de8b0339d5b7926aa6
```

The combined tool reuses the existing full Chocolate runtime, including state
parameters, transition conditions, destination decoding, state-entry reset,
and first-tick timing.

## Non-regression scope

The Experiment 1 task and YAML names were not renamed. The former mission-specific scripts remain available as compatibility launchers, while their implementation is centralized in `scripts/mercator_fsm.py`.

The shared aggregation environment gained only an arena-builder hook, zero-light
handling, and the exact disk sampler path. Experiment 1 uses the same old arena
builder, positive light intensity, and box spawn path, so those new branches do
not alter its mission behavior.
