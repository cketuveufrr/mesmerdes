#!/usr/bin/env bash
# Lance des campagnes de contrôleurs Mercator/tmercator : FSM ou checkpoint.
#
# Sans argument :
#   - missions : AAC, AAC2, FOR, FOR2, GRID, GRID2
#   - profils  : mercator, tmercator
#   - contrôleur : toutes les FSM
#   - épisodes : 100 par FSM
#   - envs     : 100 par FSM
#   - FSM simultanées dans une instance Isaac : 1 par défaut
#   - seed     : 0
#
# Le script peut être placé à la racine du projet ou dans scripts/.

set -Eeuo pipefail

PROGRAM_NAME="$(basename "$0")"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"

DEFAULT_MISSIONS=(AAC AAC2 FOR FOR2 GRID GRID2)
DEFAULT_PROFILES=(mercator tmercator)
VALID_MISSIONS="AAC AAC2 FOR FOR2 GRID GRID2"
VALID_PROFILES="mercator tmercator"

MISSIONS_SPEC="all"
PROFILES_SPEC="all"
SEEDS_SPEC="0"
EPISODES=100
NUM_ENVS=100
FSM_INDEX=""
OUTPUT_ROOT="results/mercator_fsm_boxplots"
CAMPAIGN_NAME=""
PYTHON_BIN="python"
DEVICE=""
PRINT_EVERY=100
PROJECT_ROOT_OVERRIDE=""
DRY_RUN=0
CONTINUE_ON_ERROR=0
PARALLEL_SETUPS=1
PARALLEL_FSMS=1
MAX_TOTAL_ENVS=0
CHECKPOINT=""
CHECKPOINT_OBSERVE=0
DETERMINISTIC=0
MISSIONS_EXPLICIT=0
PROFILES_EXPLICIT=0

usage() {
    cat <<EOF
Usage : $PROGRAM_NAME [options]

Sans option, conserve exactement le mode FSM historique :
  6 missions x 2 profils, toutes les FSM, 100 épisodes par FSM,
  100 environnements parallèles et seed 0.

Contrôleur :
  --checkpoint PATH      Active le mode checkpoint POCA/Option-Critic.
  --observe              Avec --checkpoint, ouvre le viewer au lieu de scorer.
  --deterministic        Checkpoint : argmax/moyenne au lieu de l'échantillonnage.

Sélection :
  --missions LISTE       Missions séparées par des virgules.
                         Valeurs : AAC,AAC2,FOR,FOR2,GRID,GRID2 ou all.
  --profiles LISTE       Profils séparés par des virgules.
                         Valeurs : mercator,tmercator ou all.
  --seed N               Seed unique. Alias pratique de --seeds.
  --seeds LISTE          Seeds séparées par des virgules, par ex. 0,1,2.
  --episodes N           FSM : épisodes par FSM. Checkpoint : épisodes totaux.
                         Défaut : 100.
  --num-envs N           FSM : environnements par FSM. Checkpoint : nombre total
                         d'environnements vectorisés. Défaut : 100.
  --parallel-fsms N       Nombre de FSM évaluées simultanément dans la même
                         instance Isaac. Défaut : 1. Ignoré en mode checkpoint.
  --max-total-envs N      Plafond de sécurité sur num-envs x parallel-fsms.
                         0 désactive le plafond. Défaut : 0.
  --all-fsms             Évalue toutes les FSM. C'est le défaut.
  --fsm-index N          Évalue uniquement la FSM N.

Sorties et exécution :
  --output-root PATH     Racine des campagnes.
                         Défaut : results/mercator_fsm_boxplots.
  --campaign-name NAME   Nom lisible du dossier parent de campagne.
  --project-root PATH    Racine contenant scripts/mercator_fsm.py et launch_p.py.
  --python CMD           Interpréteur Python. Défaut : python.
  --device DEVICE        Par ex. cuda:0.
  --print-every N        Fréquence des lignes de progression. Défaut : 100.
  --parallel-setups N    Nombre de configurations mission/profil/seed lancées
                         simultanément. Défaut : 1. Alias : --parallel.
  --continue-on-error    Continue les autres configurations après un échec.
  --dry-run              Valide et affiche toutes les commandes sans les lancer.
  -h, --help             Affiche cette aide.

Exemples :
  # Seulement les six tmercator, paramètres par défaut
  $PROGRAM_NAME --profiles tmercator

  # AAC2 et FOR2, 250 épisodes par FSM, 64 envs
  $PROGRAM_NAME --missions AAC2,FOR2 --episodes 250 --num-envs 64

  # Une seule FSM, deux seeds
  $PROGRAM_NAME --profiles mercator --fsm-index 3 --seeds 0,1

  # Les dix FSM ensemble dans une seule instance Isaac
  $PROGRAM_NAME --parallel-fsms 10 --num-envs 20

  # Trois configurations mission/profil/seed simultanées, chacune avec 5 FSM
  $PROGRAM_NAME --parallel-setups 3 --parallel-fsms 5 --num-envs 20

  # Visualiser un checkpoint tMercator
  $PROGRAM_NAME --checkpoint checkpoints/FOR_tmercator/poca_final.pt \
    --missions FOR --profiles tmercator --observe --deterministic

  # Évaluer ce checkpoint sur 100 épisodes, 20 envs en parallèle
  $PROGRAM_NAME --checkpoint checkpoints/FOR_tmercator/poca_final.pt \
    --missions FOR --profiles tmercator --episodes 100 --num-envs 20 \
    --deterministic

Organisation des résultats :
  <output-root>/<campagne-date>/
    AAC_tmercator_100ep-per-fsm_100env_seed0_all-fsms/
      *.csv, *.json, run.log, command.sh, metadata.txt
EOF
}

fail() {
    printf 'ERREUR: %s\n' "$*" >&2
    exit 2
}

is_positive_integer() {
    [[ "$1" =~ ^[1-9][0-9]*$ ]]
}

is_nonnegative_integer() {
    [[ "$1" =~ ^[0-9]+$ ]]
}

contains_word() {
    local needle="$1"
    shift
    local word
    for word in "$@"; do
        [[ "$word" == "$needle" ]] && return 0
    done
    return 1
}

parse_csv_selection() {
    local spec="$1"
    local kind="$2"
    local -n result_ref="$3"
    local item normalized
    local -a raw=()

    result_ref=()
    if [[ "${spec,,}" == "all" ]]; then
        if [[ "$kind" == "mission" ]]; then
            result_ref=("${DEFAULT_MISSIONS[@]}")
        else
            result_ref=("${DEFAULT_PROFILES[@]}")
        fi
        return
    fi

    IFS=',' read -r -a raw <<< "$spec"
    for item in "${raw[@]}"; do
        item="${item//[[:space:]]/}"
        [[ -n "$item" ]] || continue
        if [[ "$kind" == "mission" ]]; then
            normalized="${item^^}"
            contains_word "$normalized" ${VALID_MISSIONS} \
                || fail "mission inconnue '$item'"
        else
            normalized="${item,,}"
            contains_word "$normalized" ${VALID_PROFILES} \
                || fail "profil inconnu '$item'"
        fi
        if ! contains_word "$normalized" "${result_ref[@]}"; then
            result_ref+=("$normalized")
        fi
    done
    ((${#result_ref[@]} > 0)) || fail "sélection $kind vide"
}

parse_seeds() {
    local spec="$1"
    local -n result_ref="$2"
    local item
    local -a raw=()
    result_ref=()
    IFS=',' read -r -a raw <<< "$spec"
    for item in "${raw[@]}"; do
        item="${item//[[:space:]]/}"
        is_nonnegative_integer "$item" || fail "seed invalide '$item'"
        if ! contains_word "$item" "${result_ref[@]}"; then
            result_ref+=("$item")
        fi
    done
    ((${#result_ref[@]} > 0)) || fail "liste de seeds vide"
}

resolve_project_root() {
    local candidate
    local -a candidates=()

    if [[ -n "$PROJECT_ROOT_OVERRIDE" ]]; then
        candidates+=("$PROJECT_ROOT_OVERRIDE")
    else
        # Ajoute le dossier courant (.) en premier pour être sûr qu'il regarde là où vous êtes
        candidates+=("$PWD" "$SCRIPT_DIR" "$(dirname "$SCRIPT_DIR")")
    fi

    for candidate in "${candidates[@]}"; do
        if [[ -f "$candidate/scripts/mercator_fsm.py" && -f "$candidate/scripts/launch_p.py" ]]; then
            (cd "$candidate" && pwd -P)
            return 0
        fi
    done
    fail "racine du projet introuvable; utilise --project-root PATH"
}
quote_command() {
    local arg
    for arg in "$@"; do
        printf '%q ' "$arg"
    done
    printf '\n'
}

while (($#)); do
    case "$1" in
        --missions)
            (($# >= 2)) || fail "--missions exige une valeur"
            MISSIONS_SPEC="$2"; MISSIONS_EXPLICIT=1; shift 2 ;;
        --profiles)
            (($# >= 2)) || fail "--profiles exige une valeur"
            PROFILES_SPEC="$2"; PROFILES_EXPLICIT=1; shift 2 ;;
        --seed)
            (($# >= 2)) || fail "--seed exige une valeur"
            SEEDS_SPEC="$2"; shift 2 ;;
        --seeds)
            (($# >= 2)) || fail "--seeds exige une valeur"
            SEEDS_SPEC="$2"; shift 2 ;;
        --episodes)
            (($# >= 2)) || fail "--episodes exige une valeur"
            EPISODES="$2"; shift 2 ;;
        --num-envs)
            (($# >= 2)) || fail "--num-envs exige une valeur"
            NUM_ENVS="$2"; shift 2 ;;
        --parallel-fsms)
            (($# >= 2)) || fail "--parallel-fsms exige une valeur"
            PARALLEL_FSMS="$2"; shift 2 ;;
        --max-total-envs)
            (($# >= 2)) || fail "--max-total-envs exige une valeur"
            MAX_TOTAL_ENVS="$2"; shift 2 ;;
        --checkpoint)
            (($# >= 2)) || fail "--checkpoint exige une valeur"
            CHECKPOINT="$2"; shift 2 ;;
        --observe)
            CHECKPOINT_OBSERVE=1; shift ;;
        --deterministic)
            DETERMINISTIC=1; shift ;;
        --stochastic)
            DETERMINISTIC=0; shift ;;
        --all-fsms)
            FSM_INDEX=""; shift ;;
        --fsm-index)
            (($# >= 2)) || fail "--fsm-index exige une valeur"
            FSM_INDEX="$2"; shift 2 ;;
        --output-root)
            (($# >= 2)) || fail "--output-root exige une valeur"
            OUTPUT_ROOT="$2"; shift 2 ;;
        --campaign-name)
            (($# >= 2)) || fail "--campaign-name exige une valeur"
            CAMPAIGN_NAME="$2"; shift 2 ;;
        --project-root)
            (($# >= 2)) || fail "--project-root exige une valeur"
            PROJECT_ROOT_OVERRIDE="$2"; shift 2 ;;
        --python)
            (($# >= 2)) || fail "--python exige une valeur"
            PYTHON_BIN="$2"; shift 2 ;;
        --device)
            (($# >= 2)) || fail "--device exige une valeur"
            DEVICE="$2"; shift 2 ;;
        --print-every)
            (($# >= 2)) || fail "--print-every exige une valeur"
            PRINT_EVERY="$2"; shift 2 ;;
        --parallel-setups|--parallel)
            (($# >= 2)) || fail "$1 exige une valeur"
            PARALLEL_SETUPS="$2"; shift 2 ;;
        --continue-on-error)
            CONTINUE_ON_ERROR=1; shift ;;
        --dry-run)
            DRY_RUN=1; shift ;;
        -h|--help)
            usage; exit 0 ;;
        --)
            shift
            (($# == 0)) || fail "arguments positionnels non pris en charge: $*"
            ;;
        *)
            fail "option inconnue '$1'" ;;
    esac
done

is_positive_integer "$EPISODES" || fail "--episodes doit être un entier positif"
is_positive_integer "$NUM_ENVS" || fail "--num-envs doit être un entier positif"
is_nonnegative_integer "$PRINT_EVERY" || fail "--print-every doit être un entier >= 0"
is_positive_integer "$PARALLEL_SETUPS" || fail "--parallel-setups doit être un entier positif"
is_positive_integer "$PARALLEL_FSMS" || fail "--parallel-fsms doit être un entier positif"
is_nonnegative_integer "$MAX_TOTAL_ENVS" || fail "--max-total-envs doit être un entier >= 0"
if [[ -n "$FSM_INDEX" ]]; then
    is_positive_integer "$FSM_INDEX" || fail "--fsm-index doit être un entier positif"
fi

MISSIONS=()
PROFILES=()
SEEDS=()
parse_csv_selection "$MISSIONS_SPEC" mission MISSIONS
parse_csv_selection "$PROFILES_SPEC" profile PROFILES
parse_seeds "$SEEDS_SPEC" SEEDS

PROJECT_ROOT="$(resolve_project_root)"
cd "$PROJECT_ROOT"

CONTROLLER_SCRIPT="$PROJECT_ROOT/scripts/launch_p.py"
[[ -f "$CONTROLLER_SCRIPT" ]] || fail "fichier absent: $CONTROLLER_SCRIPT"

if [[ "$OUTPUT_ROOT" != /* ]]; then
    OUTPUT_ROOT="$PROJECT_ROOT/$OUTPUT_ROOT"
fi

CONTROLLER_MODE="fsm"
CHECKPOINT_ABS=""
CHECKPOINT_NAME=""
if [[ -n "$CHECKPOINT" ]]; then
    CONTROLLER_MODE="checkpoint"
    if [[ "$CHECKPOINT" == /* ]]; then
        CHECKPOINT_ABS="$CHECKPOINT"
    else
        CHECKPOINT_ABS="$PROJECT_ROOT/$CHECKPOINT"
    fi
    [[ -f "$CHECKPOINT_ABS" ]] || fail "checkpoint absent: $CHECKPOINT_ABS"
    CHECKPOINT_ABS="$(cd "$(dirname "$CHECKPOINT_ABS")" && pwd -P)/$(basename "$CHECKPOINT_ABS")"
    CHECKPOINT_NAME="$(basename "$CHECKPOINT_ABS")"
    CHECKPOINT_NAME="${CHECKPOINT_NAME%.*}"
    CHECKPOINT_NAME="${CHECKPOINT_NAME//[^[:alnum:]_.-]/_}"
    if ((MISSIONS_EXPLICIT == 0 || PROFILES_EXPLICIT == 0)); then
        fail "avec --checkpoint, précise explicitement --missions et --profiles (utilise 'all' explicitement si voulu)"
    fi
    if [[ -n "$FSM_INDEX" ]]; then
        fail "--fsm-index ne s'applique pas au mode checkpoint"
    fi
    if ((PARALLEL_FSMS != 1)); then
        printf 'AVERTISSEMENT: --parallel-fsms est ignoré en mode checkpoint.\n' >&2
    fi
else
    ((CHECKPOINT_OBSERVE == 0)) || fail "--observe exige --checkpoint"
    ((DETERMINISTIC == 0)) || fail "--deterministic exige --checkpoint"
fi

EFFECTIVE_NUM_ENVS="$NUM_ENVS"
if ((NUM_ENVS > EPISODES)) && ! [[ "$CONTROLLER_MODE" == "checkpoint" && "$CHECKPOINT_OBSERVE" -eq 1 ]]; then
    EFFECTIVE_NUM_ENVS="$EPISODES"
    if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
        printf 'AVERTISSEMENT: num-envs=%d > episodes=%d; utilisation de %d envs vectorisés.\n' \
            "$NUM_ENVS" "$EPISODES" "$EFFECTIVE_NUM_ENVS" >&2
    else
        printf 'AVERTISSEMENT: num-envs=%d > episodes=%d; utilisation de %d envs par FSM.\n' \
            "$NUM_ENVS" "$EPISODES" "$EFFECTIVE_NUM_ENVS" >&2
    fi
fi

EFFECTIVE_PARALLEL_FSMS="$PARALLEL_FSMS"
if [[ "$CONTROLLER_MODE" == "checkpoint" || -n "$FSM_INDEX" ]]; then
    EFFECTIVE_PARALLEL_FSMS=1
fi
if ((MAX_TOTAL_ENVS > 0)); then
    if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
        if ((EFFECTIVE_NUM_ENVS > MAX_TOTAL_ENVS)); then
            printf 'AVERTISSEMENT: plafond total=%d; réduction de num-envs de %d à %d.\n' \
                "$MAX_TOTAL_ENVS" "$EFFECTIVE_NUM_ENVS" "$MAX_TOTAL_ENVS" >&2
            EFFECTIVE_NUM_ENVS="$MAX_TOTAL_ENVS"
        fi
    else
        cap_width=$((MAX_TOTAL_ENVS / EFFECTIVE_NUM_ENVS))
        ((cap_width >= 1)) || fail "--max-total-envs est inférieur au nombre d'envs par FSM"
        if ((EFFECTIVE_PARALLEL_FSMS > cap_width)); then
            printf 'AVERTISSEMENT: plafond total=%d; réduction de parallel-fsms de %d à %d.\n' \
                "$MAX_TOTAL_ENVS" "$EFFECTIVE_PARALLEL_FSMS" "$cap_width" >&2
            EFFECTIVE_PARALLEL_FSMS="$cap_width"
        fi
    fi
fi
if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
    TOTAL_ENVS_PER_RUN="$EFFECTIVE_NUM_ENVS"
else
    TOTAL_ENVS_PER_RUN=$((EFFECTIVE_NUM_ENVS * EFFECTIVE_PARALLEL_FSMS))
fi

for mission in "${MISSIONS[@]}"; do
    for profile in "${PROFILES[@]}"; do
        config="$PROJECT_ROOT/configs/mercator/${mission}_${profile}_cyclamen.yaml"
        [[ -f "$config" ]] || fail "configuration absente: $config"
    done
done

if [[ "$CONTROLLER_MODE" == "checkpoint" && "$CHECKPOINT_OBSERVE" -eq 1 ]]; then
    ((${#MISSIONS[@]} == 1)) || fail "--observe exige exactement une mission"
    ((${#PROFILES[@]} == 1)) || fail "--observe exige exactement un profil"
    ((${#SEEDS[@]} == 1)) || fail "--observe exige exactement une seed"
    ((PARALLEL_SETUPS == 1)) || fail "--observe exige --parallel-setups 1"
    mission="${MISSIONS[0]}"
    profile="${PROFILES[0]}"
    seed="${SEEDS[0]}"
    config_rel="configs/mercator/${mission}_${profile}_cyclamen.yaml"
    cmd=(
        "$PYTHON_BIN" "$CONTROLLER_SCRIPT"
        --mission "$mission" --observe
        --config "$config_rel"
        --checkpoint "$CHECKPOINT_ABS"
        --num-episodes "$EPISODES"
        --seed "$seed"
        --print-every "$PRINT_EVERY"
    )
    ((DETERMINISTIC == 0)) || cmd+=(--deterministic)
    [[ -z "$DEVICE" ]] || cmd+=(--device "$DEVICE")
    printf 'Commande de visualisation: '
    quote_command "${cmd[@]}"
    ((DRY_RUN == 1)) && exit 0
    exec "${cmd[@]}"
fi

RUN_TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
if [[ -z "$CAMPAIGN_NAME" ]]; then
    if ((${#MISSIONS[@]} == ${#DEFAULT_MISSIONS[@]})); then
        mission_label="all-missions"
    else
        mission_label="$(IFS=-; printf '%s' "${MISSIONS[*]}")"
    fi
    if ((${#PROFILES[@]} == ${#DEFAULT_PROFILES[@]})); then
        profile_label="all-profiles"
    else
        profile_label="$(IFS=-; printf '%s' "${PROFILES[*]}")"
    fi
    if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
        CAMPAIGN_NAME="${mission_label}_${profile_label}_${CHECKPOINT_NAME}_${EPISODES}ep_${EFFECTIVE_NUM_ENVS}env"
    else
        CAMPAIGN_NAME="${mission_label}_${profile_label}_${EPISODES}ep-per-fsm_${EFFECTIVE_NUM_ENVS}env-per-fsm_${EFFECTIVE_PARALLEL_FSMS}fsm-par"
    fi
fi
# Évite les séparateurs de chemin accidentels dans le nom fourni.
CAMPAIGN_NAME="${CAMPAIGN_NAME//\//_}"
CAMPAIGN_DIR="$OUTPUT_ROOT/${CAMPAIGN_NAME}_${RUN_TIMESTAMP}"
if [[ -e "$CAMPAIGN_DIR" ]]; then
    CAMPAIGN_DIR="${CAMPAIGN_DIR}_$$"
fi

TOTAL_RUNS=$((${#MISSIONS[@]} * ${#PROFILES[@]} * ${#SEEDS[@]}))
FSM_LABEL="all-fsms"
[[ -n "$FSM_INDEX" ]] && FSM_LABEL="fsm-${FSM_INDEX}"
CONTROLLER_LABEL="$FSM_LABEL"
[[ "$CONTROLLER_MODE" == "checkpoint" ]] && CONTROLLER_LABEL="checkpoint-${CHECKPOINT_NAME}"

printf '%s\n' "============================================================"
printf 'Projet              : %s\n' "$PROJECT_ROOT"
printf 'Missions            : %s\n' "${MISSIONS[*]}"
printf 'Profils             : %s\n' "${PROFILES[*]}"
printf 'Seeds               : %s\n' "${SEEDS[*]}"
printf 'Mode contrôleur     : %s\n' "$CONTROLLER_MODE"
printf 'Épisodes            : %d\n' "$EPISODES"
printf 'Envs vectorisés     : %d\n' "$EFFECTIVE_NUM_ENVS"
printf 'FSM simultanées     : %d\n' "$EFFECTIVE_PARALLEL_FSMS"
printf 'Envs Isaac par run  : %d\n' "$TOTAL_ENVS_PER_RUN"
printf 'Contrôleur          : %s\n' "$CONTROLLER_LABEL"
printf 'Nombre de runs      : %d\n' "$TOTAL_RUNS"
printf 'Setups simultanés  : %d\n' "$PARALLEL_SETUPS"
printf 'Envs simultanés max: %d\n' "$((PARALLEL_SETUPS * TOTAL_ENVS_PER_RUN))"
printf 'Dossier de campagne : %s\n' "$CAMPAIGN_DIR"
printf 'Mode                 : %s\n' "$([[ "$DRY_RUN" -eq 1 ]] && echo simulation || echo exécution)"
printf '%s\n' "============================================================"

if ((DRY_RUN == 0)); then
    mkdir -p "$CAMPAIGN_DIR"
    MANIFEST="$CAMPAIGN_DIR/manifest.tsv"
    printf 'run\tmission\tprofile\tseed\tcontroller\tcheckpoint\tepisodes\tnum_envs\tparallel_fsms\ttotal_isaac_envs\tselection\tstatus\texit_code\tfolder\n' \
        > "$MANIFEST"
    {
        printf 'campaign_name=%s\n' "$CAMPAIGN_NAME"
        printf 'controller_mode=%s\n' "$CONTROLLER_MODE"
        printf 'checkpoint=%s\n' "${CHECKPOINT_ABS:-none}"
        printf 'deterministic=%s\n' "$DETERMINISTIC"
        printf 'created_at=%s\n' "$(date --iso-8601=seconds 2>/dev/null || date)"
        printf 'project_root=%s\n' "$PROJECT_ROOT"
        printf 'missions=%s\n' "${MISSIONS[*]}"
        printf 'profiles=%s\n' "${PROFILES[*]}"
        printf 'seeds=%s\n' "${SEEDS[*]}"
        printf 'episodes=%s\n' "$EPISODES"
        printf 'num_envs=%s\n' "$EFFECTIVE_NUM_ENVS"
        printf 'parallel_fsms=%s\n' "$EFFECTIVE_PARALLEL_FSMS"
        printf 'total_isaac_envs_per_run=%s\n' "$TOTAL_ENVS_PER_RUN"
        printf 'parallel_setups=%s\n' "$PARALLEL_SETUPS"
        printf 'max_simultaneous_envs=%s\n' "$((PARALLEL_SETUPS * TOTAL_ENVS_PER_RUN))"
        printf 'controller_selection=%s\n' "$CONTROLLER_LABEL"
        printf 'python=%s\n' "$PYTHON_BIN"
        printf 'device=%s\n' "${DEVICE:-default}"
        if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
            printf 'git_commit=%s\n' "$(git rev-parse HEAD)"
            printf 'git_dirty=%s\n' "$(git status --porcelain | wc -l | tr -d ' ')"
        fi
    } > "$CAMPAIGN_DIR/campaign_metadata.txt"
fi

run_number=0
success_count=0
failure_count=0

# Les processus sont lancés par lots de PARALLEL_SETUPS. Le parent est le seul
# à écrire dans le manifest, ce qui évite les écritures concurrentes.
BATCH_PIDS=()
BATCH_RUN_NUMBERS=()
BATCH_MISSIONS=()
BATCH_PROFILES=()
BATCH_SEEDS=()
BATCH_RUN_NAMES=()
BATCH_RUN_DIRS=()

execute_run() {
    local run_number="$1"
    local mission="$2"
    local profile="$3"
    local seed="$4"
    local run_name="$5"
    local run_dir="$6"
    local config_rel="$7"
    local result_file="$run_dir/.job_result"
    local status rc
    local -a cmd=("$PYTHON_BIN" "$CONTROLLER_SCRIPT" --mission "$mission" --score --config "$config_rel")
    if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
        cmd+=(
            --checkpoint "$CHECKPOINT_ABS"
            --episodes "$EPISODES"
            --num-envs "$EFFECTIVE_NUM_ENVS"
            --max-total-envs "$MAX_TOTAL_ENVS"
            --seed "$seed"
            --output-dir "$run_dir"
            --print-every "$PRINT_EVERY"
        )
        ((DETERMINISTIC == 0)) || cmd+=(--deterministic)
    else
        cmd+=(
            --episodes "$EPISODES"
            --num-envs "$EFFECTIVE_NUM_ENVS"
            --parallel-fsms "$EFFECTIVE_PARALLEL_FSMS"
            --max-total-envs "$MAX_TOTAL_ENVS"
            --seed "$seed"
            --output-dir "$run_dir"
            --print-every "$PRINT_EVERY"
        )
        if [[ -n "$FSM_INDEX" ]]; then
            cmd+=(--fsm-index "$FSM_INDEX")
        else
            cmd+=(--all-fsms)
        fi
    fi
    if [[ -n "$DEVICE" ]]; then
        cmd+=(--device "$DEVICE")
    fi

    mkdir -p "$run_dir"
    quote_command "${cmd[@]}" > "$run_dir/command.sh"
    chmod +x "$run_dir/command.sh"
    {
        printf 'run_number=%s\n' "$run_number"
        printf 'mission=%s\n' "$mission"
        printf 'robot_profile=%s\n' "$profile"
        printf 'config=%s\n' "$config_rel"
        printf 'controller_mode=%s\n' "$CONTROLLER_MODE"
        printf 'checkpoint=%s\n' "${CHECKPOINT_ABS:-none}"
        printf 'deterministic=%s\n' "$DETERMINISTIC"
        printf 'episodes=%s\n' "$EPISODES"
        printf 'num_envs=%s\n' "$EFFECTIVE_NUM_ENVS"
        printf 'parallel_fsms=%s\n' "$EFFECTIVE_PARALLEL_FSMS"
        printf 'total_isaac_envs=%s\n' "$TOTAL_ENVS_PER_RUN"
        printf 'parallel_setups=%s\n' "$PARALLEL_SETUPS"
        printf 'seed=%s\n' "$seed"
        printf 'controller_selection=%s\n' "$CONTROLLER_LABEL"
        printf 'pid=%s\n' "$BASHPID"
        printf 'started_at=%s\n' "$(date --iso-8601=seconds 2>/dev/null || date)"
    } > "$run_dir/metadata.txt"

    set +e
    if ((PARALLEL_SETUPS > 1)); then
        "${cmd[@]}" 2>&1 \
            | sed -u "s/^/[${run_name}] /" \
            | tee "$run_dir/run.log"
        rc=${PIPESTATUS[0]}
    else
        "${cmd[@]}" 2>&1 | tee "$run_dir/run.log"
        rc=${PIPESTATUS[0]}
    fi
    set -e

    if ((rc == 0)); then
        status="success"
    else
        status="failed"
    fi
    {
        printf 'status=%s\n' "$status"
        printf 'exit_code=%s\n' "$rc"
    } > "$result_file"
    printf 'finished_at=%s\nstatus=%s\nexit_code=%d\n' \
        "$(date --iso-8601=seconds 2>/dev/null || date)" "$status" "$rc" \
        >> "$run_dir/metadata.txt"
    return "$rc"
}

wait_for_batch() {
    local index pid wait_rc result_file status rc
    local batch_failed=0

    for index in "${!BATCH_PIDS[@]}"; do
        pid="${BATCH_PIDS[$index]}"
        set +e
        wait "$pid"
        wait_rc=$?
        set -e

        result_file="${BATCH_RUN_DIRS[$index]}/.job_result"
        status="failed"
        rc="$wait_rc"
        if [[ -f "$result_file" ]]; then
            # shellcheck disable=SC1090
            source "$result_file"
            rm -f "$result_file"
        fi

        if [[ "$status" == "success" && "$rc" -eq 0 ]]; then
            success_count=$((success_count + 1))
            printf '[TERMINE] %s : succès\n' "${BATCH_RUN_NAMES[$index]}"
        else
            failure_count=$((failure_count + 1))
            batch_failed=1
            printf '[TERMINE] %s : échec (code %s). Log: %s\n' \
                "${BATCH_RUN_NAMES[$index]}" "$rc" \
                "${BATCH_RUN_DIRS[$index]}/run.log" >&2
        fi

        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            "${BATCH_RUN_NUMBERS[$index]}" "${BATCH_MISSIONS[$index]}" \
            "${BATCH_PROFILES[$index]}" "${BATCH_SEEDS[$index]}" \
            "$CONTROLLER_MODE" "${CHECKPOINT_ABS:-}" "$EPISODES" \
            "$EFFECTIVE_NUM_ENVS" "$EFFECTIVE_PARALLEL_FSMS" \
            "$TOTAL_ENVS_PER_RUN" "$CONTROLLER_LABEL" "$status" "$rc" \
            "${BATCH_RUN_DIRS[$index]}" \
            >> "$MANIFEST"
    done

    BATCH_PIDS=()
    BATCH_RUN_NUMBERS=()
    BATCH_MISSIONS=()
    BATCH_PROFILES=()
    BATCH_SEEDS=()
    BATCH_RUN_NAMES=()
    BATCH_RUN_DIRS=()

    if ((batch_failed != 0 && CONTINUE_ON_ERROR == 0)); then
        printf 'Arrêt après le lot courant. Utilise --continue-on-error pour poursuivre.\n' >&2
        return 1
    fi
    return 0
}

for mission in "${MISSIONS[@]}"; do
    for profile in "${PROFILES[@]}"; do
        config_rel="configs/mercator/${mission}_${profile}_cyclamen.yaml"
        for seed in "${SEEDS[@]}"; do
            run_number=$((run_number + 1))
            if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
                run_name="${mission}_${profile}_${CHECKPOINT_NAME}_${EPISODES}ep_${EFFECTIVE_NUM_ENVS}env_seed${seed}"
            else
                run_name="${mission}_${profile}_${EPISODES}ep-per-fsm_${EFFECTIVE_NUM_ENVS}env-per-fsm_${EFFECTIVE_PARALLEL_FSMS}fsm-par_seed${seed}_${FSM_LABEL}"
            fi
            run_dir="$CAMPAIGN_DIR/$run_name"

            cmd=("$PYTHON_BIN" "$CONTROLLER_SCRIPT" --mission "$mission" --score --config "$config_rel")
            if [[ "$CONTROLLER_MODE" == "checkpoint" ]]; then
                cmd+=(
                    --checkpoint "$CHECKPOINT_ABS"
                    --episodes "$EPISODES"
                    --num-envs "$EFFECTIVE_NUM_ENVS"
                    --max-total-envs "$MAX_TOTAL_ENVS"
                    --seed "$seed"
                    --output-dir "$run_dir"
                    --print-every "$PRINT_EVERY"
                )
                ((DETERMINISTIC == 0)) || cmd+=(--deterministic)
            else
                cmd+=(
                    --episodes "$EPISODES"
                    --num-envs "$EFFECTIVE_NUM_ENVS"
                    --parallel-fsms "$EFFECTIVE_PARALLEL_FSMS"
                    --max-total-envs "$MAX_TOTAL_ENVS"
                    --seed "$seed"
                    --output-dir "$run_dir"
                    --print-every "$PRINT_EVERY"
                )
                if [[ -n "$FSM_INDEX" ]]; then
                    cmd+=(--fsm-index "$FSM_INDEX")
                else
                    cmd+=(--all-fsms)
                fi
            fi
            if [[ -n "$DEVICE" ]]; then
                cmd+=(--device "$DEVICE")
            fi

            printf '\n[%d/%d] %s / %s / seed %s\n' \
                "$run_number" "$TOTAL_RUNS" "$mission" "$profile" "$seed"
            printf 'Commande: '
            quote_command "${cmd[@]}"
            printf 'Sortie  : %s\n' "$run_dir"

            if ((DRY_RUN == 1)); then
                continue
            fi

            execute_run "$run_number" "$mission" "$profile" "$seed" \
                "$run_name" "$run_dir" "$config_rel" &
            BATCH_PIDS+=("$!")
            BATCH_RUN_NUMBERS+=("$run_number")
            BATCH_MISSIONS+=("$mission")
            BATCH_PROFILES+=("$profile")
            BATCH_SEEDS+=("$seed")
            BATCH_RUN_NAMES+=("$run_name")
            BATCH_RUN_DIRS+=("$run_dir")

            if ((${#BATCH_PIDS[@]} >= PARALLEL_SETUPS)); then
                wait_for_batch || exit 1
            fi
        done
    done
done

if ((DRY_RUN == 0 && ${#BATCH_PIDS[@]} > 0)); then
    wait_for_batch || exit 1
fi

if ((DRY_RUN == 1)); then
    printf '\nSimulation terminée : %d commandes validées.\n' "$TOTAL_RUNS"
    exit 0
fi

{
    printf 'total_runs=%d\n' "$TOTAL_RUNS"
    printf 'successes=%d\n' "$success_count"
    printf 'failures=%d\n' "$failure_count"
    printf 'parallel_setups=%d\n' "$PARALLEL_SETUPS"
    printf 'controller_mode=%s\n' "$CONTROLLER_MODE"
    printf 'checkpoint=%s\n' "${CHECKPOINT_ABS:-none}"
    printf 'deterministic=%s\n' "$DETERMINISTIC"
    printf 'parallel_fsms=%d\n' "$EFFECTIVE_PARALLEL_FSMS"
    printf 'num_envs=%d\n' "$EFFECTIVE_NUM_ENVS"
    printf 'total_isaac_envs_per_run=%d\n' "$TOTAL_ENVS_PER_RUN"
    printf 'completed_at=%s\n' "$(date --iso-8601=seconds 2>/dev/null || date)"
} > "$CAMPAIGN_DIR/campaign_summary.txt"

printf '\n============================================================\n'
printf 'Campagne terminée. Succès: %d, échecs: %d.\n' "$success_count" "$failure_count"
printf 'Résultats: %s\n' "$CAMPAIGN_DIR"
printf 'Manifest: %s\n' "$MANIFEST"
printf '============================================================\n'

((failure_count == 0)) || exit 1