# Mercator Experiment 1 — Foraging

This addition implements the Mercator **foraging** mission from Experiment 1 and keeps the existing Mercator aggregation mission independent.

## Added task

Gym task:

```text
SwarmACB-MercatorForaging-v0
```

Configuration:

```text
configs/mercator/FOR_mercator_cyclamen.yaml
```

The mission uses:

- 20 Mercator robots;
- 120 seconds per episode at 10 controller ticks per second;
- two black food sources centered at `(2.9, 0.0)` and `(-2.9, 0.0)`, radius `0.58 m`;
- the source loop-function's hand-built white nest polygon below `y = -2.35 m` for ground sensing;
- the source scoring rule `robot_center_y <= -2.35 m` for delivery;
- one carried food unit at most per robot;
- one reward point when a carrying robot reaches the nest.

The white floor and delivery test are deliberately separate. This mirrors the source code: the floor color uses five explicit triangles and the objective uses only the robot center's `y` coordinate.

## Train a learned controller

```bash
python scripts/train.py \
  --config configs/mercator/FOR_mercator_cyclamen.yaml \
  --headless
```

`train_fast.py` remains aggregation-specific and was not silently generalized. Use `train.py` for this mission.

## Visualize a learned controller or fixed module

The existing generic Mercator visualizer now supports both aggregation and foraging.

Fixed AutoMoDe module:

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/FOR_mercator_cyclamen.yaml \
  --module 0
```

Checkpoint:

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/FOR_mercator_cyclamen.yaml \
  --checkpoint checkpoints/FOR_mercator_cyclamen_/checkpoint_latest.pt \
  --deterministic
```

Foraging output reports deliveries, pickups, robots carrying food, robots on a food source and robots in the scoring nest. Aggregation output remains `N_black` and `N_white`.

## Observe a real Chocolate FSM

The exact ten Experiment-1 Mercator foraging FSM strings are stored in:

```text
configs/mercator/fsms/fsm_mercator_foraging_experiment1.txt
```

Visualize FSM 1, coloring robots by FSM state:

```bash
python scripts/mercator_fsm.py --mission FOR --observe --fsm-index 1
```

Color by AutoMoDe module instead:

```bash
python scripts/mercator_fsm.py --mission FOR --observe \
  --fsm-index 1 \
  --color-by module
```

Run a finite number of episodes:

```bash
python scripts/mercator_fsm.py --mission FOR --observe \
  --fsm-index 1 \
  --num-episodes 5 \
  --seed 0
```

## Evaluate Chocolate FSMs headlessly

One FSM:

```bash
python scripts/mercator_fsm.py --mission FOR --score \
  --fsm-index 1 \
  --episodes 50 \
  --num-envs 25 \
  --seed 0
```

All ten FSMs:

```bash
python scripts/mercator_fsm.py --mission FOR --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 50 \
  --seed 0
```

Outputs are written to:

```text
results/mercator_foraging_fsm/
```

The evaluator produces:

- per-episode CSV;
- summary CSV;
- detailed JSON including the original FSM strings;
- deliveries and pickups;
- delivery efficiency;
- deliveries per robot and per 1000 robot-steps;
- carrying, food-source and nest occupancy statistics;
- transition totals and state occupancy fractions.

## Tests independent of Isaac Sim

```bash
pytest -q \
  tests/test_mercator_foraging_model.py \
  tests/test_mercator_foraging_assets.py \
  tests/test_mercator_foraging_env_contract.py
```

These tests compare the vectorized floor classifier against an independent translation of the source five-triangle implementation, compare batched pickup/delivery trajectories against a scalar PostStep reference, exercise the environment reward/reset contract with lightweight Isaac stubs, parse all ten FSMs, validate the YAML and verify the FOR compatibility launchers of the unified FSM engine.
