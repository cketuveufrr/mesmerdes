# Mercator Foraging — Experiment 2

## Entraînement

```bash
python scripts/train.py \
  --config configs/mercator/FOR2_mercator_cyclamen.yaml \
  --headless
```

Tâche Gymnasium :

```text
SwarmACB-MercatorForaging2-v0
```

## Observer une FSM Chocolate

```bash
python scripts/mercator_fsm.py \
  --mission FOR2 \
  --observe \
  --fsm-index 1
```

## Évaluer une FSM

```bash
python scripts/mercator_fsm.py \
  --mission FOR2 \
  --score \
  --fsm-index 1 \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

## Évaluer les dix FSM

```bash
python scripts/mercator_fsm.py \
  --mission FOR2 \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

Rapports :

```text
results/mercator_foraging2_fsm/
```

## Visualiser un module fixe ou un checkpoint

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/FOR2_mercator_cyclamen.yaml \
  --module 0
```

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/FOR2_mercator_cyclamen.yaml \
  --checkpoint checkpoints/FOR2_mercator_cyclamen_/checkpoint_latest.pt \
  --deterministic
```

## Contrat de mission

- 3 Mercator, 120 s, 10 Hz ;
- petite arène dodécagonale à murs de 0.70 m ;
- sources en `(+0.8, 0)` et `(-0.8, 0)`, rayon `0.265 m` ;
- livraison lorsque le centre du robot atteint `y <= -0.63` ;
- sol blanc visible uniquement dans le polygone exact à cinq triangles ;
- placement initial uniforme dans le disque de rayon `1.2 m` ;
- lumière volontairement active à `1.0`, comme dans `AAC2`, malgré la valeur
  nulle du XML ARGoS, car les FSM contiennent des modules phototaxiques.
