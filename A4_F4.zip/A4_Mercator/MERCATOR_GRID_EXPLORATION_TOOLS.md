# Mercator Grid Exploration — Experiment 1

## Entraînement

```bash
python scripts/train.py \
  --config configs/mercator/GRID_mercator_cyclamen.yaml \
  --headless
```

La tâche enregistrée est :

```text
SwarmACB-MercatorGridExploration-v0
```

## Observer une vraie FSM Chocolate

```bash
python scripts/mercator_fsm.py \
  --mission GRID \
  --observe \
  --fsm-index 1
```

## Évaluer une FSM

```bash
python scripts/mercator_fsm.py \
  --mission GRID \
  --score \
  --fsm-index 1 \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

## Évaluer les dix FSM

```bash
python scripts/mercator_fsm.py \
  --mission GRID \
  --score \
  --all-fsms \
  --episodes 100 \
  --num-envs 20 \
  --seed 0
```

Les rapports sont écrits dans :

```text
results/mercator_grid_exploration_fsm/
```

## Visualiser un module fixe ou un checkpoint

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/GRID_mercator_cyclamen.yaml \
  --module 0
```

```bash
python scripts/visualize_mercator.py \
  --config configs/mercator/GRID_mercator_cyclamen.yaml \
  --checkpoint checkpoints/GRID_mercator_cyclamen_/checkpoint_latest.pt \
  --deterministic
```

## Objectif

La grille contient 100 cases et commence avec des âges nuls. Les cases occupées
sont remises à zéro avant la somme, puis toutes les cases sont incrémentées.
La récompense par pas est la contribution négative à l'objectif final :

```text
reward_t = -sum(grid_age_after_reset) / 100
```

Le score total de l'épisode est donc celui de l'expérience ARGoS, sans
transformation postérieure.
