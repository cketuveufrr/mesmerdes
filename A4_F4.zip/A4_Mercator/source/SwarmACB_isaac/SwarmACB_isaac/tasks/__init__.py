# Copyright (c) 2022-2026, The Isaac Lab Project Developers and SwarmACB Project.
# SPDX-License-Identifier: BSD-3-Clause

"""Task implementations and optional Isaac Lab task registration."""

from __future__ import annotations

import os

if os.environ.get("SWARMACB_SKIP_ISAAC_TASKS", "0") != "1":
    from isaaclab_tasks.utils import import_packages

    _BLACKLIST_PKGS = ["utils", ".mdp"]
    import_packages(__name__, _BLACKLIST_PKGS)
