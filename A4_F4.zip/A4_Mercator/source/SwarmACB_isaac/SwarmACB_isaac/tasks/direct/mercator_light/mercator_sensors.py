# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Analytical, vectorized Mercator sensors for the light environment."""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch

from .mercator_geometry import (
    ray_circle_distances,
    ray_obb_distances,
    rotate_body_to_world,
    rotate_world_to_body,
)


@dataclass(frozen=True)
class MercatorSensorBatch:
    proximity_values: torch.Tensor
    proximity_vector: torch.Tensor
    proximity_value: torch.Tensor
    proximity_angle: torch.Tensor
    light_values: torch.Tensor
    light_vector: torch.Tensor
    light_value: torch.Tensor
    light_angle: torch.Tensor
    neighbor_vector: torch.Tensor
    neighbor_count: torch.Tensor
    ztilde: torch.Tensor
    rab_projection: torch.Tensor


class MercatorLightSensors:
    """Pure-PyTorch substitute for TeraRanger, light, and LiDAR helpers.

    Constants and pair masks are cached once.  ``compute_cyclamen_ztilde`` is a
    deliberately narrow path for the post-step Cyclamen observation: it avoids
    the expensive proximity/light calculations and avoids a square root because
    only a range comparison and a count are required.
    """

    TERARANGER_OFFSETS = (
        (0.11825904152742861, 0.05063464246131841),
        (0.13026674673181537, -0.02204736293376039),
        (0.13026674673181537, 0.025552669396148718),
        (0.12014562013657096, -0.04114536157106244),
        (0.033117440184081914, -0.12388582081733537),
        (-0.11267632248954594, -0.10500550954394722),
        (-0.11539140389651859, 0.10488722317959201),
        (0.03118668411692954, 0.12209330094360893),
    )
    TERARANGER_HEADINGS = (
        math.radians(45.0),
        0.0,
        0.0,
        math.radians(-45.0),
        math.radians(-90.0),
        math.radians(-145.0),
        math.radians(145.0),
        math.radians(90.0),
    )
    UNIFORM_RING_HEADINGS = (
        math.radians(45.0),
        0.0,
        math.radians(-45.0),
        math.radians(-90.0),
        math.radians(-135.0),
        math.radians(180.0),
        math.radians(135.0),
        math.radians(90.0),
    )

    def __init__(
        self,
        *,
        device: torch.device | str = "cpu",
        robot_half_length: float = 0.13,
        robot_half_width: float = 0.125,
        collision_shape: str = "obb",
        robot_collision_radius: float = 0.105,
        teraranger_layout: str = "native_asymmetric",
        teraranger_ring_radius: float = 0.143,
        teraranger_max_range: float = 2.0,
        teraranger_origin_offset: float = 0.005,
        neighbor_min_range: float = 0.10,
        neighbor_max_range: float = 0.75,
        neighbor_alpha: float = 1.0,
        cyclamen_neighbor_range: float = 0.78,
        tower_offset: tuple[float, float] = (0.00343, -0.00036),
        light_max_distance: float = 12.0,
        light_enabled: bool = True,
    ):
        self.device = torch.device(device)
        self.robot_half_length = float(robot_half_length)
        self.robot_half_width = float(robot_half_width)
        self.collision_shape = str(collision_shape).strip().lower()
        self.robot_collision_radius = float(robot_collision_radius)
        if self.collision_shape not in ("obb", "circle"):
            raise ValueError("collision_shape must be obb or circle")
        if self.robot_collision_radius <= 0.0:
            raise ValueError("robot_collision_radius must be positive")
        self.teraranger_layout = str(teraranger_layout).strip().lower()
        self.teraranger_ring_radius = float(teraranger_ring_radius)
        self.teraranger_max_range = float(teraranger_max_range)
        self.teraranger_origin_offset = float(teraranger_origin_offset)
        if self.teraranger_ring_radius < 0.0:
            raise ValueError("teraranger_ring_radius must be non-negative")
        if self.teraranger_max_range <= 0.0:
            raise ValueError("teraranger_max_range must be positive")
        self.neighbor_min_range = float(neighbor_min_range)
        self.neighbor_max_range = float(neighbor_max_range)
        self.neighbor_alpha = float(neighbor_alpha)
        self.cyclamen_neighbor_range = float(cyclamen_neighbor_range)
        self.cyclamen_neighbor_range_sq = self.cyclamen_neighbor_range**2
        self.light_max_distance = float(light_max_distance)
        self.light_enabled = bool(light_enabled)

        if self.teraranger_layout == "native_asymmetric":
            offsets = self.TERARANGER_OFFSETS
            headings = self.TERARANGER_HEADINGS
            self.sensor_angles = torch.tensor(
                headings, dtype=torch.float32, device=self.device
            )
            self.sensor_dirs = torch.stack(
                (torch.cos(self.sensor_angles), torch.sin(self.sensor_angles)), dim=-1
            )
            self.sensor_offsets = torch.tensor(
                offsets, dtype=torch.float32, device=self.device
            )
        elif self.teraranger_layout == "uniform_ring":
            self.sensor_angles = torch.tensor(
                self.UNIFORM_RING_HEADINGS, dtype=torch.float32, device=self.device
            )
            self.sensor_dirs = torch.stack(
                (torch.cos(self.sensor_angles), torch.sin(self.sensor_angles)), dim=-1
            )
            self.sensor_offsets = self.teraranger_ring_radius * self.sensor_dirs
        else:
            raise ValueError(
                "Unsupported teraranger_layout "
                f"{teraranger_layout!r}; choose native_asymmetric or uniform_ring"
            )
        self.local_ray_origins = self.sensor_offsets + (
            self.teraranger_origin_offset * self.sensor_dirs
        )
        self.tower_offset = torch.tensor(
            tower_offset, dtype=torch.float32, device=self.device
        )
        self.light_sector_angles = torch.arange(
            8, device=self.device, dtype=torch.float32
        ) * (2.0 * math.pi / 8.0)
        self.light_sector_dirs = torch.stack(
            (torch.cos(self.light_sector_angles), torch.sin(self.light_sector_angles)),
            dim=-1,
        )
        self.cardinal_dirs = torch.tensor(
            ((1.0, 0.0), (0.0, 1.0), (-1.0, 0.0), (0.0, -1.0)),
            dtype=torch.float32,
            device=self.device,
        )
        self._not_self_masks: dict[int, torch.Tensor] = {}
        self._bound_wall_ptr: int | None = None
        self._bound_wall_a: torch.Tensor | None = None
        self._bound_wall_seg: torch.Tensor | None = None

    def _not_self(self, n: int, device: torch.device) -> torch.Tensor:
        mask = self._not_self_masks.get(int(n))
        if mask is None or mask.device != device:
            mask = ~torch.eye(n, dtype=torch.bool, device=device).unsqueeze(0)
            self._not_self_masks[int(n)] = mask
        return mask

    def bind_wall_segments(self, segments: torch.Tensor) -> None:
        """Cache immutable wall endpoints used at every control step."""
        self._bound_wall_ptr = int(segments.data_ptr())
        self._bound_wall_a = segments[:, 0]
        self._bound_wall_seg = segments[:, 1] - segments[:, 0]

    def _prepared_segments(self, segments: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if self._bound_wall_ptr == int(segments.data_ptr()):
            assert self._bound_wall_a is not None and self._bound_wall_seg is not None
            return self._bound_wall_a, self._bound_wall_seg
        return segments[:, 0], segments[:, 1] - segments[:, 0]

    def _ray_segment_distances(
        self,
        origins: torch.Tensor,
        directions: torch.Tensor,
        segments: torch.Tensor,
        max_range: float,
    ) -> torch.Tensor:
        """Return closest ray hit against finite line segments."""
        a, seg = self._prepared_segments(segments)
        o = origins.unsqueeze(-2)
        d = directions.unsqueeze(-2)
        a = a.view(*([1] * (origins.ndim - 1)), -1, 2)
        seg = seg.view(*([1] * (origins.ndim - 1)), -1, 2)
        ao = a - o
        cross_ds = d[..., 0] * seg[..., 1] - d[..., 1] * seg[..., 0]
        valid = cross_ds.abs() > 1e-9
        safe_denom = torch.where(valid, cross_ds, torch.ones_like(cross_ds))
        t = (ao[..., 0] * seg[..., 1] - ao[..., 1] * seg[..., 0]) / safe_denom
        u = (ao[..., 0] * d[..., 1] - ao[..., 1] * d[..., 0]) / safe_denom
        hit = valid & (t >= 0.0) & (t <= float(max_range)) & (u >= 0.0) & (u <= 1.0)
        return torch.where(
            hit, t, torch.full_like(t, float(max_range))
        ).min(dim=-1).values

    @staticmethod
    def distance_to_proximity(distance: torch.Tensor) -> torch.Tensor:
        """RVR DAO curve: active only from 5 to 40 cm."""
        valid = (distance >= 0.05) & (distance <= 0.40)
        p = ((1.0 / distance.clamp_min(1e-8)) - 2.5) / 17.5
        return torch.where(valid, p.clamp(0.0, 1.0), torch.zeros_like(distance))

    def compute_proximity(
        self,
        positions: torch.Tensor,
        yaws: torch.Tensor,
        wall_segments: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        e, n = positions.shape[:2]
        local_dirs = self.sensor_dirs.view(1, 1, 8, 2)
        local_origins = self.local_ray_origins.view(1, 1, 8, 2)
        ray_yaw = yaws.unsqueeze(-1) + self.sensor_angles.view(1, 1, 8)
        world_dirs = torch.stack((torch.cos(ray_yaw), torch.sin(ray_yaw)), dim=-1)
        world_origins = positions.unsqueeze(-2) + rotate_body_to_world(
            local_origins.expand(e, n, -1, -1), yaws.unsqueeze(-1)
        )

        wall_dist = self._ray_segment_distances(
            world_origins, world_dirs, wall_segments, self.teraranger_max_range
        )

        if self.collision_shape == "circle":
            robot_dist = ray_circle_distances(
                world_origins.unsqueeze(-2),
                world_dirs.unsqueeze(-2),
                positions[:, None, None, :, :],
                self.robot_collision_radius,
                self.teraranger_max_range,
            )
        else:
            robot_dist = ray_obb_distances(
                world_origins.unsqueeze(-2),
                world_dirs.unsqueeze(-2),
                positions[:, None, None, :, :],
                yaws[:, None, None, :],
                self.robot_half_length,
                self.robot_half_width,
                self.teraranger_max_range,
            )
        eye = ~self._not_self(n, positions.device).view(1, n, 1, n)
        robot_dist = torch.where(
            eye, torch.full_like(robot_dist, self.teraranger_max_range), robot_dist
        ).min(dim=-1).values
        distance = torch.minimum(wall_dist, robot_dist)
        readings = self.distance_to_proximity(distance)

        raw_vector = (readings.unsqueeze(-1) * local_dirs).sum(dim=-2)
        raw_norm = torch.linalg.vector_norm(raw_vector, dim=-1)
        value = raw_norm.clamp(max=1.0)
        angle = torch.where(
            raw_norm > 1e-9,
            torch.atan2(raw_vector[..., 1], raw_vector[..., 0]),
            torch.zeros_like(raw_norm),
        )
        return readings, raw_vector, value, angle

    def compute_light(
        self,
        positions: torch.Tensor,
        yaws: torch.Tensor,
        light_xy: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        to_light_world = light_xy.view(1, 1, 2) - positions
        distance = torch.linalg.vector_norm(to_light_world, dim=-1)
        to_light_body = rotate_world_to_body(to_light_world, yaws)
        angle = torch.atan2(to_light_body[..., 1], to_light_body[..., 0])
        dist_gain = (
            1.0
            - distance.clamp(max=self.light_max_distance) / self.light_max_distance
        ).clamp_min(0.0)
        sectors = self.light_sector_angles.view(1, 1, 8)
        delta = torch.atan2(
            torch.sin(angle.unsqueeze(-1) - sectors),
            torch.cos(angle.unsqueeze(-1) - sectors),
        )
        values = dist_gain.unsqueeze(-1) * torch.cos(delta).clamp_min(0.0)
        if not self.light_enabled:
            values = torch.zeros_like(values)
        vector = (
            values.unsqueeze(-1) * self.light_sector_dirs.view(1, 1, 8, 2)
        ).sum(dim=-2)
        norm = torch.linalg.vector_norm(vector, dim=-1)
        value = norm.clamp(max=1.0)
        agg_angle = torch.where(
            norm > 1e-9,
            torch.atan2(vector[..., 1], vector[..., 0]),
            torch.zeros_like(norm),
        )
        return values, vector, value, agg_angle

    def tower_centers_xy(self, positions: torch.Tensor, yaws: torch.Tensor) -> torch.Tensor:
        return positions + rotate_body_to_world(
            self.tower_offset.view(1, 1, 2).expand_as(positions), yaws
        )

    def compute_cyclamen_ztilde(
        self, positions: torch.Tensor, yaws: torch.Tensor
    ) -> torch.Tensor:
        """Compute only Cyclamen's nonlinear neighbour-count observation."""
        centers = self.tower_centers_xy(positions, yaws)
        delta = centers.unsqueeze(1) - centers.unsqueeze(2)
        dist_sq = (delta * delta).sum(dim=-1)
        mask = (dist_sq <= self.cyclamen_neighbor_range_sq) & self._not_self(
            positions.shape[1], positions.device
        )
        count = mask.sum(dim=-1).to(torch.float32)
        return torch.tanh(0.5 * count)

    def compute_neighbors(
        self,
        positions: torch.Tensor,
        yaws: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Direct tower-center neighbours; no ray casting or clustering."""
        centers = self.tower_centers_xy(positions, yaws)
        delta_world = centers.unsqueeze(1) - centers.unsqueeze(2)
        dist_sq = (delta_world * delta_world).sum(dim=-1)
        dist = torch.sqrt(dist_sq)
        not_self = self._not_self(positions.shape[1], positions.device)
        mask = (
            (dist >= self.neighbor_min_range)
            & (dist <= self.neighbor_max_range)
            & not_self
        )
        unit_world = delta_world / dist.unsqueeze(-1).clamp_min(1e-8)
        unit_body = rotate_world_to_body(unit_world, yaws.unsqueeze(-1))
        distance_cm = 100.0 * dist
        gain = self.neighbor_alpha / (1.0 + distance_cm)
        vector = (unit_body * gain.unsqueeze(-1) * mask.unsqueeze(-1)).sum(dim=-2)
        count = mask.sum(dim=-1).to(torch.float32)

        cyclamen_mask = (dist_sq <= self.cyclamen_neighbor_range_sq) & not_self
        cyclamen_count = cyclamen_mask.sum(dim=-1).to(torch.float32)
        ztilde = torch.tanh(0.5 * cyclamen_count)

        rab_projection = torch.einsum(
            "enq,cq->enc", vector, self.cardinal_dirs.to(dtype=vector.dtype)
        )
        return vector, count, ztilde, rab_projection

    @staticmethod
    def compute_pose_neighbor_ztilde(
        tower_centers: torch.Tensor,
        neighbor_range: float,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        delta = tower_centers.unsqueeze(1) - tower_centers.unsqueeze(2)
        dist_sq = (delta * delta).sum(dim=-1)
        n = tower_centers.shape[1]
        mask = (dist_sq <= float(neighbor_range) ** 2) & (
            ~torch.eye(n, dtype=torch.bool, device=tower_centers.device).unsqueeze(0)
        )
        count = mask.sum(dim=-1).to(torch.float32)
        return count, torch.tanh(0.5 * count)

    def compute_all(
        self,
        positions: torch.Tensor,
        yaws: torch.Tensor,
        wall_segments: torch.Tensor,
        light_xy: torch.Tensor,
    ) -> MercatorSensorBatch:
        prox_values, prox_vector, prox_value, prox_angle = self.compute_proximity(
            positions, yaws, wall_segments
        )
        light_values, light_vector, light_value, light_angle = self.compute_light(
            positions, yaws, light_xy
        )
        neighbor_vector, neighbor_count, ztilde, rab_projection = self.compute_neighbors(
            positions, yaws
        )
        return MercatorSensorBatch(
            proximity_values=prox_values,
            proximity_vector=prox_vector,
            proximity_value=prox_value,
            proximity_angle=prox_angle,
            light_values=light_values,
            light_vector=light_vector,
            light_value=light_value,
            light_angle=light_angle,
            neighbor_vector=neighbor_vector,
            neighbor_count=neighbor_count,
            ztilde=ztilde,
            rab_projection=rab_projection,
        )

    @staticmethod
    def compute_critic_state_5d(
        positions: torch.Tensor,
        yaws: torch.Tensor,
        arena_radius: float,
        light_direction_world: torch.Tensor,
    ) -> torch.Tensor:
        radius = torch.linalg.vector_norm(positions, dim=-1)
        rho = (radius / max(float(arena_radius), 1e-8)).clamp(0.0, 1.0)
        radial = positions / radius.unsqueeze(-1).clamp_min(1e-8)
        light = light_direction_world / torch.linalg.vector_norm(
            light_direction_world
        ).clamp_min(1e-8)
        cos_alpha = (radial * light.view(1, 1, 2)).sum(dim=-1)
        sin_alpha = radial[..., 0] * light[1] - radial[..., 1] * light[0]
        heading = torch.stack((torch.cos(yaws), torch.sin(yaws)), dim=-1)
        cos_beta = (heading * radial).sum(dim=-1)
        sin_beta = radial[..., 0] * heading[..., 1] - radial[..., 1] * heading[..., 0]
        return torch.stack((rho, cos_alpha, sin_alpha, cos_beta, sin_beta), dim=-1)
