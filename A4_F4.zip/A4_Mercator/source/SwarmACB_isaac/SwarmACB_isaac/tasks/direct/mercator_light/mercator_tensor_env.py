# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Standalone tensor-only Mercator environment for high-throughput training.

This environment intentionally contains no Isaac Sim, USD, Gym, or renderer
calls.  It uses the same arena source, analytical sensors, AutoMoDe modules,
kinematics, collision solver, reward, spawn sampler, critic state, and timeout
bootstrap contract as :class:`MercatorAggregationEnv`.

The public tensor API is:

* observations: ``[num_envs, num_agents, obs_dim]``
* actions: ``[num_envs, num_agents, action_dim]``
* reward/terminated/truncated: ``[num_envs]``

A dictionary compatibility API is retained for diagnostics, but the optimized
POCA path never constructs per-agent dictionaries.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any, Sequence

import torch

from .arena_geometry import build_argos_aac_arena, build_environment_signature
from .mercator_behavior_modules import MercatorBehaviorModules
from .mercator_geometry import (
    boxes_inside_walls,
    candidate_circle_overlaps_existing,
    candidate_overlaps_existing,
    circles_inside_walls,
    resolve_circle_wall_collisions,
    resolve_pairwise_circle_collisions,
    resolve_pairwise_obb_collisions,
    resolve_wall_collisions,
    rotate_body_to_world,
)
from .mercator_sensors import MercatorLightSensors


_NUM_MODULES = 6
_OBS_DIM = {"dandelion": 22, "daisy": 22, "lily": 2, "tulip": 2, "cyclamen": 2}
_ACT_DIM = {"dandelion": 2, "daisy": 1, "lily": 1, "tulip": 1, "cyclamen": 1}


def _agent_names(n: int) -> list[str]:
    return [f"Mercator_{i:02d}" for i in range(int(n))]


@dataclass
class TensorSimulationCfg:
    dt: float = 0.1


@dataclass
class TensorSceneCfg:
    num_envs: int = 32


@dataclass
class MercatorTensorEnvCfg:
    """Isaac-independent mirror of the aggregation environment settings."""

    variant: str = "cyclamen"
    num_agents: int = 20
    seed: int = 0
    device: str = "cuda:0" if torch.cuda.is_available() else "cpu"

    decimation: int = 1
    analytical_substeps: int = 6
    collision_iterations: int = 2
    episode_length_s: float = 120.0
    sim: TensorSimulationCfg = field(default_factory=TensorSimulationCfg)
    scene: TensorSceneCfg = field(default_factory=TensorSceneCfg)

    arena_side_length: float = 2.57
    arena_wall_thickness: float = 0.01
    arena_wall_height: float = 0.08

    black_center: tuple[float, float] = (0.0, 2.35)
    white_center: tuple[float, float] = (0.0, -2.35)
    zone_radius: float = 1.17

    light_position: tuple[float, float, float] = (0.0, -5.0, 0.2)
    light_intensity: float = 5.0
    light_max_distance: float = 12.0

    spawn_mode: str = "argos_uniform_box_rejection"
    spawn_half_range: float = 4.6
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0

    robot_profile: str = "mercator"
    robot_length: float = 0.26
    robot_width: float = 0.25
    robot_height: float = 0.20
    robot_base_height: float = 0.08
    collision_shape: str = "obb"
    collision_radius: float = 0.105
    collision_ring_radius: float = 0.0
    collision_ring_height: float = 0.0
    collision_ring_thickness: float = 0.0
    lidar_tower_diameter: float = 0.065
    lidar_tower_offset: tuple[float, float] = (0.0, 0.0)
    lidar_height: float = 0.17545
    ground_sensor_offset: tuple[float, float] = (0.056, 0.0)

    max_wheel_speed: float = 0.30
    wheelbase: float = 0.18
    teraranger_layout: str = "native_asymmetric"
    teraranger_ring_radius: float = 0.143
    teraranger_origin_offset: float = 0.005
    teraranger_max_range: float = 2.0
    proximity_threshold: float = 0.10

    neighbor_min_range: float = 0.10
    neighbor_max_range: float = 0.75
    neighbor_alpha: float = 1.0
    cyclamen_neighbor_range: float = 0.78

    exploration_tau: int = 5
    phototaxis_proximity_gain: float = 5.0
    anti_phototaxis_proximity_gain: float = 5.0
    attraction_proximity_gain: float = 6.0
    repulsion_proximity_gain: float = 5.0
    repulsion_alpha_parameter: float = 5.0

    possible_agents: list[str] = field(init=False)
    observation_spaces: dict[str, int] = field(init=False)
    action_spaces: dict[str, int] = field(init=False)
    discrete_actions: bool = field(init=False)
    num_actions: int = _NUM_MODULES

    def __post_init__(self) -> None:
        self.update_variant(self.variant)

    @property
    def num_envs(self) -> int:
        return int(self.scene.num_envs)

    def update_variant(self, variant: str) -> None:
        if variant not in _OBS_DIM:
            raise ValueError(f"Unknown CASA variant: {variant!r}")
        self.variant = variant
        self.possible_agents = _agent_names(self.num_agents)
        self.observation_spaces = {
            name: _OBS_DIM[variant] for name in self.possible_agents
        }
        self.action_spaces = {
            name: _ACT_DIM[variant] for name in self.possible_agents
        }
        self.discrete_actions = variant != "dandelion"

    def apply_overrides(self, overrides: dict[str, Any]) -> None:
        for key, value in overrides.items():
            if key == "task":
                continue
            if key == "num_envs":
                self.scene.num_envs = int(value)
            elif key == "sim_dt":
                self.sim.dt = float(value)
            elif hasattr(self, key):
                current = getattr(self, key)
                if isinstance(current, tuple) and isinstance(value, list):
                    value = tuple(value)
                setattr(self, key, value)
            else:
                raise RuntimeError(f"Unknown tensor environment setting: {key}")
        self.update_variant(self.variant)


class MercatorTensorEnv:
    """Functionally equivalent tensor backend for Mercator aggregation."""

    tensor_api = True

    def __init__(self, cfg: MercatorTensorEnvCfg):
        self.cfg = cfg
        self.unwrapped = self
        self.scene = cfg.scene
        self.num_envs = int(cfg.scene.num_envs)
        self.num_agents = int(cfg.num_agents)
        self.device = torch.device(cfg.device)
        self._closed = False

        torch.manual_seed(int(cfg.seed))
        if self.device.type == "cuda":
            torch.cuda.manual_seed_all(int(cfg.seed))

        self._arena_geometry = build_argos_aac_arena(
            wall_side_length=float(cfg.arena_side_length),
            wall_thickness=float(cfg.arena_wall_thickness),
            wall_height=float(cfg.arena_wall_height),
        )
        self._environment_signature = build_environment_signature(cfg, self._arena_geometry)

        self.robot_half_length = 0.5 * float(cfg.robot_length)
        self.robot_half_width = 0.5 * float(cfg.robot_width)
        self.collision_shape = (
            str(getattr(cfg, "collision_shape", "obb")).strip().lower()
        )
        self.collision_radius = float(getattr(cfg, "collision_radius", 0.105))
        if self.collision_shape not in ("obb", "circle"):
            raise ValueError("collision_shape must be obb or circle")
        if self.collision_radius <= 0.0:
            raise ValueError("collision_radius must be positive")
        self.control_dt = float(cfg.sim.dt) * int(cfg.decimation)
        self.max_episode_length = int(
            math.ceil(float(cfg.episode_length_s) / self.control_dt)
        )
        self._episode_step = 0
        self.last_transition_was_terminal = False

        e, n, dev = self.num_envs, self.num_agents, self.device
        self.agent_pos = torch.zeros(e, n, 2, dtype=torch.float32, device=dev)
        self.agent_yaw = torch.zeros(e, n, dtype=torch.float32, device=dev)
        self._last_module_ids = torch.zeros(e, n, dtype=torch.long, device=dev)
        self._cached_wheels = torch.zeros(e, n, 2, dtype=torch.float32, device=dev)
        self.episode_length_buf = torch.zeros(e, dtype=torch.long, device=dev)

        self.completed_group_reward = torch.zeros(e, dtype=torch.float32, device=dev)
        self._episode_group_reward = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_n_black = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_n_white = torch.zeros(e, dtype=torch.float32, device=dev)

        self._last_transition_final_critic_state = torch.zeros(
            e, n, 5, dtype=torch.float32, device=dev
        )
        self._last_transition_final_state_mask = torch.zeros(
            e, dtype=torch.bool, device=dev
        )
        self._false_done = torch.zeros(e, dtype=torch.bool, device=dev)
        self._true_done = torch.ones(e, dtype=torch.bool, device=dev)

        self.black_center = torch.tensor(cfg.black_center, dtype=torch.float32, device=dev)
        self.white_center = torch.tensor(cfg.white_center, dtype=torch.float32, device=dev)
        self.zone_radius_sq = float(cfg.zone_radius) ** 2
        self.ground_sensor_offset = torch.tensor(
            cfg.ground_sensor_offset, dtype=torch.float32, device=dev
        )
        self.light_pos = torch.tensor(cfg.light_position[:2], dtype=torch.float32, device=dev)
        light_norm = torch.linalg.vector_norm(self.light_pos)
        self.light_dir = torch.where(
            light_norm > 1e-8,
            self.light_pos / light_norm.clamp_min(1e-8),
            torch.tensor((1.0, 0.0), dtype=torch.float32, device=dev),
        )

        self.wall_segments = torch.tensor(
            self._arena_geometry.wall_segments, dtype=torch.float32, device=dev
        )
        self.wall_outward_normals = torch.tensor(
            self._arena_geometry.outward_normals, dtype=torch.float32, device=dev
        )
        self.wall_inner_offsets = torch.tensor(
            self._arena_geometry.inner_offsets, dtype=torch.float32, device=dev
        )

        self.sensors = MercatorLightSensors(
            device=dev,
            robot_half_length=self.robot_half_length,
            robot_half_width=self.robot_half_width,
            collision_shape=self.collision_shape,
            robot_collision_radius=self.collision_radius,
            teraranger_layout=cfg.teraranger_layout,
            teraranger_ring_radius=cfg.teraranger_ring_radius,
            teraranger_max_range=cfg.teraranger_max_range,
            teraranger_origin_offset=cfg.teraranger_origin_offset,
            neighbor_min_range=cfg.neighbor_min_range,
            neighbor_max_range=cfg.neighbor_max_range,
            neighbor_alpha=cfg.neighbor_alpha,
            tower_offset=cfg.lidar_tower_offset,
            cyclamen_neighbor_range=cfg.cyclamen_neighbor_range,
            light_max_distance=cfg.light_max_distance,
        )
        self.sensors.bind_wall_segments(self.wall_segments)
        self.behavior_modules = MercatorBehaviorModules(
            max_speed=cfg.max_wheel_speed,
            proximity_threshold=cfg.proximity_threshold,
            exploration_tau=cfg.exploration_tau,
            phototaxis_proximity_gain=cfg.phototaxis_proximity_gain,
            anti_phototaxis_proximity_gain=cfg.anti_phototaxis_proximity_gain,
            attraction_proximity_gain=cfg.attraction_proximity_gain,
            repulsion_proximity_gain=cfg.repulsion_proximity_gain,
            repulsion_alpha_parameter=cfg.repulsion_alpha_parameter,
            neighbor_vector_base_alpha=cfg.neighbor_alpha,
            device=dev,
        )
        self.behavior_modules.init_state(e, n)
        self._reset_all(initial=True)

    @property
    def episode_step_python(self) -> int:
        """Synchronized fixed-horizon counter without a CUDA scalar read."""
        return self._episode_step

    @property
    def arena_fingerprint(self) -> str:
        return self._arena_geometry.fingerprint

    def get_environment_signature(self) -> dict[str, Any]:
        return dict(self._environment_signature)

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        black_delta = points - self.black_center.view(1, 1, 2)
        white_delta = points - self.white_center.view(1, 1, 2)
        in_black = (black_delta * black_delta).sum(dim=-1) <= self.zone_radius_sq
        in_white = (white_delta * white_delta).sum(dim=-1) <= self.zone_radius_sq
        out = torch.full(in_black.shape, 0.5, dtype=torch.float32, device=self.device)
        out.masked_fill_(in_black, 0.0)
        out.masked_fill_(in_white, 1.0)
        return out

    def _ground_sensor_points(self) -> torch.Tensor:
        return self.agent_pos + rotate_body_to_world(
            self.ground_sensor_offset.view(1, 1, 2), self.agent_yaw
        )

    def _zone_counts_from_centers(self) -> tuple[torch.Tensor, torch.Tensor]:
        ground = self._ground_scalar_at(self.agent_pos)
        return (
            (ground < 0.25).sum(dim=1).to(torch.float32),
            (ground > 0.75).sum(dim=1).to(torch.float32),
        )

    def _get_observations_tensor(self) -> torch.Tensor:
        ground = self._ground_scalar_at(self._ground_sensor_points())
        if self.cfg.variant in ("dandelion", "daisy"):
            sensors = self.sensors.compute_all(
                self.agent_pos, self.agent_yaw, self.wall_segments, self.light_pos
            )
            return torch.cat(
                (
                    sensors.proximity_values,
                    sensors.light_values,
                    ground.unsqueeze(-1),
                    sensors.ztilde.unsqueeze(-1),
                    sensors.rab_projection,
                ),
                dim=-1,
            )
        ztilde = self.sensors.compute_cyclamen_ztilde(
            self.agent_pos, self.agent_yaw
        )
        return torch.stack((ground, ztilde), dim=-1)

    def _resolve_collisions(self) -> None:
        if self.collision_shape == "circle":
            self.agent_pos = resolve_pairwise_circle_collisions(
                self.agent_pos,
                self.collision_radius,
                iterations=int(self.cfg.collision_iterations),
            )
            self.agent_pos = resolve_circle_wall_collisions(
                self.agent_pos,
                self.wall_outward_normals,
                self.wall_inner_offsets,
                self.collision_radius,
            )
        else:
            self.agent_pos = resolve_pairwise_obb_collisions(
                self.agent_pos,
                self.agent_yaw,
                self.robot_half_length,
                self.robot_half_width,
                iterations=int(self.cfg.collision_iterations),
            )
            self.agent_pos = resolve_wall_collisions(
                self.agent_pos,
                self.agent_yaw,
                self.wall_outward_normals,
                self.wall_inner_offsets,
                self.robot_half_length,
                self.robot_half_width,
            )

    def _compute_wheels(self, actions: torch.Tensor) -> None:
        if self.cfg.discrete_actions:
            ids = actions.squeeze(-1).to(dtype=torch.long).clamp(0, 5)
            self._last_module_ids.copy_(ids)
            control_sensors = self.sensors.compute_all(
                self.agent_pos, self.agent_yaw, self.wall_segments, self.light_pos
            )
            self._cached_wheels = self.behavior_modules.compute(ids, control_sensors)
        else:
            self._cached_wheels = (
                actions.clamp(-1.0, 1.0) * float(self.cfg.max_wheel_speed)
            )
            self._last_module_ids.zero_()

    def _integrate(self) -> None:
        left = self._cached_wheels[..., 0]
        right = self._cached_wheels[..., 1]
        v = 0.5 * (left + right)
        omega = (right - left) / float(self.cfg.wheelbase)
        straight = omega.abs() < 1e-6
        safe_omega = torch.where(straight, torch.ones_like(omega), omega)
        substeps = max(1, int(self.cfg.analytical_substeps))
        dt = self.control_dt / substeps

        for _ in range(substeps):
            theta0 = self.agent_yaw
            theta1 = theta0 + omega * dt
            dx_arc = v / safe_omega * (torch.sin(theta1) - torch.sin(theta0))
            dy_arc = -v / safe_omega * (torch.cos(theta1) - torch.cos(theta0))
            dx = torch.where(straight, v * torch.cos(theta0) * dt, dx_arc)
            dy = torch.where(straight, v * torch.sin(theta0) * dt, dy_arc)
            self.agent_pos[..., 0] += dx
            self.agent_pos[..., 1] += dy
            self.agent_yaw = torch.atan2(torch.sin(theta1), torch.cos(theta1))
            self._resolve_collisions()

    def step_tensor(
        self, actions: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, dict[str, Any]]:
        if actions.shape[:2] != (self.num_envs, self.num_agents):
            raise ValueError(
                f"Expected actions [E,N,...]=[{self.num_envs},{self.num_agents},...], "
                f"got {tuple(actions.shape)}"
            )
        actions = actions.to(device=self.device)
        self._compute_wheels(actions)
        self._integrate()

        n_black, n_white = self._zone_counts_from_centers()
        self.last_n_black.copy_(n_black)
        self.last_n_white.copy_(n_white)
        self._episode_group_reward.add_(n_black)
        reward = n_black

        self._episode_step += 1
        self.episode_length_buf.fill_(self._episode_step)
        timed_out = self._episode_step >= self.max_episode_length - 1
        self.last_transition_was_terminal = bool(timed_out)

        if timed_out:
            self._last_transition_final_state_mask.fill_(True)
            self._last_transition_final_critic_state.copy_(self.get_critic_state())
            truncated = self._true_done
            self._reset_all(initial=False)
            self.last_transition_was_terminal = True
        else:
            self._last_transition_final_state_mask.zero_()
            truncated = self._false_done

        obs = self._get_observations_tensor()
        return obs, reward, self._false_done, truncated, {}

    def reset_tensor(
        self, *, seed: int | None = None
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        if seed is not None:
            torch.manual_seed(int(seed))
            if self.device.type == "cuda":
                torch.cuda.manual_seed_all(int(seed))
        self._reset_all(initial=True)
        return self._get_observations_tensor(), {}

    # Dictionary compatibility for diagnostics and old scripts.
    def reset(self, *, seed: int | None = None):
        obs, info = self.reset_tensor(seed=seed)
        return {
            agent: obs[:, i] for i, agent in enumerate(self.cfg.possible_agents)
        }, info

    def step(self, action_dict: dict[str, torch.Tensor]):
        actions = torch.stack(
            [action_dict[a] for a in self.cfg.possible_agents], dim=1
        )
        obs, reward, terminated, truncated, info = self.step_tensor(actions)
        return (
            {a: obs[:, i] for i, a in enumerate(self.cfg.possible_agents)},
            {a: reward for a in self.cfg.possible_agents},
            {a: terminated for a in self.cfg.possible_agents},
            {a: truncated for a in self.cfg.possible_agents},
            info,
        )

    def _sample_argos_spawns(self, count: int) -> tuple[torch.Tensor, torch.Tensor]:
        cfg = self.cfg
        positions = torch.empty(
            count, cfg.num_agents, 2, dtype=torch.float32, device=self.device
        )
        yaws = torch.empty(
            count, cfg.num_agents, dtype=torch.float32, device=self.device
        )
        mode = str(cfg.spawn_mode)
        spawn_range = float(cfg.spawn_half_range)
        if mode not in (
            "argos_uniform_disk_rejection",
            "argos_uniform_box_rejection",
        ):
            raise ValueError(f"Unsupported spawn_mode={mode!r}")

        for robot_idx in range(cfg.num_agents):
            pending = torch.ones(count, dtype=torch.bool, device=self.device)
            for _ in range(int(cfg.spawn_max_trials)):
                if mode == "argos_uniform_disk_rejection":
                    u = torch.rand(count, 2, device=self.device)
                    radius = spawn_range * torch.sqrt(u[:, 0])
                    bearing = math.tau * u[:, 1]
                    candidate_pos = torch.stack(
                        (radius * torch.cos(bearing), radius * torch.sin(bearing)),
                        dim=-1,
                    )
                    raw_yaw = math.tau * torch.rand(count, device=self.device)
                else:
                    candidate_pos = (
                        2.0 * torch.rand(count, 2, device=self.device) - 1.0
                    ) * spawn_range
                    raw_yaw = (
                        math.radians(float(cfg.spawn_yaw_mean_deg))
                        + torch.randn(count, device=self.device)
                        * math.radians(float(cfg.spawn_yaw_std_deg))
                    )
                candidate_yaw = torch.atan2(torch.sin(raw_yaw), torch.cos(raw_yaw))
                if self.collision_shape == "circle":
                    inside = circles_inside_walls(
                        candidate_pos,
                        self.wall_outward_normals,
                        self.wall_inner_offsets,
                        self.collision_radius,
                    )
                    overlaps = candidate_circle_overlaps_existing(
                        candidate_pos, positions[:, :robot_idx], self.collision_radius
                    )
                else:
                    inside = boxes_inside_walls(
                        candidate_pos,
                        candidate_yaw,
                        self.wall_outward_normals,
                        self.wall_inner_offsets,
                        self.robot_half_length,
                        self.robot_half_width,
                    )
                    overlaps = candidate_overlaps_existing(
                        candidate_pos,
                        candidate_yaw,
                        positions[:, :robot_idx],
                        yaws[:, :robot_idx],
                        self.robot_half_length,
                        self.robot_half_width,
                    )
                accepted = pending & inside & (~overlaps)
                positions[accepted, robot_idx] = candidate_pos[accepted]
                yaws[accepted, robot_idx] = candidate_yaw[accepted]
                pending &= ~accepted
                if not bool(pending.any()):
                    break
            if bool(pending.any()):
                raise RuntimeError(
                    f"{mode} spawn failed for robot {robot_idx}: "
                    f"{int(pending.sum().item())}/{count} environments after "
                    f"{cfg.spawn_max_trials} trials"
                )
        return positions, yaws

    def _reset_all(self, *, initial: bool) -> None:
        if not initial:
            self.completed_group_reward.copy_(self._episode_group_reward)
        else:
            self.completed_group_reward.zero_()
            self._last_transition_final_state_mask.zero_()
        self._episode_group_reward.zero_()
        self.last_n_black.zero_()
        self.last_n_white.zero_()
        self._episode_step = 0
        if initial:
            self.last_transition_was_terminal = False
        self.episode_length_buf.zero_()

        pos, yaw = self._sample_argos_spawns(self.num_envs)
        self.agent_pos.copy_(pos)
        self.agent_yaw.copy_(yaw)
        self._last_module_ids.zero_()
        self.behavior_modules.reset_state()

    def get_critic_state(self) -> torch.Tensor:
        return MercatorLightSensors.compute_critic_state_5d(
            self.agent_pos,
            self.agent_yaw,
            float(self._arena_geometry.circumradius),
            self.light_dir,
        )

    def get_last_transition_final_critic_state(
        self,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        return (
            self._last_transition_final_critic_state,
            self._last_transition_final_state_mask,
        )

    @property
    def completed_terminal_critic_state(self) -> torch.Tensor:
        """Critic state captured immediately before an automatic reset."""
        return self._last_transition_final_critic_state

    def close(self) -> None:
        self._closed = True
