# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Vectorized Mercator AutoMoDe behavior modules.

This file is a drop-in replacement for ``mercator_behavior_modules.py``.
It follows the control laws used by the Mercator AutoMoDe implementation in:

- ARGoS3-AutoMoDe-rvr/src/modules
- demiurge-rvr-dao/src/ReferenceModel1Dot2.cpp

Important scope limitation
--------------------------
The behavior equations are matched as closely as possible while preserving the
existing vectorized sensor API. Exact trajectory equivalence still depends on
feeding sensor readings equivalent to the Mercator DAO (LiDAR beacon/neighbor
extraction, proximity aggregation, noise, occlusions, and timing).

Module IDs
----------
0: exploration
1: stop
2: phototaxis
3: anti-phototaxis
4: attraction
5: repulsion
"""

from __future__ import annotations

import math

import torch

from .mercator_sensors import MercatorSensorBatch


class MercatorBehaviorModules:
    """Convert AutoMoDe module IDs 0..5 to differential wheel speeds.

    The public API is compatible with the previous implementation. Two optional
    parameters were added:

    ``attraction_alpha_parameter``
        AutoMoDe ``att`` parameter. The Mercator paper/configuration commonly
        uses values in [1, 5]. Default: 5.

    ``neighbor_vector_base_alpha``
        Alpha already used by ``MercatorLightSensors.compute_neighbors`` when
        constructing ``sensors.neighbor_vector``. In the current project this is
        ``cfg.neighbor_alpha`` and defaults to 1. Keeping this value at 1 makes
        the formulas below reproduce the DAO's ``alpha / (1 + distance)`` sum.
    """

    EXPLORATION = 0
    STOP = 1
    PHOTOTAXIS = 2
    ANTI_PHOTOTAXIS = 3
    ATTRACTION = 4
    REPULSION = 5

    def __init__(
        self,
        *,
        max_speed: float = 0.30,
        turn_speed: float | None = None,
        proximity_threshold: float = 0.10,
        exploration_tau: int = 5,
        phototaxis_proximity_gain: float = 5.0,
        anti_phototaxis_proximity_gain: float = 5.0,
        attraction_proximity_gain: float = 6.0,
        repulsion_proximity_gain: float = 5.0,
        repulsion_alpha_parameter: float = 5.0,
        attraction_alpha_parameter: float = 5.0,
        neighbor_vector_base_alpha: float = 1.0,
        fallback_vector_threshold: float = 0.10,
        device: torch.device | str = "cpu",
    ):
        self.device = torch.device(device)
        self.max_speed = float(max_speed)
        self.turn_speed = float(max_speed if turn_speed is None else turn_speed)
        self.proximity_threshold = float(proximity_threshold)
        self.exploration_tau = max(int(exploration_tau), 0)

        self.phototaxis_proximity_gain = float(phototaxis_proximity_gain)
        self.anti_phototaxis_proximity_gain = float(anti_phototaxis_proximity_gain)
        self.attraction_proximity_gain = float(attraction_proximity_gain)
        self.repulsion_proximity_gain = float(repulsion_proximity_gain)
        self.repulsion_alpha_parameter = float(repulsion_alpha_parameter)
        self.attraction_alpha_parameter = float(attraction_alpha_parameter)

        if abs(float(neighbor_vector_base_alpha)) < 1e-12:
            raise ValueError("neighbor_vector_base_alpha must be non-zero")
        self.neighbor_vector_base_alpha = float(neighbor_vector_base_alpha)
        self.fallback_vector_threshold = float(fallback_vector_threshold)

        # Stateful part of AutoMoDe exploration, one value per env/robot.
        self.turn_steps_remaining: torch.Tensor | None = None
        self.turn_sign: torch.Tensor | None = None
        self.is_turning: torch.Tensor | None = None
        self.previous_module_ids: torch.Tensor | None = None

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def init_state(self, num_envs: int, num_agents: int) -> None:
        shape = (int(num_envs), int(num_agents))
        self.turn_steps_remaining = torch.zeros(
            shape, dtype=torch.long, device=self.device
        )
        # +1 => LEFT  => (-v, +v)
        # -1 => RIGHT => (+v, -v)
        self.turn_sign = torch.zeros(
            shape, dtype=torch.float32, device=self.device
        )
        self.is_turning = torch.zeros(
            shape, dtype=torch.bool, device=self.device
        )
        self.previous_module_ids = torch.full(
            shape, -1, dtype=torch.long, device=self.device
        )

    def reset_state(self, env_mask: torch.Tensor | None = None) -> None:
        if self.is_turning is None:
            return

        if env_mask is None:
            self.turn_steps_remaining.zero_()
            self.turn_sign.zero_()
            self.is_turning.zero_()
            self.previous_module_ids.fill_(-1)
            return

        mask = env_mask.to(device=self.device)
        self.turn_steps_remaining[mask] = 0
        self.turn_sign[mask] = 0.0
        self.is_turning[mask] = False
        self.previous_module_ids[mask] = -1

    def _require_state(self) -> None:
        if (
            self.turn_steps_remaining is None
            or self.turn_sign is None
            or self.is_turning is None
            or self.previous_module_ids is None
        ):
            raise RuntimeError("Call init_state() before compute().")

    # ------------------------------------------------------------------
    # DAO-compatible vector helpers
    # ------------------------------------------------------------------

    @staticmethod
    def wheels_from_vector(vector: torch.Tensor, max_speed: float) -> torch.Tensor:
        """Vectorized port of ``ComputeWheelsVelocityFromVector``.

        For a non-zero target vector, one wheel is set to maximum speed and the
        other to ``cos(target_angle) * max_speed``. This allows backward wheel
        motion for targets behind the robot, as in the C++ AutoMoDe code.
        """

        dx = vector[..., 0]
        dy = vector[..., 1]
        non_zero = (dx.abs() > 1e-12) | (dy.abs() > 1e-12)

        angle = torch.remainder(torch.atan2(dy, dx), 2.0 * math.pi)
        cos_a = torch.cos(angle)

        # C++ behavior:
        #   angle in left hemisphere  -> left=cos(a), right=1
        #   angle in right hemisphere -> left=1,      right=cos(a)
        left = torch.where(angle < math.pi, cos_a, torch.ones_like(cos_a))
        right = torch.where(angle < math.pi, torch.ones_like(cos_a), cos_a)

        denominator = torch.maximum(left.abs(), right.abs()).clamp_min(1e-12)
        factor = float(max_speed) / denominator
        wheels = torch.stack((factor * left, factor * right), dim=-1)

        return torch.where(
            non_zero.unsqueeze(-1), wheels, torch.zeros_like(wheels)
        )

    @staticmethod
    def _vector_from_polar(value: torch.Tensor, angle: torch.Tensor) -> torch.Tensor:
        return torch.stack(
            (value * torch.cos(angle), value * torch.sin(angle)), dim=-1
        )

    @classmethod
    def _dao_proximity_vector(cls, sensors: MercatorSensorBatch) -> torch.Tensor:
        """Reconstruct the DAO's capped proximity reading as a Cartesian vector.

        ``ReferenceModel1Dot2::GetProximityReading`` caps the norm to 1 before
        exposing the aggregate reading. The previous Python code used the raw
        uncapped sum, which could make obstacle avoidance too strong.
        """

        return cls._vector_from_polar(
            sensors.proximity_value.clamp(0.0, 1.0),
            sensors.proximity_angle,
        )

    @staticmethod
    def _dao_beacon_vector(light_vector: torch.Tensor) -> torch.Tensor:
        """Match ``GetAttractionVectorToBeacons`` at behavior level.

        The Mercator DAO returns magnitude 1 whenever at least one beacon is
        detected, and 0 otherwise. The angle is the angle of the summed beacon
        vector. The existing analytical simulator has one synthetic light
        vector, so this method preserves its angle but forces the same 0/1 norm.
        """

        norm = torch.linalg.vector_norm(light_vector, dim=-1, keepdim=True)
        unit = light_vector / norm.clamp_min(1e-12)
        return torch.where(norm > 1e-12, unit, torch.zeros_like(light_vector))

    def _dao_neighbor_vector(
        self,
        base_neighbor_vector: torch.Tensor,
        alpha: float | torch.Tensor,
    ) -> torch.Tensor:
        """Scale the base vector to the DAO's ``alpha/(1+d)`` convention.

        ``alpha`` may be a scalar (the training path) or an ``[env, agent]``
        tensor supplied by an AutoMoDe FSM state.
        """

        scale = torch.as_tensor(
            alpha, dtype=base_neighbor_vector.dtype, device=base_neighbor_vector.device
        ) / self.neighbor_vector_base_alpha
        if scale.ndim == base_neighbor_vector.ndim - 1:
            scale = scale.unsqueeze(-1)
        return base_neighbor_vector * scale

    def _with_forward_fallback(self, vector: torch.Tensor) -> torch.Tensor:
        """AutoMoDe modules move forward when the result norm is below 0.1."""

        forward = torch.zeros_like(vector)
        forward[..., 0] = 1.0
        small = (
            torch.linalg.vector_norm(vector, dim=-1)
            < self.fallback_vector_threshold
        )
        return torch.where(small.unsqueeze(-1), forward, vector)

    # ------------------------------------------------------------------
    # Exploration
    # ------------------------------------------------------------------

    def _reset_exploration_agents(self, mask: torch.Tensor) -> None:
        self.turn_steps_remaining.masked_fill_(mask, 0)
        self.turn_sign.masked_fill_(mask, 0.0)
        self.is_turning.masked_fill_(mask, False)

    def _exploration(
        self,
        sensors: MercatorSensorBatch,
        active: torch.Tensor,
        exploration_tau: int | torch.Tensor | None = None,
        state_entry_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Vectorized port of ``AutoMoDeBehaviourExploration::ControlStep``.

        Key timing details copied from the C++ module:

        * On the tick where an obstacle is first detected, the robot still
          commands forward motion and only schedules the turn.
        * On the next tick, the turn counter is decremented before commanding
          the in-place rotation.
        * A sampled duration of zero still yields one rotation tick.
        * Entering exploration resets its internal state, matching AutoMoDe's
          behavior reset on FSM state entry.
        * Exploration state advances only for robots currently selecting module
          0. The previous implementation advanced it for every robot because all
          six outputs were computed eagerly.
        """

        self._require_state()

        entering = active & (self.previous_module_ids != self.EXPLORATION)
        if state_entry_mask is not None:
            entering = entering | (
                active & state_entry_mask.to(device=self.device, dtype=torch.bool)
            )
        self._reset_exploration_agents(entering)

        shape = (*active.shape, 2)
        forward = torch.full(
            shape,
            self.max_speed,
            dtype=sensors.proximity_value.dtype,
            device=self.device,
        )
        output = forward.clone()

        # Preserve the state at function entry. A robot that finishes a turn on
        # this tick must still output the turn command and must not immediately
        # re-check obstacles until the following control tick.
        was_turning = self.is_turning.clone()
        turning_now = active & was_turning

        decremented = self.turn_steps_remaining - 1
        self.turn_steps_remaining = torch.where(
            turning_now,
            decremented,
            self.turn_steps_remaining,
        )

        turn = torch.stack(
            (
                -self.turn_sign * self.turn_speed,
                self.turn_sign * self.turn_speed,
            ),
            dim=-1,
        )
        output = torch.where(turning_now.unsqueeze(-1), turn, output)

        finished = turning_now & (self.turn_steps_remaining <= 0)
        self.is_turning = torch.where(
            finished, torch.zeros_like(self.is_turning), self.is_turning
        )
        self.turn_sign = torch.where(
            finished, torch.zeros_like(self.turn_sign), self.turn_sign
        )

        random_walk_now = active & ~was_turning
        obstacle_in_front = (
            sensors.proximity_value >= self.proximity_threshold
        ) & (sensors.proximity_angle <= math.pi / 2.0) & (
            sensors.proximity_angle >= -math.pi / 2.0
        )
        start_turn = random_walk_now & obstacle_in_front

        tau = self.exploration_tau if exploration_tau is None else exploration_tau
        tau_tensor = torch.as_tensor(
            tau, dtype=torch.long, device=self.device
        ).clamp_min(0)
        if tau_tensor.ndim == 0:
            tau_tensor = tau_tensor.expand_as(self.turn_steps_remaining)
        elif tau_tensor.shape != self.turn_steps_remaining.shape:
            raise ValueError(
                "exploration_tau must be scalar or have shape "
                f"{tuple(self.turn_steps_remaining.shape)}, got {tuple(tau_tensor.shape)}"
            )

        # ARGoS samples an integer uniformly in the inclusive range [0, rwm].
        # A tensor-valued upper bound is needed because each FSM state may have
        # its own rwm parameter. floor(U * (rwm + 1)) has the same distribution.
        sampled_steps = torch.floor(
            torch.rand(tau_tensor.shape, device=self.device)
            * (tau_tensor.to(torch.float32) + 1.0)
        ).to(torch.long)

        # C++ direction rule:
        #   proximity angle < 0 -> LEFT  (-v,+v)
        #   otherwise           -> RIGHT (+v,-v)
        direction = torch.where(
            sensors.proximity_angle < 0.0,
            torch.ones_like(sensors.proximity_angle),
            -torch.ones_like(sensors.proximity_angle),
        )

        self.turn_steps_remaining = torch.where(
            start_turn, sampled_steps, self.turn_steps_remaining
        )
        self.turn_sign = torch.where(start_turn, direction, self.turn_sign)
        self.is_turning = self.is_turning | start_turn

        # Non-active values are ignored by gather(), but zeros make debugging
        # clearer and prevent accidental use outside compute().
        return torch.where(active.unsqueeze(-1), output, torch.zeros_like(output))

    # ------------------------------------------------------------------
    # Public computation
    # ------------------------------------------------------------------

    def compute(
        self,
        module_ids: torch.Tensor,
        sensors: MercatorSensorBatch,
        *,
        exploration_tau: int | torch.Tensor | None = None,
        attraction_alpha: float | torch.Tensor | None = None,
        repulsion_alpha: float | torch.Tensor | None = None,
        state_entry_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Return wheel speeds for the selected module of every robot.

        Optional tensor parameters preserve the per-state ``rwm``, ``att`` and
        ``rep`` values encoded in Chocolate FSMs. Existing callers can omit them.
        """

        self._require_state()
        ids = module_ids.to(device=self.device, dtype=torch.long).clamp(0, 5)

        prox = self._dao_proximity_vector(sensors)
        beacon = self._dao_beacon_vector(sensors.light_vector)

        exploration = self._exploration(
            sensors,
            active=(ids == self.EXPLORATION),
            exploration_tau=exploration_tau,
            state_entry_mask=state_entry_mask,
        )
        stop = torch.zeros_like(exploration)

        # AutoMoDeBehaviourPhototaxis.cpp:
        #   beacon - 5 * proximity
        photo_vector = self._with_forward_fallback(
            beacon - self.phototaxis_proximity_gain * prox
        )
        phototaxis = self.wheels_from_vector(photo_vector, self.max_speed)

        # AutoMoDeBehaviourAntiPhototaxis.cpp:
        #   -beacon - 5 * proximity
        anti_vector = self._with_forward_fallback(
            -beacon - self.anti_phototaxis_proximity_gain * prox
        )
        anti_phototaxis = self.wheels_from_vector(anti_vector, self.max_speed)

        # ReferenceModel1Dot2::GetAttractionVectorToNeighbors(att) returns
        # sum(att/(1+d) * unit_vector). The behavior then subtracts 6*prox.
        attraction_parameter = (
            self.attraction_alpha_parameter
            if attraction_alpha is None
            else attraction_alpha
        )
        attraction_neighbors = self._dao_neighbor_vector(
            sensors.neighbor_vector, attraction_parameter
        )
        attraction_vector = self._with_forward_fallback(
            attraction_neighbors - self.attraction_proximity_gain * prox
        )
        attraction = self.wheels_from_vector(attraction_vector, self.max_speed)

        # The Mercator C++ repulsion module first asks the DAO for a neighbor
        # vector already multiplied by rep, then multiplies that vector by -rep
        # once more. Relative to a base-alpha=1 vector this is therefore -rep^2.
        repulsion_parameter = (
            self.repulsion_alpha_parameter
            if repulsion_alpha is None
            else repulsion_alpha
        )
        repulsion_neighbors = self._dao_neighbor_vector(
            sensors.neighbor_vector, repulsion_parameter
        )
        repulsion_scale = torch.as_tensor(
            repulsion_parameter, dtype=prox.dtype, device=prox.device
        )
        if repulsion_scale.ndim == prox.ndim - 1:
            repulsion_scale = repulsion_scale.unsqueeze(-1)
        repulsion_vector = self._with_forward_fallback(
            -repulsion_scale * repulsion_neighbors
            - self.repulsion_proximity_gain * prox
        )
        repulsion = self.wheels_from_vector(repulsion_vector, self.max_speed)

        all_wheels = torch.stack(
            (
                exploration,
                stop,
                phototaxis,
                anti_phototaxis,
                attraction,
                repulsion,
            ),
            dim=2,
        )
        index = ids.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, 1, 2)
        selected = all_wheels.gather(2, index).squeeze(2)

        self.previous_module_ids.copy_(ids)
        return selected