# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Named Mercator embodiment profiles and YAML expansion helpers.

The Python environment configuration defaults to the native ``mercator``
profile. A YAML may select ``robot_profile: tmercator`` and may still override
any individual field afterwards. This keeps experiment files explicit while
allowing omitted profile fields to resolve deterministically.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping


MERCATOR_PROFILE: dict[str, Any] = {
    "robot_profile": "mercator",
    "robot_length": 0.26,
    "robot_width": 0.25,
    "robot_height": 0.20,
    "robot_base_height": 0.08,
    "collision_shape": "obb",
    "collision_radius": 0.105,
    "collision_ring_radius": 0.0,
    "collision_ring_height": 0.0,
    "collision_ring_thickness": 0.0,
    "lidar_tower_diameter": 0.065,
    "lidar_tower_offset": (0.0, 0.0),
    "lidar_height": 0.17545,
    "wheelbase": 0.18,
    "ground_sensor_offset": (0.056, 0.0),
    "teraranger_layout": "native_asymmetric",
    "teraranger_ring_radius": 0.143,
    "teraranger_origin_offset": 0.005,
    "teraranger_max_range": 2.0,
}

TMERCATOR_PROFILE: dict[str, Any] = {
    "robot_profile": "tmercator",
    # Sphero RVR body box: 216 mm long x 185 mm wide x 114 mm high.
    "robot_length": 0.216,
    "robot_width": 0.185,
    "robot_height": 0.170,
    "robot_base_height": 0.114,
    # The centered bumper/proximity ring is the real analytical footprint.
    # Its radius is exactly 3 x the 35 mm e-puck radius used by this project.
    "collision_shape": "circle",
    "collision_radius": 0.105,
    "collision_ring_radius": 0.105,
    "collision_ring_height": 0.056,
    "collision_ring_thickness": 0.010,
    "lidar_tower_diameter": 0.065,
    "lidar_tower_offset": (0.0, 0.0),
    "lidar_height": 0.140,
    # Preserve the transferability setup's existing RVR kinematic track.
    "wheelbase": 0.147,
    "ground_sensor_offset": (0.05, 0.0),
    "teraranger_layout": "uniform_ring",
    "teraranger_ring_radius": 0.105,
    "teraranger_origin_offset": 0.0,
    "teraranger_max_range": 2.0,
}

ROBOT_PROFILES: dict[str, dict[str, Any]] = {
    "mercator": MERCATOR_PROFILE,
    "tmercator": TMERCATOR_PROFILE,
}

_PROFILE_ALIASES = {
    "native": "mercator",
    "transferability": "tmercator",
    "transferability_mercator": "tmercator",
}


def normalize_robot_profile(value: str) -> str:
    """Return a canonical profile name or raise a useful configuration error."""

    normalized = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    normalized = _PROFILE_ALIASES.get(normalized, normalized)
    if normalized not in ROBOT_PROFILES:
        choices = ", ".join(sorted(ROBOT_PROFILES))
        raise ValueError(f"Unknown Mercator robot_profile {value!r}; choose {choices}")
    return normalized


def get_robot_profile(value: str) -> dict[str, Any]:
    """Return a defensive copy of a complete named robot profile."""

    return deepcopy(ROBOT_PROFILES[normalize_robot_profile(value)])


def expand_robot_profile_overrides(environment: Mapping[str, Any]) -> dict[str, Any]:
    """Expand an explicitly selected profile, then apply YAML field overrides.

    If ``robot_profile`` is absent, the mapping is returned unchanged. The
    environment configuration class then supplies the native Mercator defaults.
    If the profile is explicit, every preset field is inserted first and every
    YAML field wins afterwards.
    """

    explicit = dict(environment)
    profile_name = explicit.get("robot_profile")
    if profile_name is None:
        return explicit
    expanded = get_robot_profile(str(profile_name))
    expanded.update(explicit)
    expanded["robot_profile"] = normalize_robot_profile(str(profile_name))
    return expanded
