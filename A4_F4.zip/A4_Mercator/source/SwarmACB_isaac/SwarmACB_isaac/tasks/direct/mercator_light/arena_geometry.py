# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Single source of truth for the Mercator AAC arena.

The ARGoS file specifies twelve wall boxes.  This module stores those twelve
boxes once and derives every representation used by training and rendering:

* wall centre lines for analytical range sensors;
* inward collision boundary half-spaces;
* the visible dodecagonal floor polygon;
* wall centres and yaws for USD rendering;
* a deterministic fingerprint saved in checkpoints.

No training or visualisation code is allowed to rebuild the arena independently.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from typing import Any


# Exact values copied from the user-provided ARGoS XML.  ARGoS wall boxes have
# size=(0.01, 2.57, 0.08), therefore their long local axis is Y.  The derived
# Isaac/analytical segment yaw is ARGoS yaw + 90 degrees.
ARGOS_WALL_CENTERS: tuple[tuple[float, float], ...] = (
    (-4.7957, 0.0),
    (4.7957, 0.0),
    (0.0, 4.7957),
    (0.0, -4.7957),
    (-2.4086, -4.1562),
    (-4.1562, -2.4086),
    (2.4086, 4.1562),
    (4.1562, 2.4086),
    (-2.4086, 4.1562),
    (-4.1562, 2.4086),
    (2.4086, -4.1562),
    (4.1562, -2.4086),
)
ARGOS_WALL_YAW_DEG: tuple[float, ...] = (
    0.0, 0.0, 90.0, 90.0,
    60.0, 30.0, 60.0, 30.0,
    -60.0, -30.0, -60.0, -30.0,
)


def _round_nested(value: Any, digits: int = 9) -> Any:
    if isinstance(value, float):
        return round(value, digits)
    if isinstance(value, (tuple, list)):
        return [_round_nested(v, digits) for v in value]
    if isinstance(value, dict):
        return {k: _round_nested(value[k], digits) for k in sorted(value)}
    return value


def _fingerprint(payload: dict[str, Any]) -> str:
    canonical = json.dumps(
        _round_nested(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=True,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _line_intersection(
    n1: tuple[float, float], d1: float,
    n2: tuple[float, float], d2: float,
) -> tuple[float, float]:
    """Intersection of n1·x=d1 and n2·x=d2."""
    det = n1[0] * n2[1] - n1[1] * n2[0]
    if abs(det) < 1e-12:
        raise ValueError("Adjacent arena wall planes are parallel")
    x = (d1 * n2[1] - n1[1] * d2) / det
    y = (n1[0] * d2 - d1 * n2[0]) / det
    return (x, y)


@dataclass(frozen=True)
class ArenaGeometry:
    wall_side_length: float
    wall_thickness: float
    wall_height: float
    wall_centers: tuple[tuple[float, float], ...]
    wall_segment_yaws_rad: tuple[float, ...]
    wall_segments: tuple[tuple[tuple[float, float], tuple[float, float]], ...]
    outward_normals: tuple[tuple[float, float], ...]
    inner_offsets: tuple[float, ...]
    floor_vertices: tuple[tuple[float, float], ...]
    circumradius: float
    inradius: float
    fingerprint: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "wall_side_length": self.wall_side_length,
            "wall_thickness": self.wall_thickness,
            "wall_height": self.wall_height,
            "wall_centers": self.wall_centers,
            "wall_segment_yaws_rad": self.wall_segment_yaws_rad,
            "wall_segments": self.wall_segments,
            "outward_normals": self.outward_normals,
            "inner_offsets": self.inner_offsets,
            "floor_vertices": self.floor_vertices,
            "circumradius": self.circumradius,
            "inradius": self.inradius,
        }


def build_argos_aac_arena(
    wall_side_length: float = 2.57,
    wall_thickness: float = 0.01,
    wall_height: float = 0.08,
) -> ArenaGeometry:
    """Build every arena representation from the twelve ARGoS wall boxes."""
    if len(ARGOS_WALL_CENTERS) != 12 or len(ARGOS_WALL_YAW_DEG) != 12:
        raise RuntimeError("The ARGoS AAC arena must contain exactly twelve walls")

    half = 0.5 * float(wall_side_length)
    centers: list[tuple[float, float]] = []
    yaws: list[float] = []
    segments: list[tuple[tuple[float, float], tuple[float, float]]] = []
    normals: list[tuple[float, float]] = []
    offsets: list[float] = []

    for center, argos_yaw_deg in zip(ARGOS_WALL_CENTERS, ARGOS_WALL_YAW_DEG):
        cx, cy = float(center[0]), float(center[1])
        segment_yaw = math.radians(float(argos_yaw_deg) + 90.0)
        tx, ty = math.cos(segment_yaw), math.sin(segment_yaw)
        a = (cx - half * tx, cy - half * ty)
        b = (cx + half * tx, cy + half * ty)

        radius = math.hypot(cx, cy)
        if radius <= 0.0:
            raise ValueError("Arena wall centre cannot be at the origin")
        nx, ny = cx / radius, cy / radius
        inner_offset = cx * nx + cy * ny - 0.5 * float(wall_thickness)

        centers.append((cx, cy))
        yaws.append(segment_yaw)
        segments.append((a, b))
        normals.append((nx, ny))
        offsets.append(inner_offset)

    # Sort collision planes by outward-normal angle.  Adjacent plane
    # intersections form the exact visible/traversable floor polygon.
    order = sorted(range(len(normals)), key=lambda i: math.atan2(normals[i][1], normals[i][0]))
    sorted_normals = [normals[i] for i in order]
    sorted_offsets = [offsets[i] for i in order]
    floor_vertices = []
    for i in range(len(order)):
        j = (i + 1) % len(order)
        floor_vertices.append(
            _line_intersection(
                sorted_normals[i], sorted_offsets[i],
                sorted_normals[j], sorted_offsets[j],
            )
        )

    circumradius = max(math.hypot(x, y) for x, y in floor_vertices)
    inradius = min(sorted_offsets)

    payload = {
        "wall_side_length": float(wall_side_length),
        "wall_thickness": float(wall_thickness),
        "wall_height": float(wall_height),
        "argos_wall_centers": ARGOS_WALL_CENTERS,
        "argos_wall_yaw_deg": ARGOS_WALL_YAW_DEG,
        "wall_segments": segments,
        "outward_normals": normals,
        "inner_offsets": offsets,
        "floor_vertices": floor_vertices,
    }
    return ArenaGeometry(
        wall_side_length=float(wall_side_length),
        wall_thickness=float(wall_thickness),
        wall_height=float(wall_height),
        wall_centers=tuple(centers),
        wall_segment_yaws_rad=tuple(yaws),
        wall_segments=tuple(segments),
        outward_normals=tuple(normals),
        inner_offsets=tuple(offsets),
        floor_vertices=tuple(floor_vertices),
        circumradius=float(circumradius),
        inradius=float(inradius),
        fingerprint=_fingerprint(payload),
    )


def build_environment_signature(cfg: Any, arena: ArenaGeometry) -> dict[str, Any]:
    """Mission-critical signature embedded in every new checkpoint."""
    payload = {
        "schema": 1,
        "robot_profile": str(cfg.robot_profile),
        "teraranger_layout": str(cfg.teraranger_layout),
        "teraranger_ring_radius": float(cfg.teraranger_ring_radius),
        "teraranger_origin_offset": float(cfg.teraranger_origin_offset),
        "arena_fingerprint": arena.fingerprint,
        "arena": arena.as_dict(),
        "variant": str(cfg.variant),
        "num_agents": int(cfg.num_agents),
        "episode_length_s": float(cfg.episode_length_s),
        "sim_dt": float(cfg.sim.dt),
        "black_center": tuple(float(v) for v in cfg.black_center),
        "white_center": tuple(float(v) for v in cfg.white_center),
        "zone_radius": float(cfg.zone_radius),
        "light_position": tuple(float(v) for v in cfg.light_position),
        "light_intensity": float(cfg.light_intensity),
        "light_max_distance": float(cfg.light_max_distance),
        "spawn_mode": str(cfg.spawn_mode),
        "spawn_half_range": float(cfg.spawn_half_range),
        "spawn_max_trials": int(cfg.spawn_max_trials),
        "spawn_yaw_mean_deg": float(cfg.spawn_yaw_mean_deg),
        "spawn_yaw_std_deg": float(cfg.spawn_yaw_std_deg),
        "robot_length": float(cfg.robot_length),
        "robot_width": float(cfg.robot_width),
        "robot_height": float(cfg.robot_height),
        "robot_base_height": float(cfg.robot_base_height),
        "lidar_tower_diameter": float(cfg.lidar_tower_diameter),
        "lidar_tower_offset": tuple(float(v) for v in cfg.lidar_tower_offset),
        "lidar_height": float(cfg.lidar_height),
        "ground_sensor_offset": tuple(float(v) for v in cfg.ground_sensor_offset),
        "max_wheel_speed": float(cfg.max_wheel_speed),
        "wheelbase": float(cfg.wheelbase),
        "teraranger_max_range": float(cfg.teraranger_max_range),
        "proximity_threshold": float(cfg.proximity_threshold),
        "neighbor_min_range": float(cfg.neighbor_min_range),
        "neighbor_max_range": float(cfg.neighbor_max_range),
        "neighbor_alpha": float(cfg.neighbor_alpha),
        "cyclamen_neighbor_range": float(cfg.cyclamen_neighbor_range),
        "exploration_tau": int(cfg.exploration_tau),
        "phototaxis_proximity_gain": float(cfg.phototaxis_proximity_gain),
        "anti_phototaxis_proximity_gain": float(cfg.anti_phototaxis_proximity_gain),
        "attraction_proximity_gain": float(cfg.attraction_proximity_gain),
        "repulsion_proximity_gain": float(cfg.repulsion_proximity_gain),
        "repulsion_alpha_parameter": float(cfg.repulsion_alpha_parameter),
    }
    if str(getattr(cfg, "collision_shape", "obb")).strip().lower() != "obb":
        payload.update(
            {
                "collision_shape": str(cfg.collision_shape),
                "collision_radius": float(cfg.collision_radius),
                "collision_ring_radius": float(cfg.collision_ring_radius),
                "collision_ring_height": float(cfg.collision_ring_height),
                "collision_ring_thickness": float(cfg.collision_ring_thickness),
            }
        )

    return {
        "schema": 1,
        "arena_fingerprint": arena.fingerprint,
        "fingerprint": _fingerprint(payload),
        "payload": _round_nested(payload),
    }
