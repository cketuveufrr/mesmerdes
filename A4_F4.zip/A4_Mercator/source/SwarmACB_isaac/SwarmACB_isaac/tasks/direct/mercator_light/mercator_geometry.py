# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Pure-PyTorch 2-D geometry for Mercator OBB and circular footprints.

The hot pairwise OBB path deliberately avoids materialising an
``[..., 4, 2]`` tensor of SAT axes.  It evaluates the same four axes in the
same order as the legacy implementation, preserving tie-breaking and collision
correction semantics while reducing temporary memory and kernel count.
"""

from __future__ import annotations

import torch


_PAIR_MASK_CACHE: dict[tuple[str, int], tuple[torch.Tensor, torch.Tensor]] = {}


def _pair_masks(n: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    """Return cached ``not-self`` and upper-triangle masks for ``n`` robots."""
    key = (str(device), int(n))
    cached = _PAIR_MASK_CACHE.get(key)
    if cached is None:
        eye = torch.eye(n, dtype=torch.bool, device=device).unsqueeze(0)
        upper = torch.triu(
            torch.ones(n, n, dtype=torch.bool, device=device), diagonal=1
        ).unsqueeze(0)
        cached = (~eye, upper)
        _PAIR_MASK_CACHE[key] = cached
    return cached


def body_axes(yaw: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Return forward and left unit vectors for yaw."""
    c = torch.cos(yaw)
    s = torch.sin(yaw)
    return torch.stack((c, s), dim=-1), torch.stack((-s, c), dim=-1)


def rotate_body_to_world(v: torch.Tensor, yaw: torch.Tensor) -> torch.Tensor:
    c = torch.cos(yaw)
    s = torch.sin(yaw)
    return torch.stack(
        (c * v[..., 0] - s * v[..., 1], s * v[..., 0] + c * v[..., 1]),
        dim=-1,
    )


def rotate_world_to_body(v: torch.Tensor, yaw: torch.Tensor) -> torch.Tensor:
    c = torch.cos(yaw)
    s = torch.sin(yaw)
    return torch.stack(
        (c * v[..., 0] + s * v[..., 1], -s * v[..., 0] + c * v[..., 1]),
        dim=-1,
    )


def support_radius(
    yaw: torch.Tensor,
    axes: torch.Tensor,
    half_length: float,
    half_width: float,
) -> torch.Tensor:
    """Projected radius of an oriented box on arbitrary world axes."""
    fwd, left = body_axes(yaw)
    while fwd.ndim < axes.ndim:
        fwd = fwd.unsqueeze(-2)
        left = left.unsqueeze(-2)
    return (
        float(half_length) * (axes * fwd).sum(dim=-1).abs()
        + float(half_width) * (axes * left).sum(dim=-1).abs()
    )


def ray_obb_distances(
    origins: torch.Tensor,
    directions: torch.Tensor,
    centers: torch.Tensor,
    yaws: torch.Tensor,
    half_length: float,
    half_width: float,
    max_distance: float,
) -> torch.Tensor:
    """Ray/OBB intersections with fully broadcastable inputs.

    This is algebraically identical to the legacy slab implementation, but it
    operates on scalar X/Y components and therefore does not allocate bound,
    near, and far tensors with a trailing vector dimension.
    """
    rel = origins - centers
    o = rotate_world_to_body(rel, yaws)
    d = rotate_world_to_body(directions, yaws)

    ox, oy = o[..., 0], o[..., 1]
    dx, dy = d[..., 0], d[..., 1]
    eps = 1e-9
    hl = float(half_length)
    hw = float(half_width)

    non_parallel_x = dx.abs() > eps
    non_parallel_y = dy.abs() > eps
    safe_dx = torch.where(non_parallel_x, dx, torch.ones_like(dx))
    safe_dy = torch.where(non_parallel_y, dy, torch.ones_like(dy))

    t1x = (-hl - ox) / safe_dx
    t2x = (hl - ox) / safe_dx
    t1y = (-hw - oy) / safe_dy
    t2y = (hw - oy) / safe_dy

    neg_inf_x = torch.full_like(t1x, -torch.inf)
    pos_inf_x = torch.full_like(t1x, torch.inf)
    neg_inf_y = torch.full_like(t1y, -torch.inf)
    pos_inf_y = torch.full_like(t1y, torch.inf)

    near_x = torch.where(non_parallel_x, torch.minimum(t1x, t2x), neg_inf_x)
    far_x = torch.where(non_parallel_x, torch.maximum(t1x, t2x), pos_inf_x)
    near_y = torch.where(non_parallel_y, torch.minimum(t1y, t2y), neg_inf_y)
    far_y = torch.where(non_parallel_y, torch.maximum(t1y, t2y), pos_inf_y)

    parallel_outside = (
        ((~non_parallel_x) & ((ox < -hl) | (ox > hl)))
        | ((~non_parallel_y) & ((oy < -hw) | (oy > hw)))
    )
    t_near = torch.maximum(near_x, near_y)
    t_far = torch.minimum(far_x, far_y)
    t = torch.where(t_near >= 0.0, t_near, t_far)
    valid = (~parallel_outside) & (
        t_far >= torch.maximum(t_near, torch.zeros_like(t_near))
    )
    valid &= (t >= 0.0) & (t <= float(max_distance))
    return torch.where(valid, t, torch.full_like(t, float(max_distance)))


def ray_circle_distances(
    origins: torch.Tensor,
    directions: torch.Tensor,
    centers: torch.Tensor,
    radius: float,
    max_distance: float,
) -> torch.Tensor:
    """Ray/circle intersections with fully broadcastable unit directions."""
    rel = origins - centers
    projection = (rel * directions).sum(dim=-1)
    c = (rel * rel).sum(dim=-1) - float(radius) ** 2
    discriminant = projection * projection - c
    has_intersection = discriminant >= 0.0
    root = torch.sqrt(discriminant.clamp_min(0.0))
    near = -projection - root
    far = -projection + root
    distance = torch.where(near >= 0.0, near, far)
    valid = has_intersection & (distance >= 0.0) & (distance <= float(max_distance))
    return torch.where(
        valid, distance, torch.full_like(distance, float(max_distance))
    )


def _pairwise_sat_data(
    positions: torch.Tensor,
    yaws: torch.Tensor,
    half_length: float,
    half_width: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return pair overlap mask, minimum penetration, and separating axis.

    The four SAT axes are evaluated in the legacy order ``fi, li, fj, lj``.
    Thus ``torch.min`` keeps exactly the same first-axis tie-breaking behavior.
    """
    fwd, left = body_axes(yaws)  # E,N,2
    rel = positions.unsqueeze(1) - positions.unsqueeze(2)  # E,i,j: p_j - p_i

    fi = fwd.unsqueeze(2)
    li = left.unsqueeze(2)
    fj = fwd.unsqueeze(1)
    lj = left.unsqueeze(1)

    hl = float(half_length)
    hw = float(half_width)

    fi_fj = (fi * fj).sum(dim=-1)
    fi_lj = (fi * lj).sum(dim=-1)
    li_fj = (li * fj).sum(dim=-1)
    li_lj = (li * lj).sum(dim=-1)

    proj_fi = (rel * fi).sum(dim=-1).abs()
    proj_li = (rel * li).sum(dim=-1).abs()
    proj_fj = (rel * fj).sum(dim=-1).abs()
    proj_lj = (rel * lj).sum(dim=-1).abs()

    overlap_fi = hl + hl * fi_fj.abs() + hw * fi_lj.abs() - proj_fi
    overlap_li = hw + hl * li_fj.abs() + hw * li_lj.abs() - proj_li
    overlap_fj = hl * fi_fj.abs() + hw * li_fj.abs() + hl - proj_fj
    overlap_lj = hl * fi_lj.abs() + hw * li_lj.abs() + hw - proj_lj

    overlap_axes = torch.stack(
        (overlap_fi, overlap_li, overlap_fj, overlap_lj), dim=-1
    )
    overlap = (overlap_axes > 0.0).all(dim=-1)
    not_self, _ = _pair_masks(positions.shape[1], positions.device)
    overlap &= not_self

    min_pen, min_idx = overlap_axes.min(dim=-1)
    # Select the same axis as legacy gather(), without materialising all axes.
    fi_full = fi.expand_as(rel)
    li_full = li.expand_as(rel)
    fj_full = fj.expand_as(rel)
    lj_full = lj.expand_as(rel)
    axis = torch.where(
        (min_idx == 0).unsqueeze(-1),
        fi_full,
        torch.where(
            (min_idx == 1).unsqueeze(-1),
            li_full,
            torch.where((min_idx == 2).unsqueeze(-1), fj_full, lj_full),
        ),
    )
    signed = (rel * axis).sum(dim=-1)
    axis = axis * torch.where(signed >= 0.0, 1.0, -1.0).unsqueeze(-1)
    return overlap, min_pen.clamp_min(0.0), axis


def pairwise_sat_overlap(
    positions: torch.Tensor,
    yaws: torch.Tensor,
    half_length: float,
    half_width: float,
) -> torch.Tensor:
    return _pairwise_sat_data(positions, yaws, half_length, half_width)[0]


def resolve_pairwise_obb_collisions(
    positions: torch.Tensor,
    yaws: torch.Tensor,
    half_length: float,
    half_width: float,
    iterations: int = 2,
) -> torch.Tensor:
    """Resolve OBB penetration and return corrected positions."""
    out = positions
    _, upper = _pair_masks(positions.shape[1], positions.device)
    for _ in range(max(1, int(iterations))):
        overlap, penetration, axis = _pairwise_sat_data(
            out, yaws, half_length, half_width
        )
        active = overlap & upper
        correction = (
            0.5
            * penetration.unsqueeze(-1)
            * axis
            * active.unsqueeze(-1).to(out.dtype)
        )
        incoming = correction.sum(dim=1)
        outgoing = correction.sum(dim=2)
        out = out + incoming - outgoing
    return out


def candidate_overlaps_existing(
    candidate_pos: torch.Tensor,
    candidate_yaw: torch.Tensor,
    existing_pos: torch.Tensor,
    existing_yaw: torch.Tensor,
    half_length: float,
    half_width: float,
) -> torch.Tensor:
    """Return whether each candidate overlaps any existing OBB."""
    if existing_pos.shape[-2] == 0:
        return torch.zeros(
            candidate_pos.shape[0], dtype=torch.bool, device=candidate_pos.device
        )
    pos = torch.cat((candidate_pos.unsqueeze(1), existing_pos), dim=1)
    yaw = torch.cat((candidate_yaw.unsqueeze(1), existing_yaw), dim=1)
    overlap = pairwise_sat_overlap(pos, yaw, half_length, half_width)
    return overlap[:, 0, 1:].any(dim=-1)


def boxes_inside_walls(
    positions: torch.Tensor,
    yaws: torch.Tensor,
    outward_normals: torch.Tensor,
    inner_offsets: torch.Tensor,
    half_length: float,
    half_width: float,
) -> torch.Tensor:
    """Check OBBs against convex arena half-spaces n·x <= offset."""
    axes = outward_normals.view(*([1] * (positions.ndim - 1)), -1, 2)
    support = support_radius(yaws, axes, half_length, half_width)
    center_proj = (positions.unsqueeze(-2) * axes).sum(dim=-1)
    return (
        center_proj
        + support
        <= inner_offsets.view(*([1] * (positions.ndim - 1)), -1) + 1e-7
    ).all(dim=-1)


def resolve_wall_collisions(
    positions: torch.Tensor,
    yaws: torch.Tensor,
    outward_normals: torch.Tensor,
    inner_offsets: torch.Tensor,
    half_length: float,
    half_width: float,
) -> torch.Tensor:
    """Project OBBs back inside all arena half-spaces."""
    axes = outward_normals.view(1, 1, -1, 2)
    support = support_radius(yaws, axes, half_length, half_width)
    center_proj = (positions.unsqueeze(-2) * axes).sum(dim=-1)
    penetration = (
        center_proj + support - inner_offsets.view(1, 1, -1)
    ).clamp_min(0.0)
    return positions - (penetration.unsqueeze(-1) * axes).sum(dim=-2)


def resolve_pairwise_circle_collisions(
    positions: torch.Tensor,
    radius: float,
    iterations: int = 2,
) -> torch.Tensor:
    """Resolve equal-radius circular penetration and return corrected positions."""
    out = positions
    _, upper = _pair_masks(positions.shape[1], positions.device)
    diameter = 2.0 * float(radius)
    for _ in range(max(1, int(iterations))):
        rel = out.unsqueeze(1) - out.unsqueeze(2)
        distance = torch.linalg.vector_norm(rel, dim=-1)
        active = (distance < diameter) & upper
        safe_distance = distance.clamp_min(1e-9)
        axis = rel / safe_distance.unsqueeze(-1)
        fallback = torch.zeros_like(axis)
        fallback[..., 0] = 1.0
        axis = torch.where((distance > 1e-9).unsqueeze(-1), axis, fallback)
        penetration = (diameter - distance).clamp_min(0.0)
        correction = (
            0.5
            * penetration.unsqueeze(-1)
            * axis
            * active.unsqueeze(-1).to(out.dtype)
        )
        incoming = correction.sum(dim=1)
        outgoing = correction.sum(dim=2)
        out = out + incoming - outgoing
    return out


def candidate_circle_overlaps_existing(
    candidate_pos: torch.Tensor,
    existing_pos: torch.Tensor,
    radius: float,
) -> torch.Tensor:
    """Return whether each circular candidate overlaps any existing circle."""
    if existing_pos.shape[-2] == 0:
        return torch.zeros(
            candidate_pos.shape[0], dtype=torch.bool, device=candidate_pos.device
        )
    delta = existing_pos - candidate_pos.unsqueeze(-2)
    return ((delta * delta).sum(dim=-1) < (2.0 * float(radius)) ** 2).any(dim=-1)


def circles_inside_walls(
    positions: torch.Tensor,
    outward_normals: torch.Tensor,
    inner_offsets: torch.Tensor,
    radius: float,
) -> torch.Tensor:
    """Check circles against convex arena half-spaces ``n·x <= offset``."""
    axes = outward_normals.view(*([1] * (positions.ndim - 1)), -1, 2)
    center_proj = (positions.unsqueeze(-2) * axes).sum(dim=-1)
    return (
        center_proj + float(radius)
        <= inner_offsets.view(*([1] * (positions.ndim - 1)), -1) + 1e-7
    ).all(dim=-1)


def resolve_circle_wall_collisions(
    positions: torch.Tensor,
    outward_normals: torch.Tensor,
    inner_offsets: torch.Tensor,
    radius: float,
) -> torch.Tensor:
    """Project circular footprints back inside all arena half-spaces."""
    axes = outward_normals.view(1, 1, -1, 2)
    center_proj = (positions.unsqueeze(-2) * axes).sum(dim=-1)
    penetration = (
        center_proj + float(radius) - inner_offsets.view(1, 1, -1)
    ).clamp_min(0.0)
    return positions - (penetration.unsqueeze(-1) * axes).sum(dim=-2)
