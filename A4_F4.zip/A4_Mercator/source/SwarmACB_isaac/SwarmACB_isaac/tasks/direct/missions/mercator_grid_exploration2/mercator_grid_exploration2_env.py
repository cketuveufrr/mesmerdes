# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Experiment-2 grid exploration in the exact small Mercator arena."""

from __future__ import annotations

import torch

from ..mercator_aggregation2.mercator_aggregation2_arena import build_argos_aac2_arena
from ..mercator_grid_exploration.mercator_grid_exploration_env import (
    MercatorGridExplorationEnv,
)
from .mercator_grid_exploration2_env_cfg import MercatorGridExploration2EnvCfg
from .mercator_grid_exploration2_model import (
    build_grid2_environment_signature,
    ground_scalar,
    update_grid_ages,
)


class MercatorGridExploration2Env(MercatorGridExplorationEnv):
    """Ten-by-ten cell-age objective from ``BigGridExplorationLoopFunc``."""

    cfg: MercatorGridExploration2EnvCfg

    def __init__(
        self,
        cfg: MercatorGridExploration2EnvCfg,
        render_mode: str | None = None,
        **kwargs,
    ):
        super().__init__(cfg, render_mode, **kwargs)
        self._environment_signature = build_grid2_environment_signature(
            cfg, self._arena_geometry
        )

    def _build_arena_geometry(self, cfg: MercatorGridExploration2EnvCfg):
        return build_argos_aac2_arena(
            wall_side_length=float(cfg.arena_side_length),
            wall_thickness=float(cfg.arena_wall_thickness),
            wall_height=float(cfg.arena_wall_height),
        )

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        return ground_scalar(points)

    def _get_rewards(self) -> dict[str, torch.Tensor]:
        step = update_grid_ages(
            self._grid_ages,
            self.agent_pos,
            arena_size=float(self.cfg.grid_arena_size),
            grid_size=int(self.cfg.grid_size),
        )
        self._grid_ages.copy_(step.ages)
        self._ever_visited |= step.visited_mask
        coverage = self._ever_visited.sum(dim=(1, 2)).to(torch.float32) / float(
            int(self.cfg.grid_size) ** 2
        )

        self.last_grid_total_age.copy_(step.total_age)
        self.last_grid_mean_age.copy_(step.mean_age)
        self.last_grid_max_age.copy_(step.max_age)
        self.last_grid_visited_cells.copy_(step.visited_cells)
        self.last_grid_coverage.copy_(coverage)
        self._episode_visited_cell_events += step.visited_cells

        self.last_n_black.zero_()
        self.last_n_white.zero_()
        self._episode_group_reward += step.reward
        return {agent: step.reward for agent in self.cfg.possible_agents}
