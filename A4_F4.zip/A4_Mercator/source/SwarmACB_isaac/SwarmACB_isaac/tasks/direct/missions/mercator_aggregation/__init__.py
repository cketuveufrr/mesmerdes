# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Gym registration for the vectorized Mercator aggregation mission."""

import gymnasium as gym


gym.register(
    id="SwarmACB-MercatorAggregation-v0",
    entry_point=f"{__name__}.mercator_aggregation_env:MercatorAggregationEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": (
            f"{__name__}.mercator_aggregation_env_cfg:MercatorAggregationEnvCfg"
        ),
    },
)
