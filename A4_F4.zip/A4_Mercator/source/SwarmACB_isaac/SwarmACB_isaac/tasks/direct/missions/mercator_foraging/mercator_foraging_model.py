# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Isaac-independent model of Experiment-1 Mercator foraging.

The constants and update order mirror ``GiantForagingTwoSpotsLoopFunc.cpp``
from ``demiurge-project/Results-Transferability``:

* two circular black food spots, radius 0.58 m, centred at (+/-2.9, 0);
* a white nest defined by the arena portion below y=-2.35 m;
* a robot carries at most one unit of food;
* touching either source sets its carrying flag;
* a carried unit is scored and cleared when the robot is in the nest.

This module has no Isaac Sim imports so geometry and scoring can be tested with
ordinary Python/PyTorch.
"""

from __future__ import annotations

from collections.abc import Sequence
import math
from dataclasses import dataclass
import hashlib
import json
from typing import Any

import torch


FOOD_RADIUS = 0.58
FOOD_CENTERS = ((2.9, 0.0), (-2.9, 0.0))
NEST_LIMIT_Y = -2.35

# These vertices reproduce the hand-built white nest used by
# GiantForagingTwoSpotsLoopFunc::GetFloorColor(), rather than approximating it
# as the whole arena half-plane. The top boundary itself remains gray because
# the source first requires y < NEST_LIMIT_Y.
_SOURCE_MAX_DIM = 4.7957
_SOURCE_WALL_CENTER = 4.1562
_SOURCE_WALL_LENGTH = 2.57
_SOURCE_WALL_WIDTH = 0.01
_SOURCE_DIAGONAL_DROP = math.sin(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
NEST_FLOOR_POLYGON = (
    (-_SOURCE_WALL_CENTER - _SOURCE_WALL_WIDTH, NEST_LIMIT_Y),
    (_SOURCE_WALL_CENTER + _SOURCE_WALL_WIDTH, NEST_LIMIT_Y),
    (
        _SOURCE_WALL_CENTER
        - math.cos(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
        + _SOURCE_WALL_WIDTH,
        NEST_LIMIT_Y - _SOURCE_DIAGONAL_DROP - _SOURCE_WALL_WIDTH,
    ),
    (_SOURCE_WALL_LENGTH / 2.0 + _SOURCE_WALL_WIDTH, -_SOURCE_MAX_DIM),
    (-(_SOURCE_WALL_LENGTH / 2.0 + _SOURCE_WALL_WIDTH), -_SOURCE_MAX_DIM),
    (
        -_SOURCE_WALL_CENTER
        + math.cos(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
        - _SOURCE_WALL_WIDTH,
        NEST_LIMIT_Y - _SOURCE_DIAGONAL_DROP - _SOURCE_WALL_WIDTH,
    ),
)


def clip_polygon_below_y(
    vertices: Sequence[Sequence[float]],
    limit_y: float,
) -> tuple[tuple[float, float], ...]:
    """Clip a polygon against ``y <= limit_y``.

    The shared Mercator arena polygon is convex, but the implementation is the
    general Sutherland-Hodgman half-plane clip and is useful in unit tests too.
    """

    points = [(float(point[0]), float(point[1])) for point in vertices]
    if not points:
        return ()

    output: list[tuple[float, float]] = []
    previous = points[-1]
    previous_inside = previous[1] <= float(limit_y)

    for current in points:
        current_inside = current[1] <= float(limit_y)
        if current_inside != previous_inside:
            dy = current[1] - previous[1]
            if abs(dy) < 1e-12:
                intersection = (current[0], float(limit_y))
            else:
                alpha = (float(limit_y) - previous[1]) / dy
                intersection = (
                    previous[0] + alpha * (current[0] - previous[0]),
                    float(limit_y),
                )
            output.append(intersection)
        if current_inside:
            output.append(current)
        previous = current
        previous_inside = current_inside

    return tuple(output)


def food_membership(
    points: torch.Tensor,
    food_centers: Sequence[Sequence[float]] = FOOD_CENTERS,
    food_radius: float = FOOD_RADIUS,
) -> torch.Tensor:
    """Return ``[..., num_food_sources]`` circular membership flags."""

    centers = torch.as_tensor(food_centers, dtype=points.dtype, device=points.device)
    delta = points.unsqueeze(-2) - centers
    return (delta.square().sum(dim=-1) <= float(food_radius) ** 2)


def score_nest_membership(
    points: torch.Tensor,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> torch.Tensor:
    """Return the PostStep delivery test, ``robot_center_y <= limit``."""

    return points[..., 1] <= float(nest_limit_y)


def _triangle_membership_by_area(
    points: torch.Tensor,
    a: torch.Tensor,
    b: torch.Tensor,
    c: torch.Tensor,
    tolerance: float = 1e-4,
) -> torch.Tensor:
    """Vectorized equivalent of the source ``IsWithinTriangle`` helper."""

    def doubled_area(p, q, r):
        return torch.abs(
            p[..., 0] * (q[..., 1] - r[..., 1])
            + q[..., 0] * (r[..., 1] - p[..., 1])
            + r[..., 0] * (p[..., 1] - q[..., 1])
        )

    reference = doubled_area(a, b, c)
    parts = (
        doubled_area(a, b, points)
        + doubled_area(a, c, points)
        + doubled_area(b, c, points)
    )
    # The C++ compares ordinary triangle areas, hence doubled values use twice
    # its 0.0001 tolerance.
    return torch.abs(reference - parts) < (2.0 * float(tolerance))


def floor_nest_membership(
    points: torch.Tensor,
    nest_limit_y: float = NEST_LIMIT_Y,
    polygon: Sequence[Sequence[float]] = NEST_FLOOR_POLYGON,
) -> torch.Tensor:
    """Reproduce the five-triangle white floor test from GetFloorColor()."""

    vertices = torch.as_tensor(polygon, dtype=points.dtype, device=points.device)
    if vertices.shape != (6, 2):
        raise ValueError("The source Mercator foraging nest must have six vertices")
    center = torch.tensor(
        (0.0, float(nest_limit_y)), dtype=points.dtype, device=points.device
    )
    bottom, top, angle1, angle2, angle3, angle4 = vertices
    inside = (
        _triangle_membership_by_area(points, center, top, angle1)
        | _triangle_membership_by_area(points, center, angle2, angle3)
        | _triangle_membership_by_area(points, center, angle1, angle2)
        | _triangle_membership_by_area(points, center, angle3, angle4)
        | _triangle_membership_by_area(points, center, angle4, bottom)
    )
    return (points[..., 1] < float(nest_limit_y)) & inside


def nest_membership(
    points: torch.Tensor,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> torch.Tensor:
    """Backward-compatible alias for the delivery/scoring nest test."""

    return score_nest_membership(points, nest_limit_y)


def ground_scalar(
    points: torch.Tensor,
    food_centers: Sequence[Sequence[float]] = FOOD_CENTERS,
    food_radius: float = FOOD_RADIUS,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> torch.Tensor:
    """Return exact AutoMoDe floor categories: black=0, gray=0.5, white=1."""

    in_food = food_membership(points, food_centers, food_radius).any(dim=-1)
    in_nest = floor_nest_membership(points, nest_limit_y)
    result = torch.full(points.shape[:-1], 0.5, dtype=points.dtype, device=points.device)
    result = torch.where(in_nest, torch.ones_like(result), result)
    # The C++ loop function checks black food spots before the nest. They do not
    # overlap in Experiment 1, but this ordering keeps the implementation exact.
    result = torch.where(in_food, torch.zeros_like(result), result)
    return result


@dataclass(frozen=True)
class ForagingStep:
    carrying: torch.Tensor
    pickup_mask: torch.Tensor
    delivery_mask: torch.Tensor
    in_food: torch.Tensor
    in_nest: torch.Tensor


def update_carrying_state(
    agent_positions: torch.Tensor,
    carrying: torch.Tensor,
    food_centers: Sequence[Sequence[float]] = FOOD_CENTERS,
    food_radius: float = FOOD_RADIUS,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> ForagingStep:
    """Apply one ARGoS foraging score update to an ``[..., robot, 2]`` batch."""

    if agent_positions.shape[:-1] != carrying.shape:
        raise ValueError(
            "agent_positions without its XY axis must match carrying; "
            f"got {tuple(agent_positions.shape)} and {tuple(carrying.shape)}"
        )
    if agent_positions.shape[-1] != 2:
        raise ValueError("agent_positions must end in an XY axis of size 2")

    carrying_before = carrying.to(dtype=torch.bool)
    in_food = food_membership(agent_positions, food_centers, food_radius).any(dim=-1)
    in_nest = score_nest_membership(agent_positions, nest_limit_y)

    pickup_mask = in_food & ~carrying_before
    carrying_after_pickup = carrying_before | in_food
    delivery_mask = in_nest & carrying_after_pickup
    carrying_after = carrying_after_pickup & ~delivery_mask

    return ForagingStep(
        carrying=carrying_after,
        pickup_mask=pickup_mask,
        delivery_mask=delivery_mask,
        in_food=in_food,
        in_nest=in_nest,
    )


def build_foraging_environment_signature(cfg: Any, arena: Any) -> dict[str, Any]:
    """Build a mission-specific checkpoint signature without changing AAC hashes."""

    payload = {
        "schema": 1,
        "robot_profile": str(cfg.robot_profile),
        "teraranger_layout": str(cfg.teraranger_layout),
        "teraranger_ring_radius": float(cfg.teraranger_ring_radius),
        "teraranger_origin_offset": float(cfg.teraranger_origin_offset),
        "mission": "experiment1_mercator_foraging",
        "arena_fingerprint": str(arena.fingerprint),
        "arena": arena.as_dict(),
        "variant": str(cfg.variant),
        "num_agents": int(cfg.num_agents),
        "episode_length_s": float(cfg.episode_length_s),
        "sim_dt": float(cfg.sim.dt),
        "decimation": int(cfg.decimation),
        "analytical_substeps": int(cfg.analytical_substeps),
        "food_centers": tuple(tuple(float(v) for v in center) for center in cfg.food_centers),
        "food_radius": float(cfg.food_radius),
        "nest_limit_y": float(cfg.nest_limit_y),
        "nest_floor_polygon": tuple(
            tuple(float(v) for v in point) for point in NEST_FLOOR_POLYGON
        ),
        "floor_nest_boundary": "strict_y_less_than_limit_and_five_triangles",
        "delivery_boundary": "robot_center_y_less_than_or_equal_to_limit",
        "light_position": tuple(float(v) for v in cfg.light_position),
        "light_intensity": float(cfg.light_intensity),
        "light_max_distance": float(cfg.light_max_distance),
        "spawn_mode": str(cfg.spawn_mode),
        "spawn_half_range": float(cfg.spawn_half_range),
        "spawn_max_trials": int(cfg.spawn_max_trials),
        "spawn_yaw_mean_deg": float(cfg.spawn_yaw_mean_deg),
        "spawn_yaw_std_deg": float(cfg.spawn_yaw_std_deg),
        "robot_length": float(cfg.robot_length),
        "robot_width": float(cfg.robot_width),
        "robot_height": float(cfg.robot_height),
        "robot_base_height": float(cfg.robot_base_height),
        "lidar_tower_diameter": float(cfg.lidar_tower_diameter),
        "lidar_tower_offset": tuple(float(v) for v in cfg.lidar_tower_offset),
        "lidar_height": float(cfg.lidar_height),
        "ground_sensor_offset": tuple(float(v) for v in cfg.ground_sensor_offset),
        "max_wheel_speed": float(cfg.max_wheel_speed),
        "wheelbase": float(cfg.wheelbase),
        "teraranger_max_range": float(cfg.teraranger_max_range),
        "proximity_threshold": float(cfg.proximity_threshold),
        "neighbor_min_range": float(cfg.neighbor_min_range),
        "neighbor_max_range": float(cfg.neighbor_max_range),
        "neighbor_alpha": float(cfg.neighbor_alpha),
        "cyclamen_neighbor_range": float(cfg.cyclamen_neighbor_range),
        "exploration_tau": int(cfg.exploration_tau),
        "phototaxis_proximity_gain": float(cfg.phototaxis_proximity_gain),
        "anti_phototaxis_proximity_gain": float(cfg.anti_phototaxis_proximity_gain),
        "attraction_proximity_gain": float(cfg.attraction_proximity_gain),
        "repulsion_proximity_gain": float(cfg.repulsion_proximity_gain),
        "repulsion_alpha_parameter": float(cfg.repulsion_alpha_parameter),
    }

    def normalize(value: Any) -> Any:
        if isinstance(value, float):
            return round(value, 9)
        if isinstance(value, (tuple, list)):
            return [normalize(item) for item in value]
        if isinstance(value, dict):
            return {key: normalize(value[key]) for key in sorted(value)}
        return value

    if str(getattr(cfg, "collision_shape", "obb")).strip().lower() != "obb":
        payload.update(
            {
                "collision_shape": str(cfg.collision_shape),
                "collision_radius": float(cfg.collision_radius),
                "collision_ring_radius": float(cfg.collision_ring_radius),
                "collision_ring_height": float(cfg.collision_ring_height),
                "collision_ring_thickness": float(cfg.collision_ring_thickness),
            }
        )

    canonical = json.dumps(
        normalize(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")
    return {
        "schema": 1,
        "mission": payload["mission"],
        "arena_fingerprint": arena.fingerprint,
        "fingerprint": hashlib.sha256(canonical).hexdigest(),
        "payload": normalize(payload),
    }
