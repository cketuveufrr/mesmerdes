# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Massively parallel AAC environment for the light Mercator model.

The mechanical body is a 0.26 x 0.25 x 0.08 m oriented box.  A visual/LiDAR
 tower of diameter 0.065 m extends from z=0.08 m to z=0.20 m through the USD
 lidar-link offset.  Physics, sensors and neighbours are analytical batched
 PyTorch operations; USD primitives are visual only.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

import numpy as np
import torch

import isaaclab.sim as sim_utils
from isaaclab.envs import DirectMARLEnv
from isaaclab.sim.spawners.from_files import GroundPlaneCfg, spawn_ground_plane

from pxr import Gf, UsdGeom
import omni.usd

from ...mercator_light import (
    MercatorBehaviorModules,
    MercatorLightSensors,
    build_argos_aac_arena,
    build_environment_signature,
)
from ...mercator_light.argos_spawn import chocolate_big_aac_disk_points
from ...mercator_light.mercator_geometry import (
    boxes_inside_walls,
    candidate_circle_overlaps_existing,
    candidate_overlaps_existing,
    circles_inside_walls,
    resolve_circle_wall_collisions,
    resolve_pairwise_circle_collisions,
    resolve_pairwise_obb_collisions,
    resolve_wall_collisions,
    rotate_body_to_world,
)
from ...mercator_light.mercator_sensors import MercatorSensorBatch
from .mercator_aggregation_env_cfg import MercatorAggregationEnvCfg


_MODULE_COLORS = (
    (0.10, 0.35, 0.95),  # exploration
    (0.45, 0.45, 0.45),  # stop
    (1.00, 0.78, 0.15),  # phototaxis
    (0.55, 0.20, 0.85),  # anti-phototaxis
    (0.10, 0.72, 0.35),  # attraction
    (0.95, 0.22, 0.18),  # repulsion
)


class MercatorAggregationEnv(DirectMARLEnv):
    cfg: MercatorAggregationEnvCfg

    def _build_arena_geometry(self, cfg: MercatorAggregationEnvCfg):
        """Return the mission arena. Subclasses may select another ARGoS arena."""
        return build_argos_aac_arena(
            wall_side_length=float(cfg.arena_side_length),
            wall_thickness=float(cfg.arena_wall_thickness),
            wall_height=float(cfg.arena_wall_height),
        )

    def __init__(self, cfg: MercatorAggregationEnvCfg, render_mode: str | None = None, **kwargs):
        # Build the arena before DirectMARLEnv invokes _setup_scene().  The same
        # immutable object is then used for rendering, sensors, collision, spawn
        # and checkpoint verification.
        self._arena_geometry = self._build_arena_geometry(cfg)
        self._environment_signature = build_environment_signature(cfg, self._arena_geometry)
        super().__init__(cfg, render_mode, **kwargs)
        e, n, dev = self.num_envs, cfg.num_agents, self.device

        self.agent_pos = torch.zeros(e, n, 2, dtype=torch.float32, device=dev)
        self.agent_yaw = torch.zeros(e, n, dtype=torch.float32, device=dev)
        self._raw_actions: dict[str, torch.Tensor] = {}
        self._sensor_cache: MercatorSensorBatch | None = None
        self._last_module_ids = torch.zeros(e, n, dtype=torch.long, device=dev)
        self._cached_wheels = torch.zeros(e, n, 2, dtype=torch.float32, device=dev)

        # Snapshot used by the trainer to bootstrap time-limit truncations from
        # the final state rather than from Isaac Lab's auto-reset state.
        self._last_transition_final_critic_state = torch.zeros(
            e, n, 5, dtype=torch.float32, device=dev,
        )
        self._last_transition_final_state_mask = torch.zeros(
            e, dtype=torch.bool, device=dev,
        )

        self.completed_group_reward = torch.zeros(e, device=dev)
        self._episode_group_reward = torch.zeros(e, device=dev)
        self.last_n_black = torch.zeros(e, device=dev)
        self.last_n_white = torch.zeros(e, device=dev)
        self.completed_n_black = torch.zeros(e, device=dev)
        self.completed_n_white = torch.zeros(e, device=dev)

        # One-step side channel used only by the real AutoMoDe FSM playback
        # scripts. Training callers never set it and retain the original path.
        self._fsm_behavior_parameters: dict[str, torch.Tensor] | None = None

        self.robot_half_length = 0.5 * float(cfg.robot_length)
        self.robot_half_width = 0.5 * float(cfg.robot_width)
        self.collision_shape = (
            str(getattr(cfg, "collision_shape", "obb")).strip().lower()
        )
        self.collision_radius = float(getattr(cfg, "collision_radius", 0.105))
        if self.collision_shape not in ("obb", "circle"):
            raise ValueError("collision_shape must be obb or circle")
        if self.collision_radius <= 0.0:
            raise ValueError("collision_radius must be positive")
        self.robot_base_height = float(cfg.robot_base_height)
        self.lidar_tower_height = float(cfg.robot_height) - self.robot_base_height
        if self.lidar_tower_height <= 0.0:
            raise ValueError("robot_height must be greater than robot_base_height")
        if not self.robot_base_height < float(cfg.lidar_height) < float(cfg.robot_height):
            raise ValueError("lidar_height must lie inside the artificial tower")

        self.light_pos = torch.tensor(cfg.light_position[:2], dtype=torch.float32, device=dev)
        light_norm = torch.linalg.vector_norm(self.light_pos)
        if float(light_norm) > 1e-8:
            self.light_dir = self.light_pos / light_norm
        else:
            self.light_dir = torch.tensor((1.0, 0.0), dtype=torch.float32, device=dev)
        self.ground_sensor_offset = torch.tensor(
            cfg.ground_sensor_offset, dtype=torch.float32, device=dev,
        )
        # Immutable mission constants are tensors once, not allocations in the
        # per-step ground/reward hot path.
        self.black_center = torch.tensor(
            cfg.black_center, dtype=torch.float32, device=dev,
        )
        self.white_center = torch.tensor(
            cfg.white_center, dtype=torch.float32, device=dev,
        )
        self.zone_radius_sq = float(cfg.zone_radius) ** 2

        self.wall_segments = torch.tensor(
            self._arena_geometry.wall_segments, dtype=torch.float32, device=self.device,
        )
        self.wall_outward_normals = torch.tensor(
            self._arena_geometry.outward_normals, dtype=torch.float32, device=self.device,
        )
        self.wall_inner_offsets = torch.tensor(
            self._arena_geometry.inner_offsets, dtype=torch.float32, device=self.device,
        )

        self.sensors = MercatorLightSensors(
            device=dev,
            robot_half_length=self.robot_half_length,
            robot_half_width=self.robot_half_width,
            collision_shape=self.collision_shape,
            robot_collision_radius=self.collision_radius,
            teraranger_layout=cfg.teraranger_layout,
            teraranger_ring_radius=cfg.teraranger_ring_radius,
            teraranger_max_range=cfg.teraranger_max_range,
            teraranger_origin_offset=cfg.teraranger_origin_offset,
            neighbor_min_range=cfg.neighbor_min_range,
            neighbor_max_range=cfg.neighbor_max_range,
            neighbor_alpha=cfg.neighbor_alpha,
            tower_offset=cfg.lidar_tower_offset,
            cyclamen_neighbor_range=cfg.cyclamen_neighbor_range,
            light_max_distance=cfg.light_max_distance,
            light_enabled=float(cfg.light_intensity) > 0.0,
        )
        self.sensors.bind_wall_segments(self.wall_segments)
        self.behavior_modules = MercatorBehaviorModules(
            max_speed=cfg.max_wheel_speed,
            proximity_threshold=cfg.proximity_threshold,
            exploration_tau=cfg.exploration_tau,
            phototaxis_proximity_gain=cfg.phototaxis_proximity_gain,
            anti_phototaxis_proximity_gain=cfg.anti_phototaxis_proximity_gain,
            attraction_proximity_gain=cfg.attraction_proximity_gain,
            repulsion_proximity_gain=cfg.repulsion_proximity_gain,
            repulsion_alpha_parameter=cfg.repulsion_alpha_parameter,
            device=dev,
        )
        self.behavior_modules.init_state(e, n)

    # ------------------------------------------------------------------
    # Scene: visual only
    # ------------------------------------------------------------------

    def _setup_scene(self):
        spawn_ground_plane(prim_path="/World/ground", cfg=GroundPlaneCfg())
        dome = sim_utils.DomeLightCfg(intensity=1800.0, color=(0.75, 0.75, 0.75))
        dome.func("/World/Light", dome)
        self._spawn_arena_visuals()

        # Clone the simulation environments first.  Robot visuals are global,
        # display-only prims and must be created after cloning so that the scene
        # cloner cannot hide, relocate, or replace them.
        self.scene.clone_environments(copy_from_source=False)

        self._robot_visual_xforms = []
        self._robot_visual_leds = []
        if bool(getattr(self.cfg, "enable_visualization", False)):
            self._create_direct_robot_visuals()

    def _spawn_arena_visuals(self):
        cfg = self.cfg
        arena = self._arena_geometry
        self._spawn_shared_arena_floor_visual()

        for name, center, color in (
            ("Black", cfg.black_center, (0.015, 0.015, 0.015)),
            ("White", cfg.white_center, (0.96, 0.96, 0.96)),
        ):
            zone = sim_utils.CylinderCfg(
                radius=float(cfg.zone_radius),
                height=0.004,
                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=color),
            )
            zone.func(
                f"/World/Arena/{name}Zone", zone,
                translation=(float(center[0]), float(center[1]), 0.003),
            )

        wall_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.73, 0.64, 0.42))
        for idx, (center, yaw) in enumerate(
            zip(arena.wall_centers, arena.wall_segment_yaws_rad)
        ):
            wall = sim_utils.CuboidCfg(
                size=(arena.wall_side_length, arena.wall_thickness, arena.wall_height),
                visual_material=wall_material,
            )
            wall.func(
                f"/World/Arena/Wall_{idx}", wall,
                translation=(float(center[0]), float(center[1]), 0.5 * arena.wall_height),
                orientation=(0.0, 0.0, math.sin(0.5 * yaw), math.cos(0.5 * yaw)),
            )

        # ARGoS Experiment 2 declares the light entity with intensity 0.0.
        # Do not draw an active yellow beacon when the corresponding sensor is
        # intentionally disabled; Experiment 1 and Foraging keep their marker.
        if float(getattr(cfg, "light_intensity", 1.0)) > 0.0:
            lx, ly, lz = cfg.light_position
            light_marker = sim_utils.SphereCfg(
                radius=0.08,
                visual_material=sim_utils.PreviewSurfaceCfg(
                    diffuse_color=(1.0, 0.85, 0.10)
                ),
            )
            light_marker.func(
                "/World/Arena/LightIndicator", light_marker,
                translation=(float(lx), float(ly), float(lz)),
            )

    def _spawn_shared_arena_floor_visual(self) -> None:
        """Draw the exact collision polygon from the shared arena object."""
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            raise RuntimeError("USD stage is unavailable while creating arena floor")
        vertices = [
            Gf.Vec3f(float(x), float(y), 0.002)
            for x, y in self._arena_geometry.floor_vertices
        ]
        count = len(vertices)
        mesh = UsdGeom.Mesh.Define(stage, "/World/Arena/DodecagonFloor")
        mesh.CreatePointsAttr(vertices)
        mesh.CreateFaceVertexCountsAttr([count])
        mesh.CreateFaceVertexIndicesAttr(list(range(count)))
        mesh.CreateDoubleSidedAttr(True)
        gprim = UsdGeom.Gprim(mesh.GetPrim())
        gprim.CreateDisplayColorAttr([Gf.Vec3f(0.46, 0.46, 0.46)])
        gprim.CreateDisplayOpacityAttr([1.0])

    @staticmethod
    def _create_annulus_mesh(
        stage,
        path: str,
        *,
        outer_radius: float,
        inner_radius: float,
        bottom_z: float,
        top_z: float,
        segments: int = 32,
    ) -> None:
        """Create a lightweight closed annular prism for the tMercator bumper."""
        points = []
        for z in (bottom_z, top_z):
            for radius in (outer_radius, inner_radius):
                for index in range(segments):
                    angle = math.tau * index / segments
                    points.append(
                        Gf.Vec3f(
                            radius * math.cos(angle), radius * math.sin(angle), z
                        )
                    )

        def vertex(layer: int, ring: int, index: int) -> int:
            return layer * (2 * segments) + ring * segments + (index % segments)

        counts = []
        indices = []
        for index in range(segments):
            nxt = index + 1
            faces = (
                (
                    vertex(0, 0, index),
                    vertex(0, 0, nxt),
                    vertex(1, 0, nxt),
                    vertex(1, 0, index),
                ),
                (
                    vertex(0, 1, nxt),
                    vertex(0, 1, index),
                    vertex(1, 1, index),
                    vertex(1, 1, nxt),
                ),
                (
                    vertex(1, 0, index),
                    vertex(1, 0, nxt),
                    vertex(1, 1, nxt),
                    vertex(1, 1, index),
                ),
                (
                    vertex(0, 0, nxt),
                    vertex(0, 0, index),
                    vertex(0, 1, index),
                    vertex(0, 1, nxt),
                ),
            )
            for face in faces:
                counts.append(4)
                indices.extend(face)
        mesh = UsdGeom.Mesh.Define(stage, path)
        mesh.CreatePointsAttr(points)
        mesh.CreateFaceVertexCountsAttr(counts)
        mesh.CreateFaceVertexIndicesAttr(indices)
        mesh.CreateDoubleSidedAttr(True)
        gprim = UsdGeom.Gprim(mesh.GetPrim())
        gprim.CreateDisplayColorAttr([Gf.Vec3f(0.92, 0.25, 0.08)])
        gprim.CreateDisplayOpacityAttr([1.0])

    def _create_direct_robot_visuals(self) -> None:
        """Create one ordinary USD hierarchy per visible robot.

        VisualizationMarkers are efficient, but their PointInstancer prototypes
        can remain hidden on some Isaac Sim/Isaac Lab combinations.  Twenty
        ordinary Xforms are negligible here and considerably more robust.
        """
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            raise RuntimeError("USD stage is unavailable while creating robot visuals")

        root_path = "/World/Visuals/MercatorRobots"
        UsdGeom.Xform.Define(stage, root_path)

        base_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.18, 0.43, 0.82))
        tower_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.10, 0.24, 0.52))
        heading_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(1.0, 0.95, 0.15))

        tower_height = float(self.cfg.robot_height) - float(self.cfg.robot_base_height)
        tower_offset = tuple(float(v) for v in self.cfg.lidar_tower_offset)

        for robot_idx in range(int(self.cfg.num_agents)):
            robot_path = f"{root_path}/Mercator_{robot_idx:02d}"
            robot_xform = UsdGeom.Xform.Define(stage, robot_path)
            xform_api = UsdGeom.XformCommonAPI(robot_xform.GetPrim())
            self._robot_visual_xforms.append(xform_api)

            base_cfg = sim_utils.CuboidCfg(
                size=(
                    float(self.cfg.robot_length),
                    float(self.cfg.robot_width),
                    float(self.cfg.robot_base_height),
                ),
                visual_material=base_material,
            )
            base_cfg.func(
                f"{robot_path}/Base",
                base_cfg,
                translation=(0.0, 0.0, 0.5 * float(self.cfg.robot_base_height)),
            )

            ring_radius = float(getattr(self.cfg, "collision_ring_radius", 0.0))
            ring_height = float(getattr(self.cfg, "collision_ring_height", 0.0))
            ring_thickness = float(getattr(self.cfg, "collision_ring_thickness", 0.0))
            if ring_radius > 0.0 and ring_height > 0.0 and ring_thickness > 0.0:
                inner_radius = max(1e-4, ring_radius - ring_thickness)
                ring_bottom = float(self.cfg.robot_height) - ring_height
                self._create_annulus_mesh(
                    stage,
                    f"{robot_path}/CollisionRing",
                    outer_radius=ring_radius,
                    inner_radius=inner_radius,
                    bottom_z=ring_bottom,
                    top_z=float(self.cfg.robot_height),
                )

            tower_cfg = sim_utils.CylinderCfg(
                radius=0.5 * float(self.cfg.lidar_tower_diameter),
                height=tower_height,
                visual_material=tower_material,
            )
            tower_cfg.func(
                f"{robot_path}/LidarTower",
                tower_cfg,
                translation=(
                    tower_offset[0],
                    tower_offset[1],
                    0.5 * (float(self.cfg.robot_base_height) + float(self.cfg.robot_height)),
                ),
            )

            # Large enough to remain visible from the default overhead camera.
            heading_cfg = sim_utils.SphereCfg(
                radius=0.028,
                visual_material=heading_material,
            )
            heading_cfg.func(
                f"{robot_path}/Heading",
                heading_cfg,
                translation=(
                    0.40 * float(self.cfg.robot_length),
                    0.0,
                    float(self.cfg.robot_base_height) + 0.025,
                ),
            )

            # One small colored status lamp for each module. Only the selected
            # lamp is visible; the body itself remains a stable blue robot shape.
            led_images = []
            for module_idx, color in enumerate(_MODULE_COLORS):
                led_path = f"{robot_path}/ModuleLed_{module_idx}"
                led_cfg = sim_utils.SphereCfg(
                    radius=0.020,
                    visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=color),
                )
                led_cfg.func(
                    led_path,
                    led_cfg,
                    translation=(
                        tower_offset[0],
                        tower_offset[1],
                        float(self.cfg.robot_height) + 0.018,
                    ),
                )
                imageable = UsdGeom.Imageable(stage.GetPrimAtPath(led_path))
                if module_idx == 0:
                    imageable.MakeVisible()
                else:
                    imageable.MakeInvisible()
                led_images.append(imageable)
            self._robot_visual_leds.append(led_images)

        print(
            f"[MercatorVisuals] Created {len(self._robot_visual_xforms)} direct USD robot hierarchies "
            f"under {root_path}"
        )

    def _update_visual_markers(self):
        """Update the direct USD visual hierarchy from the analytical state."""
        if not bool(getattr(self.cfg, "enable_visualization", False)):
            return
        if not hasattr(self, "agent_pos") or not self._robot_visual_xforms:
            return

        positions = self.agent_pos[0].detach().cpu().numpy()
        yaws = self.agent_yaw[0].detach().cpu().numpy()
        module_ids = self._last_module_ids[0].detach().cpu().numpy().astype(np.int32)

        for idx, xform_api in enumerate(self._robot_visual_xforms):
            xform_api.SetTranslate(
                Gf.Vec3d(float(positions[idx, 0]), float(positions[idx, 1]), 0.0)
            )
            xform_api.SetRotate(
                Gf.Vec3f(0.0, 0.0, float(math.degrees(yaws[idx]))),
                UsdGeom.XformCommonAPI.RotationOrderXYZ,
            )

            active_module = int(module_ids[idx])
            for module_idx, imageable in enumerate(self._robot_visual_leds[idx]):
                if module_idx == active_module:
                    imageable.MakeVisible()
                else:
                    imageable.MakeInvisible()

    # ------------------------------------------------------------------
    # Arena geometry
    # ------------------------------------------------------------------

    def _build_wall_segments(self) -> torch.Tensor:
        """Compatibility helper; returns the shared sensor segments."""
        return torch.tensor(
            self._arena_geometry.wall_segments, dtype=torch.float32, device=self.device,
        )

    def _build_wall_halfspaces(self) -> tuple[torch.Tensor, torch.Tensor]:
        """Compatibility helper; returns the shared collision half-spaces."""
        return (
            torch.tensor(
                self._arena_geometry.outward_normals,
                dtype=torch.float32, device=self.device,
            ),
            torch.tensor(
                self._arena_geometry.inner_offsets,
                dtype=torch.float32, device=self.device,
            ),
        )

    @property
    def arena_fingerprint(self) -> str:
        return self._arena_geometry.fingerprint

    def get_environment_signature(self) -> dict:
        # Return a detached regular Python structure suitable for torch.save.
        return dict(self._environment_signature)

    def _resolve_collisions(self):
        if self.collision_shape == "circle":
            self.agent_pos = resolve_pairwise_circle_collisions(
                self.agent_pos, self.collision_radius, iterations=2
            )
            self.agent_pos = resolve_circle_wall_collisions(
                self.agent_pos,
                self.wall_outward_normals,
                self.wall_inner_offsets,
                self.collision_radius,
            )
        else:
            self.agent_pos = resolve_pairwise_obb_collisions(
                self.agent_pos,
                self.agent_yaw,
                self.robot_half_length,
                self.robot_half_width,
                iterations=2,
            )
            self.agent_pos = resolve_wall_collisions(
                self.agent_pos,
                self.agent_yaw,
                self.wall_outward_normals,
                self.wall_inner_offsets,
                self.robot_half_length,
                self.robot_half_width,
            )

    # ------------------------------------------------------------------
    # Actions and kinematics
    # ------------------------------------------------------------------

    def set_fsm_behavior_parameters(
        self,
        *,
        exploration_tau: torch.Tensor,
        attraction_alpha: torch.Tensor,
        repulsion_alpha: torch.Tensor,
        state_entry_mask: torch.Tensor,
    ) -> None:
        """Attach per-robot Chocolate parameters to the next environment step.

        The public action remains the module ID, preserving the registered Gym
        interface. This side channel carries parameters that are part of the FSM
        state itself and therefore cannot be represented by IDs 0..5 alone.
        """

        expected = (self.num_envs, int(self.cfg.num_agents))
        values = {
            "exploration_tau": exploration_tau,
            "attraction_alpha": attraction_alpha,
            "repulsion_alpha": repulsion_alpha,
            "state_entry_mask": state_entry_mask,
        }
        normalized: dict[str, torch.Tensor] = {}
        for name, value in values.items():
            tensor = value.to(device=self.device)
            if tuple(tensor.shape) != expected:
                raise ValueError(
                    f"{name} must have shape {expected}, got {tuple(tensor.shape)}"
                )
            normalized[name] = tensor
        self._fsm_behavior_parameters = normalized

    def _pre_physics_step(self, actions: dict[str, torch.Tensor]) -> None:
        """Evaluate the selected AutoMoDe module once per 10 Hz control step."""
        self._raw_actions = actions
        cfg = self.cfg

        if cfg.discrete_actions:
            module_ids = torch.stack(
                [self._raw_actions[a].squeeze(-1).long() for a in cfg.possible_agents],
                dim=1,
            ).clamp(0, 5)
            self._last_module_ids = module_ids
            control_sensors = self.sensors.compute_all(
                self.agent_pos, self.agent_yaw, self.wall_segments, self.light_pos,
            )
            fsm_parameters = self._fsm_behavior_parameters
            self._fsm_behavior_parameters = None
            if fsm_parameters is None:
                self._cached_wheels = self.behavior_modules.compute(
                    module_ids, control_sensors,
                )
            else:
                self._cached_wheels = self.behavior_modules.compute(
                    module_ids,
                    control_sensors,
                    exploration_tau=fsm_parameters["exploration_tau"],
                    attraction_alpha=fsm_parameters["attraction_alpha"],
                    repulsion_alpha=fsm_parameters["repulsion_alpha"],
                    state_entry_mask=fsm_parameters["state_entry_mask"],
                )
        else:
            normalized = torch.stack(
                [self._raw_actions[a] for a in cfg.possible_agents], dim=1,
            )
            self._cached_wheels = (
                normalized.clamp(-1.0, 1.0) * float(cfg.max_wheel_speed)
            )
            self._last_module_ids.zero_()

        # Observations are sampled after all six physics substeps, so a control
        # sensor snapshot from the beginning of the step must never be reused.
        self._sensor_cache = None

    def _apply_action(self) -> None:
        """Integrate one 10 Hz command through the original 6 x 60 Hz steps.

        Isaac itself advances only once per control tick.  All mission-relevant
        dynamics are analytical, so keeping collision resolution after every
        internal substep reproduces the old decimation=6 trajectory.
        """
        cfg = self.cfg
        wheels = self._cached_wheels
        left, right = wheels[..., 0], wheels[..., 1]
        v = 0.5 * (left + right)
        omega = (right - left) / float(cfg.wheelbase)

        substeps = max(1, int(getattr(cfg, "analytical_substeps", 1)))
        control_dt = float(cfg.sim.dt) * int(cfg.decimation)
        dt = control_dt / substeps
        straight = omega.abs() < 1e-6
        safe_omega = torch.where(straight, torch.ones_like(omega), omega)

        for _ in range(substeps):
            theta0 = self.agent_yaw
            theta1 = theta0 + omega * dt
            dx_arc = v / safe_omega * (torch.sin(theta1) - torch.sin(theta0))
            dy_arc = -v / safe_omega * (torch.cos(theta1) - torch.cos(theta0))
            dx = torch.where(straight, v * torch.cos(theta0) * dt, dx_arc)
            dy = torch.where(straight, v * torch.sin(theta0) * dt, dy_arc)
            self.agent_pos[..., 0] += dx
            self.agent_pos[..., 1] += dy
            self.agent_yaw = torch.atan2(torch.sin(theta1), torch.cos(theta1))
            self._resolve_collisions()

        self._update_visual_markers()

    # ------------------------------------------------------------------
    # Observations/reward/reset
    # ------------------------------------------------------------------

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        black_delta = points - self.black_center.view(1, 1, 2)
        white_delta = points - self.white_center.view(1, 1, 2)
        in_black = (black_delta * black_delta).sum(dim=-1) <= self.zone_radius_sq
        in_white = (white_delta * white_delta).sum(dim=-1) <= self.zone_radius_sq
        out = torch.full(in_black.shape, 0.5, dtype=torch.float32, device=self.device)
        out.masked_fill_(in_black, 0.0)
        out.masked_fill_(in_white, 1.0)
        return out

    def _ground_sensor_points(self) -> torch.Tensor:
        return self.agent_pos + rotate_body_to_world(
            self.ground_sensor_offset.view(1, 1, 2), self.agent_yaw,
        )

    def _zone_counts_from_centers(self) -> tuple[torch.Tensor, torch.Tensor]:
        ground = self._ground_scalar_at(self.agent_pos)
        return (ground < 0.25).sum(dim=1).float(), (ground > 0.75).sum(dim=1).float()

    def _current_sensors(self) -> MercatorSensorBatch:
        if self._sensor_cache is not None:
            result = self._sensor_cache
            self._sensor_cache = None
            return result
        return self.sensors.compute_all(
            self.agent_pos, self.agent_yaw, self.wall_segments, self.light_pos,
        )

    def _get_observations_tensor(self) -> torch.Tensor:
        """Return the native ``[env, agent, obs]`` actor observation tensor."""
        # Actor ground sensing uses the physical forward sensor position.  The
        # group reward below intentionally remains center-based.
        ground = self._ground_scalar_at(self._ground_sensor_points())

        if self.cfg.variant in ("dandelion", "daisy"):
            sensors = self._current_sensors()
            return torch.cat(
                (
                    sensors.proximity_values,
                    sensors.light_values,
                    ground.unsqueeze(-1),
                    sensors.ztilde.unsqueeze(-1),
                    sensors.rab_projection,
                ),
                dim=-1,
            )

        # Cyclamen/Lily/Tulip require only ground + nonlinear neighbour count.
        # Recomputing all 8 proximity rays, light sectors, and neighbour vectors
        # here used to duplicate the most expensive sensor pass every step.
        ztilde = self.sensors.compute_cyclamen_ztilde(
            self.agent_pos, self.agent_yaw
        )
        return torch.stack((ground, ztilde), dim=-1)

    def _get_observations(self) -> dict[str, torch.Tensor]:
        obs_all = self._get_observations_tensor()
        return {
            agent: obs_all[:, index]
            for index, agent in enumerate(self.cfg.possible_agents)
        }
    def _get_rewards(self) -> dict[str, torch.Tensor]:
        n_black, n_white = self._zone_counts_from_centers()
        self.last_n_black = n_black
        self.last_n_white = n_white
        self._episode_group_reward += n_black
        return {a: n_black for a in self.cfg.possible_agents}

    def _get_dones(self) -> tuple[dict[str, torch.Tensor], dict[str, torch.Tensor]]:
        timeout = self.episode_length_buf >= self.max_episode_length - 1

        # _get_dones() runs before DirectMARLEnv auto-resets timed-out envs.
        # Preserve that exact final state for POCA's interrupted-trajectory
        # bootstrap.  Non-timeout entries are explicitly invalidated each step.
        self._last_transition_final_state_mask.copy_(timeout)
        # Avoid a CUDA -> CPU synchronization from ``if timeout.any()``.  The
        # 5-D state is cheap and masked entirely on-device.
        final_state = self.get_critic_state()
        self._last_transition_final_critic_state.copy_(
            torch.where(
                timeout.view(self.num_envs, 1, 1),
                final_state,
                self._last_transition_final_critic_state,
            )
        )

        terminated = {a: torch.zeros_like(timeout) for a in self.cfg.possible_agents}
        truncated = {a: timeout for a in self.cfg.possible_agents}
        return terminated, truncated

    def _sample_argos_spawns(self, count: int) -> tuple[torch.Tensor, torch.Tensor]:
        """Sample collision-free initial poses.

        ``argos_uniform_disk_rejection`` reproduces Kegeleirs' Mercator setup:
        centers are uniform over the area of a disk of radius
        ``spawn_half_range`` and headings are uniform over ``[0, 2*pi)``.
        The legacy square/Gaussian sampler remains available for old configs.
        """
        cfg = self.cfg
        positions = torch.empty(
            count, cfg.num_agents, 2,
            dtype=torch.float32, device=self.device,
        )
        yaws = torch.empty(
            count, cfg.num_agents,
            dtype=torch.float32, device=self.device,
        )

        mode = str(getattr(cfg, "spawn_mode", "argos_uniform_box_rejection"))
        spawn_range = float(cfg.spawn_half_range)
        if mode not in (
            "argos_uniform_disk_rejection",
            "argos_uniform_box_rejection",
        ):
            raise ValueError(
                f"Unsupported spawn_mode={mode!r}; expected "
                "'argos_uniform_disk_rejection' or "
                "'argos_uniform_box_rejection'"
            )

        for robot_idx in range(cfg.num_agents):
            pending = torch.ones(count, dtype=torch.bool, device=self.device)

            for _ in range(int(cfg.spawn_max_trials)):
                if mode == "argos_uniform_disk_rejection":
                    # Exact translation of ChocolateBigAACLoopFunction::
                    # GetRandomPosition(): sort a,b in [0,1], then use b as
                    # radius and 2*pi*(a/b) as bearing. This is uniform over
                    # disk area and preserves the source algorithm rather than
                    # merely using an equivalent sqrt(U) sampler.
                    u = torch.rand(count, 2, device=self.device)
                    candidate_pos = chocolate_big_aac_disk_points(
                        u, spawn_range
                    )
                    raw_yaw = math.tau * torch.rand(count, device=self.device)
                else:
                    candidate_pos = (
                        2.0 * torch.rand(count, 2, device=self.device) - 1.0
                    ) * spawn_range
                    raw_yaw = (
                        math.radians(float(cfg.spawn_yaw_mean_deg))
                        + torch.randn(count, device=self.device)
                        * math.radians(float(cfg.spawn_yaw_std_deg))
                    )

                candidate_yaw = torch.atan2(
                    torch.sin(raw_yaw), torch.cos(raw_yaw)
                )
                if self.collision_shape == "circle":
                    inside = circles_inside_walls(
                        candidate_pos,
                        self.wall_outward_normals,
                        self.wall_inner_offsets,
                        self.collision_radius,
                    )
                    overlaps = candidate_circle_overlaps_existing(
                        candidate_pos,
                        positions[:, :robot_idx],
                        self.collision_radius,
                    )
                else:
                    inside = boxes_inside_walls(
                        candidate_pos,
                        candidate_yaw,
                        self.wall_outward_normals,
                        self.wall_inner_offsets,
                        self.robot_half_length,
                        self.robot_half_width,
                    )
                    overlaps = candidate_overlaps_existing(
                        candidate_pos,
                        candidate_yaw,
                        positions[:, :robot_idx],
                        yaws[:, :robot_idx],
                        self.robot_half_length,
                        self.robot_half_width,
                    )
                accepted = pending & inside & (~overlaps)
                positions[accepted, robot_idx] = candidate_pos[accepted]
                yaws[accepted, robot_idx] = candidate_yaw[accepted]
                pending &= ~accepted

                if not bool(pending.any()):
                    break

            if bool(pending.any()):
                raise RuntimeError(
                    f"{mode} spawn failed for robot {robot_idx}: "
                    f"{int(pending.sum().item())}/{count} environments after "
                    f"{cfg.spawn_max_trials} trials"
                )

        return positions, yaws

    def _reset_idx(self, env_ids: Sequence[int] | torch.Tensor | None):
        if env_ids is None:
            idx = torch.arange(self.num_envs, device=self.device, dtype=torch.long)
        elif isinstance(env_ids, torch.Tensor):
            idx = env_ids.to(device=self.device, dtype=torch.long)
        else:
            idx = torch.tensor(list(env_ids), device=self.device, dtype=torch.long)
        super()._reset_idx(idx)

        self.completed_group_reward[idx] = self._episode_group_reward[idx]
        self.completed_n_black[idx] = self.last_n_black[idx]
        self.completed_n_white[idx] = self.last_n_white[idx]
        self._episode_group_reward[idx] = 0.0
        self.last_n_black[idx] = 0.0
        self.last_n_white[idx] = 0.0

        pos, yaw = self._sample_argos_spawns(int(idx.numel()))
        self.agent_pos[idx] = pos
        self.agent_yaw[idx] = yaw
        self._last_module_ids[idx] = 0
        reset_mask = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        reset_mask[idx] = True
        self.behavior_modules.reset_state(reset_mask)
        self._fsm_behavior_parameters = None
        self._sensor_cache = None
        self._update_visual_markers()

    def get_critic_state(self) -> torch.Tensor:
        return MercatorLightSensors.compute_critic_state_5d(
            self.agent_pos,
            self.agent_yaw,
            float(self._arena_geometry.circumradius),
            self.light_dir,
        )

    def get_last_transition_final_critic_state(
        self,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Return the pre-reset critic-state snapshot and its validity mask."""
        return (
            self._last_transition_final_critic_state,
            self._last_transition_final_state_mask,
        )
    @property
    def completed_terminal_critic_state(self) -> torch.Tensor:
        """Critic state captured immediately before Isaac Lab auto-reset.

        POCA reads this property after ``env.step()`` to bootstrap trajectories
        truncated by the episode time limit from the true terminal state rather
        than from the freshly reset state.
        """
        return self._last_transition_final_critic_state