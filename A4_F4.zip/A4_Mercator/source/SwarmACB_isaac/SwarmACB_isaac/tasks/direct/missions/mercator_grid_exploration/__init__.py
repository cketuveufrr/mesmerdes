# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Gym registration for Experiment-1 Mercator grid exploration."""

import gymnasium as gym


gym.register(
    id="SwarmACB-MercatorGridExploration-v0",
    entry_point=(
        f"{__name__}.mercator_grid_exploration_env:MercatorGridExplorationEnv"
    ),
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": (
            f"{__name__}.mercator_grid_exploration_env_cfg:"
            "MercatorGridExplorationEnvCfg"
        ),
    },
)
