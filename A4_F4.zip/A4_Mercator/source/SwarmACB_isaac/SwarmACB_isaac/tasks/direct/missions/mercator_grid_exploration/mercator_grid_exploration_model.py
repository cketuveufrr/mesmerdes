# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Isaac-independent Experiment-1 Mercator grid-exploration objective.

This module is a direct tensor translation of
``GiantGridExplorationLoopFunc.cpp`` from Results-Transferability.  The source
maintains a 10 x 10 grid of cell ages.  At each 10 Hz control tick, cells
containing at least one robot are reset to zero, all cell ages are summed, and
then every cell age is incremented.  The reported episode objective is the
negative cumulative age divided by the number of cells.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any

import torch


ARENA_SIZE = 9.65
GRID_SIZE = 10
NUM_CELLS = GRID_SIZE * GRID_SIZE


def ground_scalar(points: torch.Tensor) -> torch.Tensor:
    """Return the exact source floor category: uniform gray (0.5)."""

    if points.shape[-1] != 2:
        raise ValueError("points must end in an XY axis of size 2")
    return torch.full(points.shape[:-1], 0.5, dtype=points.dtype, device=points.device)


def position_to_grid_cells(
    positions: torch.Tensor,
    arena_size: float = ARENA_SIZE,
    grid_size: int = GRID_SIZE,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Translate the source C++ cell-index computation.

    Returns ``(x_index, y_index, valid)``.  Assignment to ``UInt32`` in the C++
    truncates non-negative scaled coordinates, which is equivalent to floor for
    valid in-arena points.  Invalid points are retained only through ``valid``.
    """

    if positions.shape[-1] != 2:
        raise ValueError("positions must end in an XY axis of size 2")
    if arena_size <= 0.0 or grid_size <= 0:
        raise ValueError("arena_size and grid_size must be positive")

    scaled = float(grid_size) * (positions / float(arena_size) + 0.5)
    x_index = torch.floor(scaled[..., 0]).to(torch.long)
    y_index = torch.floor(scaled[..., 1]).to(torch.long)
    valid = (
        (x_index >= 0)
        & (x_index < int(grid_size))
        & (y_index >= 0)
        & (y_index < int(grid_size))
    )
    return x_index, y_index, valid


@dataclass(frozen=True)
class GridExplorationStep:
    ages: torch.Tensor
    reward: torch.Tensor
    total_age: torch.Tensor
    mean_age: torch.Tensor
    max_age: torch.Tensor
    visited_cells: torch.Tensor
    visited_mask: torch.Tensor
    robot_cell_x: torch.Tensor
    robot_cell_y: torch.Tensor
    valid_robot_cells: torch.Tensor


def update_grid_ages(
    ages: torch.Tensor,
    agent_positions: torch.Tensor,
    arena_size: float = ARENA_SIZE,
    grid_size: int = GRID_SIZE,
) -> GridExplorationStep:
    """Apply one exact ``PostStep`` update to a batch of grid ages.

    ``ages`` has shape ``[env, grid_size, grid_size]`` and positions have shape
    ``[env, robot, 2]``.  The returned reward is the per-step contribution to
    the original final objective, namely ``-sum(age) / grid_size**2`` after
    visited cells are reset and before all cells are incremented.
    """

    if ages.ndim != 3 or ages.shape[1:] != (int(grid_size), int(grid_size)):
        raise ValueError(
            f"ages must have shape [env, {grid_size}, {grid_size}], got {tuple(ages.shape)}"
        )
    if agent_positions.ndim != 3 or agent_positions.shape[0] != ages.shape[0]:
        raise ValueError("agent_positions must have shape [env, robot, 2]")
    if agent_positions.shape[-1] != 2:
        raise ValueError("agent_positions must end in an XY axis of size 2")

    x_index, y_index, valid = position_to_grid_cells(
        agent_positions, arena_size=arena_size, grid_size=grid_size
    )
    linear = (x_index * int(grid_size) + y_index).clamp(
        0, int(grid_size) * int(grid_size) - 1
    )
    visit_counts = torch.zeros(
        ages.shape[0], int(grid_size) * int(grid_size),
        dtype=torch.long, device=ages.device,
    )
    visit_counts.scatter_add_(1, linear, valid.to(torch.long))
    visited_mask = visit_counts.view(ages.shape[0], int(grid_size), int(grid_size)) > 0

    reset_ages = torch.where(visited_mask, torch.zeros_like(ages), ages)
    total_age = reset_ages.sum(dim=(1, 2))
    mean_age = total_age.to(torch.float32) / float(int(grid_size) ** 2)
    reward = -mean_age
    max_age = reset_ages.amax(dim=(1, 2)).to(torch.float32)
    visited_cells = visited_mask.sum(dim=(1, 2)).to(torch.float32)

    return GridExplorationStep(
        ages=reset_ages + 1,
        reward=reward,
        total_age=total_age.to(torch.float32),
        mean_age=mean_age,
        max_age=max_age,
        visited_cells=visited_cells,
        visited_mask=visited_mask,
        robot_cell_x=x_index,
        robot_cell_y=y_index,
        valid_robot_cells=valid,
    )


def _round_nested(value: Any, digits: int = 9) -> Any:
    if isinstance(value, float):
        return round(value, digits)
    if isinstance(value, (tuple, list)):
        return [_round_nested(item, digits) for item in value]
    if isinstance(value, dict):
        return {key: _round_nested(value[key], digits) for key in sorted(value)}
    return value


def _fingerprint(payload: dict[str, Any]) -> str:
    canonical = json.dumps(
        _round_nested(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def build_grid_environment_signature(cfg: Any, arena: Any) -> dict[str, Any]:
    """Build a mission-specific checkpoint signature without changing AAC."""

    payload = {
        "schema": 1,
        "robot_profile": str(cfg.robot_profile),
        "teraranger_layout": str(cfg.teraranger_layout),
        "teraranger_ring_radius": float(cfg.teraranger_ring_radius),
        "teraranger_origin_offset": float(cfg.teraranger_origin_offset),
        "mission": "experiment1_mercator_grid_exploration",
        "arena_fingerprint": str(arena.fingerprint),
        "arena": arena.as_dict(),
        "variant": str(cfg.variant),
        "num_agents": int(cfg.num_agents),
        "episode_length_s": float(cfg.episode_length_s),
        "sim_dt": float(cfg.sim.dt),
        "decimation": int(cfg.decimation),
        "analytical_substeps": int(cfg.analytical_substeps),
        "grid_arena_size": float(cfg.grid_arena_size),
        "grid_size": int(cfg.grid_size),
        "light_position": tuple(float(v) for v in cfg.light_position),
        "light_intensity": float(cfg.light_intensity),
        "spawn_mode": str(cfg.spawn_mode),
        "spawn_half_range": float(cfg.spawn_half_range),
        "spawn_max_trials": int(cfg.spawn_max_trials),
        "robot_length": float(cfg.robot_length),
        "robot_width": float(cfg.robot_width),
        "ground_sensor_offset": tuple(float(v) for v in cfg.ground_sensor_offset),
        "teraranger_max_range": float(cfg.teraranger_max_range),
        "cyclamen_neighbor_range": float(cfg.cyclamen_neighbor_range),
    }
    if str(getattr(cfg, "collision_shape", "obb")).strip().lower() != "obb":
        payload.update(
            {
                "collision_shape": str(cfg.collision_shape),
                "collision_radius": float(cfg.collision_radius),
                "collision_ring_radius": float(cfg.collision_ring_radius),
                "collision_ring_height": float(cfg.collision_ring_height),
                "collision_ring_thickness": float(cfg.collision_ring_thickness),
            }
        )

    return {
        "schema": 1,
        "arena_fingerprint": str(arena.fingerprint),
        "fingerprint": _fingerprint(payload),
        "payload": _round_nested(payload),
    }
