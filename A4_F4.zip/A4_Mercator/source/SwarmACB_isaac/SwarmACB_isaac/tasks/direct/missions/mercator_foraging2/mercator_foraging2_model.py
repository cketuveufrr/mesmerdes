# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Isaac-independent model of Experiment-2 Mercator foraging.

The constants and update order mirror ``BigForagingTwoSpotsLoopFunc.cpp`` in
``demiurge-project/Results-Transferability``:

* two black circular food spots of radius 0.265 m at (+/-0.8, 0);
* a white nest whose score boundary is ``robot_center_y <= -0.63``;
* the visible white floor is the exact five-triangle polygon from
  ``GetFloorColor()`` and uses the strict test ``y < -0.63``;
* touching either source sets a one-unit carrying flag;
* returning to the score nest delivers and clears that unit.

This module intentionally contains no Isaac Sim imports so geometry and scoring
can be validated with ordinary Python and PyTorch.
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any

import torch

from ..mercator_foraging.mercator_foraging_model import (
    ForagingStep,
    floor_nest_membership,
    food_membership as _food_membership,
    score_nest_membership as _score_nest_membership,
    update_carrying_state as _update_carrying_state,
)


FOOD_RADIUS = 0.265
FOOD_CENTERS = ((0.8, 0.0), (-0.8, 0.0))
NEST_LIMIT_Y = -0.63

# Literal translation of the points constructed in
# BigForagingTwoSpotsLoopFunction::GetFloorColor().  The tuple ordering matches
# the Experiment-1 helper: (bottom, top, angle1, angle2, angle3, angle4).
_SOURCE_MAX_DIM = 1.305
_SOURCE_WALL_CENTER = 1.131
_SOURCE_WALL_LENGTH = 0.70
_SOURCE_WALL_WIDTH = 0.01
_SOURCE_DIAGONAL_DROP = math.sin(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
NEST_FLOOR_POLYGON = (
    (-_SOURCE_WALL_CENTER - _SOURCE_WALL_WIDTH, NEST_LIMIT_Y),
    (_SOURCE_WALL_CENTER + _SOURCE_WALL_WIDTH, NEST_LIMIT_Y),
    (
        _SOURCE_WALL_CENTER
        - math.cos(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
        + _SOURCE_WALL_WIDTH,
        NEST_LIMIT_Y - _SOURCE_DIAGONAL_DROP - _SOURCE_WALL_WIDTH,
    ),
    (_SOURCE_WALL_LENGTH / 2.0 + _SOURCE_WALL_WIDTH, -_SOURCE_MAX_DIM),
    (-(_SOURCE_WALL_LENGTH / 2.0 + _SOURCE_WALL_WIDTH), -_SOURCE_MAX_DIM),
    (
        -_SOURCE_WALL_CENTER
        + math.cos(math.radians(60.0)) * _SOURCE_WALL_LENGTH / 2.0
        - _SOURCE_WALL_WIDTH,
        NEST_LIMIT_Y - _SOURCE_DIAGONAL_DROP - _SOURCE_WALL_WIDTH,
    ),
)

def food_membership(
    points: torch.Tensor,
    food_centers=FOOD_CENTERS,
    food_radius: float = FOOD_RADIUS,
) -> torch.Tensor:
    """Experiment-2 circular food membership with mission-local defaults."""

    return _food_membership(points, food_centers, food_radius)


def score_nest_membership(
    points: torch.Tensor,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> torch.Tensor:
    """Experiment-2 delivery boundary with mission-local defaults."""

    return _score_nest_membership(points, nest_limit_y)


def update_carrying_state(
    agent_positions: torch.Tensor,
    carrying: torch.Tensor,
    food_centers=FOOD_CENTERS,
    food_radius: float = FOOD_RADIUS,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> ForagingStep:
    """Apply one Experiment-2 foraging update with local defaults."""

    return _update_carrying_state(
        agent_positions, carrying, food_centers, food_radius, nest_limit_y
    )


def ground_scalar(
    points: torch.Tensor,
    food_centers=FOOD_CENTERS,
    food_radius: float = FOOD_RADIUS,
    nest_limit_y: float = NEST_LIMIT_Y,
) -> torch.Tensor:
    """Return the exact floor categories: black=0, gray=0.5, white=1."""

    if points.shape[-1] != 2:
        raise ValueError("points must end in an XY axis of size 2")
    in_food = food_membership(points, food_centers, food_radius).any(dim=-1)
    in_nest = floor_nest_membership(
        points,
        nest_limit_y=nest_limit_y,
        polygon=NEST_FLOOR_POLYGON,
    )
    result = torch.full(points.shape[:-1], 0.5, dtype=points.dtype, device=points.device)
    result = torch.where(in_nest, torch.ones_like(result), result)
    # The source checks food spots before the white nest.
    return torch.where(in_food, torch.zeros_like(result), result)


def build_foraging2_environment_signature(cfg: Any, arena: Any) -> dict[str, Any]:
    """Build a checkpoint signature specific to Experiment-2 foraging."""

    payload = {
        "schema": 1,
        "robot_profile": str(cfg.robot_profile),
        "teraranger_layout": str(cfg.teraranger_layout),
        "teraranger_ring_radius": float(cfg.teraranger_ring_radius),
        "teraranger_origin_offset": float(cfg.teraranger_origin_offset),
        "mission": "experiment2_mercator_foraging",
        "arena_fingerprint": str(arena.fingerprint),
        "arena": arena.as_dict(),
        "variant": str(cfg.variant),
        "num_agents": int(cfg.num_agents),
        "episode_length_s": float(cfg.episode_length_s),
        "sim_dt": float(cfg.sim.dt),
        "decimation": int(cfg.decimation),
        "analytical_substeps": int(cfg.analytical_substeps),
        "food_centers": tuple(tuple(float(v) for v in center) for center in cfg.food_centers),
        "food_radius": float(cfg.food_radius),
        "nest_limit_y": float(cfg.nest_limit_y),
        "nest_floor_polygon": tuple(
            tuple(float(v) for v in point) for point in NEST_FLOOR_POLYGON
        ),
        "floor_nest_boundary": "strict_y_less_than_limit_and_five_triangles",
        "delivery_boundary": "robot_center_y_less_than_or_equal_to_limit",
        "light_position": tuple(float(v) for v in cfg.light_position),
        "light_intensity": float(cfg.light_intensity),
        "light_max_distance": float(cfg.light_max_distance),
        "spawn_mode": str(cfg.spawn_mode),
        "spawn_half_range": float(cfg.spawn_half_range),
        "spawn_max_trials": int(cfg.spawn_max_trials),
        "spawn_yaw_mean_deg": float(cfg.spawn_yaw_mean_deg),
        "spawn_yaw_std_deg": float(cfg.spawn_yaw_std_deg),
        "robot_length": float(cfg.robot_length),
        "robot_width": float(cfg.robot_width),
        "robot_height": float(cfg.robot_height),
        "robot_base_height": float(cfg.robot_base_height),
        "lidar_tower_diameter": float(cfg.lidar_tower_diameter),
        "lidar_tower_offset": tuple(float(v) for v in cfg.lidar_tower_offset),
        "lidar_height": float(cfg.lidar_height),
        "ground_sensor_offset": tuple(float(v) for v in cfg.ground_sensor_offset),
        "max_wheel_speed": float(cfg.max_wheel_speed),
        "wheelbase": float(cfg.wheelbase),
        "teraranger_max_range": float(cfg.teraranger_max_range),
        "proximity_threshold": float(cfg.proximity_threshold),
        "neighbor_min_range": float(cfg.neighbor_min_range),
        "neighbor_max_range": float(cfg.neighbor_max_range),
        "neighbor_alpha": float(cfg.neighbor_alpha),
        "cyclamen_neighbor_range": float(cfg.cyclamen_neighbor_range),
        "exploration_tau": int(cfg.exploration_tau),
        "phototaxis_proximity_gain": float(cfg.phototaxis_proximity_gain),
        "anti_phototaxis_proximity_gain": float(cfg.anti_phototaxis_proximity_gain),
        "attraction_proximity_gain": float(cfg.attraction_proximity_gain),
        "repulsion_proximity_gain": float(cfg.repulsion_proximity_gain),
        "repulsion_alpha_parameter": float(cfg.repulsion_alpha_parameter),
    }

    def normalize(value: Any) -> Any:
        if isinstance(value, float):
            return round(value, 9)
        if isinstance(value, (tuple, list)):
            return [normalize(item) for item in value]
        if isinstance(value, dict):
            return {key: normalize(value[key]) for key in sorted(value)}
        return value

    if str(getattr(cfg, "collision_shape", "obb")).strip().lower() != "obb":
        payload.update(
            {
                "collision_shape": str(cfg.collision_shape),
                "collision_radius": float(cfg.collision_radius),
                "collision_ring_radius": float(cfg.collision_ring_radius),
                "collision_ring_height": float(cfg.collision_ring_height),
                "collision_ring_thickness": float(cfg.collision_ring_thickness),
            }
        )

    canonical = json.dumps(
        normalize(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")
    return {
        "schema": 1,
        "mission": payload["mission"],
        "arena_fingerprint": arena.fingerprint,
        "fingerprint": hashlib.sha256(canonical).hexdigest(),
        "payload": normalize(payload),
    }


__all__ = [
    "FOOD_CENTERS",
    "FOOD_RADIUS",
    "NEST_LIMIT_Y",
    "NEST_FLOOR_POLYGON",
    "food_membership",
    "score_nest_membership",
    "update_carrying_state",
    "ground_scalar",
    "build_foraging2_environment_signature",
]
