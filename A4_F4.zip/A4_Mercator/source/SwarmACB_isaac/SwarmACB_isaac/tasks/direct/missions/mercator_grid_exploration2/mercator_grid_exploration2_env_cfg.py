# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration for Experiment-2 Mercator grid exploration."""

from __future__ import annotations

from isaaclab.utils.configclass import configclass

from ..mercator_aggregation2.mercator_aggregation2_env_cfg import (
    MercatorAggregation2EnvCfg,
)
from .mercator_grid_exploration2_model import ARENA_SIZE, GRID_SIZE


@configclass
class MercatorGridExploration2EnvCfg(MercatorAggregation2EnvCfg):
    """Exact small-arena grid-exploration constants from Experiment 2."""

    mission_name: str = "experiment2_mercator_grid_exploration"
    episode_length_s: float = 120.0

    grid_arena_size: float = ARENA_SIZE
    grid_size: int = GRID_SIZE

    # The XML sets intensity=0, but the small-setup Isaac convention keeps the
    # light active because some delivered Chocolate FSMs use photo behaviours.
    light_position: tuple = (0.0, -2.0, 0.4)
    light_intensity: float = 1.0

    spawn_mode: str = "argos_uniform_disk_rejection"
    spawn_half_range: float = 1.2
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0
