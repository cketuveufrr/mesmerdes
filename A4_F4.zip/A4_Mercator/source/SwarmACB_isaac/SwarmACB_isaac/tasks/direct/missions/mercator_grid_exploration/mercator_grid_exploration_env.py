# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Experiment-1 grid-exploration mission for the analytical Mercator model."""

from __future__ import annotations

import math
from collections.abc import Sequence

import torch

import isaaclab.sim as sim_utils

from ..mercator_aggregation.mercator_aggregation_env import MercatorAggregationEnv
from .mercator_grid_exploration_env_cfg import MercatorGridExplorationEnvCfg
from .mercator_grid_exploration_model import (
    build_grid_environment_signature,
    ground_scalar,
    update_grid_ages,
)


class MercatorGridExplorationEnv(MercatorAggregationEnv):
    """Ten-by-ten cell-age objective from ``GiantGridExplorationLoopFunc``."""

    cfg: MercatorGridExplorationEnvCfg

    def __init__(
        self,
        cfg: MercatorGridExplorationEnvCfg,
        render_mode: str | None = None,
        **kwargs,
    ):
        super().__init__(cfg, render_mode, **kwargs)
        e, g, dev = self.num_envs, int(cfg.grid_size), self.device

        self._grid_ages = torch.zeros(e, g, g, dtype=torch.long, device=dev)
        self._ever_visited = torch.zeros(e, g, g, dtype=torch.bool, device=dev)
        self._episode_visited_cell_events = torch.zeros(e, dtype=torch.float32, device=dev)

        self.last_grid_total_age = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_grid_mean_age = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_grid_max_age = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_grid_visited_cells = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_grid_coverage = torch.zeros(e, dtype=torch.float32, device=dev)

        self.completed_grid_total_age = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_grid_mean_age = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_grid_max_age = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_grid_visited_cells = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_grid_coverage = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_grid_visit_events = torch.zeros(e, dtype=torch.float32, device=dev)

        self._environment_signature = build_grid_environment_signature(
            cfg, self._arena_geometry
        )

    # ------------------------------------------------------------------
    # Mission visuals and floor
    # ------------------------------------------------------------------

    def _spawn_arena_visuals(self) -> None:
        cfg = self.cfg
        arena = self._arena_geometry
        self._spawn_shared_arena_floor_visual()

        wall_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.73, 0.64, 0.42))
        for index, (center, yaw) in enumerate(
            zip(arena.wall_centers, arena.wall_segment_yaws_rad)
        ):
            wall = sim_utils.CuboidCfg(
                size=(arena.wall_side_length, arena.wall_thickness, arena.wall_height),
                visual_material=wall_material,
            )
            wall.func(
                f"/World/Arena/Wall_{index}",
                wall,
                translation=(float(center[0]), float(center[1]), 0.5 * arena.wall_height),
                orientation=(0.0, 0.0, math.sin(0.5 * yaw), math.cos(0.5 * yaw)),
            )

        if float(cfg.light_intensity) > 0.0:
            lx, ly, lz = cfg.light_position
            marker = sim_utils.SphereCfg(
                radius=0.08,
                visual_material=sim_utils.PreviewSurfaceCfg(
                    diffuse_color=(1.0, 0.85, 0.10)
                ),
            )
            marker.func(
                "/World/Arena/LightIndicator",
                marker,
                translation=(float(lx), float(ly), float(lz)),
            )

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        return ground_scalar(points)

    def _zone_counts_from_centers(self) -> tuple[torch.Tensor, torch.Tensor]:
        # Generic Mercator diagnostics expect two occupancy tensors.  Grid
        # exploration has no black/white zones, so both are identically zero.
        zeros = torch.zeros(self.num_envs, dtype=torch.float32, device=self.device)
        return zeros, zeros

    # ------------------------------------------------------------------
    # Exact grid-age objective
    # ------------------------------------------------------------------

    def _get_rewards(self) -> dict[str, torch.Tensor]:
        step = update_grid_ages(
            self._grid_ages,
            self.agent_pos,
            arena_size=float(self.cfg.grid_arena_size),
            grid_size=int(self.cfg.grid_size),
        )
        self._grid_ages.copy_(step.ages)
        self._ever_visited |= step.visited_mask
        coverage = self._ever_visited.sum(dim=(1, 2)).to(torch.float32) / float(
            int(self.cfg.grid_size) ** 2
        )

        self.last_grid_total_age.copy_(step.total_age)
        self.last_grid_mean_age.copy_(step.mean_age)
        self.last_grid_max_age.copy_(step.max_age)
        self.last_grid_visited_cells.copy_(step.visited_cells)
        self.last_grid_coverage.copy_(coverage)
        self._episode_visited_cell_events += step.visited_cells

        # Retain harmless generic occupancy fields for tools that inspect them.
        self.last_n_black.zero_()
        self.last_n_white.zero_()
        self._episode_group_reward += step.reward
        return {agent: step.reward for agent in self.cfg.possible_agents}

    def _reset_idx(self, env_ids: Sequence[int] | torch.Tensor | None):
        if env_ids is None:
            idx = torch.arange(self.num_envs, device=self.device, dtype=torch.long)
        elif isinstance(env_ids, torch.Tensor):
            idx = env_ids.to(device=self.device, dtype=torch.long)
        else:
            idx = torch.tensor(list(env_ids), device=self.device, dtype=torch.long)

        super()._reset_idx(idx)
        if not hasattr(self, "_grid_ages"):
            return

        self.completed_grid_total_age[idx] = self.last_grid_total_age[idx]
        self.completed_grid_mean_age[idx] = self.last_grid_mean_age[idx]
        self.completed_grid_max_age[idx] = self.last_grid_max_age[idx]
        self.completed_grid_visited_cells[idx] = self.last_grid_visited_cells[idx]
        self.completed_grid_coverage[idx] = self.last_grid_coverage[idx]
        self.completed_grid_visit_events[idx] = self._episode_visited_cell_events[idx]

        self._grid_ages[idx] = 0
        self._ever_visited[idx] = False
        self._episode_visited_cell_events[idx] = 0.0
        self.last_grid_total_age[idx] = 0.0
        self.last_grid_mean_age[idx] = 0.0
        self.last_grid_max_age[idx] = 0.0
        self.last_grid_visited_cells[idx] = 0.0
        self.last_grid_coverage[idx] = 0.0

    @property
    def grid_ages(self) -> torch.Tensor:
        """Read-only-by-convention cell ages used by diagnostics."""

        return self._grid_ages
