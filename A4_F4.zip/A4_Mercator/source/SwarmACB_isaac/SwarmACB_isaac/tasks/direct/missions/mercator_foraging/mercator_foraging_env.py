# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Experiment-1 foraging mission for the analytical Mercator environment."""

from __future__ import annotations

import math
from collections.abc import Sequence

import torch

import isaaclab.sim as sim_utils
from pxr import Gf, UsdGeom
import omni.usd

from ..mercator_aggregation.mercator_aggregation_env import MercatorAggregationEnv
from .mercator_foraging_env_cfg import MercatorForagingEnvCfg
from .mercator_foraging_model import (
    NEST_FLOOR_POLYGON,
    build_foraging_environment_signature,
    food_membership,
    ground_scalar,
    score_nest_membership,
    update_carrying_state,
)


class MercatorForagingEnv(MercatorAggregationEnv):
    """Two-source foraging with the original Chocolate/ARGoS score contract."""

    cfg: MercatorForagingEnvCfg

    def __init__(self, cfg: MercatorForagingEnvCfg, render_mode: str | None = None, **kwargs):
        super().__init__(cfg, render_mode, **kwargs)
        e, n, dev = self.num_envs, cfg.num_agents, self.device

        self._carrying_food = torch.zeros(e, n, dtype=torch.bool, device=dev)
        self._episode_pickups = torch.zeros(e, dtype=torch.float32, device=dev)

        self.last_deliveries = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_pickups = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_carrying = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_in_food = torch.zeros(e, dtype=torch.float32, device=dev)
        self.last_in_nest = torch.zeros(e, dtype=torch.float32, device=dev)

        self.completed_deliveries = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_pickups = torch.zeros(e, dtype=torch.float32, device=dev)
        self.completed_carrying = torch.zeros(e, dtype=torch.float32, device=dev)

        # The base aggregation signature is deliberately left unchanged for AAC
        # checkpoints. Foraging replaces only this instance's signature.
        self._environment_signature = build_foraging_environment_signature(
            cfg, self._arena_geometry
        )

    # ------------------------------------------------------------------
    # Mission visuals
    # ------------------------------------------------------------------

    def _spawn_arena_visuals(self) -> None:
        cfg = self.cfg
        arena = self._arena_geometry
        self._spawn_shared_arena_floor_visual()
        self._spawn_nest_visual()

        food_material = sim_utils.PreviewSurfaceCfg(
            diffuse_color=(0.015, 0.015, 0.015)
        )
        for index, center in enumerate(cfg.food_centers):
            spot = sim_utils.CylinderCfg(
                radius=float(cfg.food_radius),
                height=0.004,
                visual_material=food_material,
            )
            spot.func(
                f"/World/Arena/FoodSpot_{index}",
                spot,
                translation=(float(center[0]), float(center[1]), 0.004),
            )

        wall_material = sim_utils.PreviewSurfaceCfg(
            diffuse_color=(0.73, 0.64, 0.42)
        )
        for index, (center, yaw) in enumerate(
            zip(arena.wall_centers, arena.wall_segment_yaws_rad)
        ):
            wall = sim_utils.CuboidCfg(
                size=(arena.wall_side_length, arena.wall_thickness, arena.wall_height),
                visual_material=wall_material,
            )
            wall.func(
                f"/World/Arena/Wall_{index}",
                wall,
                translation=(float(center[0]), float(center[1]), 0.5 * arena.wall_height),
                orientation=(0.0, 0.0, math.sin(0.5 * yaw), math.cos(0.5 * yaw)),
            )

        lx, ly, lz = cfg.light_position
        light_marker = sim_utils.SphereCfg(
            radius=0.08,
            visual_material=sim_utils.PreviewSurfaceCfg(
                diffuse_color=(1.0, 0.85, 0.10)
            ),
        )
        light_marker.func(
            "/World/Arena/LightIndicator",
            light_marker,
            translation=(float(lx), float(ly), float(lz)),
        )

    def _spawn_nest_visual(self) -> None:
        """Overlay the exact six-vertex nest polygon from GetFloorColor()."""

        stage = omni.usd.get_context().get_stage()
        if stage is None:
            raise RuntimeError("USD stage is unavailable while creating foraging nest")
        vertices_2d = NEST_FLOOR_POLYGON
        if len(vertices_2d) < 3:
            raise RuntimeError("Foraging nest polygon contains fewer than three vertices")

        vertices = [Gf.Vec3f(float(x), float(y), 0.004) for x, y in vertices_2d]
        mesh = UsdGeom.Mesh.Define(stage, "/World/Arena/ForagingNest")
        mesh.CreatePointsAttr(vertices)
        mesh.CreateFaceVertexCountsAttr([len(vertices)])
        mesh.CreateFaceVertexIndicesAttr(list(range(len(vertices))))
        mesh.CreateDoubleSidedAttr(True)
        gprim = UsdGeom.Gprim(mesh.GetPrim())
        gprim.CreateDisplayColorAttr([Gf.Vec3f(0.96, 0.96, 0.96)])
        gprim.CreateDisplayOpacityAttr([1.0])

    # ------------------------------------------------------------------
    # Ground categories and objective
    # ------------------------------------------------------------------

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        return ground_scalar(
            points,
            self.cfg.food_centers,
            float(self.cfg.food_radius),
            float(self.cfg.nest_limit_y),
        )

    def _zone_counts_from_centers(self) -> tuple[torch.Tensor, torch.Tensor]:
        in_food = food_membership(
            self.agent_pos,
            self.cfg.food_centers,
            float(self.cfg.food_radius),
        ).any(dim=-1)
        in_nest = score_nest_membership(self.agent_pos, float(self.cfg.nest_limit_y))
        return in_food.sum(dim=1).float(), in_nest.sum(dim=1).float()

    def _get_rewards(self) -> dict[str, torch.Tensor]:
        step = update_carrying_state(
            self.agent_pos,
            self._carrying_food,
            self.cfg.food_centers,
            float(self.cfg.food_radius),
            float(self.cfg.nest_limit_y),
        )
        self._carrying_food.copy_(step.carrying)

        deliveries = step.delivery_mask.sum(dim=1).float()
        pickups = step.pickup_mask.sum(dim=1).float()
        carrying = step.carrying.sum(dim=1).float()
        in_food = step.in_food.sum(dim=1).float()
        in_nest = step.in_nest.sum(dim=1).float()

        self.last_deliveries.copy_(deliveries)
        self.last_pickups.copy_(pickups)
        self.last_carrying.copy_(carrying)
        self.last_in_food.copy_(in_food)
        self.last_in_nest.copy_(in_nest)

        # Keep the inherited occupancy fields useful to generic Mercator tools:
        # black means food source and white means nest for this mission.
        self.last_n_black.copy_(in_food)
        self.last_n_white.copy_(in_nest)

        self._episode_pickups += pickups
        self._episode_group_reward += deliveries
        return {agent: deliveries for agent in self.cfg.possible_agents}

    def _reset_idx(self, env_ids: Sequence[int] | torch.Tensor | None):
        if env_ids is None:
            idx = torch.arange(self.num_envs, device=self.device, dtype=torch.long)
        elif isinstance(env_ids, torch.Tensor):
            idx = env_ids.to(device=self.device, dtype=torch.long)
        else:
            idx = torch.tensor(list(env_ids), device=self.device, dtype=torch.long)

        super()._reset_idx(idx)
        if not hasattr(self, "_carrying_food"):
            # Defensive guard for Isaac Lab versions that reset during the base
            # constructor before subclass state has been allocated.
            return

        self.completed_deliveries[idx] = self.completed_group_reward[idx]
        self.completed_pickups[idx] = self._episode_pickups[idx]
        self.completed_carrying[idx] = self.last_carrying[idx]

        self._carrying_food[idx] = False
        self._episode_pickups[idx] = 0.0
        self.last_deliveries[idx] = 0.0
        self.last_pickups[idx] = 0.0
        self.last_carrying[idx] = 0.0
        self.last_in_food[idx] = 0.0
        self.last_in_nest[idx] = 0.0

    @property
    def carrying_food(self) -> torch.Tensor:
        """Read-only-by-convention carrying mask used by diagnostics."""

        return self._carrying_food
