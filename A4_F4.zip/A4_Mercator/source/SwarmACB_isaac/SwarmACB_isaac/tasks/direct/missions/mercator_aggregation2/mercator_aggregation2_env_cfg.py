# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration for Mercator Aggregation Experiment 2 (small arena)."""

from __future__ import annotations

import math

from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils.configclass import configclass

from ..mercator_aggregation.mercator_aggregation_env_cfg import MercatorAggregationEnvCfg


_NUM_AGENTS = 3
_NUM_MODULES = 6
_N_SIDES = 12
_SIDE_LENGTH = 0.70
_CIRCUMRADIUS = _SIDE_LENGTH / (2.0 * math.sin(math.pi / _N_SIDES))
_AREA = 0.5 * _N_SIDES * _CIRCUMRADIUS**2 * math.sin(2.0 * math.pi / _N_SIDES)


def _agent_names() -> list[str]:
    return [f"Mercator_{i:02d}" for i in range(_NUM_AGENTS)]


@configclass
class MercatorAggregation2EnvCfg(MercatorAggregationEnvCfg):
    """Experiment-2 AAC mission while preserving the original AAC config."""

    num_agents: int = _NUM_AGENTS
    possible_agents: list = _agent_names()
    observation_spaces: dict = {name: 2 for name in _agent_names()}
    action_spaces: dict = {name: 1 for name in _agent_names()}
    num_actions: int = _NUM_MODULES

    scene: InteractiveSceneCfg = InteractiveSceneCfg(
        num_envs=50,
        env_spacing=4.0,
        replicate_physics=True,
    )

    arena_num_sides: int = _N_SIDES
    arena_side_length: float = _SIDE_LENGTH
    arena_circumradius: float = _CIRCUMRADIUS
    arena_area: float = _AREA
    arena_wall_thickness: float = 0.01
    arena_wall_height: float = 0.08

    black_center: tuple = (0.0, 0.63)
    white_center: tuple = (0.0, -0.63)
    zone_radius: float = 0.32

    light_position: tuple = (0.0, -2.0, 0.4)
    light_intensity: float = 1.0
    light_max_distance: float = 12.0

    spawn_mode: str = "argos_uniform_disk_rejection"
    spawn_half_range: float = 1.2
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0
