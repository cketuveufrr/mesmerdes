# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration for Experiment-1 Mercator grid exploration."""

from __future__ import annotations

from isaaclab.utils.configclass import configclass

from ..mercator_aggregation.mercator_aggregation_env_cfg import MercatorAggregationEnvCfg
from .mercator_grid_exploration_model import ARENA_SIZE, GRID_SIZE


@configclass
class MercatorGridExplorationEnvCfg(MercatorAggregationEnvCfg):
    """Exact giant-arena grid-exploration constants from Results-Transferability."""

    mission_name: str = "experiment1_mercator_grid_exploration"
    episode_length_s: float = 120.0

    grid_arena_size: float = ARENA_SIZE
    grid_size: int = GRID_SIZE

    # Same 20-robot giant dodecagon and ARGoS distribute rule as Experiment 1
    # aggregation/foraging.  Grid exploration's light is mounted at z=0.8 m.
    light_position: tuple = (0.0, -5.0, 0.8)
    light_intensity: float = 5.0
    spawn_mode: str = "argos_uniform_box_rejection"
    spawn_half_range: float = 4.6
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0
