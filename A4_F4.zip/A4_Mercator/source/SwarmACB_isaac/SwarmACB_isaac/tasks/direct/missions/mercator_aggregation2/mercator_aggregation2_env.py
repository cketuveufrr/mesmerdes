# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Mercator Aggregation Experiment 2 in the exact small ARGoS arena."""

from __future__ import annotations

from ..mercator_aggregation.mercator_aggregation_env import MercatorAggregationEnv
from .mercator_aggregation2_arena import build_argos_aac2_arena
from .mercator_aggregation2_env_cfg import MercatorAggregation2EnvCfg


class MercatorAggregation2Env(MercatorAggregationEnv):
    cfg: MercatorAggregation2EnvCfg

    def _build_arena_geometry(self, cfg: MercatorAggregation2EnvCfg):
        return build_argos_aac2_arena(
            wall_side_length=float(cfg.arena_side_length),
            wall_thickness=float(cfg.arena_wall_thickness),
            wall_height=float(cfg.arena_wall_height),
        )
