# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Experiment-2 Mercator foraging in the exact small ARGoS arena."""

from __future__ import annotations

from pxr import Gf, UsdGeom
import omni.usd
import torch

from ..mercator_aggregation2.mercator_aggregation2_arena import build_argos_aac2_arena
from ..mercator_foraging.mercator_foraging_env import MercatorForagingEnv
from .mercator_foraging2_env_cfg import MercatorForaging2EnvCfg
from .mercator_foraging2_model import (
    NEST_FLOOR_POLYGON,
    build_foraging2_environment_signature,
    ground_scalar,
)


class MercatorForaging2Env(MercatorForagingEnv):
    """Three-robot, two-source foraging in Experiment 2's small dodecagon."""

    cfg: MercatorForaging2EnvCfg

    def __init__(self, cfg: MercatorForaging2EnvCfg, render_mode: str | None = None, **kwargs):
        super().__init__(cfg, render_mode, **kwargs)
        # MercatorForagingEnv deliberately builds the Experiment-1 signature.
        # Replace it only for this subclass after every inherited state tensor
        # has been allocated.
        self._environment_signature = build_foraging2_environment_signature(
            cfg, self._arena_geometry
        )

    def _build_arena_geometry(self, cfg: MercatorForaging2EnvCfg):
        return build_argos_aac2_arena(
            wall_side_length=float(cfg.arena_side_length),
            wall_thickness=float(cfg.arena_wall_thickness),
            wall_height=float(cfg.arena_wall_height),
        )

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        return ground_scalar(
            points,
            self.cfg.food_centers,
            float(self.cfg.food_radius),
            float(self.cfg.nest_limit_y),
        )

    def _spawn_nest_visual(self) -> None:
        """Overlay the exact Experiment-2 five-triangle nest polygon."""

        stage = omni.usd.get_context().get_stage()
        if stage is None:
            raise RuntimeError("USD stage is unavailable while creating foraging-2 nest")
        vertices = [Gf.Vec3f(float(x), float(y), 0.004) for x, y in NEST_FLOOR_POLYGON]
        mesh = UsdGeom.Mesh.Define(stage, "/World/Arena/ForagingNest")
        mesh.CreatePointsAttr(vertices)
        mesh.CreateFaceVertexCountsAttr([len(vertices)])
        mesh.CreateFaceVertexIndicesAttr(list(range(len(vertices))))
        mesh.CreateDoubleSidedAttr(True)
        gprim = UsdGeom.Gprim(mesh.GetPrim())
        gprim.CreateDisplayColorAttr([Gf.Vec3f(0.96, 0.96, 0.96)])
        gprim.CreateDisplayOpacityAttr([1.0])
