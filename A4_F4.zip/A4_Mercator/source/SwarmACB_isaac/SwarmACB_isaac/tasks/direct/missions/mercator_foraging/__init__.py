# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Gym registration for Experiment-1 Mercator foraging."""

import gymnasium as gym


gym.register(
    id="SwarmACB-MercatorForaging-v0",
    entry_point=f"{__name__}.mercator_foraging_env:MercatorForagingEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": (
            f"{__name__}.mercator_foraging_env_cfg:MercatorForagingEnvCfg"
        ),
    },
)
