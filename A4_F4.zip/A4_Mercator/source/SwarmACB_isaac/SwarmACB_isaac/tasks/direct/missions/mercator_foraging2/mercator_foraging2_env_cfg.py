# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration for Experiment-2 Mercator foraging in the small arena."""

from __future__ import annotations

from isaaclab.utils.configclass import configclass

from ..mercator_aggregation2.mercator_aggregation2_env_cfg import (
    MercatorAggregation2EnvCfg,
)
from .mercator_foraging2_model import FOOD_CENTERS, FOOD_RADIUS, NEST_LIMIT_Y


@configclass
class MercatorForaging2EnvCfg(MercatorAggregation2EnvCfg):
    """Small-arena foraging constants from Results-Transferability Experiment 2."""

    mission_name: str = "experiment2_mercator_foraging"
    episode_length_s: float = 120.0

    food_centers: tuple = FOOD_CENTERS
    food_radius: float = FOOD_RADIUS
    nest_limit_y: float = NEST_LIMIT_Y

    # The ARGoS XML declares intensity 0, but the project deliberately keeps
    # the small-arena light active because Experiment-2 Chocolate FSMs contain
    # phototaxis and anti-phototaxis states. This matches the existing AAC2
    # compatibility decision.
    light_position: tuple = (0.0, -2.0, 0.4)
    light_intensity: float = 1.0

    spawn_mode: str = "argos_uniform_disk_rejection"
    spawn_half_range: float = 1.2
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0
