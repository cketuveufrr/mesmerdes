# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration for Experiment-1 Mercator foraging."""

from __future__ import annotations

from isaaclab.utils.configclass import configclass

from ..mercator_aggregation.mercator_aggregation_env_cfg import MercatorAggregationEnvCfg
from .mercator_foraging_model import FOOD_CENTERS, FOOD_RADIUS, NEST_LIMIT_Y


@configclass
class MercatorForagingEnvCfg(MercatorAggregationEnvCfg):
    """Exact Mercator mission constants from Results-Transferability."""

    mission_name: str = "experiment1_mercator_foraging"
    episode_length_s: float = 120.0

    food_centers: tuple = FOOD_CENTERS
    food_radius: float = FOOD_RADIUS
    nest_limit_y: float = NEST_LIMIT_Y

    # The experiment uses the same giant Mercator arena, light and spawn rule
    # as aggregation. Inherited black/white AAC fields remain only for backward
    # compatibility with generic configuration tooling and are not used here.
    light_position: tuple = (0.0, -5.0, 0.2)
    spawn_mode: str = "argos_uniform_box_rejection"
    spawn_half_range: float = 4.6
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0
