# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration complète de Mercator Light AAC.

Ce fichier contient explicitement toutes les clés utilisées par
configs/AAC_mercator_cyclamen_light.yaml et par scripts/visualize.py.
Il conserve aussi quelques alias hérités afin de rester compatible avec une
ancienne version de mercator_aggregation_env.py.
"""

from __future__ import annotations

import math

from isaaclab.envs import DirectMARLEnvCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sim import SimulationCfg
from isaaclab.utils.configclass import configclass


_NUM_AGENTS = 20
_NUM_MODULES = 6
_N_SIDES = 12
_SIDE_LENGTH = 2.57
_CIRCUMRADIUS = _SIDE_LENGTH / (2.0 * math.sin(math.pi / _N_SIDES))
_AREA = 0.5 * _N_SIDES * _CIRCUMRADIUS**2 * math.sin(2.0 * math.pi / _N_SIDES)

_OBS_DIM = {
    "dandelion": 22,
    "daisy": 22,
    "lily": 2,
    "tulip": 2,
    "cyclamen": 2,  # [single Mercator ground reading, normalized neighbor density]
}
_ACT_DIM = {
    "dandelion": 2,
    "daisy": 1,
    "lily": 1,
    "tulip": 1,
    "cyclamen": 1,
}


def _agent_names(n: int = _NUM_AGENTS) -> list[str]:
    return [f"Mercator_{i:02d}" for i in range(n)]


def _spaces(dim: int, n: int = _NUM_AGENTS) -> dict[str, int]:
    return {name: dim for name in _agent_names(n)}


@configclass
class MercatorAggregationEnvCfg(DirectMARLEnvCfg):
    """Configuration AAC Mercator Light, compatible train/play/visualize."""

    variant: str = "cyclamen"
    num_agents: int = _NUM_AGENTS
    possible_agents: list = _agent_names()
    observation_spaces: dict = _spaces(_OBS_DIM["cyclamen"])
    action_spaces: dict = _spaces(_ACT_DIM["cyclamen"])
    state_space: int = -1
    discrete_actions: bool = True
    num_actions: int = _NUM_MODULES

    seed: int = 0
    # The robots, sensors and collisions are analytical PyTorch tensors.  Do
    # one Isaac step per 10 Hz control tick and reproduce the original six
    # 60 Hz analytical integration/collision substeps inside _apply_action().
    # This preserves the robot trajectory while avoiding five empty Isaac
    # physics steps per decision.
    decimation: int = 1
    analytical_substeps: int = 6
    episode_length_s: float = 120.0
    sim: SimulationCfg = SimulationCfg(
        dt=0.1,
        render_interval=1,
        gravity=(0.0, 0.0, -9.81),
    )
    scene: InteractiveSceneCfg = InteractiveSceneCfg(
        num_envs=50,
        env_spacing=12.0,
        replicate_physics=True,
    )

    # Explicit visualisation switch. Training/play stay fast and headless;
    # scripts/visualize.py sets it to True and marker updates no longer depend
    # on SimulationContext.has_gui, which is unreliable with some launchers.
    enable_visualization: bool = False

    # Arène ARGoS.  The twelve wall poses live only in
    # mercator_light/arena_geometry.py and every representation is derived
    # from that one source.
    arena_num_sides: int = _N_SIDES
    arena_side_length: float = _SIDE_LENGTH
    arena_circumradius: float = _CIRCUMRADIUS  # compatibility/critic normalisation
    arena_area: float = _AREA
    arena_wall_thickness: float = 0.01
    arena_wall_height: float = 0.08

    # Zones AAC conservées du setup géant utilisé précédemment.
    black_center: tuple = (0.0, 2.35)
    white_center: tuple = (0.0, -2.35)
    zone_radius: float = 1.17

    # Lumière du XML ARGoS.
    light_position: tuple = (0.0, -5.0, 0.2)
    light_intensity: float = 5.0
    light_max_distance: float = 12.0

    # Spawn du XML ARGoS.
    spawn_mode: str = "argos_uniform_box_rejection"
    spawn_half_range: float = 4.6
    spawn_max_trials: int = 100
    spawn_yaw_mean_deg: float = 0.0
    spawn_yaw_std_deg: float = 360.0
    spawn_margin: float = 0.0

    # Named embodiment profile. YAML values may override any preset field.
    robot_profile: str = "mercator"

    # Base mécanique / hitbox.
    robot_length: float = 0.26
    robot_width: float = 0.25
    robot_height: float = 0.20
    robot_base_height: float = 0.08

    # Analytical collision footprint. Native Mercator keeps its OBB; the
    # tMercator profile overrides this with the centered RVR bumper circle.
    collision_shape: str = "obb"
    collision_radius: float = 0.105

    # Optional visual annulus, disabled for native Mercator.
    collision_ring_radius: float = 0.0
    collision_ring_height: float = 0.0
    collision_ring_thickness: float = 0.0

    # Alias conservateurs pour les anciennes versions de l'environnement.
    robot_radius: float = math.sqrt((0.26 / 2.0) ** 2 + (0.25 / 2.0) ** 2)
    robot_mass: float = 1.0

    # Tour visible au LiDAR.
    lidar_tower_diameter: float = 0.065
    lidar_tower_offset: tuple = (0.0, 0.0)
    lidar_height: float = 0.17545

    # Capteur de sol réel, décalé vers l'avant.
    ground_sensor_offset: tuple = (0.056, 0.0)

    # Cinématique différentielle.
    max_wheel_speed: float = 0.30
    wheelbase: float = 0.18

    # TeraRanger analytique.
    teraranger_layout: str = "native_asymmetric"
    teraranger_ring_radius: float = 0.143
    teraranger_origin_offset: float = 0.005
    teraranger_max_range: float = 2.0
    proximity_threshold: float = 0.10

    # Voisins par centres de tours.
    neighbor_min_range: float = 0.10
    neighbor_max_range: float = 0.75
    neighbor_alpha: float = 1.0
    cyclamen_neighbor_range: float = 0.78

    # Gains AutoMoDe Mercator.
    exploration_tau: int = 5
    phototaxis_proximity_gain: float = 5.0
    anti_phototaxis_proximity_gain: float = 5.0
    attraction_proximity_gain: float = 6.0
    repulsion_proximity_gain: float = 5.0
    repulsion_alpha_parameter: float = 5.0

    def update_variant(self, variant: str):
        if variant not in _OBS_DIM:
            raise ValueError(f"Unknown CASA variant: {variant!r}")
        self.variant = variant
        self.observation_spaces = _spaces(_OBS_DIM[variant], self.num_agents)
        self.action_spaces = _spaces(_ACT_DIM[variant], self.num_agents)
        self.discrete_actions = variant != "dandelion"