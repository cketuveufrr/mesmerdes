# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import os

if os.environ.get("SWARMACB_SKIP_ISAAC_TASKS", "0") != "1":
    import gymnasium as gym  # noqa: F401
