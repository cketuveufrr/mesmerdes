# Copyright (c) 2022-2026, The Isaac Lab Project Developers and SwarmACB Project.
# SPDX-License-Identifier: BSD-3-Clause

"""SwarmACB package.

Set ``SWARMACB_SKIP_ISAAC_TASKS=1`` before importing the package to use the
standalone tensor-only Mercator backend without importing Isaac Lab. The
default path is unchanged: it registers the Isaac/Gym tasks and UI extension.
"""

from __future__ import annotations

import os

if os.environ.get("SWARMACB_SKIP_ISAAC_TASKS", "0") != "1":
    from .tasks import *  # noqa: F401,F403
    from .ui_extension_example import *  # noqa: F401,F403
