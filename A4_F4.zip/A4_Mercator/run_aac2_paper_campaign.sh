#!/usr/bin/env bash
# AAC2 Mercator - 10 conceptions AutoMoDe, budget de 100 000 simulations chacune.
#
# Version 0.3 :
# - aucune génération partielle ;
# - validation finale équilibrée sur de nouveaux épisodes ;
# - best_fsm.txt ne peut jamais provenir d'une unique évaluation chanceuse ;
# - contrôle préalable des FSM AAC2 de référence ;
# - plusieurs recherches de population 1024 remplissent conjointement le GPU.
#
# Utilisation recommandée :
#   chmod +x run_aac2_paper_campaign_v3.sh
#   DEVICE=cuda:1 MAX_PARALLEL=8 ./run_aac2_paper_campaign_v3.sh
#
# Pour seulement afficher toutes les commandes :
#   DRY_RUN=1 SKIP_REFERENCE_CHECK=1 ./run_aac2_paper_campaign_v3.sh

set -Eeuo pipefail

PYTHON_BIN="${PYTHON_BIN:-python}"
DEVICE="${DEVICE:-cuda:1}"
CONFIG="${CONFIG:-configs/mercator/AAC2_mercator_cyclamen.yaml}"
REFERENCE_FSMS="${REFERENCE_FSMS:-configs/mercator/fsms/fsm_mercator_aggregation2_experiment2.txt}"
OUTPUT_ROOT="${OUTPUT_ROOT:-results/automode/AAC2/paper_100k_v3}"

BUDGET="${BUDGET:-100000}"
FIRST_SEED="${FIRST_SEED:-1}"
NUM_RUNS="${NUM_RUNS:-10}"

# Une course utilise 1024 environnements actifs à chaque étage :
# 1024x1, 512x2, 256x4, 128x8.
# Plusieurs processus indépendants remplissent le GPU sans réduire la recherche
# à trois générations comme avec une population de 8192.
BATCH_SIZE="${BATCH_SIZE:-1024}"
POPULATION_SIZE="${POPULATION_SIZE:-1024}"
MAX_PARALLEL="${MAX_PARALLEL:-8}"

SURVIVAL_RATE="${SURVIVAL_RATE:-0.5}"
RANDOM_FRACTION="${RANDOM_FRACTION:-0.15}"
ELITE_KEEP="${ELITE_KEEP:-4}"
MUTATION_STRENGTH="${MUTATION_STRENGTH:-2}"
ROUND_REPEATS=(1 2 4 8)

VALIDATION_BUDGET="${VALIDATION_BUDGET:-20000}"
VALIDATION_CANDIDATES="${VALIDATION_CANDIDATES:-32}"
MIN_VALIDATION_EPISODES="${MIN_VALIDATION_EPISODES:-100}"
MIN_FULL_GENERATIONS="${MIN_FULL_GENERATIONS:-10}"

# Contrôle du modèle avant de dépenser 1 000 000 de simulations.
SKIP_REFERENCE_CHECK="${SKIP_REFERENCE_CHECK:-0}"
REFERENCE_EPISODES="${REFERENCE_EPISODES:-256}"
REFERENCE_BATCH_SIZE="${REFERENCE_BATCH_SIZE:-1024}"
REFERENCE_SEED="${REFERENCE_SEED:-987654}"
REFERENCE_HARD_MIN="${REFERENCE_HARD_MIN:-1500}"
REFERENCE_WARN_MIN="${REFERENCE_WARN_MIN:-2200}"
ALLOW_LOW_REFERENCE="${ALLOW_LOW_REFERENCE:-0}"
RUN_RANDOM_BASELINE="${RUN_RANDOM_BASELINE:-1}"
RANDOM_BASELINE_COUNT="${RANDOM_BASELINE_COUNT:-32}"
RANDOM_BASELINE_EPISODES="${RANDOM_BASELINE_EPISODES:-64}"

# Réévaluation extérieure au budget de conception, avec de nouveaux seeds.
FINAL_EVAL_EPISODES="${FINAL_EVAL_EPISODES:-1000}"
FINAL_EVAL_BATCH_SIZE="${FINAL_EVAL_BATCH_SIZE:-1024}"
FINAL_EVAL_SEED="${FINAL_EVAL_SEED:-2000001}"
SKIP_FINAL_EVAL="${SKIP_FINAL_EVAL:-0}"

SKIP_SELF_TEST="${SKIP_SELF_TEST:-0}"
FORCE="${FORCE:-0}"
DRY_RUN="${DRY_RUN:-0}"

fail() {
  printf 'ERREUR: %s\n' "$*" >&2
  exit 1
}

warn() {
  printf 'AVERTISSEMENT: %s\n' "$*" >&2
}

is_positive_integer() {
  [[ "$1" =~ ^[1-9][0-9]*$ ]]
}

for name in BUDGET FIRST_SEED NUM_RUNS BATCH_SIZE POPULATION_SIZE MAX_PARALLEL \
  ELITE_KEEP MUTATION_STRENGTH VALIDATION_BUDGET VALIDATION_CANDIDATES \
  MIN_VALIDATION_EPISODES MIN_FULL_GENERATIONS REFERENCE_EPISODES \
  REFERENCE_BATCH_SIZE RANDOM_BASELINE_COUNT RANDOM_BASELINE_EPISODES \
  FINAL_EVAL_EPISODES FINAL_EVAL_BATCH_SIZE; do
  value="${!name}"
  is_positive_integer "$value" || fail "$name doit être un entier strictement positif (reçu: $value)"
done

[[ "$BUDGET" -eq 100000 ]] || fail "Le protocole demandé impose BUDGET=100000 par conception."
[[ "$NUM_RUNS" -eq 10 ]] || fail "Le protocole demandé impose NUM_RUNS=10 pour AAC2/Chocolate/Mercator."
[[ "$POPULATION_SIZE" -eq "$BATCH_SIZE" ]] || fail \
  "Cette campagne exige POPULATION_SIZE=BATCH_SIZE pour éviter tout padding GPU."
[[ "$MAX_PARALLEL" -le "$NUM_RUNS" ]] || fail "MAX_PARALLEL ne peut pas dépasser NUM_RUNS."

[[ -f automode/__main__.py ]] || fail \
  "automode/__main__.py introuvable. Exécute le script depuis la racine de A4_Mercator."
[[ -f "$CONFIG" ]] || fail "Configuration introuvable: $CONFIG"
[[ -f "$REFERENCE_FSMS" ]] || fail "FSM de référence introuvables: $REFERENCE_FSMS"

mkdir -p "$OUTPUT_ROOT/logs" "$OUTPUT_ROOT/sanity"

# Vérification structurelle du projet, de la version et du protocole AAC2.
"$PYTHON_BIN" - "$CONFIG" "$DEVICE" "$DRY_RUN" <<'PY'
import sys
import torch
import automode
from automode.config import build_tensor_env_cfg, load_mission_config
from automode.optimizer import VectorizedRaceOptimizer

config, device, dry_run = sys.argv[1:]
loaded = load_mission_config(config)
cfg = build_tensor_env_cfg(loaded, device="cpu", num_envs=1, seed=0)

assert tuple(int(x) for x in automode.__version__.split(".")) >= (0, 3, 0), (
    f"AutoMoDe >=0.3.0 requis, version trouvée: {automode.__version__}"
)
assert VectorizedRaceOptimizer.ALGORITHM_NAME == "vectorized-race-v2-balanced-validation"
assert loaded.mission == "AAC2", f"mission attendue AAC2, obtenue {loaded.mission}"
assert cfg.num_agents == 3, f"AAC2 doit utiliser 3 robots, obtenu {cfg.num_agents}"
assert abs(float(cfg.episode_length_s) - 120.0) < 1e-9
assert abs(float(cfg.sim.dt) - 0.1) < 1e-9
episode_steps = int(round(float(cfg.episode_length_s) / (float(cfg.sim.dt) * int(cfg.decimation))))
assert episode_steps == 1200

# Regression guard for the bug caught by the first v2 sanity run: the generic
# tensor environment used Experiment-1 wall centres (radius 4.7957 m) even
# when the YAML requested AAC2.  Version 0.3 must build the exact small arena.
from automode.mission_geometry import build_experiment2_arena
arena = build_experiment2_arena(
    wall_side_length=float(cfg.arena_side_length),
    wall_thickness=float(cfg.arena_wall_thickness),
    wall_height=float(cfg.arena_wall_height),
)
assert abs(float(arena.inradius) - 1.3073) < 1e-6, arena.inradius
assert abs(float(arena.circumradius) - 1.3550846413085473) < 1e-6, arena.circumradius
assert max((x*x + y*y) ** 0.5 for x, y in arena.wall_centers) < 1.32

if dry_run != "1":
    if not torch.cuda.is_available():
        raise SystemExit("CUDA n'est pas disponible dans cet environnement Python")
    if not device.startswith("cuda:"):
        raise SystemExit(f"DEVICE doit être de la forme cuda:N, reçu {device!r}")
    index = int(device.split(":", 1)[1])
    if not 0 <= index < torch.cuda.device_count():
        raise SystemExit(
            f"GPU {device} invalide; torch voit {torch.cuda.device_count()} périphérique(s)"
        )

print(
    f"Préflight valide: AutoMoDe={automode.__version__}, mission={loaded.mission}, "
    f"robots={cfg.num_agents}, ticks={episode_steps}, arena_inradius={arena.inradius:.4f}m, device={device}"
)
PY

# Calcule exactement le plan de budget avant le premier lancement.
PLAN_JSON="$OUTPUT_ROOT/campaign_plan.json"
"$PYTHON_BIN" - "$PLAN_JSON" "$BUDGET" "$POPULATION_SIZE" "$SURVIVAL_RATE" \
  "$VALIDATION_BUDGET" "$VALIDATION_CANDIDATES" "$MIN_VALIDATION_EPISODES" \
  "$MIN_FULL_GENERATIONS" <<'PY'
import json
import math
import pathlib
import sys

(
    output, budget, population, survival, validation_budget,
    requested_candidates, min_validation_episodes, min_generations,
) = sys.argv[1:]
budget = int(budget)
population = int(population)
survival = float(survival)
validation_budget = int(validation_budget)
requested_candidates = int(requested_candidates)
min_validation_episodes = int(min_validation_episodes)
min_generations = int(min_generations)
rounds = [1, 2, 4, 8]

survivors = population
generation_cost = 0
for repeats in rounds:
    generation_cost += survivors * repeats
    if survivors > 1:
        survivors = max(1, math.ceil(survivors * survival))

search_limit = budget - validation_budget
generations = search_limit // generation_cost
search_simulations = generations * generation_cost
remaining = budget - search_simulations
eligible = survivors * generations
max_candidates = min(
    requested_candidates,
    eligible,
    remaining // min_validation_episodes,
)
if generations < min_generations:
    raise SystemExit(
        f"Seulement {generations} générations complètes. Minimum demandé: {min_generations}. "
        "Réduisez POPULATION_SIZE ou les répétitions."
    )
if max_candidates < 2:
    raise SystemExit("Budget de validation insuffisant pour au moins deux finalistes")

chosen = None
for count in range(max_candidates, 1, -1):
    if remaining % count == 0 and remaining // count >= min_validation_episodes:
        chosen = (count, remaining // count, 0)
        break
if chosen is None:
    count = max_candidates
    episodes = remaining // count
    chosen = (count, episodes, remaining - count * episodes)

count, episodes, tail = chosen
payload = {
    "algorithm": "vectorized-race-v2-balanced-validation",
    "budget": budget,
    "population_size": population,
    "round_repeats": rounds,
    "survival_rate": survival,
    "generation_cost": generation_cost,
    "finalists_per_generation": survivors,
    "complete_generations": generations,
    "search_simulations": search_simulations,
    "remaining_after_search": remaining,
    "validation_candidates": count,
    "validation_episodes_per_candidate": episodes,
    "balanced_validation_simulations": count * episodes,
    "post_selection_tail": tail,
}
path = pathlib.Path(output)
path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print("Plan de budget:")
for key, value in payload.items():
    print(f"  {key:34s}: {value}")
PY

if [[ "$SKIP_SELF_TEST" != "1" ]]; then
  printf '\nExécution des tests intégrés AutoMoDe 0.3...\n'
  "$PYTHON_BIN" -m automode self-test
fi

if [[ "$DRY_RUN" != "1" && "$SKIP_REFERENCE_CHECK" != "1" ]]; then
  printf '\nContrôle des dix FSM AAC2 Mercator fournies avec le projet...\n'
  REFERENCE_JSON="$OUTPUT_ROOT/sanity/reference_aac2.json"
  "$PYTHON_BIN" -m automode evaluate \
    --config "$CONFIG" \
    --fsm-file "$REFERENCE_FSMS" \
    --episodes "$REFERENCE_EPISODES" \
    --batch-size "$REFERENCE_BATCH_SIZE" \
    --device "$DEVICE" \
    --seed "$REFERENCE_SEED" \
    --output-json "$REFERENCE_JSON" \
    2>&1 | tee "$OUTPUT_ROOT/logs/reference_aac2.log"

  RANDOM_JSON=""
  if [[ "$RUN_RANDOM_BASELINE" == "1" ]]; then
    RANDOM_FSMS="$OUTPUT_ROOT/sanity/random_aac2_${RANDOM_BASELINE_COUNT}.txt"
    RANDOM_JSON="$OUTPUT_ROOT/sanity/random_aac2.json"
    "$PYTHON_BIN" - "$RANDOM_FSMS" "$RANDOM_BASELINE_COUNT" <<'PY'
import pathlib
import random
import sys
from automode.fsm import random_fsm, serialize_fsm

path = pathlib.Path(sys.argv[1])
count = int(sys.argv[2])
rng = random.Random(424242)
path.write_text(
    "\n".join(serialize_fsm(random_fsm(rng)) for _ in range(count)) + "\n",
    encoding="utf-8",
)
PY
    printf '\nContrôle complémentaire sur %s FSM aléatoires...\n' "$RANDOM_BASELINE_COUNT"
    "$PYTHON_BIN" -m automode evaluate \
      --config "$CONFIG" \
      --fsm-file "$RANDOM_FSMS" \
      --episodes "$RANDOM_BASELINE_EPISODES" \
      --batch-size "$REFERENCE_BATCH_SIZE" \
      --device "$DEVICE" \
      --seed "$REFERENCE_SEED" \
      --output-json "$RANDOM_JSON" \
      2>&1 | tee "$OUTPUT_ROOT/logs/random_aac2.log"
  fi

  "$PYTHON_BIN" - "$REFERENCE_JSON" "$RANDOM_JSON" "$REFERENCE_HARD_MIN" \
    "$REFERENCE_WARN_MIN" "$ALLOW_LOW_REFERENCE" \
    "$OUTPUT_ROOT/sanity/sanity_summary.json" <<'PY'
import json
import pathlib
import statistics
import sys

ref_path, random_path, hard_min, warn_min, allow_low, output = sys.argv[1:]
hard_min = float(hard_min)
warn_min = float(warn_min)
allow_low = allow_low == "1"
ref = json.loads(pathlib.Path(ref_path).read_text(encoding="utf-8"))
ref_scores = [float(row["score"]) for row in ref["results"]]
if len(ref_scores) != 10:
    raise SystemExit(f"10 FSM de référence attendues, obtenu {len(ref_scores)}")

payload = {
    "reference_count": len(ref_scores),
    "reference_episodes_per_fsm": int(ref["episodes_per_fsm"]),
    "reference_min": min(ref_scores),
    "reference_median": statistics.median(ref_scores),
    "reference_mean": statistics.fmean(ref_scores),
    "reference_max": max(ref_scores),
    "hard_min": hard_min,
    "warn_min": warn_min,
}

if random_path:
    random_data = json.loads(pathlib.Path(random_path).read_text(encoding="utf-8"))
    random_scores = [float(row["score"]) for row in random_data["results"]]
    payload.update({
        "random_count": len(random_scores),
        "random_episodes_per_fsm": int(random_data["episodes_per_fsm"]),
        "random_median": statistics.median(random_scores),
        "random_mean": statistics.fmean(random_scores),
        "random_max": max(random_scores),
        "reference_minus_random_best": max(ref_scores) - max(random_scores),
    })

pathlib.Path(output).write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print("\nRésumé du contrôle AAC2:")
for key, value in payload.items():
    print(f"  {key:34s}: {value}")

if payload["reference_max"] < hard_min:
    message = (
        f"Le meilleur contrôleur AAC2 de référence vaut {payload['reference_max']:.1f}, "
        f"sous le seuil critique {hard_min:.1f}. Le backend tensoriel ne reproduit "
        "probablement pas l'échelle attendue; campagne arrêtée pour éviter de gaspiller "
        "un million de simulations."
    )
    if allow_low:
        print("AVERTISSEMENT IGNORÉ PAR ALLOW_LOW_REFERENCE=1: " + message)
    else:
        raise SystemExit(message)
elif payload["reference_max"] < warn_min:
    print(
        f"AVERTISSEMENT: meilleur score de référence {payload['reference_max']:.1f} "
        f"sous le seuil d'attention {warn_min:.1f}."
    )

if "random_max" in payload and payload["reference_max"] <= payload["random_max"]:
    print(
        "AVERTISSEMENT: la meilleure FSM fournie ne dépasse pas la meilleure FSM "
        "aléatoire de ce contrôle. Vérifier le modèle avant interprétation scientifique."
    )
PY
elif [[ "$SKIP_REFERENCE_CHECK" == "1" ]]; then
  warn "Contrôle des FSM de référence désactivé par SKIP_REFERENCE_CHECK=1."
fi

# Manifeste complet et immuable de la campagne.
"$PYTHON_BIN" - "$OUTPUT_ROOT/campaign_manifest.json" "$CONFIG" "$DEVICE" "$BUDGET" \
  "$FIRST_SEED" "$NUM_RUNS" "$BATCH_SIZE" "$POPULATION_SIZE" "$MAX_PARALLEL" \
  "$SURVIVAL_RATE" "$RANDOM_FRACTION" "$ELITE_KEEP" "$MUTATION_STRENGTH" \
  "$VALIDATION_BUDGET" "$VALIDATION_CANDIDATES" "$MIN_VALIDATION_EPISODES" <<'PY'
import json
import pathlib
import sys
from datetime import datetime, timezone

(
    output, config, device, budget, first_seed, num_runs, batch, population,
    parallel, survival, random_fraction, elite, mutation, validation_budget,
    validation_candidates, min_validation_episodes,
) = sys.argv[1:]
payload = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "protocol": {
        "mission": "AAC2",
        "platform": "Mercator",
        "robots": 3,
        "episode_seconds": 120.0,
        "control_period_seconds": 0.1,
        "simulations_per_design": int(budget),
        "independent_designs": int(num_runs),
        "seed_first": int(first_seed),
    },
    "engine": "vectorized-race-v2-balanced-validation",
    "engine_note": "Chocolate space and paper budget; not bit-identical to R/irace",
    "config": config,
    "device": device,
    "batch_size_per_process": int(batch),
    "population_size": int(population),
    "max_parallel_processes": int(parallel),
    "nominal_parallel_environments": int(batch) * int(parallel),
    "round_repeats": [1, 2, 4, 8],
    "survival_rate": float(survival),
    "random_fraction": float(random_fraction),
    "elite_keep": int(elite),
    "mutation_strength": int(mutation),
    "validation_budget_minimum": int(validation_budget),
    "validation_candidates_requested": int(validation_candidates),
    "min_validation_episodes": int(min_validation_episodes),
}
pathlib.Path(output).write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
PY

is_complete_run() {
  local run_dir="$1"
  local seed="$2"
  [[ -f "$run_dir/summary.json" && -s "$run_dir/best_fsm.txt" && \
     -f "$run_dir/validation_results.json" ]] || return 1
  "$PYTHON_BIN" - "$run_dir/summary.json" "$BUDGET" "$BATCH_SIZE" \
    "$POPULATION_SIZE" "$seed" "$VALIDATION_BUDGET" "$VALIDATION_CANDIDATES" \
    "$MIN_VALIDATION_EPISODES" <<'PY' >/dev/null 2>&1
import json
import sys
s = json.load(open(sys.argv[1], encoding="utf-8"))
assert s["algorithm"] == "vectorized-race-v2-balanced-validation"
assert s["mission"] == "AAC2"
assert int(s["simulations_used"]) == int(sys.argv[2])
assert int(s["batch_size"]) == int(sys.argv[3])
assert int(s["population_size"]) == int(sys.argv[4])
assert int(s["seed"]) == int(sys.argv[5])
assert int(s["minimum_validation_budget"]) == int(sys.argv[6])
assert int(s["validation_candidates_requested"]) == int(sys.argv[7])
assert int(s["min_validation_episodes"]) == int(sys.argv[8])
assert s["round_repeats"] == [1, 2, 4, 8]
assert int(s["best_episodes"]) == int(s["validation_episodes_per_candidate"])
assert int(s["best_episodes"]) >= int(sys.argv[8])
assert int(s["search_simulations"]) + int(s["validation_simulations"]) == int(s["simulations_used"])
PY
}

prepare_run_dir() {
  local run_dir="$1"
  local seed="$2"
  if [[ -e "$run_dir" ]]; then
    if is_complete_run "$run_dir" "$seed" && [[ "$FORCE" != "1" ]]; then
      return 10
    fi
    local archived="${run_dir}.previous.$(date -u +%Y%m%dT%H%M%SZ)"
    printf 'Archivage de %s vers %s\n' "$run_dir" "$archived"
    mv "$run_dir" "$archived"
  fi
  mkdir -p "$run_dir"
  return 0
}

run_one_seed() {
  local seed="$1"
  local run_dir="$OUTPUT_ROOT/seed_${seed}"
  local log_file="$OUTPUT_ROOT/logs/seed_${seed}.log"

  if prepare_run_dir "$run_dir" "$seed"; then
    :
  else
    local status=$?
    if [[ "$status" -eq 10 ]]; then
      printf '[seed %s] sortie 0.2 complète déjà présente; ignorée.\n' "$seed"
      return 0
    fi
    return "$status"
  fi

  local -a cmd=(
    "$PYTHON_BIN" -m automode design
    --config "$CONFIG"
    --device "$DEVICE"
    --batch-size "$BATCH_SIZE"
    --population-size "$POPULATION_SIZE"
    --budget "$BUDGET"
    --round-repeats "${ROUND_REPEATS[@]}"
    --survival-rate "$SURVIVAL_RATE"
    --random-fraction "$RANDOM_FRACTION"
    --elite-keep "$ELITE_KEEP"
    --mutation-strength "$MUTATION_STRENGTH"
    --validation-budget "$VALIDATION_BUDGET"
    --validation-candidates "$VALIDATION_CANDIDATES"
    --min-validation-episodes "$MIN_VALIDATION_EPISODES"
    --seed "$seed"
    --output "$run_dir"
  )

  printf '\n[%s] Début AAC2 seed=%s\n' "$(date -Is)" "$seed"
  printf 'Commande:'
  printf ' %q' "${cmd[@]}"
  printf '\n'

  {
    printf 'started=%s\n' "$(date -Is)"
    printf 'seed=%s\n' "$seed"
    printf 'command='
    printf '%q ' "${cmd[@]}"
    printf '\n'
  } > "$run_dir/launch.txt"

  if [[ "$DRY_RUN" == "1" ]]; then
    printf '[seed %s] DRY_RUN: commande non exécutée.\n' "$seed"
    rm -rf "$run_dir"
    return 0
  fi

  "${cmd[@]}" 2>&1 | tee "$log_file"
  is_complete_run "$run_dir" "$seed" || {
    printf '[seed %s] sortie invalide ou incomplète.\n' "$seed" >&2
    return 1
  }
  printf '[%s] Fin AAC2 seed=%s\n' "$(date -Is)" "$seed"
}

wait_wave() {
  local -n pids_ref=$1
  local -n seeds_ref=$2
  local failed=0
  local i
  for i in "${!pids_ref[@]}"; do
    if ! wait "${pids_ref[$i]}"; then
      printf 'Échec seed=%s (PID %s).\n' "${seeds_ref[$i]}" "${pids_ref[$i]}" >&2
      failed=1
    fi
  done
  pids_ref=()
  seeds_ref=()
  [[ "$failed" -eq 0 ]]
}

terminate_children() {
  local pids
  pids="$(jobs -pr || true)"
  if [[ -n "$pids" ]]; then
    warn "Interruption: arrêt des processus enfants: $pids"
    # shellcheck disable=SC2086
    kill $pids 2>/dev/null || true
  fi
}
trap terminate_children INT TERM

printf '\nConfiguration de campagne corrigée\n'
printf '  mission                    : AAC2 Mercator, 3 robots\n'
printf '  conceptions                : %s\n' "$NUM_RUNS"
printf '  seeds                      : %s..%s\n' "$FIRST_SEED" "$((FIRST_SEED + NUM_RUNS - 1))"
printf '  budget / conception        : %s\n' "$BUDGET"
printf '  batch/population/processus : %s\n' "$BATCH_SIZE"
printf '  processus parallèles       : %s\n' "$MAX_PARALLEL"
printf '  environnements nominaux    : %s\n' "$((BATCH_SIZE * MAX_PARALLEL))"
printf '  validation minimale        : %s simulations\n' "$VALIDATION_BUDGET"
printf '  finalistes demandés        : %s\n' "$VALIDATION_CANDIDATES"
printf '  sortie                     : %s\n\n' "$OUTPUT_ROOT"

wave_pids=()
wave_seeds=()
for ((offset = 0; offset < NUM_RUNS; offset++)); do
  seed=$((FIRST_SEED + offset))
  run_one_seed "$seed" &
  wave_pids+=("$!")
  wave_seeds+=("$seed")
  if (( ${#wave_pids[@]} >= MAX_PARALLEL )); then
    wait_wave wave_pids wave_seeds || fail "au moins une optimisation a échoué"
  fi
done
if (( ${#wave_pids[@]} > 0 )); then
  wait_wave wave_pids wave_seeds || fail "au moins une optimisation a échoué"
fi

if [[ "$DRY_RUN" == "1" ]]; then
  printf '\nDRY_RUN terminé avec succès.\n'
  exit 0
fi

# Regroupe les dix FSM et vérifie les invariants de chaque conception.
"$PYTHON_BIN" - "$OUTPUT_ROOT" "$FIRST_SEED" "$NUM_RUNS" "$BUDGET" <<'PY'
import csv
import json
import pathlib
import statistics
import sys

root = pathlib.Path(sys.argv[1])
first_seed = int(sys.argv[2])
num_runs = int(sys.argv[3])
budget = int(sys.argv[4])
rows = []
fsms = []
for seed in range(first_seed, first_seed + num_runs):
    run = root / f"seed_{seed}"
    summary = json.loads((run / "summary.json").read_text(encoding="utf-8"))
    assert summary["algorithm"] == "vectorized-race-v2-balanced-validation"
    assert summary["mission"] == "AAC2"
    assert int(summary["simulations_used"]) == budget
    assert int(summary["best_episodes"]) == int(summary["validation_episodes_per_candidate"])
    assert int(summary["best_episodes"]) > 1
    fsm = (run / "best_fsm.txt").read_text(encoding="utf-8").strip()
    if not fsm:
        raise SystemExit(f"FSM vide pour seed {seed}")
    fsms.append(fsm)
    rows.append({
        "seed": seed,
        "simulations": int(summary["simulations_used"]),
        "search_simulations": int(summary["search_simulations"]),
        "validation_simulations": int(summary["validation_simulations"]),
        "generations": int(summary["generations"]),
        "validation_candidates": int(summary["validation_candidates"]),
        "validation_episodes_per_candidate": int(summary["validation_episodes_per_candidate"]),
        "best_validation_score": float(summary["best_validation_score"]),
        "best_validation_std": float(summary["best_validation_std"]),
        "best_search_score": float(summary["best_search_score"]),
        "elapsed_s": float(summary["elapsed_s"]),
        "archive_size": int(summary["archive_size"]),
        "fsm_file": str(run / "best_fsm.txt"),
    })

(root / "best_10_fsms.txt").write_text("\n".join(fsms) + "\n", encoding="utf-8")
with (root / "campaign_summary.tsv").open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t")
    writer.writeheader()
    writer.writerows(rows)

aggregate = {
    "runs": len(rows),
    "simulations_total": sum(row["simulations"] for row in rows),
    "internal_validation_score_mean": statistics.fmean(row["best_validation_score"] for row in rows),
    "internal_validation_score_std": statistics.pstdev(row["best_validation_score"] for row in rows),
    "internal_validation_episodes_per_selected_fsm": sorted({row["validation_episodes_per_candidate"] for row in rows}),
    "elapsed_process_seconds_total": sum(row["elapsed_s"] for row in rows),
    "note": "Internal validation scores are balanced, but final independent evaluation remains authoritative.",
}
(root / "campaign_aggregate.json").write_text(
    json.dumps(aggregate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print("\nDix conceptions vérifiées:")
print(f"  simulations total : {aggregate['simulations_total']}")
print(f"  FSM regroupées    : {root / 'best_10_fsms.txt'}")
print(f"  résumé            : {root / 'campaign_summary.tsv'}")
PY

if [[ "$SKIP_FINAL_EVAL" != "1" ]]; then
  printf '\nRéévaluation indépendante des dix FSM sélectionnées...\n'
  "$PYTHON_BIN" -m automode evaluate \
    --config "$CONFIG" \
    --fsm-file "$OUTPUT_ROOT/best_10_fsms.txt" \
    --episodes "$FINAL_EVAL_EPISODES" \
    --batch-size "$FINAL_EVAL_BATCH_SIZE" \
    --device "$DEVICE" \
    --seed "$FINAL_EVAL_SEED" \
    --output-json "$OUTPUT_ROOT/final_independent_evaluation.json" \
    2>&1 | tee "$OUTPUT_ROOT/logs/final_independent_evaluation.log"

  "$PYTHON_BIN" - "$OUTPUT_ROOT/final_independent_evaluation.json" \
    "$OUTPUT_ROOT/final_independent_summary.json" <<'PY'
import json
import pathlib
import statistics
import sys

source = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
scores = [float(row["score"]) for row in source["results"]]
stds = [float(row["std"]) for row in source["results"]]
payload = {
    "fsm_count": len(scores),
    "episodes_per_fsm": int(source["episodes_per_fsm"]),
    "score_min": min(scores),
    "score_median": statistics.median(scores),
    "score_mean": statistics.fmean(scores),
    "score_population_std_across_fsms": statistics.pstdev(scores),
    "score_max": max(scores),
    "within_fsm_std_mean": statistics.fmean(stds),
    "seed": int(source["seed"]),
}
pathlib.Path(sys.argv[2]).write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print("\nRésultat indépendant final:")
for key, value in payload.items():
    print(f"  {key:34s}: {value}")
PY
fi

printf '\nCampagne AAC2 0.2 terminée avec succès.\n'
printf 'Résultats: %s\n' "$OUTPUT_ROOT"
