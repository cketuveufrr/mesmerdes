# Cyclamen-PS test report

Validated against the supplied `A4__.zip` project state.

- Python compilation: passed.
- Six Mercator-only YAML files: parsed and validated.
- No tMercator Cyclamen-PS YAML generated.
- All six tensor environments: smoke test passed.
- All six Cyclamen-PS trainers: actor observation 8D, critic state 5D.
- Previous module chronology: reset = six zeros; next observation = one-hot of
  the module actually executed during the preceding decision.
- Actor-only contract: critic architecture and parameter count unchanged
  (`134,595` parameters in the tested configuration).
- Same-seed initial-policy test: optimized Cyclamen and Cyclamen-PS logits,
  hidden state and cell state are exactly equal before the PS projection learns.
- Standard-YAML regression test: `train_ps.py` and existing `train_p3.py`
  produced tensor-identical actor and critic weights after a complete update.
- Vectorized Cyclamen-PS training: passed.
- Non-vectorized Cyclamen-PS training: passed.
- Checkpoint isolation: standard and Cyclamen-PS checkpoints reject each other.
