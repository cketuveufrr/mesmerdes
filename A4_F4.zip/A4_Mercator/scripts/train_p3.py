#!/usr/bin/env python3
"""Run ``train_2.py`` with isolated POCA performance optimizations.

Installation layout, relative to the project root::

    poca_opti/
        __init__.py
        poca_networks.py
        poca_buffer.py
        poca_trainer.py
    scripts/
        train_2.py
        train_p3.py

Only the POCA network, buffer and trainer are replaced for this Python process.
All configurations, Mercator environments, mission models and helper functions
are imported from the existing project exactly as ``train_2.py`` uses them.
"""

from __future__ import annotations

import os
from pathlib import Path
import sys

# Keep the same lightweight tensor-only startup contract as train_2.py.
os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")

_SCRIPT_DIR = Path(__file__).resolve().parent
_ROOT = _SCRIPT_DIR.parent
if not (_ROOT / "source" / "SwarmACB_isaac").is_dir():
    raise RuntimeError(
        "train_p3.py must be placed in the project's scripts/ directory"
    )
if not (_ROOT / "poca_alt" / "poca_opti" / "poca_trainer.py").is_file():
    raise RuntimeError(
        "Missing root-level poca_opti/. Extract the bundle at the project root."
    )

# The project root is needed for importing the isolated root-level package.
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# Import the unchanged fast tensor training script. Since this file lives beside
# train_2.py, Python resolves the sibling module without duplicating its code.
import train_2 as _train2

from poca_alt.poca_opti.poca_trainer import (
    POCATrainer as _OptimizedPOCATrainer,
    trust_region_policy_loss as _optimized_policy_loss,
    trust_region_value_loss as _optimized_value_loss,
)


class FastPOCATrainer(_OptimizedPOCATrainer):
    """Optimized trainer plus train_2.py's already-validated batched LSTM loss."""

    # Reuse the exact vectorized recurrent-loss implementation from train_2.py.
    # A function keeps the globals of the module where it was defined, so the
    # trust-region globals below are also rebound to the isolated implementations.
    _compute_recurrent_losses = _train2.FastPOCATrainer._compute_recurrent_losses


# Rebind only the POCA components selected by train_2.main(). Everything else in
# train_2.py continues to use the original project modules and functions.
_train2.POCATrainer = _OptimizedPOCATrainer
_train2.FastPOCATrainer = FastPOCATrainer
_train2.trust_region_policy_loss = _optimized_policy_loss
_train2.trust_region_value_loss = _optimized_value_loss


def main() -> None:
    print(
        "[train_p3] Isolated POCA optimizations enabled from "
        f"{_ROOT / 'poca_alt' / 'poca_opti'}"
    )
    _train2.main()


if __name__ == "__main__":
    main()
