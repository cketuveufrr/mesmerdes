#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Launch full-USD Mercator evaluation in pseudo-reality.

The command mirrors ``scripts/launch_ps.py`` at the user-facing level, but it
runs one collision-enabled scene containing the real Mercator USD assets and
local TeraRanger/RTX-LiDAR sensing.

Examples
--------
Observe a trained controller::

    python scripts/launch_real_.py --mission AAC --observe \
      --checkpoint checkpoints/AAC_mercator_cyclamen/poca_final.pt \
      --deterministic

Score a checkpoint::

    python scripts/launch_real_.py --mission FOR --score \
      --checkpoint checkpoints/FOR_mercator_cyclamen/poca_final.pt \
      --episodes 10 --deterministic

Observe or score Chocolate FSMs::

    python scripts/launch_real_.py --mission GRID --observe --fsm-index 1
    python scripts/launch_real_.py --mission AAC --score --all-fsms --episodes 10

Validate files and setup without starting Isaac Sim::

    python scripts/launch_real_.py --mission AAC --score --fsm-index 1 --validate-only
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import traceback


ROOT = Path(__file__).resolve().parents[1]
REAL_ROOT = ROOT / "real_robot"
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
SCRIPTS_ROOT = ROOT / "scripts"
for path in (ROOT, REAL_ROOT, SOURCE_ROOT, SCRIPTS_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from real_robot.runtime.config import load_real_robot_config, normalize_mission


DEFAULT_CONFIGS = {
    "AAC": ROOT / "real_robot" / "configs" / "AAC_real.yaml",
    "FOR": ROOT / "real_robot" / "configs" / "FOR_real.yaml",
    "GRID": ROOT / "real_robot" / "configs" / "GRID_real.yaml",
}
DEFAULT_FSMS = {
    "AAC": ROOT / "configs" / "mercator" / "fsms" / "fsm_mercator_aggregation_experiment1.txt",
    "FOR": ROOT / "configs" / "mercator" / "fsms" / "fsm_mercator_foraging_experiment1.txt",
    "GRID": ROOT / "configs" / "mercator" / "fsms" / "fsm_mercator_grid_exploration_experiment1.txt",
}


def _mission(value: str) -> str:
    try:
        return normalize_mission(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Observe or score checkpoints/FSMs on the full Mercator USD model"
    )
    parser.add_argument("--mission", required=True, type=_mission, choices=("AAC", "FOR", "GRID"))
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--observe", action="store_true", help="Open the Isaac viewer")
    mode.add_argument("--score", action="store_true", help="Run headlessly and write reports")
    parser.add_argument("--config", default=None, help="real_robot YAML setup")

    controller = parser.add_mutually_exclusive_group()
    controller.add_argument("--checkpoint", default=None, help="POCA/SwarmACB checkpoint")
    controller.add_argument("--fsm-file", default=None, help="Chocolate FSM file")
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument("--fsm-index", type=int, default=1, help="1-based FSM index")
    selection.add_argument("--all-fsms", action="store_true", help="Evaluate every FSM")

    parser.add_argument("--deterministic", action="store_true", help="Use argmax/mean checkpoint actions")
    parser.add_argument("--episodes", type=int, default=1, help="Sequential episodes per controller/FSM")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--print-every", type=int, default=100)
    parser.add_argument("--headless", action="store_true", help="Run observe mode without a visible window")
    parser.add_argument("--width", type=int, default=1600)
    parser.add_argument("--height", type=int, default=900)
    parser.add_argument("--renderer", default="RaytracedLighting")
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Validate YAML/controller files without starting Isaac Sim",
    )
    return parser


def resolve_args(args: argparse.Namespace, parser: argparse.ArgumentParser) -> argparse.Namespace:
    if args.episodes < 1:
        parser.error("--episodes must be positive")
    if args.seed < 0:
        parser.error("--seed must be non-negative")
    if args.fsm_index < 1:
        parser.error("--fsm-index must be >= 1")
    if args.observe and args.all_fsms:
        parser.error("--all-fsms is available only with --score")
    if args.checkpoint and args.all_fsms:
        parser.error("--all-fsms applies only to FSM mode")

    if args.config is None:
        args.config = str(DEFAULT_CONFIGS[args.mission])
    else:
        args.config = str(Path(args.config).expanduser().resolve())
    if args.fsm_file is None and not args.checkpoint:
        args.fsm_file = str(DEFAULT_FSMS[args.mission])
    elif args.fsm_file is not None:
        args.fsm_file = str(Path(args.fsm_file).expanduser().resolve())
    if args.checkpoint is not None:
        args.checkpoint = str(Path(args.checkpoint).expanduser().resolve())
    return args


def validate_only(args: argparse.Namespace) -> None:
    cfg = load_real_robot_config(args.config)
    print(f"YAML: {cfg.source_path}")
    print(
        f"Mission={cfg.mission_key} robots={cfg.robot.count} "
        f"track_width={cfg.robot.track_width:.3f}m "
        f"ground_offset={cfg.robot.ground_sensor_offset[0]:.5f}m"
    )
    print(
        f"LiDAR={cfg.lidar.min_range:.2f}-{cfg.lidar.max_range:.2f}m "
        f"at {cfg.lidar.scan_rate_hz:g}Hz, min_cluster_points={cfg.lidar.min_cluster_points}"
    )
    print(
        "Noise: "
        f"wheel_std={cfg.noise.wheels.std_fraction:g}, "
        f"lidar_uniform={cfg.noise.lidar.range_uniform_m:g}m, "
        f"lidar_gaussian={cfg.noise.lidar.range_gaussian_std_m:g}m, "
        f"lidar_dropout={cfg.noise.lidar.dropout_probability:g}, "
        f"lidar_azimuth_std={cfg.noise.lidar.azimuth_gaussian_std_deg:g}deg, "
        f"proximity_std={cfg.noise.sensors.proximity_gaussian_std:g}, "
        f"light_std={cfg.noise.sensors.light_gaussian_std:g}, "
        f"ground_flip={cfg.noise.sensors.ground_flip_probability:g}"
    )
    usd = ROOT / "real_robot" / cfg.robot.usd
    if not usd.is_file():
        raise FileNotFoundError(f"Mercator USD not found: {usd}")
    print(f"USD: {usd}")

    if args.checkpoint:
        from real_robot.runtime.policy import checkpoint_raw_obs_dim, load_checkpoint

        checkpoint = load_checkpoint(args.checkpoint, "cpu")
        obs_dim = checkpoint_raw_obs_dim(checkpoint)
        if obs_dim not in (2, 22):
            raise ValueError(f"Unsupported checkpoint obs_dim={obs_dim}; expected 2 or 22")
        configured = str(cfg.control.observation).strip().lower()
        if configured != "auto" and obs_dim != int(configured):
            raise ValueError(
                f"Checkpoint obs_dim={obs_dim} does not match YAML control.observation={configured}"
            )
        print(
            f"Checkpoint: {args.checkpoint} trainer={checkpoint.get('trainer_type', 'poca')} "
            f"discrete={bool(checkpoint.get('discrete', False))} "
            f"recurrent={bool(checkpoint.get('recurrent', False))} obs={obs_dim}"
        )
    else:
        from mercator_chocolate_fsm import load_fsm_file

        fsms = load_fsm_file(args.fsm_file)
        if not 1 <= args.fsm_index <= len(fsms) and not args.all_fsms:
            raise ValueError(f"--fsm-index must be in [1, {len(fsms)}]")
        print(f"FSM file: {args.fsm_file} ({len(fsms)} FSMs)")
    print("Validation successful.")


def main() -> int:
    parser = build_parser()
    args, unknown = parser.parse_known_args()
    args = resolve_args(args, parser)
    if unknown:
        print("Passing unknown arguments to Isaac/Kit:", " ".join(unknown))
    try:
        if args.validate_only:
            validate_only(args)
            return 0

        from isaacsim import SimulationApp

        simulation_app = SimulationApp(
            {
                "headless": bool(args.score or args.headless),
                "renderer": str(args.renderer),
                "multi_gpu": False,
                "width": int(args.width),
                "height": int(args.height),
            }
        )
        try:
            from real_robot.runtime.runner import run

            return int(run(args, simulation_app, ROOT))
        finally:
            simulation_app.close()
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130
    except Exception:
        print("launch_real_.py failed", file=sys.stderr)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())