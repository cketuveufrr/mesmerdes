#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Train the A(4) POCA implementation on tensor-only Mercator aggregation.

This script keeps the POCA networks, buffer, critic, losses, schedules and
checkpoint format from A(4). Only the environment transport uses direct
``[num_envs, num_agents, ...]`` tensors when ``tensor_api=True``.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import random
import sys

# Must be set before importing SwarmACB_isaac: the tensor backend has no Isaac
# Sim, Kit, USD or Gym dependency.
os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")
ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

import numpy as np
import torch

from SwarmACB_isaac.tasks.direct.agents.config_loader import load_config, print_config
from SwarmACB_isaac.tasks.direct.agents.poca_trainer import POCATrainer
from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
    MercatorTensorEnv,
    MercatorTensorEnvCfg,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="A(4) POCA training on the tensor-only Mercator backend"
    )
    parser.add_argument(
        "--config",
        default="configs/AAC_mercator_cyclamen.yaml",
        help="ML-Agents-style Mercator YAML configuration.",
    )
    parser.add_argument(
        "--device",
        default="cuda:0" if torch.cuda.is_available() else "cpu",
    )
    parser.add_argument("--num_envs", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--checkpoint", default=None)
    parser.add_argument("--total_timesteps", type=int, default=None)
    parser.add_argument("--analytical_substeps", type=int, default=None)
    parser.add_argument("--collision_iterations", type=int, default=None)
    parser.add_argument(
        "--matmul_precision",
        choices=("highest", "high", "medium"),
        default="highest",
        help=(
            "PyTorch float32 matmul precision. 'highest' is the conservative "
            "default; 'high' can enable faster TF32 kernels on compatible GPUs."
        ),
    )
    parser.add_argument("--log_dir", default=None)
    parser.add_argument("--checkpoint_dir", default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path

    run_name, variant, trainer_cfg, env_overrides = load_config(config_path)
    if getattr(trainer_cfg, "trainer_type", "poca") != "poca":
        raise ValueError("train_fast.py supports the A(4) POCA trainer only.")

    task_id = env_overrides.get("task", "SwarmACB-MercatorAggregation-v0")
    if task_id != "SwarmACB-MercatorAggregation-v0":
        raise ValueError(
            "train_fast.py supports SwarmACB-MercatorAggregation-v0 only; "
            f"got {task_id!r}."
        )
    if int(trainer_cfg.decision_period) != 1:
        raise ValueError(
            "The tensor Mercator backend expects decision_period=1 because one "
            "step_tensor() call already represents the complete 0.1 s control step."
        )

    env_cfg = MercatorTensorEnvCfg(variant=variant, device=args.device)
    env_cfg.apply_overrides(env_overrides)

    if args.num_envs is not None:
        if args.num_envs <= 0:
            raise ValueError("--num_envs must be positive")
        env_cfg.scene.num_envs = int(args.num_envs)
    if args.seed is not None:
        trainer_cfg.seed = int(args.seed)
        env_cfg.seed = int(args.seed)
    else:
        # A(4)'s generic loader leaves environment.seed in env_overrides.
        trainer_cfg.seed = int(env_cfg.seed)
    if args.analytical_substeps is not None:
        if args.analytical_substeps <= 0:
            raise ValueError("--analytical_substeps must be positive")
        env_cfg.analytical_substeps = int(args.analytical_substeps)
    if args.collision_iterations is not None:
        if args.collision_iterations <= 0:
            raise ValueError("--collision_iterations must be positive")
        env_cfg.collision_iterations = int(args.collision_iterations)
    if args.total_timesteps is not None:
        if args.total_timesteps <= 0:
            raise ValueError("--total_timesteps must be positive")
        trainer_cfg.total_timesteps = int(args.total_timesteps)
    if args.log_dir is not None:
        trainer_cfg.log_dir = args.log_dir
    if args.checkpoint_dir is not None:
        trainer_cfg.checkpoint_dir = args.checkpoint_dir

    torch.set_float32_matmul_precision(args.matmul_precision)
    random.seed(trainer_cfg.seed)
    np.random.seed(trainer_cfg.seed)
    torch.manual_seed(trainer_cfg.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(trainer_cfg.seed)

    printable_overrides = dict(env_overrides)
    printable_overrides.update(
        {
            "backend": "tensor-only",
            "device": str(env_cfg.device),
            "num_envs": env_cfg.scene.num_envs,
            "num_agents": env_cfg.num_agents,
            "analytical_substeps": env_cfg.analytical_substeps,
            "collision_iterations": env_cfg.collision_iterations,
            "matmul_precision": args.matmul_precision,
        }
    )
    print_config(run_name, variant, trainer_cfg, printable_overrides)

    env = MercatorTensorEnv(env_cfg)
    try:
        trainer = POCATrainer(env, trainer_cfg)
        if not trainer.tensor_env:
            raise RuntimeError("MercatorTensorEnv was not detected as tensor_api=True")
        if args.checkpoint:
            trainer.load_checkpoint(args.checkpoint)
        trainer.train()
    finally:
        env.close()


if __name__ == "__main__":
    main()
