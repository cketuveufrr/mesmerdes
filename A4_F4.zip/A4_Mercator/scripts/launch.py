#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Unified Mercator/tMercator controller launcher.

The launcher deliberately stays Isaac-free: it validates the requested setup,
selects the correct mission/profile YAML, then delegates to the proven FSM or
checkpoint visualizer.  This keeps one stable command-line interface for:

* real Chocolate FSM observation and batch scoring;
* trained checkpoint playback;
* one fixed AutoMoDe module via ``--module``.

Examples::

    python scripts/launch.py --mission AAC --profile tmercator --fsm-index 1
    python scripts/launch.py --mission FOR2 --profile mercator --module attraction
    python scripts/launch.py --mission GRID --profile tmercator \
        --checkpoint checkpoints/GRID_tmercator/poca_final.pt --deterministic
    python scripts/launch.py --mission AAC2 --profile tmercator \
        --score --all-fsms --episodes 100 --num-envs 100
"""

from __future__ import annotations

import argparse
import os
import shlex
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FSM_SCRIPT = ROOT / "scripts" / "mercator_fsm.py"
VISUAL_SCRIPT = ROOT / "scripts" / "visualize_mercator.py"

MISSION_ALIASES = {
    "AAC": "AAC",
    "AAC1": "AAC",
    "AGG": "AAC",
    "AGG1": "AAC",
    "AAC2": "AAC2",
    "AGG2": "AAC2",
    "FOR": "FOR",
    "FOR1": "FOR",
    "FORAGING": "FOR",
    "FORAGING1": "FOR",
    "FOR2": "FOR2",
    "FORAGING2": "FOR2",
    "GRID": "GRID",
    "GEX": "GRID",
    "GRIDEXPLORATION": "GRID",
    "GRID2": "GRID2",
    "GEX2": "GRID2",
    "GRIDEXPLORATION2": "GRID2",
}
MODULE_NAMES = {
    0: "exploration",
    1: "stop",
    2: "phototaxis",
    3: "anti_phototaxis",
    4: "attraction",
    5: "repulsion",
}
MODULE_ALIASES = {
    **{str(index): index for index in MODULE_NAMES},
    **{name: index for index, name in MODULE_NAMES.items()},
    "anti-phototaxis": 3,
    "antiphototaxis": 3,
}


def parse_mission(value: str) -> str:
    normalized = value.strip().upper().replace("-", "").replace("_", "").replace(" ", "")
    try:
        return MISSION_ALIASES[normalized]
    except KeyError as exc:
        raise argparse.ArgumentTypeError(
            f"unknown mission {value!r}; choose AAC, AAC2, FOR, FOR2, GRID, or GRID2"
        ) from exc


def parse_profile(value: str) -> str:
    normalized = value.strip().lower().replace("-", "").replace("_", "")
    aliases = {
        "mercator": "mercator",
        "native": "mercator",
        "tmercator": "tmercator",
        "transferability": "tmercator",
    }
    try:
        return aliases[normalized]
    except KeyError as exc:
        raise argparse.ArgumentTypeError(
            f"unknown profile {value!r}; choose mercator or tmercator"
        ) from exc


def parse_module(value: str) -> int:
    normalized = value.strip().lower().replace(" ", "_")
    try:
        return MODULE_ALIASES[normalized]
    except KeyError as exc:
        choices = ", ".join(f"{index}:{name}" for index, name in MODULE_NAMES.items())
        raise argparse.ArgumentTypeError(f"unknown module {value!r}; choose {choices}") from exc


def resolve_user_path(value: str) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def config_for(mission: str, profile: str, explicit: str | None) -> Path:
    if explicit:
        return resolve_user_path(explicit)
    return ROOT / "configs" / "mercator" / f"{mission}_{profile}_cyclamen.yaml"


def append_option(command: list[str], name: str, value) -> None:
    if value is not None:
        command.extend((name, str(value)))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Visualize or score Mercator/tMercator FSMs, checkpoints, and fixed modules"
    )
    parser.add_argument("--mission", type=parse_mission, default="AAC")
    parser.add_argument("--profile", type=parse_profile, default="mercator")
    parser.add_argument(
        "--config", default=None, help="Explicit YAML; otherwise mission/profile selects it"
    )

    controller = parser.add_mutually_exclusive_group()
    controller.add_argument("--checkpoint", default=None, help="Trained .pt actor checkpoint")
    controller.add_argument(
        "--module", type=parse_module, default=None,
        help="Fixed module index or name (exploration, stop, phototaxis, anti_phototaxis, attraction, repulsion)",
    )
    controller.add_argument("--fsm", action="store_true", help="Explicitly select FSM mode (the default)")

    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--observe", action="store_true", help="Open the visualizer (default)")
    mode.add_argument("--score", action="store_true", help="Headless FSM scoring")

    parser.add_argument("--fsm-file", default=None)
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument("--fsm-index", type=int, default=1)
    selection.add_argument("--all-fsms", action="store_true")
    parser.add_argument("--color-by", choices=("state", "module"), default="module")

    parser.add_argument("--episodes", type=int, default=20, help="Episodes per FSM in score mode")
    parser.add_argument("--num-envs", "--num_envs", dest="num_envs", type=int, default=20)
    parser.add_argument(
        "--num-episodes",
        "--num_episodes",
        dest="num_episodes",
        type=int,
        default=0,
        help="GUI episodes; 0 runs until the window closes",
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default=None)
    parser.add_argument("--deterministic", action="store_true")
    parser.add_argument("--headless", action="store_true", help="GUI diagnostic without a window")
    parser.add_argument(
        "--camera-height",
        "--camera_height",
        dest="camera_height",
        type=float,
        default=None,
    )
    parser.add_argument(
        "--camera-y", "--camera_y", dest="camera_y", type=float, default=None
    )
    parser.add_argument("--width", type=int, default=1600)
    parser.add_argument("--height", type=int, default=900)
    parser.add_argument(
        "--print-every", "--print_every", dest="print_every", type=int, default=50
    )
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--list-modules", action="store_true")
    parser.add_argument("--dry-run", action="store_true", help="Print the delegated command without executing it")
    return parser


def build_command(args: argparse.Namespace, passthrough: list[str]) -> list[str]:
    config = config_for(args.mission, args.profile, args.config)
    if not config.is_file():
        raise FileNotFoundError(f"Mercator config not found: {config}")

    visual_controller = args.checkpoint is not None or args.module is not None
    if args.score and visual_controller:
        raise ValueError("--score is available only for FSM controllers")
    if args.all_fsms and visual_controller:
        raise ValueError("--all-fsms is available only for FSM controllers")

    if visual_controller:
        command = [sys.executable, str(VISUAL_SCRIPT), "--config", str(config)]
        if args.checkpoint is not None:
            checkpoint = resolve_user_path(args.checkpoint)
            if not checkpoint.is_file():
                raise FileNotFoundError(f"checkpoint not found: {checkpoint}")
            command.extend(("--checkpoint", str(checkpoint)))
        else:
            command.extend(("--module", str(args.module)))
        command.extend(("--num_episodes", str(args.num_episodes)))
        command.extend(("--print_every", str(args.print_every)))
        command.extend(("--width", str(args.width), "--height", str(args.height)))
        append_option(command, "--camera_height", args.camera_height)
        append_option(command, "--camera_y", args.camera_y)
        if args.deterministic:
            command.append("--deterministic")
        if args.headless:
            command.append("--headless")
    else:
        command = [
            sys.executable, str(FSM_SCRIPT),
            "--mission", args.mission,
            "--config", str(config),
            "--seed", str(args.seed),
            "--print-every", str(args.print_every),
        ]
        command.append("--score" if args.score else "--observe")
        if args.fsm_file:
            command.extend(("--fsm-file", str(resolve_user_path(args.fsm_file))))
        if args.all_fsms:
            command.append("--all-fsms")
        else:
            command.extend(("--fsm-index", str(args.fsm_index)))
        if args.score:
            command.extend(("--episodes", str(args.episodes), "--num-envs", str(args.num_envs)))
            append_option(command, "--output-dir", args.output_dir)
        else:
            command.extend(("--color-by", args.color_by))
            command.extend(("--num-episodes", str(args.num_episodes)))
            command.extend(
                ("--width", str(args.width), "--height", str(args.height))
            )
            append_option(command, "--camera-height", args.camera_height)
            append_option(command, "--camera-y", args.camera_y)
            if args.headless:
                command.append("--headless")
        append_option(command, "--device", args.device)

    command.extend(passthrough)
    return command


def main() -> int:
    parser = build_parser()
    args, passthrough = parser.parse_known_args()
    if args.list_modules:
        for index, name in MODULE_NAMES.items():
            print(f"{index}: {name}")
        return 0
    if args.fsm_index < 1:
        parser.error("--fsm-index must be >= 1")
    if args.episodes < 1:
        parser.error("--episodes must be >= 1")
    if args.num_envs < 1:
        parser.error("--num-envs must be >= 1")
    if args.num_episodes < 0:
        parser.error("--num-episodes must be >= 0")

    try:
        command = build_command(args, passthrough)
    except (FileNotFoundError, ValueError) as exc:
        parser.error(str(exc))

    print("[MercatorLaunch] " + shlex.join(command), flush=True)
    if args.dry_run:
        return 0
    os.execv(command[0], command)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
