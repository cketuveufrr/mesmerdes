#!/usr/bin/env python3
"""Pure-PyTorch checks for Mercator Light; Isaac Sim is not required."""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
DIRECT = ROOT / "source" / "SwarmACB_isaac" / "SwarmACB_isaac" / "tasks" / "direct"
AGENTS = DIRECT / "agents"
sys.path.insert(0, str(DIRECT))
sys.path.insert(0, str(AGENTS))

from mercator_light import (  # noqa: E402
    MercatorBehaviorModules, MercatorLightSensors, build_argos_aac_arena,
)
from mercator_light.mercator_geometry import (  # noqa: E402
    boxes_inside_walls,
    pairwise_sat_overlap,
    ray_obb_distances,
    resolve_pairwise_obb_collisions,
    rotate_body_to_world,
)
from mercator_light.mercator_sensors import MercatorSensorBatch  # noqa: E402
from poca_buffer import POCARolloutBuffer  # noqa: E402
from poca_networks import POCACritic, RecurrentDiscreteActor  # noqa: E402

ARENA = build_argos_aac_arena(
    wall_side_length=2.57, wall_thickness=0.01, wall_height=0.08,
)


def wall_segments(device):
    return torch.tensor(ARENA.wall_segments, dtype=torch.float32, device=device)


def wall_halfspaces(device):
    return (
        torch.tensor(ARENA.outward_normals, dtype=torch.float32, device=device),
        torch.tensor(ARENA.inner_offsets, dtype=torch.float32, device=device),
    )


def test_geometry(device):
    assert len(ARENA.wall_segments) == 12
    assert len(ARENA.floor_vertices) == 12
    for a, b in ARENA.wall_segments:
        length = math.hypot(b[0] - a[0], b[1] - a[1])
        assert abs(length - 2.57) < 1e-9
    # Every floor vertex must satisfy every collision half-space.
    for x, y in ARENA.floor_vertices:
        for (nx, ny), offset in zip(ARENA.outward_normals, ARENA.inner_offsets):
            assert nx * x + ny * y <= offset + 1e-7

    origin = torch.tensor([[[-1.0, 0.0]]], device=device)
    direction = torch.tensor([[[1.0, 0.0]]], device=device)
    center = torch.tensor([[[0.0, 0.0]]], device=device)
    yaw = torch.zeros((1, 1), device=device)
    hit = ray_obb_distances(origin, direction, center, yaw, 0.13, 0.125, 10.0)
    torch.testing.assert_close(hit, torch.tensor([[0.87]], device=device), atol=1e-6, rtol=0)

    pos = torch.tensor([[[0.0, 0.0], [0.20, 0.0]]], device=device)
    yaws = torch.zeros((1, 2), device=device)
    assert bool(pairwise_sat_overlap(pos, yaws, 0.13, 0.125)[0, 0, 1])
    resolved = resolve_pairwise_obb_collisions(pos, yaws, 0.13, 0.125, iterations=3)
    assert float(torch.linalg.vector_norm(resolved[0, 1] - resolved[0, 0])) >= 0.259

    normals, offsets = wall_halfspaces(device)
    inside = boxes_inside_walls(
        torch.tensor([[0.0, 0.0], [4.75, 0.0]], device=device),
        torch.zeros(2, device=device), normals, offsets, 0.13, 0.125,
    )
    assert bool(inside[0]) and not bool(inside[1])


def test_ground_offset(device):
    offset = torch.tensor([0.0561900017, 0.0], device=device)
    rotated = rotate_body_to_world(offset, torch.tensor(math.pi / 2, device=device))
    torch.testing.assert_close(rotated, torch.tensor([0.0, 0.0561900017], device=device), atol=1e-6, rtol=0)


def test_sensors_and_modules(device, envs, agents):
    sensors = MercatorLightSensors(device=device)
    radial = torch.sqrt(torch.rand(envs, agents, device=device)) * 4.0
    angle = torch.rand(envs, agents, device=device) * 2 * math.pi
    positions = torch.stack((radial * torch.cos(angle), radial * torch.sin(angle)), dim=-1)
    yaws = torch.rand(envs, agents, device=device) * 2 * math.pi - math.pi
    batch = sensors.compute_all(
        positions, yaws, wall_segments(device),
        torch.tensor((0.0, -5.0), device=device),
    )
    assert batch.proximity_values.shape == (envs, agents, 8)
    assert batch.light_values.shape == (envs, agents, 8)
    assert batch.neighbor_vector.shape == (envs, agents, 2)
    for value in batch.__dict__.values():
        assert torch.isfinite(value).all()

    # Exact direct tower-centre neighbour direction for a known pair.
    pair_pos = torch.tensor([[[0.0, 0.0], [0.5, 0.0]]], device=device)
    pair_yaw = torch.zeros((1, 2), device=device)
    vector, count, ztilde, _ = sensors.compute_neighbors(pair_pos, pair_yaw)
    expected = 1.0 / 51.0
    torch.testing.assert_close(vector[0, 0], torch.tensor([expected, 0.0], device=device), atol=1e-6, rtol=0)
    torch.testing.assert_close(vector[0, 1], torch.tensor([-expected, 0.0], device=device), atol=1e-6, rtol=0)
    torch.testing.assert_close(count, torch.ones_like(count), atol=0, rtol=0)
    torch.testing.assert_close(ztilde, torch.full_like(ztilde, math.tanh(0.5)), atol=1e-6, rtol=0)

    modules = MercatorBehaviorModules(device=device)
    modules.init_state(envs, agents)
    for module_id in range(6):
        wheels = modules.compute(
            torch.full((envs, agents), module_id, dtype=torch.long, device=device), batch,
        )
        assert wheels.shape == (envs, agents, 2)
        assert torch.isfinite(wheels).all()
        assert float(wheels.abs().max()) <= 0.300001

    # End-of-turn exploration semantics: the final counter tick still commands the turn;
    # forward motion resumes on the following control tick.
    modules = MercatorBehaviorModules(device=device)
    modules.init_state(1, 1)
    modules.is_turning[:] = True
    modules.turn_steps_remaining[:] = 1
    modules.turn_sign[:] = 1.0
    modules.previous_module_ids[:] = 0
    zero8 = torch.zeros(1, 1, 8, device=device)
    zero2 = torch.zeros(1, 1, 2, device=device)
    fake = MercatorSensorBatch(
        zero8, zero2, torch.ones(1, 1, device=device), torch.zeros(1, 1, device=device),
        zero8, zero2, torch.zeros(1, 1, device=device), torch.zeros(1, 1, device=device),
        zero2, torch.zeros(1, 1, device=device), torch.zeros(1, 1, device=device),
        torch.zeros(1, 1, 4, device=device),
    )
    wheels = modules.compute(torch.zeros(1, 1, dtype=torch.long, device=device), fake)
    torch.testing.assert_close(
        wheels, torch.tensor([[[-0.3, 0.3]]], device=device), atol=1e-7, rtol=0
    )
    wheels_next = modules.compute(
        torch.zeros(1, 1, dtype=torch.long, device=device), fake
    )
    torch.testing.assert_close(
        wheels_next, torch.tensor([[[0.3, 0.3]]], device=device), atol=1e-7, rtol=0
    )


def test_recurrent_components(device):
    actor = RecurrentDiscreteActor(2, 6, 128, 1, 64).to(device)
    h, c = actor.initial_state(20, device)
    logits, (h, c) = actor.step(torch.rand(20, 2, device=device), (h, c))
    assert logits.shape == (20, 6)

    buffer = POCARolloutBuffer(
        17, 3, 4, 2, 1, state_dim=5, memory_size=8, device=device
    )
    for _ in range(17):
        buffer.add(
            obs=torch.rand(3, 4, 2, device=device),
            critic_states=torch.rand(3, 4, 5, device=device),
            actions=torch.zeros(3, 4, 1, device=device),
            log_probs=torch.zeros(3, 4, 1, device=device),
            reward=torch.rand(3, device=device),
            done=torch.zeros(3, device=device),
            timeout=torch.zeros(3, device=device),
            timeout_value=torch.zeros(3, device=device),
            team_value=torch.rand(3, device=device),
            baselines=torch.rand(3, 4, device=device),
            memory_h=torch.rand(3, 4, 8, device=device),
            memory_c=torch.rand(3, 4, 8, device=device),
        )
    buffer.compute_returns_and_advantages(torch.rand(3, device=device))
    valid_count = sum(int(batch["loss_mask"].sum()) for batch in buffer.get_sequence_batches(5, 4))
    assert valid_count == 17 * 3 * 4


def test_checkpoint(path: Path, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    signature = ckpt.get("environment_signature")
    if signature is not None:
        assert signature.get("arena_fingerprint") == ARENA.fingerprint
    actor = RecurrentDiscreteActor(
        int(ckpt.get("obs_dim", 2)),
        int(ckpt.get("num_actions", 6)),
        int(ckpt.get("hidden_dim", 128)),
        int(ckpt.get("num_layers", 1)),
        int(ckpt.get("memory_size", 64)),
    ).to(device)
    critic = POCACritic(
        int(ckpt.get("state_dim", 5)),
        int(ckpt.get("num_actions", 6)),
        20,
        int(ckpt.get("critic_hidden_dim", 128)),
        int(ckpt.get("critic_num_heads", 4)),
        int(ckpt.get("critic_num_layers", 2)),
        memory_size=int(ckpt.get("memory_size", 64)),
    ).to(device)
    actor.load_state_dict(ckpt["actor"], strict=True)
    critic.load_state_dict(ckpt["critic"], strict=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--num-envs", type=int, default=4)
    parser.add_argument("--num-agents", type=int, default=20)
    parser.add_argument("--checkpoint", type=Path, default=None)
    args = parser.parse_args()
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")

    test_geometry(device)
    test_ground_offset(device)
    test_sensors_and_modules(device, args.num_envs, args.num_agents)
    test_recurrent_components(device)
    if args.checkpoint is not None:
        test_checkpoint(args.checkpoint, device)
        print(f"Checkpoint strict-load OK: {args.checkpoint}")
    print(f"ARENA_FINGERPRINT={ARENA.fingerprint}")
    print(
        "MERCATOR_LIGHT_SMOKE_OK "
        f"device={device} envs={args.num_envs} agents={args.num_agents}"
    )


if __name__ == "__main__":
    main()
