#!/usr/bin/env python3
"""Run the reproducible CPU validation suite for the A(4) Mercator port."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ENV = os.environ.copy()
ENV["SWARMACB_SKIP_ISAAC_TASKS"] = "1"
ENV["PYTHONPATH"] = str(ROOT / "source" / "SwarmACB_isaac") + os.pathsep + ENV.get("PYTHONPATH", "")
# Small CPU tests are faster and more deterministic without BLAS/OpenMP oversubscription.
ENV.setdefault("OMP_NUM_THREADS", "1")
ENV.setdefault("MKL_NUM_THREADS", "1")


def run(label: str, command: list[str]) -> None:
    print(f"\n===== {label} =====")
    subprocess.run(command, cwd=ROOT, env=ENV, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skip-cli",
        action="store_true",
        help="Skip the tiny end-to-end train_fast subprocess.",
    )
    args = parser.parse_args()

    run("compileall", [sys.executable, "-m", "compileall", "-q", "source", "scripts", "tests"])
    run(
        "Mercator smoke",
        [sys.executable, "scripts/smoke_mercator_light.py", "--device", "cpu", "--num-envs", "2", "--num-agents", "8"],
    )
    run("geometry/sensor/trajectory equivalence", [sys.executable, "tests/run_mercator_equivalence_tests.py"])
    run("A(4) POCA integration", [sys.executable, "tests/test_mercator_port_integration.py"])

    if not args.skip_cli:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            run(
                "train_fast CLI",
                [
                    sys.executable,
                    "scripts/train_fast.py",
                    "--config",
                    "configs/TEST_mercator_cyclamen.yaml",
                    "--device",
                    "cpu",
                    "--log_dir",
                    str(root / "runs"),
                    "--checkpoint_dir",
                    str(root / "checkpoints"),
                ],
            )
            checkpoint = root / "checkpoints" / "poca_final.pt"
            if not checkpoint.exists():
                raise RuntimeError(f"Missing CLI checkpoint: {checkpoint}")
            print(f"CLI checkpoint OK: {checkpoint}")

    print("\nA4_MERCATOR_PORT_VALIDATION_OK")


if __name__ == "__main__":
    main()
