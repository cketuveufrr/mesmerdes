#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Parser and batched runtime for Mercator AutoMoDe/Chocolate FSM strings.

The format is the command-line representation produced by Chocolate. State and
condition IDs follow ARGoS3-AutoMoDe-rvr's Mercator builder:

Behaviors: 0 exploration, 1 stop, 2 phototaxis, 3 anti-phototaxis,
           4 attraction, 5 repulsion.
Conditions: 0 black, 1 gray, 2 white, 3 neighbors, 4 inverted neighbors,
            5 fixed probability.

This module deliberately contains no Isaac Sim imports, so the parser/runtime
can be unit-tested with ordinary PyTorch.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import shlex

import torch


MODULE_NAMES = {
    0: "exploration",
    1: "stop",
    2: "phototaxis",
    3: "anti-phototaxis",
    4: "attraction",
    5: "repulsion",
}

CONDITION_NAMES = {
    0: "black_floor",
    1: "gray_floor",
    2: "white_floor",
    3: "neighbors_count",
    4: "inverted_neighbors_count",
    5: "fixed_probability",
}


@dataclass(frozen=True)
class Transition:
    destination: int
    condition_id: int
    p: float
    w: float | None = None


@dataclass(frozen=True)
class State:
    index: int
    module_id: int
    parameter: float | None
    transitions: tuple[Transition, ...]

    @property
    def module_name(self) -> str:
        return MODULE_NAMES[self.module_id]


@dataclass(frozen=True)
class ChocolateFSM:
    states: tuple[State, ...]
    source: str

    @property
    def num_states(self) -> int:
        return len(self.states)

    def describe(self) -> str:
        rows = []
        for state in self.states:
            parameter = ""
            if state.module_id == 0:
                parameter = f" rwm={int(state.parameter or 0)}"
            elif state.module_id == 4:
                parameter = f" att={float(state.parameter):g}"
            elif state.module_id == 5:
                parameter = f" rep={float(state.parameter):g}"
            rows.append(
                f"S{state.index}: {state.module_name}{parameter}, "
                f"{len(state.transitions)} transition(s)"
            )
            for transition in state.transitions:
                extra = "" if transition.w is None else f", w={transition.w:g}"
                rows.append(
                    f"  -> S{transition.destination}: "
                    f"{CONDITION_NAMES[transition.condition_id]}"
                    f"(p={transition.p:g}{extra})"
                )
        return "\n".join(rows)


def _token_map(text: str) -> dict[str, str]:
    tokens = shlex.split(text.strip())
    if len(tokens) % 2:
        raise ValueError("FSM line must contain --key value pairs")
    parsed: dict[str, str] = {}
    for key, value in zip(tokens[0::2], tokens[1::2]):
        if not key.startswith("--"):
            raise ValueError(f"Expected an option name, got {key!r}")
        clean = key[2:]
        if clean in parsed:
            raise ValueError(f"Duplicate FSM option --{clean}")
        parsed[clean] = value
    return parsed


def parse_fsm(text: str) -> ChocolateFSM:
    values = _token_map(text)
    try:
        num_states = int(values["nstates"])
    except KeyError as exc:
        raise ValueError("Missing --nstates") from exc
    if not 1 <= num_states <= 64:
        raise ValueError(f"Invalid number of states: {num_states}")

    states: list[State] = []
    for state_index in range(num_states):
        module_key = f"s{state_index}"
        if module_key not in values:
            raise ValueError(f"Missing --{module_key}")
        module_id = int(values[module_key])
        if module_id not in MODULE_NAMES:
            raise ValueError(f"Unsupported Mercator module ID {module_id}")

        parameter: float | None = None
        if module_id == 0:
            key = f"rwm{state_index}"
            if key not in values:
                raise ValueError(f"Exploration state S{state_index} lacks --{key}")
            parameter = float(int(float(values[key])))
        elif module_id == 4:
            key = f"att{state_index}"
            if key not in values:
                raise ValueError(f"Attraction state S{state_index} lacks --{key}")
            parameter = float(values[key])
        elif module_id == 5:
            key = f"rep{state_index}"
            if key not in values:
                raise ValueError(f"Repulsion state S{state_index} lacks --{key}")
            parameter = float(values[key])

        transition_count = int(values.get(f"n{state_index}", "0"))
        transitions: list[Transition] = []
        possible_destinations = [i for i in range(num_states) if i != state_index]
        for transition_index in range(transition_count):
            prefix = f"{state_index}x{transition_index}"
            destination_option = int(values[f"n{prefix}"])
            if not 0 <= destination_option < len(possible_destinations):
                raise ValueError(
                    f"S{state_index} transition {transition_index}: destination option "
                    f"{destination_option} outside [0, {len(possible_destinations) - 1}]"
                )
            destination = possible_destinations[destination_option]
            condition_id = int(values[f"c{prefix}"])
            if condition_id not in CONDITION_NAMES:
                raise ValueError(
                    f"S{state_index} transition {transition_index}: unsupported "
                    f"condition ID {condition_id}"
                )
            p = float(values[f"p{prefix}"])
            w_key = f"w{prefix}"
            w = float(values[w_key]) if w_key in values else None
            if condition_id in (3, 4) and w is None:
                raise ValueError(
                    f"S{state_index} transition {transition_index}: condition "
                    f"{condition_id} requires --{w_key}"
                )
            transitions.append(Transition(destination, condition_id, p, w))

        states.append(State(state_index, module_id, parameter, tuple(transitions)))

    return ChocolateFSM(tuple(states), text.strip())


def load_fsm_file(path: str | Path) -> list[ChocolateFSM]:
    path = Path(path)
    lines = [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    if not lines:
        raise ValueError(f"No FSM found in {path}")
    return [parse_fsm(line) for line in lines]


@dataclass(frozen=True)
class FSMStep:
    module_ids: torch.Tensor
    state_ids: torch.Tensor
    exploration_tau: torch.Tensor
    attraction_alpha: torch.Tensor
    repulsion_alpha: torch.Tensor
    state_entry_mask: torch.Tensor
    transitioned: torch.Tensor


class BatchedChocolateRuntime:
    """Execute one identical FSM for an ``[environment, robot]`` batch."""

    def __init__(
        self,
        fsm: ChocolateFSM,
        num_envs: int,
        num_agents: int,
        device: torch.device | str,
    ) -> None:
        self.fsm = fsm
        self.device = torch.device(device)
        shape = (int(num_envs), int(num_agents))
        self.state_ids = torch.zeros(shape, dtype=torch.long, device=self.device)
        self.entering = torch.ones(shape, dtype=torch.bool, device=self.device)

    def reset(self, env_mask: torch.Tensor | None = None) -> None:
        if env_mask is None:
            self.state_ids.zero_()
            self.entering.fill_(True)
            return
        mask = env_mask.to(device=self.device, dtype=torch.bool)
        self.state_ids[mask] = 0
        self.entering[mask] = True

    @staticmethod
    def _condition_probability(
        transition: Transition,
        ground: torch.Tensor,
        neighbor_count: torch.Tensor,
    ) -> torch.Tensor:
        condition_id = transition.condition_id
        p = float(transition.p)
        if condition_id == 0:
            return (ground <= 0.10).to(torch.float32) * p
        if condition_id == 1:
            # C++ uses grayscale values in the gray interval. The analytical
            # arena emits exact category values 0.0, 0.5 and 1.0.
            gray = (ground > 0.10) & (ground < (160.0 / 255.0))
            return gray.to(torch.float32) * p
        if condition_id == 2:
            return (ground >= (220.0 / 255.0)).to(torch.float32) * p
        if condition_id in (3, 4):
            assert transition.w is not None
            xi = int(p)  # C++ stores this field as UInt32.
            logistic = torch.sigmoid(
                float(transition.w) * (neighbor_count - float(xi))
            )
            return logistic if condition_id == 3 else (1.0 - logistic)
        if condition_id == 5:
            return torch.full_like(ground, p, dtype=torch.float32)
        raise RuntimeError(f"Unsupported condition ID {condition_id}")

    def step(
        self,
        ground: torch.Tensor,
        neighbor_count: torch.Tensor,
    ) -> FSMStep:
        expected = self.state_ids.shape
        if tuple(ground.shape) != expected or tuple(neighbor_count.shape) != expected:
            raise ValueError(
                f"ground and neighbor_count must have shape {tuple(expected)}"
            )
        ground = ground.to(device=self.device, dtype=torch.float32)
        neighbor_count = neighbor_count.to(device=self.device, dtype=torch.float32)

        state_before = self.state_ids.clone()
        entry_before = self.entering.clone()
        modules = torch.empty_like(state_before)
        exploration_tau = torch.zeros_like(state_before)
        attraction_alpha = torch.ones(expected, dtype=torch.float32, device=self.device)
        repulsion_alpha = torch.ones(expected, dtype=torch.float32, device=self.device)

        for state in self.fsm.states:
            active = state_before == state.index
            modules.masked_fill_(active, state.module_id)
            if state.module_id == 0:
                exploration_tau.masked_fill_(active, int(state.parameter or 0))
            elif state.module_id == 4:
                attraction_alpha.masked_fill_(active, float(state.parameter))
            elif state.module_id == 5:
                repulsion_alpha.masked_fill_(active, float(state.parameter))

        transitioned = torch.zeros_like(self.entering)
        next_states = state_before.clone()

        # AutoMoDe does not evaluate outgoing conditions on the entry tick. On
        # later ticks, it randomizes their order and takes the first true one.
        for state in self.fsm.states:
            active = (state_before == state.index) & ~entry_before
            if not state.transitions or not bool(active.any()):
                continue
            success_masks = []
            priorities = []
            for transition in state.transitions:
                probability = self._condition_probability(
                    transition, ground, neighbor_count
                ).clamp(0.0, 1.0)
                success_masks.append(torch.rand(expected, device=self.device) < probability)
                priorities.append(torch.rand(expected, device=self.device))
            successes = torch.stack(success_masks, dim=-1) & active.unsqueeze(-1)
            priority = torch.stack(priorities, dim=-1)
            priority = torch.where(
                successes,
                priority,
                torch.full_like(priority, float("inf")),
            )
            chosen = priority.argmin(dim=-1)
            any_success = successes.any(dim=-1)
            destinations = torch.tensor(
                [transition.destination for transition in state.transitions],
                dtype=torch.long,
                device=self.device,
            )
            selected_destination = destinations[chosen]
            next_states = torch.where(any_success, selected_destination, next_states)
            transitioned |= any_success

        self.state_ids.copy_(next_states)
        self.entering.copy_(transitioned)

        return FSMStep(
            module_ids=modules,
            state_ids=state_before,
            exploration_tau=exploration_tau,
            attraction_alpha=attraction_alpha,
            repulsion_alpha=repulsion_alpha,
            state_entry_mask=entry_before,
            transitioned=transitioned,
        )
