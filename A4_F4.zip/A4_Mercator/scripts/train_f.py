#!/usr/bin/env python3
"""Run ``train_2.py`` with the selected isolated POCA implementation.

By default, this entry point uses the optimized 5D POCA implementation from
``poca_alt/poca_opti``. Passing ``--6d`` selects the experimental implementation
from ``poca_alt/poca_opti_6d`` instead.

Apart from backend selection, execution is intentionally identical to
``train_p3.py``: the environment, configuration loader, mission logic, CLI
options, vectorized recurrent loss, checkpoint handling and training loop all
come directly from ``train_2.py``.
"""

from __future__ import annotations

import importlib
import os
from pathlib import Path
import sys
from types import ModuleType

# Keep the same lightweight tensor-only startup contract as train_2.py.
os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")

_SCRIPT_DIR = Path(__file__).resolve().parent
_ROOT = _SCRIPT_DIR.parent
if not (_ROOT / "source" / "SwarmACB_isaac").is_dir():
    raise RuntimeError(
        "train_f.py must be placed in the project's scripts/ directory"
    )


def _consume_6d_flag(argv: list[str]) -> bool:
    """Remove the train_f-only ``--6d`` flag before train_2 parses arguments."""
    use_6d = False
    filtered = [argv[0]]
    for argument in argv[1:]:
        if argument == "--6d":
            use_6d = True
        else:
            filtered.append(argument)
    argv[:] = filtered
    return use_6d


_USE_6D = _consume_6d_flag(sys.argv)
_BACKEND_NAME = "poca_opti_6d" if _USE_6D else "poca_opti"
_BACKEND_DIR = _ROOT / "poca_alt" / _BACKEND_NAME
if not (_BACKEND_DIR / "poca_trainer.py").is_file():
    raise RuntimeError(
        f"Missing POCA backend: {_BACKEND_DIR}. "
        "Expected poca_alt/poca_opti and poca_alt/poca_opti_6d at project root."
    )

# The project root is needed for importing the isolated root-level package.
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# Import the unchanged fast tensor training script. Since this file lives beside
# train_2.py, Python resolves the sibling module without duplicating its code.
import train_2 as _train2


def _load_backend(name: str) -> ModuleType:
    return importlib.import_module(f"poca_alt.{name}.poca_trainer")


_backend = _load_backend(_BACKEND_NAME)
_OptimizedPOCATrainer = _backend.POCATrainer
_optimized_policy_loss = _backend.trust_region_policy_loss
_optimized_value_loss = _backend.trust_region_value_loss


class FastPOCATrainer(_OptimizedPOCATrainer):
    """Selected trainer plus train_2.py's validated batched LSTM loss."""

    # Reuse the exact vectorized recurrent-loss implementation from train_2.py.
    # A function keeps the globals of the module where it was defined, so the
    # trust-region globals below are also rebound to the selected implementation.
    _compute_recurrent_losses = _train2.FastPOCATrainer._compute_recurrent_losses


# Rebind only the POCA components selected by train_2.main(). Everything else in
# train_2.py continues to use the original project modules and functions.
_train2.POCATrainer = _OptimizedPOCATrainer
_train2.FastPOCATrainer = FastPOCATrainer
_train2.trust_region_policy_loss = _optimized_policy_loss
_train2.trust_region_value_loss = _optimized_value_loss


def main() -> None:
    critic_label = "6D-capable" if _USE_6D else "5D"
    print(
        f"[train_f] Selected {critic_label} POCA backend from {_BACKEND_DIR}"
    )
    _train2.main()


if __name__ == "__main__":
    main()
