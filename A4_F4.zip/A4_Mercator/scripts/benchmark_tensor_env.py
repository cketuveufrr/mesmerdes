#!/usr/bin/env python3
"""Measure standalone Mercator environment throughput on the target machine."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys
import time

os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source" / "SwarmACB_isaac"))

import torch

from SwarmACB_isaac.tasks.direct.agents.config_loader import load_config
from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
    MercatorTensorEnv,
    MercatorTensorEnvCfg,
)


def sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/AAC_mercator_cyclamen.yaml")
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--num-envs", type=int, nargs="+", default=[32, 64, 128, 256])
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--module", type=int, default=2, choices=range(6))
    parser.add_argument("--analytical-substeps", type=int, default=None)
    args = parser.parse_args()

    _, variant, _, overrides = load_config(args.config)
    device = torch.device(args.device)
    print(
        "num_envs agents decisions/s agent-steps/s ms/decision "
        "substeps module"
    )
    for num_envs in args.num_envs:
        cfg = MercatorTensorEnvCfg(variant=variant, device=str(device))
        cfg.apply_overrides(overrides)
        cfg.scene.num_envs = int(num_envs)
        if args.analytical_substeps is not None:
            cfg.analytical_substeps = int(args.analytical_substeps)
        env = MercatorTensorEnv(cfg)
        actions = torch.full(
            (num_envs, cfg.num_agents, 1),
            int(args.module),
            dtype=torch.long,
            device=device,
        )
        try:
            with torch.inference_mode():
                for _ in range(args.warmup):
                    env.step_tensor(actions)
                sync(device)
                start = time.perf_counter()
                for _ in range(args.steps):
                    env.step_tensor(actions)
                sync(device)
                elapsed = time.perf_counter() - start
            decisions_per_s = args.steps / elapsed
            agent_steps_per_s = decisions_per_s * num_envs * cfg.num_agents
            print(
                f"{num_envs:8d} {cfg.num_agents:6d} {decisions_per_s:11.2f} "
                f"{agent_steps_per_s:13.0f} {1000.0/decisions_per_s:11.3f} "
                f"{cfg.analytical_substeps:8d} {args.module:6d}"
            )
        finally:
            env.close()
            del env
            if device.type == "cuda":
                torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
