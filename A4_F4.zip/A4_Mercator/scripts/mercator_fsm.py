#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Unified Mercator Chocolate FSM observation and scoring tool.

Examples::

    python scripts/mercator_fsm.py --mission AAC --observe --fsm-index 1
    python scripts/mercator_fsm.py --mission AAC2 --score --all-fsms --episodes 100
    python scripts/mercator_fsm.py --mission FOR --observe --fsm-index 3
    python scripts/mercator_fsm.py --mission FOR2 --score --all-fsms --episodes 100
    python scripts/mercator_fsm.py --mission GRID --score --fsm-index 1
    python scripts/mercator_fsm.py --mission GRID2 --observe --fsm-index 1

``--mission`` selects the environment, the matching real Chocolate FSM file,
mission-specific HUD fields, scoring metrics, camera, and output directory.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
import importlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import sys
import traceback


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))


@dataclass(frozen=True)
class MissionSpec:
    key: str
    title: str
    kind: str
    task_id: str
    config: str
    fsm_file: str
    output_dir: str
    output_prefix: str
    camera_height: float
    camera_y: float


MISSION_SPECS = {
    "AAC": MissionSpec(
        key="AAC",
        title="Aggregation Experiment 1",
        kind="aggregation",
        task_id="SwarmACB-MercatorAggregation-v0",
        config="configs/mercator/AAC_mercator_cyclamen.yaml",
        fsm_file="configs/mercator/fsms/fsm_mercator_aggregation_experiment1.txt",
        output_dir="results/mercator_fsm",
        output_prefix="mercator_aggregation_fsm",
        camera_height=13.0,
        camera_y=-8.0,
    ),
    "AAC2": MissionSpec(
        key="AAC2",
        title="Aggregation Experiment 2",
        kind="aggregation",
        task_id="SwarmACB-MercatorAggregation2-v0",
        config="configs/mercator/AAC2_mercator_cyclamen.yaml",
        fsm_file="configs/mercator/fsms/fsm_mercator_aggregation2_experiment2.txt",
        output_dir="results/mercator_aggregation2_fsm",
        output_prefix="mercator_aggregation2_fsm",
        camera_height=4.2,
        camera_y=-3.0,
    ),
    "FOR": MissionSpec(
        key="FOR",
        title="Foraging Experiment 1",
        kind="foraging",
        task_id="SwarmACB-MercatorForaging-v0",
        config="configs/mercator/FOR_mercator_cyclamen.yaml",
        fsm_file="configs/mercator/fsms/fsm_mercator_foraging_experiment1.txt",
        output_dir="results/mercator_foraging_fsm",
        output_prefix="mercator_foraging_fsm",
        camera_height=13.0,
        camera_y=-8.0,
    ),
    "FOR2": MissionSpec(
        key="FOR2",
        title="Foraging Experiment 2",
        kind="foraging",
        task_id="SwarmACB-MercatorForaging2-v0",
        config="configs/mercator/FOR2_mercator_cyclamen.yaml",
        fsm_file="configs/mercator/fsms/fsm_mercator_foraging2_experiment2.txt",
        output_dir="results/mercator_foraging2_fsm",
        output_prefix="mercator_foraging2_fsm",
        camera_height=4.2,
        camera_y=-3.0,
    ),
    "GRID": MissionSpec(
        key="GRID",
        title="Grid Exploration Experiment 1",
        kind="grid",
        task_id="SwarmACB-MercatorGridExploration-v0",
        config="configs/mercator/GRID_mercator_cyclamen.yaml",
        fsm_file="configs/mercator/fsms/fsm_mercator_grid_exploration_experiment1.txt",
        output_dir="results/mercator_grid_exploration_fsm",
        output_prefix="mercator_grid_exploration_fsm",
        camera_height=13.0,
        camera_y=-8.0,
    ),
    "GRID2": MissionSpec(
        key="GRID2",
        title="Grid Exploration Experiment 2",
        kind="grid",
        task_id="SwarmACB-MercatorGridExploration2-v0",
        config="configs/mercator/GRID2_mercator_cyclamen.yaml",
        fsm_file="configs/mercator/fsms/fsm_mercator_grid_exploration2_experiment2.txt",
        output_dir="results/mercator_grid_exploration2_fsm",
        output_prefix="mercator_grid_exploration2_fsm",
        camera_height=4.2,
        camera_y=-3.0,
    ),
}

MISSION_ALIASES = {
    "AAC": "AAC",
    "AAC1": "AAC",
    "AGG": "AAC",
    "AGG1": "AAC",
    "AAC2": "AAC2",
    "AGG2": "AAC2",
    "FOR": "FOR",
    "FOR1": "FOR",
    "FORAGING": "FOR",
    "FORAGING1": "FOR",
    "FOR2": "FOR2",
    "FORAGING2": "FOR2",
    "GRID": "GRID",
    "GEX": "GRID",
    "GRIDEXPLORATION": "GRID",
    "GRID_EXPLORATION": "GRID",
    "GRID2": "GRID2",
    "GEX2": "GRID2",
    "GRIDEXPLORATION2": "GRID2",
    "GRID_EXPLORATION2": "GRID2",
}


def parse_mission(value: str) -> str:
    normalized = value.strip().upper().replace("-", "_").replace(" ", "_")
    compact = normalized.replace("_", "")
    if normalized in MISSION_ALIASES:
        return MISSION_ALIASES[normalized]
    if compact in MISSION_ALIASES:
        return MISSION_ALIASES[compact]
    raise argparse.ArgumentTypeError(
        f"unknown Mercator mission {value!r}; choose AAC, AAC2, FOR, FOR2, GRID, or GRID2"
    )


parser = argparse.ArgumentParser(
    description="Observe or score real AutoMoDe/Chocolate FSMs on any Mercator mission"
)
parser.add_argument(
    "--mission",
    required=True,
    type=parse_mission,
    metavar="{AAC,AAC2,FOR,FOR2,GRID,GRID2}",
    help="Mission selector; aliases AAC1, AGG2, FORAGING1, FORAGING2, GEX and GEX2 are accepted",
)
mode = parser.add_mutually_exclusive_group(required=True)
mode.add_argument("--observe", action="store_true", help="Open the Isaac Sim viewer")
mode.add_argument("--score", action="store_true", help="Evaluate headlessly and write reports")
parser.add_argument("--config", default=None, help="Override the mission YAML")
parser.add_argument("--fsm-file", default=None, help="Override the mission FSM file")
selection = parser.add_mutually_exclusive_group()
selection.add_argument("--fsm-index", type=int, default=1, help="1-based FSM index")
selection.add_argument("--all-fsms", action="store_true", help="Score every FSM")
parser.add_argument("--seed", type=int, default=0)
parser.add_argument("--device", default=None, help="Isaac device override, e.g. cuda:0")

# Observation controls.
parser.add_argument("--color-by", choices=("state", "module"), default="state")
parser.add_argument(
    "--num-episodes", type=int, default=0,
    help="Observation only: 0 runs until the window is closed",
)
parser.add_argument(
    "--headless", action="store_true",
    help="Observation diagnostic without a window; scoring is always headless",
)
parser.add_argument("--camera-height", type=float, default=None)
parser.add_argument("--camera-y", type=float, default=None)
parser.add_argument("--width", type=int, default=1600)
parser.add_argument("--height", type=int, default=900)

# Scoring controls.
parser.add_argument("--episodes", type=int, default=20, help="Episodes per FSM")
parser.add_argument("--num-envs", type=int, default=20, help="Parallel environments")
parser.add_argument("--output-dir", default=None, help="Override the report directory")
parser.add_argument(
    "--print-every", type=int, default=100,
    help="Control steps between progress lines; <=0 disables them",
)
args, unknown_args = parser.parse_known_args()

SPEC = MISSION_SPECS[args.mission]
if args.observe and args.all_fsms:
    parser.error("--all-fsms is available only with --score")
if args.score and args.headless:
    print("Note: --score is already headless; --headless is redundant.")

headless = bool(args.score or args.headless)
if not headless:
    for name in (
        "HEADLESS",
        "ISAACLAB_HEADLESS",
        "OMNI_KIT_HEADLESS",
        "DISABLE_VIEWPORT_UPDATES",
    ):
        os.environ.pop(name, None)

# SimulationApp must exist before Isaac Lab, Gym task, omni, pxr, or torch task imports.
from isaacsim import SimulationApp  # noqa: E402

simulation_app = SimulationApp(
    {
        "headless": headless,
        "multi_gpu": False,
        "width": int(args.width),
        "height": int(args.height),
    }
)

import gymnasium as gym  # noqa: E402
import numpy as np  # noqa: E402
import omni.kit.app  # noqa: E402
import omni.timeline  # noqa: E402
import torch  # noqa: E402
from pxr import Gf, Sdf, UsdShade  # noqa: E402

import SwarmACB_isaac.tasks  # noqa: E402,F401
from SwarmACB_isaac.tasks.direct.agents.config_loader import load_config  # noqa: E402
from mercator_chocolate_fsm import (  # noqa: E402
    BatchedChocolateRuntime,
    ChocolateFSM,
    MODULE_NAMES,
    load_fsm_file,
)


MODULE_COLORS = {
    0: (0.20, 0.55, 1.00),
    1: (0.45, 0.45, 0.45),
    2: (1.00, 0.85, 0.10),
    3: (0.65, 0.20, 0.90),
    4: (0.15, 0.80, 0.30),
    5: (1.00, 0.20, 0.15),
}
STATE_COLORS = {
    0: (0.15, 0.55, 0.95),
    1: (0.95, 0.45, 0.12),
    2: (0.20, 0.75, 0.35),
    3: (0.72, 0.25, 0.85),
    4: (0.85, 0.75, 0.15),
    5: (0.20, 0.75, 0.75),
}


def resolve_path(path: str) -> Path:
    candidate = Path(path)
    return candidate.resolve() if candidate.is_absolute() else (ROOT / candidate).resolve()


def resolve_env_cfg(task_id: str):
    spec = gym.spec(task_id)
    entry = spec.kwargs.get("env_cfg_entry_point")
    if entry is None:
        raise ValueError(f"Task {task_id!r} has no env_cfg_entry_point")
    module_path, class_name = entry.rsplit(":", 1)
    return getattr(importlib.import_module(module_path), class_name)()


def _coerce_override(current, value):
    if isinstance(current, tuple) and isinstance(value, list):
        return tuple(
            tuple(item) if isinstance(item, list) else item
            for item in value
        )
    return value


def apply_env_overrides(env_cfg, overrides: dict, num_envs: int, visualize: bool) -> None:
    missing = []
    for key, value in overrides.items():
        if key in ("task", "num_envs"):
            continue
        if not hasattr(env_cfg, key):
            missing.append(key)
            continue
        setattr(env_cfg, key, _coerce_override(getattr(env_cfg, key), value))
    if missing:
        raise RuntimeError(
            f"Unknown {SPEC.key} Mercator environment keys: " + ", ".join(missing)
        )
    env_cfg.scene.num_envs = int(num_envs)
    env_cfg.seed = int(args.seed)
    env_cfg.enable_visualization = bool(visualize)
    if visualize:
        env_cfg.sim.render_interval = 1
    if args.device is not None:
        env_cfg.sim.device = str(args.device)


def load_mission() -> tuple[Path, Path, list[ChocolateFSM], object, dict]:
    config_path = resolve_path(args.config or SPEC.config)
    fsm_path = resolve_path(args.fsm_file or SPEC.fsm_file)
    fsms = load_fsm_file(fsm_path)
    _, variant, _, env_overrides = load_config(config_path)
    task_id = env_overrides.get("task", SPEC.task_id)
    if task_id != SPEC.task_id:
        raise ValueError(
            f"Mission {SPEC.key} requires {SPEC.task_id}; config selected {task_id!r}"
        )
    env_cfg = resolve_env_cfg(task_id)
    if hasattr(env_cfg, "update_variant"):
        env_cfg.update_variant(variant)
    return config_path, fsm_path, fsms, env_cfg, env_overrides


def reseed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def force_viewport_extensions() -> None:
    manager = omni.kit.app.get_app().get_extension_manager()
    for extension in (
        "omni.kit.window.viewport",
        "omni.kit.viewport.window",
        "omni.kit.viewport.utility",
    ):
        try:
            manager.set_extension_enabled_immediate(extension, True)
        except Exception:
            pass


def prepare_robot_color_inputs(base):
    inputs = []
    safe_key = SPEC.key.lower()
    for index, visual in enumerate(getattr(base, "_robot_visual_xforms", [])):
        prim = visual.GetPrim()
        stage = prim.GetStage()
        material_path = f"/World/FSMRobotMaterials/{safe_key}_Robot_{index:03d}"
        material = UsdShade.Material.Define(stage, material_path)
        shader = UsdShade.Shader.Define(stage, material_path + "/Shader")
        shader.CreateIdAttr("UsdPreviewSurface")
        color_input = shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f)
        shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.45)
        shader.CreateOutput("surface", Sdf.ValueTypeNames.Token)
        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
        UsdShade.MaterialBindingAPI.Apply(prim).Bind(
            material, UsdShade.Tokens.strongerThanDescendants
        )
        inputs.append(color_input)
    return inputs


def update_robot_colors(color_inputs, ids: list[int], palette: dict, previous=None):
    for index, value in enumerate(ids):
        if previous is None or previous[index] != value:
            color_inputs[index].Set(Gf.Vec3f(*palette[value]))
    return ids


class StatusHud:
    def __init__(self) -> None:
        self.label = None
        self.window = None
        if headless:
            return
        try:
            import omni.ui as ui

            self.window = ui.Window(f"Mercator {SPEC.key} FSM", width=520, height=270)
            with self.window.frame:
                with ui.VStack(spacing=5):
                    ui.Label(f"{SPEC.title} / real Chocolate FSM", height=24)
                    self.label = ui.Label("", word_wrap=True)
        except Exception as exc:
            print(f"HUD unavailable: {exc}")

    def set(self, text: str) -> None:
        if self.label is not None:
            self.label.text = text


def _mission_observe_lines(base, done: bool, episode_score: float, reward: float) -> list[str]:
    if SPEC.kind == "aggregation":
        if done:
            n_black = int(base.completed_n_black[0].item())
            n_white = int(base.completed_n_white[0].item())
        else:
            n_black = int(base.last_n_black[0].item())
            n_white = int(base.last_n_white[0].item())
        return [f"N_black={n_black}  N_white={n_white}  score={episode_score:.1f}"]

    if SPEC.kind == "foraging":
        if done:
            deliveries = int(base.completed_deliveries[0].item())
            pickups = int(base.completed_pickups[0].item())
            carrying = int(base.completed_carrying[0].item())
        else:
            deliveries = int(round(episode_score))
            pickups = int(base._episode_pickups[0].item())
            carrying = int(base.last_carrying[0].item())
        return [
            f"deliveries={deliveries} (+{int(round(reward))})  pickups={pickups}  carrying={carrying}",
            f"on food={int(base.last_in_food[0].item())}  in nest={int(base.last_in_nest[0].item())}",
        ]

    if done:
        mean_age = float(base.completed_grid_mean_age[0].item())
        max_age = float(base.completed_grid_max_age[0].item())
        visited = int(base.completed_grid_visited_cells[0].item())
        coverage = float(base.completed_grid_coverage[0].item())
    else:
        mean_age = float(base.last_grid_mean_age[0].item())
        max_age = float(base.last_grid_max_age[0].item())
        visited = int(base.last_grid_visited_cells[0].item())
        coverage = float(base.last_grid_coverage[0].item())
    return [
        f"score={episode_score:.2f}  mean cell age={mean_age:.2f}  max age={max_age:.0f}",
        f"visited cells this tick={visited}  cumulative coverage={100.0 * coverage:.1f}%",
    ]


def _mission_episode_message(base, episode_number: int, score: float, transitions: int) -> str:
    if SPEC.kind == "aggregation":
        return (
            f"[Episode {episode_number:02d}] score={score:.1f}, "
            f"final_black={int(base.completed_n_black[0].item())}, "
            f"final_white={int(base.completed_n_white[0].item())}, "
            f"transitions={transitions}"
        )
    if SPEC.kind == "foraging":
        deliveries = float(base.completed_deliveries[0].item())
        pickups = float(base.completed_pickups[0].item())
        efficiency = deliveries / pickups if pickups > 0.0 else 0.0
        return (
            f"[Episode {episode_number:02d}] deliveries={deliveries:.0f}, "
            f"pickups={pickups:.0f}, efficiency={efficiency:.3f}, "
            f"carrying_at_end={base.completed_carrying[0].item():.0f}, "
            f"transitions={transitions}"
        )
    return (
        f"[Episode {episode_number:02d}] score={score:.2f}, "
        f"final_mean_age={base.completed_grid_mean_age[0].item():.2f}, "
        f"final_max_age={base.completed_grid_max_age[0].item():.0f}, "
        f"coverage={100.0 * base.completed_grid_coverage[0].item():.1f}%, "
        f"transitions={transitions}"
    )


def observe() -> None:
    config_path, fsm_path, fsms, env_cfg, env_overrides = load_mission()
    if not 1 <= args.fsm_index <= len(fsms):
        raise ValueError(f"--fsm-index must be between 1 and {len(fsms)}")
    fsm = fsms[args.fsm_index - 1]
    apply_env_overrides(env_cfg, env_overrides, num_envs=1, visualize=True)
    force_viewport_extensions()

    print(f"\n========== MERCATOR {SPEC.key} / OBSERVE ==========")
    print(f"Mission   : {SPEC.title}")
    print(f"Profile   : {env_cfg.robot_profile}")
    print(f"Config    : {config_path}")
    print(f"FSM file  : {fsm_path}")
    print(f"FSM index : {args.fsm_index}/{len(fsms)}")
    print(f"Color by  : {args.color_by}")
    print(fsm.describe())
    print("===================================================\n")

    env = gym.make(SPEC.task_id, cfg=env_cfg, render_mode="human")
    base = env.unwrapped
    agents = base.cfg.possible_agents
    num_agents = len(agents)
    device = base.device
    hud = StatusHud()

    try:
        env.reset(seed=args.seed)
        base._update_visual_markers()
        if len(getattr(base, "_robot_visual_xforms", [])) != num_agents:
            raise RuntimeError(f"{SPEC.key} Mercator robot visuals were not created")
        color_inputs = prepare_robot_color_inputs(base)
        camera_y = SPEC.camera_y if args.camera_y is None else float(args.camera_y)
        camera_height = (
            SPEC.camera_height if args.camera_height is None else float(args.camera_height)
        )
        base.sim.set_camera_view(
            eye=[0.0, camera_y, camera_height], target=[0.0, 0.0, 0.0]
        )
        for _ in range(30):
            try:
                base.sim.render()
            except Exception:
                pass
            simulation_app.update()

        timeline = omni.timeline.get_timeline_interface()
        if not timeline.is_playing():
            timeline.play()

        runtime = BatchedChocolateRuntime(fsm, 1, num_agents, device)
        episode_score = 0.0
        episode_number = 1
        control_step = 0
        total_transitions = 0
        previous_colors = None

        while simulation_app.is_running():
            if args.num_episodes > 0 and episode_number > args.num_episodes:
                break

            with torch.no_grad():
                ground = base._ground_scalar_at(base._ground_sensor_points())
                _, neighbor_count, _, _ = base.sensors.compute_neighbors(
                    base.agent_pos, base.agent_yaw
                )
                controller_step = runtime.step(ground, neighbor_count)
                base.set_fsm_behavior_parameters(
                    exploration_tau=controller_step.exploration_tau,
                    attraction_alpha=controller_step.attraction_alpha,
                    repulsion_alpha=controller_step.repulsion_alpha,
                    state_entry_mask=controller_step.state_entry_mask,
                )
                if args.color_by == "state":
                    color_ids = controller_step.state_ids[0].detach().cpu().tolist()
                    palette = STATE_COLORS
                else:
                    color_ids = controller_step.module_ids[0].detach().cpu().tolist()
                    palette = MODULE_COLORS
                previous_colors = update_robot_colors(
                    color_inputs, color_ids, palette, previous_colors
                )
                actions = controller_step.module_ids.unsqueeze(-1)
                action_dict = {
                    agent: actions[:, index] for index, agent in enumerate(agents)
                }
                _, rewards, terminated, truncated, _ = env.step(action_dict)

            try:
                base.sim.render()
            except Exception:
                pass
            simulation_app.update()

            reward = float(rewards[agents[0]][0].item())
            done = bool((terminated[agents[0]] | truncated[agents[0]])[0].item())
            episode_score += reward
            control_step += 1
            total_transitions += int(controller_step.transitioned[0].sum().item())
            state_counts = torch.bincount(
                controller_step.state_ids[0], minlength=fsm.num_states
            ).detach().cpu().tolist()
            module_counts = torch.bincount(
                controller_step.module_ids[0], minlength=6
            ).detach().cpu().tolist()
            state_text = " ".join(
                f"S{index}:{count}" for index, count in enumerate(state_counts)
            )
            module_text = " ".join(
                f"{MODULE_NAMES[index]}:{count}"
                for index, count in enumerate(module_counts)
                if count
            )
            metric_lines = _mission_observe_lines(base, done, episode_score, reward)
            hud.set(
                "\n".join(
                    [
                        f"{SPEC.key} | FSM {args.fsm_index} | episode {episode_number} | "
                        f"t={control_step * float(base.cfg.sim.dt):.1f}s",
                        *metric_lines,
                        f"States: {state_text}",
                        f"Modules: {module_text}",
                        f"Transitions: {total_transitions}",
                    ]
                )
            )

            if args.print_every > 0 and control_step % args.print_every == 0:
                print(
                    f"episode={episode_number:02d} step={control_step:04d} "
                    + " | ".join(metric_lines)
                    + f" | states=[{state_text}] transitions={total_transitions}"
                )

            if done:
                print(
                    _mission_episode_message(
                        base, episode_number, episode_score, total_transitions
                    )
                )
                runtime.reset(torch.tensor([True], device=device))
                episode_score = 0.0
                control_step = 0
                total_transitions = 0
                previous_colors = None
                episode_number += 1
    finally:
        env.close()


def state_histogram_add(target: torch.Tensor, state_ids: torch.Tensor) -> None:
    target.scatter_add_(1, state_ids, torch.ones_like(state_ids, dtype=target.dtype))


def _init_mission_accumulators(num_envs: int, device) -> dict[str, torch.Tensor]:
    zeros = lambda: torch.zeros(num_envs, dtype=torch.float32, device=device)
    if SPEC.kind == "aggregation":
        return {"max_black": zeros()}
    if SPEC.kind == "foraging":
        return {
            "carrying_sum": zeros(),
            "food_sum": zeros(),
            "nest_sum": zeros(),
            "max_carrying": zeros(),
            "max_step_deliveries": zeros(),
        }
    return {
        "mean_age_sum": zeros(),
        "coverage_sum": zeros(),
        "visited_sum": zeros(),
        "max_age": zeros(),
    }


def _update_mission_accumulators(
    acc: dict[str, torch.Tensor], base, reward: torch.Tensor, done: torch.Tensor
) -> None:
    if SPEC.kind == "aggregation":
        acc["max_black"] = torch.maximum(acc["max_black"], reward)
        return
    if SPEC.kind == "foraging":
        carrying = torch.where(done, base.completed_carrying, base.last_carrying)
        acc["carrying_sum"] += carrying
        acc["food_sum"] += base.last_in_food
        acc["nest_sum"] += base.last_in_nest
        acc["max_carrying"] = torch.maximum(acc["max_carrying"], carrying)
        acc["max_step_deliveries"] = torch.maximum(
            acc["max_step_deliveries"], reward
        )
        return
    mean_age = torch.where(done, base.completed_grid_mean_age, base.last_grid_mean_age)
    coverage = torch.where(done, base.completed_grid_coverage, base.last_grid_coverage)
    visited = torch.where(
        done, base.completed_grid_visited_cells, base.last_grid_visited_cells
    )
    max_age = torch.where(done, base.completed_grid_max_age, base.last_grid_max_age)
    acc["mean_age_sum"] += mean_age
    acc["coverage_sum"] += coverage
    acc["visited_sum"] += visited
    acc["max_age"] = torch.maximum(acc["max_age"], max_age)


def _mission_record(
    base,
    acc: dict[str, torch.Tensor],
    env_id: int,
    score_value: float,
    steps: int,
    num_agents: int,
) -> dict:
    total_robot_steps = max(1, steps * num_agents)
    if SPEC.kind == "aggregation":
        final_black = float(base.completed_n_black[env_id].item())
        final_white = float(base.completed_n_white[env_id].item())
        return {
            "mean_black": score_value / max(1, steps),
            "normalized_score": score_value / total_robot_steps,
            "final_black": final_black,
            "final_white": final_white,
            "max_black": float(acc["max_black"][env_id].item()),
        }

    if SPEC.kind == "foraging":
        completed = float(base.completed_deliveries[env_id].item())
        if abs(score_value - completed) > 1e-4:
            raise RuntimeError(
                f"Foraging reward/objective mismatch in env {env_id}: "
                f"{score_value} != {completed}"
            )
        pickups = float(base.completed_pickups[env_id].item())
        carrying_end = float(base.completed_carrying[env_id].item())
        return {
            "deliveries": completed,
            "pickups": pickups,
            "delivery_efficiency": completed / pickups if pickups > 0.0 else 0.0,
            "deliveries_per_robot": completed / num_agents,
            "deliveries_per_1000_robot_steps": 1000.0 * completed / total_robot_steps,
            "carrying_at_end": carrying_end,
            "undelivered_pickups": max(0.0, pickups - completed),
            "mean_carrying": float(acc["carrying_sum"][env_id].item()) / max(1, steps),
            "mean_on_food": float(acc["food_sum"][env_id].item()) / max(1, steps),
            "mean_in_nest": float(acc["nest_sum"][env_id].item()) / max(1, steps),
            "max_carrying": float(acc["max_carrying"][env_id].item()),
            "max_step_deliveries": float(
                acc["max_step_deliveries"][env_id].item()
            ),
        }

    completed = float(base.completed_group_reward[env_id].item())
    if abs(score_value - completed) > 1e-3:
        raise RuntimeError(
            f"Grid reward/objective mismatch in env {env_id}: "
            f"{score_value} != {completed}"
        )
    visit_events = float(base.completed_grid_visit_events[env_id].item())
    return {
        "mean_grid_age": -score_value / max(1, steps),
        "final_grid_mean_age": float(base.completed_grid_mean_age[env_id].item()),
        "final_grid_max_age": float(base.completed_grid_max_age[env_id].item()),
        "final_grid_coverage": float(base.completed_grid_coverage[env_id].item()),
        "final_step_visited_cells": float(
            base.completed_grid_visited_cells[env_id].item()
        ),
        "visited_cell_events": visit_events,
        "mean_unique_visited_cells_per_step": visit_events / max(1, steps),
        "mean_grid_coverage_over_time": float(
            acc["coverage_sum"][env_id].item()
        ) / max(1, steps),
        "max_grid_age_over_episode": float(acc["max_age"][env_id].item()),
        "normalized_score_per_robot_step": score_value / total_robot_steps,
    }


def _reset_accumulators(acc: dict[str, torch.Tensor], done: torch.Tensor) -> None:
    for value in acc.values():
        value[done] = 0.0


def evaluate_fsm(
    env,
    fsm: ChocolateFSM,
    fsm_index: int,
    episodes_requested: int,
    seed: int,
) -> list[dict]:
    base = env.unwrapped
    agents = base.cfg.possible_agents
    num_envs = int(base.num_envs)
    num_agents = len(agents)
    max_steps = int(base.max_episode_length)
    device = base.device

    reseed(seed)
    env.reset(seed=seed)
    runtime = BatchedChocolateRuntime(fsm, num_envs, num_agents, device)
    episode_score = torch.zeros(num_envs, dtype=torch.float32, device=device)
    episode_steps = torch.zeros(num_envs, dtype=torch.long, device=device)
    transitions = torch.zeros(num_envs, dtype=torch.long, device=device)
    state_counts = torch.zeros(
        num_envs, fsm.num_states, dtype=torch.long, device=device
    )
    mission_acc = _init_mission_accumulators(num_envs, device)

    records: list[dict] = []
    global_step = 0
    while len(records) < episodes_requested and simulation_app.is_running():
        with torch.no_grad():
            ground = base._ground_scalar_at(base._ground_sensor_points())
            _, neighbor_count, _, _ = base.sensors.compute_neighbors(
                base.agent_pos, base.agent_yaw
            )
            controller_step = runtime.step(ground, neighbor_count)
            base.set_fsm_behavior_parameters(
                exploration_tau=controller_step.exploration_tau,
                attraction_alpha=controller_step.attraction_alpha,
                repulsion_alpha=controller_step.repulsion_alpha,
                state_entry_mask=controller_step.state_entry_mask,
            )
            action_tensor = controller_step.module_ids.unsqueeze(-1)
            action_dict = {
                agent: action_tensor[:, index] for index, agent in enumerate(agents)
            }
            _, rewards, terminated, truncated, _ = env.step(action_dict)

        reward = rewards[agents[0]].to(torch.float32)
        done = terminated[agents[0]] | truncated[agents[0]]
        episode_score += reward
        episode_steps += 1
        transitions += controller_step.transitioned.sum(dim=1)
        state_histogram_add(state_counts, controller_step.state_ids)
        _update_mission_accumulators(mission_acc, base, reward, done)
        global_step += 1

        if args.print_every > 0 and global_step % args.print_every == 0:
            metric = (
                f"mean_reward={float(reward.mean().item()):.3f}"
                if SPEC.kind != "grid"
                else f"mean_cell_age={float((-reward).mean().item()):.3f}"
            )
            print(
                f"[{SPEC.key} FSM {fsm_index:02d}] step={global_step:5d}/{max_steps} "
                f"episodes={len(records):4d}/{episodes_requested} {metric}",
                flush=True,
            )

        if bool(done.any()):
            for env_id in done.nonzero(as_tuple=False).flatten().tolist():
                if len(records) >= episodes_requested:
                    break
                steps = int(episode_steps[env_id].item())
                score_value = float(episode_score[env_id].item())
                total_robot_steps = max(1, steps * num_agents)
                row = {
                    "mission": SPEC.key,
                    "robot_profile": str(base.cfg.robot_profile),
                    "fsm_index": fsm_index,
                    "episode": len(records) + 1,
                    "seed": seed,
                    "parallel_env": env_id,
                    "steps": steps,
                    "score": score_value,
                    "transitions_total": int(transitions[env_id].item()),
                    "transitions_per_robot": float(
                        transitions[env_id].item()
                    ) / num_agents,
                }
                row.update(
                    _mission_record(
                        base, mission_acc, env_id, score_value, steps, num_agents
                    )
                )
                for state_index in range(fsm.num_states):
                    count = int(state_counts[env_id, state_index].item())
                    row[f"state_{state_index}_fraction"] = count / total_robot_steps
                records.append(row)

            runtime.reset(done)
            episode_score[done] = 0.0
            episode_steps[done] = 0
            transitions[done] = 0
            state_counts[done] = 0
            _reset_accumulators(mission_acc, done)

    if len(records) < episodes_requested:
        raise RuntimeError(
            f"Simulation stopped after {len(records)}/{episodes_requested} episodes"
        )
    return records


def summarize(
    records: list[dict], fsm: ChocolateFSM, fsm_index: int, num_agents: int
) -> dict:
    def values(key: str) -> list[float]:
        return [float(row[key]) for row in records]

    scores = values("score")
    std = statistics.stdev(scores) if len(scores) > 1 else 0.0
    ci95 = 1.96 * std / math.sqrt(len(scores)) if scores else 0.0
    summary = {
        "mission": SPEC.key,
        "robot_profile": str(records[0]["robot_profile"]),
        "fsm_index": fsm_index,
        "episodes": len(records),
        "num_agents": num_agents,
        "num_states": fsm.num_states,
        "modules": [state.module_name for state in fsm.states],
        "score_mean": statistics.mean(scores),
        "score_std": std,
        "score_ci95_half_width": ci95,
        "score_min": min(scores),
        "score_max": max(scores),
        "transitions_per_robot_mean": statistics.mean(values("transitions_per_robot")),
        "fsm": fsm.source,
    }

    if SPEC.kind == "aggregation":
        final_black = values("final_black")
        summary.update(
            {
                "mean_black_over_time": statistics.mean(values("mean_black")),
                "normalized_score_mean": statistics.mean(values("normalized_score")),
                "final_black_mean": statistics.mean(final_black),
                "final_black_std": (
                    statistics.stdev(final_black) if len(final_black) > 1 else 0.0
                ),
                "all_robots_black_rate": statistics.mean(
                    1.0 if value >= float(num_agents) else 0.0
                    for value in final_black
                ),
            }
        )
    elif SPEC.kind == "foraging":
        summary.update(
            {
                "deliveries_mean": statistics.mean(values("deliveries")),
                "pickups_mean": statistics.mean(values("pickups")),
                "delivery_efficiency_mean": statistics.mean(
                    values("delivery_efficiency")
                ),
                "deliveries_per_robot_mean": statistics.mean(
                    values("deliveries_per_robot")
                ),
                "deliveries_per_1000_robot_steps_mean": statistics.mean(
                    values("deliveries_per_1000_robot_steps")
                ),
                "carrying_at_end_mean": statistics.mean(values("carrying_at_end")),
                "mean_carrying_over_time": statistics.mean(values("mean_carrying")),
                "mean_on_food_over_time": statistics.mean(values("mean_on_food")),
                "mean_in_nest_over_time": statistics.mean(values("mean_in_nest")),
            }
        )
    else:
        summary.update(
            {
                "mean_grid_age_over_time": statistics.mean(values("mean_grid_age")),
                "final_grid_mean_age_mean": statistics.mean(
                    values("final_grid_mean_age")
                ),
                "final_grid_max_age_mean": statistics.mean(
                    values("final_grid_max_age")
                ),
                "final_grid_coverage_mean": statistics.mean(
                    values("final_grid_coverage")
                ),
                "mean_grid_coverage_over_time": statistics.mean(
                    values("mean_grid_coverage_over_time")
                ),
                "mean_unique_visited_cells_per_step": statistics.mean(
                    values("mean_unique_visited_cells_per_step")
                ),
                "max_grid_age_over_episode_mean": statistics.mean(
                    values("max_grid_age_over_episode")
                ),
            }
        )

    for state_index in range(fsm.num_states):
        summary[f"state_{state_index}_fraction_mean"] = statistics.mean(
            float(row[f"state_{state_index}_fraction"]) for row in records
        )
    return summary


def write_outputs(
    output_dir: Path, records: list[dict], summaries: list[dict]
) -> tuple[Path, Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    profile = str(records[0].get("robot_profile", "mercator"))
    prefix = f"{SPEC.output_prefix}_{profile}"
    episode_path = output_dir / f"{prefix}_episodes_{stamp}.csv"
    summary_csv_path = output_dir / f"{prefix}_summary_{stamp}.csv"
    summary_json_path = output_dir / f"{prefix}_summary_{stamp}.json"

    episode_fields = sorted({key for row in records for key in row})
    with episode_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=episode_fields)
        writer.writeheader()
        writer.writerows(records)

    summary_fields = sorted({key for row in summaries for key in row if key != "fsm"})
    with summary_csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=summary_fields)
        writer.writeheader()
        writer.writerows(
            {key: value for key, value in row.items() if key != "fsm"}
            for row in summaries
        )
    summary_json_path.write_text(
        json.dumps(summaries, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return episode_path, summary_csv_path, summary_json_path


def score() -> None:
    if args.episodes <= 0:
        raise ValueError("--episodes must be positive")
    if args.num_envs <= 0:
        raise ValueError("--num-envs must be positive")

    config_path, fsm_path, fsms, env_cfg, env_overrides = load_mission()
    if args.all_fsms:
        selected = list(enumerate(fsms, start=1))
    else:
        if not 1 <= args.fsm_index <= len(fsms):
            raise ValueError(f"--fsm-index must be between 1 and {len(fsms)}")
        selected = [(args.fsm_index, fsms[args.fsm_index - 1])]

    num_envs = min(int(args.num_envs), int(args.episodes))
    apply_env_overrides(env_cfg, env_overrides, num_envs=num_envs, visualize=False)

    print(f"\n========== MERCATOR {SPEC.key} / SCORE ==========")
    print(f"Mission               : {SPEC.title}")
    print(f"Profile               : {env_cfg.robot_profile}")
    print(f"Config                : {config_path}")
    print(f"FSM file              : {fsm_path}")
    print(f"Parallel environments : {num_envs}")
    print(f"Episodes per FSM      : {args.episodes}")
    print(f"Selected FSMs         : {[index for index, _ in selected]}")
    print("=================================================\n")

    env = gym.make(SPEC.task_id, cfg=env_cfg)
    all_records: list[dict] = []
    summaries: list[dict] = []
    try:
        num_agents = len(env.unwrapped.cfg.possible_agents)
        for fsm_index, fsm in selected:
            print(f"\n========== FSM {fsm_index} ==========")
            print(fsm.describe())
            records = evaluate_fsm(env, fsm, fsm_index, args.episodes, args.seed)
            summary = summarize(records, fsm, fsm_index, num_agents)
            all_records.extend(records)
            summaries.append(summary)
            if SPEC.kind == "aggregation":
                detail = (
                    f"mean N_black={summary['mean_black_over_time']:.3f}, "
                    f"final N_black={summary['final_black_mean']:.3f}"
                )
            elif SPEC.kind == "foraging":
                detail = (
                    f"deliveries={summary['deliveries_mean']:.3f}, "
                    f"efficiency={summary['delivery_efficiency_mean']:.3f}"
                )
            else:
                detail = (
                    f"mean cell age={summary['mean_grid_age_over_time']:.3f}, "
                    f"coverage={100.0 * summary['final_grid_coverage_mean']:.1f}%"
                )
            print(
                f"FSM {fsm_index}: score={summary['score_mean']:.3f} "
                f"± {summary['score_std']:.3f}, {detail}"
            )
    finally:
        env.close()

    output_dir = resolve_path(args.output_dir or SPEC.output_dir)
    paths = write_outputs(output_dir, all_records, summaries)
    print("\nOutputs:")
    for path in paths:
        print(f"  {path}")


def main() -> None:
    if unknown_args:
        print("Ignoring simulator arguments:", " ".join(unknown_args))
    if args.observe:
        observe()
    else:
        score()


if __name__ == "__main__":
    exit_code = 0
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        exit_code = 130
    except Exception:
        exit_code = 1
        print(f"\nMercator {SPEC.key} FSM tool failed", file=sys.stderr)
        traceback.print_exc()
    finally:
        simulation_app.close()
    raise SystemExit(exit_code)
