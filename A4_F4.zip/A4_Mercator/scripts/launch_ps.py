#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Unified Mercator launcher with Cyclamen-PS checkpoint support.

FSM mode keeps the parallel inter-FSM evaluator from the optimized launcher.
Checkpoint mode loads POCA or fixed-option Option-Critic policies directly.
It can either open the Isaac viewer and color robots by selected module, or
evaluate many episodes across several vectorized environments and write CSV/JSON.

Examples
--------
Parallel FSM score::

    python scripts/launch_ps.py --mission AAC --score --all-fsms \
      --episodes 100 --num-envs 20 --parallel-fsms 10

Visualize a Cyclamen-PS Mercator checkpoint::

    python scripts/launch_ps.py --mission FOR --observe \
      --config configs/mercator/FOR_mercator_cyclamen_ps.yaml \
      --checkpoint checkpoints/FOR_mercator_cyclamen_ps/poca_final.pt \
      --deterministic

Evaluate the same checkpoint on ten vectorized environments::

    python scripts/launch_ps.py --mission FOR --score \
      --config configs/mercator/FOR_mercator_cyclamen_ps.yaml \
      --checkpoint checkpoints/FOR_mercator_cyclamen_ps/poca_final.pt \
      --episodes 100 --num-envs 10 --deterministic

In FSM mode ``--num-envs`` means environments per active FSM. In checkpoint
mode it means the total number of vectorized evaluation environments.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
import json
import math
import statistics
from pathlib import Path
import sys
import traceback
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))


def _parse_launcher_args(argv: list[str]) -> tuple[argparse.Namespace, list[str]]:
    """Extract launch_ps-specific options and leave core options untouched."""
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        metavar="PATH",
        help="Trained POCA/Option-Critic checkpoint; enables checkpoint mode",
    )
    parser.add_argument(
        "--deterministic",
        action="store_true",
        help="Choose argmax/mean actions instead of sampling in checkpoint mode",
    )
    parser.add_argument(
        "--parallel-fsms",
        type=int,
        default=0,
        metavar="N",
        help="FSMs evaluated simultaneously; 0 means all selected FSMs",
    )
    parser.add_argument(
        "--max-total-envs",
        type=int,
        default=0,
        metavar="N",
        help="Optional safety cap for total Isaac environments; 0 disables it",
    )
    parser.add_argument(
        "--launch-ps-help",
        action="store_true",
        help="Show launch_ps-specific options and exit",
    )
    return parser.parse_known_args(argv)


LAUNCH_ARGS, CORE_ARGV = _parse_launcher_args(sys.argv[1:])

if LAUNCH_ARGS.launch_ps_help:
    print(
        "launch_ps.py additional options:\n"
        "  --checkpoint PATH    Load a POCA or Option-Critic checkpoint.\n"
        "                       Pair with --observe to visualize it or --score\n"
        "                       to evaluate it over vectorized environments.\n"
        "  --deterministic      Use argmax/mean actions for checkpoint playback.\n"
        "  --parallel-fsms N   FSMs sharing one Isaac vectorized environment.\n"
        "                      0 means all selected FSMs. FSM mode only.\n"
        "  --max-total-envs N  Safety cap on total Isaac environments.\n"
        "                      0 means no cap.\n\n"
        "All other options are accepted by scripts/mercator_fsm.py.\n"
        "FSM score: --num-envs is per FSM. Checkpoint score: it is total envs."
    )
    raise SystemExit(0)

if LAUNCH_ARGS.parallel_fsms < 0:
    raise SystemExit("--parallel-fsms must be >= 0")
if LAUNCH_ARGS.max_total_envs < 0:
    raise SystemExit("--max-total-envs must be >= 0")

# mercator_fsm initializes SimulationApp at import time. Remove launch_ps-only
# arguments first so its parser sees only options it understands.
sys.argv = [sys.argv[0], *CORE_ARGV]
import mercator_fsm as core  # noqa: E402


torch = core.torch


@dataclass
class ParallelFSMGroup:
    """Runtime and metrics for one FSM assigned to a contiguous env slice."""

    fsm_index: int
    fsm: Any
    start: int
    stop: int
    runtime: Any
    state_counts: Any
    records: list[dict]
    last_step: Any | None = None

    @property
    def env_slice(self) -> slice:
        return slice(self.start, self.stop)

    @property
    def num_envs(self) -> int:
        return self.stop - self.start

    def complete(self, episodes: int) -> bool:
        return len(self.records) >= episodes


def _selected_fsms(fsms: list[Any]) -> list[tuple[int, Any]]:
    if core.args.all_fsms:
        return list(enumerate(fsms, start=1))
    if not 1 <= core.args.fsm_index <= len(fsms):
        raise ValueError(f"--fsm-index must be between 1 and {len(fsms)}")
    return [(core.args.fsm_index, fsms[core.args.fsm_index - 1])]


def _parallel_width(selected_count: int, envs_per_fsm: int) -> int:
    requested = LAUNCH_ARGS.parallel_fsms or selected_count
    width = min(requested, selected_count)
    if LAUNCH_ARGS.max_total_envs:
        cap_width = LAUNCH_ARGS.max_total_envs // envs_per_fsm
        if cap_width < 1:
            raise ValueError(
                "--max-total-envs is smaller than --num-envs. "
                "Increase the cap or reduce --num-envs."
            )
        width = min(width, cap_width)
    return max(1, width)


def _summary_detail(summary: dict) -> str:
    if core.SPEC.kind == "aggregation":
        return (
            f"mean N_black={summary['mean_black_over_time']:.3f}, "
            f"final N_black={summary['final_black_mean']:.3f}"
        )
    if core.SPEC.kind == "foraging":
        return (
            f"deliveries={summary['deliveries_mean']:.3f}, "
            f"efficiency={summary['delivery_efficiency_mean']:.3f}"
        )
    return (
        f"mean cell age={summary['mean_grid_age_over_time']:.3f}, "
        f"coverage={100.0 * summary['final_grid_coverage_mean']:.1f}%"
    )


def _make_record(
    *,
    base: Any,
    group: ParallelFSMGroup,
    local_env_id: int,
    global_env_id: int,
    episode_score: Any,
    episode_steps: Any,
    transitions: Any,
    mission_acc: dict[str, Any],
    seed: int,
    effective_seed: int,
    wave_index: int,
    num_agents: int,
) -> dict:
    steps = int(episode_steps[global_env_id].item())
    score_value = float(episode_score[global_env_id].item())
    total_robot_steps = max(1, steps * num_agents)

    row = {
        "mission": core.SPEC.key,
        "robot_profile": str(base.cfg.robot_profile),
        "fsm_index": group.fsm_index,
        "episode": len(group.records) + 1,
        "seed": seed,
        "effective_seed": effective_seed,
        "parallel_env": local_env_id,
        "isaac_env": global_env_id,
        "fsm_parallel_wave": wave_index + 1,
        "steps": steps,
        "score": score_value,
        "transitions_total": int(transitions[global_env_id].item()),
        "transitions_per_robot": float(transitions[global_env_id].item()) / num_agents,
    }
    row.update(
        core._mission_record(
            base,
            mission_acc,
            global_env_id,
            score_value,
            steps,
            num_agents,
        )
    )
    for state_index in range(group.fsm.num_states):
        count = int(group.state_counts[local_env_id, state_index].item())
        row[f"state_{state_index}_fraction"] = count / total_robot_steps
    return row


def _evaluate_wave(
    env: Any,
    wave: list[tuple[int, Any]],
    *,
    envs_per_fsm: int,
    total_envs: int,
    episodes_requested: int,
    seed: int,
    wave_index: int,
) -> list[ParallelFSMGroup]:
    """Evaluate one wave of FSMs concurrently in a shared env.step loop."""
    base = env.unwrapped
    agents = base.cfg.possible_agents
    num_agents = len(agents)
    device = base.device

    # A deterministic but distinct reset for each wave avoids repeating the
    # exact same global random stream when more FSMs exist than parallel slots.
    wave_seed = int(seed + wave_index * 1_000_003)
    core.reseed(wave_seed)
    env.reset(seed=wave_seed)

    groups: list[ParallelFSMGroup] = []
    for slot, (fsm_index, fsm) in enumerate(wave):
        start = slot * envs_per_fsm
        stop = start + envs_per_fsm
        groups.append(
            ParallelFSMGroup(
                fsm_index=fsm_index,
                fsm=fsm,
                start=start,
                stop=stop,
                runtime=core.BatchedChocolateRuntime(
                    fsm, envs_per_fsm, num_agents, device
                ),
                state_counts=torch.zeros(
                    envs_per_fsm,
                    fsm.num_states,
                    dtype=torch.long,
                    device=device,
                ),
                records=[],
            )
        )

    episode_score = torch.zeros(total_envs, dtype=torch.float32, device=device)
    episode_steps = torch.zeros(total_envs, dtype=torch.long, device=device)
    transitions = torch.zeros(total_envs, dtype=torch.long, device=device)
    mission_acc = core._init_mission_accumulators(total_envs, device)

    active_env_mask = torch.zeros(total_envs, dtype=torch.bool, device=device)
    for group in groups:
        active_env_mask[group.env_slice] = True

    global_step = 0
    while (
        any(not group.complete(episodes_requested) for group in groups)
        and core.simulation_app.is_running()
    ):
        with torch.no_grad():
            ground = base._ground_scalar_at(base._ground_sensor_points())
            _, neighbor_count, _, _ = base.sensors.compute_neighbors(
                base.agent_pos, base.agent_yaw
            )

            # Unused slots and already-completed FSM groups receive STOP.
            module_ids = torch.ones(
                total_envs, num_agents, dtype=torch.long, device=device
            )
            exploration_tau = torch.zeros_like(module_ids)
            attraction_alpha = torch.ones(
                total_envs, num_agents, dtype=torch.float32, device=device
            )
            repulsion_alpha = torch.ones_like(attraction_alpha)
            state_entry_mask = torch.zeros(
                total_envs, num_agents, dtype=torch.bool, device=device
            )

            for group in groups:
                if group.complete(episodes_requested):
                    group.last_step = None
                    continue
                step = group.runtime.step(
                    ground[group.env_slice], neighbor_count[group.env_slice]
                )
                group.last_step = step
                module_ids[group.env_slice] = step.module_ids
                exploration_tau[group.env_slice] = step.exploration_tau
                attraction_alpha[group.env_slice] = step.attraction_alpha
                repulsion_alpha[group.env_slice] = step.repulsion_alpha
                state_entry_mask[group.env_slice] = step.state_entry_mask

            base.set_fsm_behavior_parameters(
                exploration_tau=exploration_tau,
                attraction_alpha=attraction_alpha,
                repulsion_alpha=repulsion_alpha,
                state_entry_mask=state_entry_mask,
            )
            action_dict = {
                agent: module_ids[:, agent_index].unsqueeze(-1)
                for agent_index, agent in enumerate(agents)
            }
            _, rewards, terminated, truncated, _ = env.step(action_dict)

        reward = rewards[agents[0]].to(torch.float32)
        done = terminated[agents[0]] | truncated[agents[0]]
        episode_score[active_env_mask] += reward[active_env_mask]
        episode_steps[active_env_mask] += 1
        core._update_mission_accumulators(mission_acc, base, reward, done)
        global_step += 1

        for group in groups:
            if group.last_step is None:
                continue
            local_done = done[group.env_slice]
            global_slice = group.env_slice
            transitions[global_slice] += group.last_step.transitioned.sum(dim=1)
            core.state_histogram_add(group.state_counts, group.last_step.state_ids)

            done_ids = torch.nonzero(local_done, as_tuple=False).flatten().tolist()
            for local_env_id in done_ids:
                if group.complete(episodes_requested):
                    break
                global_env_id = group.start + int(local_env_id)
                group.records.append(
                    _make_record(
                        base=base,
                        group=group,
                        local_env_id=int(local_env_id),
                        global_env_id=global_env_id,
                        episode_score=episode_score,
                        episode_steps=episode_steps,
                        transitions=transitions,
                        mission_acc=mission_acc,
                        seed=seed,
                        effective_seed=wave_seed,
                        wave_index=wave_index,
                        num_agents=num_agents,
                    )
                )

            if bool(local_done.any()):
                group.runtime.reset(local_done)
                group.state_counts[local_done] = 0

        # Reset global per-episode metrics for every environment that completed.
        episode_score[done] = 0.0
        episode_steps[done] = 0
        transitions[done] = 0
        core._reset_accumulators(mission_acc, done)

        if core.args.print_every > 0 and global_step % core.args.print_every == 0:
            progress = " ".join(
                f"F{group.fsm_index:02d}={len(group.records)}/{episodes_requested}"
                for group in groups
            )
            print(
                f"[{core.SPEC.key} wave {wave_index + 1}] "
                f"step={global_step:6d} {progress}",
                flush=True,
            )

    incomplete = [
        group for group in groups if len(group.records) < episodes_requested
    ]
    if incomplete:
        detail = ", ".join(
            f"FSM {group.fsm_index}: {len(group.records)}/{episodes_requested}"
            for group in incomplete
        )
        raise RuntimeError(f"Simulation stopped before completing wave: {detail}")
    return groups


@dataclass
class CheckpointMission:
    config_path: Path
    run_name: str
    variant: str
    trainer_cfg: Any
    env_cfg: Any
    env_overrides: dict[str, Any]
    checkpoint_path: Path
    checkpoint: dict[str, Any]
    decision_period: int


def _torch_load(path: Path, map_location: Any) -> dict[str, Any]:
    """Load metadata checkpoints on old and new PyTorch versions."""
    try:
        value = torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        value = torch.load(path, map_location=map_location)
    if not isinstance(value, dict):
        raise TypeError(f"Checkpoint {path} must contain a dictionary, got {type(value).__name__}")
    return value


def _load_checkpoint_mission() -> CheckpointMission:
    checkpoint_path = core.resolve_path(LAUNCH_ARGS.checkpoint)
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    config_path = core.resolve_path(core.args.config or core.SPEC.config)
    run_name, variant, trainer_cfg, env_overrides = core.load_config(config_path)
    task_id = env_overrides.get("task", core.SPEC.task_id)
    if task_id != core.SPEC.task_id:
        raise ValueError(
            f"Mission {core.SPEC.key} requires {core.SPEC.task_id}; "
            f"config selected {task_id!r}"
        )
    env_cfg = core.resolve_env_cfg(task_id)
    # ``cyclamen_ps`` is an actor-interface variant only. The physical Mercator
    # environment, sensors, modules and critic state remain ordinary Cyclamen.
    env_variant = "cyclamen" if str(variant) == "cyclamen_ps" else variant
    if hasattr(env_cfg, "update_variant"):
        env_cfg.update_variant(env_variant)

    checkpoint = _torch_load(checkpoint_path, "cpu")
    is_ps_checkpoint = bool(checkpoint.get("previous_state_actor_only", False)) or (
        int(checkpoint.get("cyclamen_ps_version", 0)) > 0
    )
    if str(variant) == "cyclamen_ps" and not is_ps_checkpoint:
        raise ValueError(
            "The cyclamen_ps YAML requires a Cyclamen-PS checkpoint. "
            "A standard Cyclamen actor has a different input schema."
        )
    if str(variant) != "cyclamen_ps" and is_ps_checkpoint:
        raise ValueError(
            "Cyclamen-PS checkpoint selected with a non-cyclamen_ps YAML. "
            "Use the matching *_mercator_cyclamen_ps.yaml config."
        )
    checkpoint_variant = checkpoint.get("variant")
    if checkpoint_variant is not None and str(checkpoint_variant) != str(variant):
        raise ValueError(
            f"Checkpoint variant {checkpoint_variant!r} does not match "
            f"config variant {variant!r}"
        )

    config_period = max(1, int(getattr(trainer_cfg, "decision_period", 1)))
    checkpoint_period = int(checkpoint.get("decision_period", config_period))
    if checkpoint_period < 1:
        raise ValueError(f"Invalid checkpoint decision_period={checkpoint_period}")
    if checkpoint_period != config_period:
        raise ValueError(
            f"Checkpoint decision_period={checkpoint_period} does not match "
            f"config decision_period={config_period}"
        )

    return CheckpointMission(
        config_path=config_path,
        run_name=run_name,
        variant=variant,
        trainer_cfg=trainer_cfg,
        env_cfg=env_cfg,
        env_overrides=env_overrides,
        checkpoint_path=checkpoint_path,
        checkpoint=checkpoint,
        decision_period=checkpoint_period,
    )


def _network_classes():
    from SwarmACB_isaac.tasks.direct.agents.poca_networks import (
        Actor,
        DiscreteActor,
        RecurrentDiscreteActor,
        checkpoint_memory_size,
    )
    from SwarmACB_isaac.tasks.direct.agents.option_critic_networks import (
        FixedOptionManager,
    )
    try:
        from poca_alt.poca_opti_ps.poca_networks import (
            PreviousStateRecurrentDiscreteActor,
        )
    except ImportError as exc:
        raise ImportError(
            "Cyclamen-PS playback requires "
            "poca_alt/poca_opti_ps at the project root."
        ) from exc

    return (
        Actor,
        DiscreteActor,
        RecurrentDiscreteActor,
        checkpoint_memory_size,
        FixedOptionManager,
        PreviousStateRecurrentDiscreteActor,
    )


class CheckpointPolicy:
    """Checkpoint-backed POCA or fixed-option Option-Critic policy."""

    def __init__(
        self,
        checkpoint: dict[str, Any],
        *,
        obs_dim: int,
        num_envs: int,
        num_agents: int,
        device: Any,
        deterministic: bool,
    ) -> None:
        (
            Actor,
            DiscreteActor,
            RecurrentDiscreteActor,
            checkpoint_memory_size,
            FixedOptionManager,
            PreviousStateRecurrentDiscreteActor,
        ) = _network_classes()

        self.checkpoint = checkpoint
        self.device = device
        self.num_envs = int(num_envs)
        self.num_agents = int(num_agents)
        self.deterministic = bool(deterministic)
        self.trainer_type = str(checkpoint.get("trainer_type", "poca"))
        self.discrete = bool(checkpoint.get("discrete", False))
        self.recurrent = bool(checkpoint.get("recurrent", False))
        self.hidden_dim = int(checkpoint.get("hidden_dim", 256))
        self.num_layers = int(checkpoint.get("num_layers", 2))
        self.num_actions = int(checkpoint.get("num_actions", 6))
        self.num_options = int(checkpoint.get("num_options", self.num_actions))
        self.act_dim = int(checkpoint.get("act_dim", 2))
        self.memory_size = int(checkpoint_memory_size(checkpoint))
        self.cyclamen_ps = bool(checkpoint.get("previous_state_actor_only", False)) or (
            int(checkpoint.get("cyclamen_ps_version", 0)) > 0
        )
        self.raw_obs_dim = int(checkpoint.get("raw_obs_dim", obs_dim))
        self.actor_obs_dim = int(checkpoint.get("obs_dim", obs_dim))
        self.actor_observation_schema = checkpoint.get("actor_observation_schema")

        if self.cyclamen_ps:
            if self.trainer_type != "poca" or not self.discrete or not self.recurrent:
                raise ValueError(
                    "Cyclamen-PS checkpoints must contain a recurrent discrete POCA actor"
                )
            if self.raw_obs_dim != int(obs_dim):
                raise ValueError(
                    f"Checkpoint raw_obs_dim={self.raw_obs_dim} does not match "
                    f"environment obs_dim={obs_dim}"
                )
            expected_actor_dim = self.raw_obs_dim + self.num_actions
            if self.actor_obs_dim != expected_actor_dim:
                raise ValueError(
                    f"Invalid Cyclamen-PS actor width {self.actor_obs_dim}; "
                    f"expected raw_obs_dim + num_actions = {expected_actor_dim}"
                )
        else:
            saved_obs_dim = checkpoint.get("obs_dim")
            if saved_obs_dim is not None and int(saved_obs_dim) != int(obs_dim):
                raise ValueError(
                    f"Checkpoint obs_dim={saved_obs_dim} does not match "
                    f"environment obs_dim={obs_dim}"
                )
        if self.trainer_type != "option_critic" and self.recurrent and not self.discrete:
            raise ValueError("Recurrent checkpoint playback is supported only for discrete actors")

        if self.trainer_type == "option_critic":
            self.model = FixedOptionManager(
                obs_dim,
                self.num_options,
                self.hidden_dim,
                self.num_layers,
                self.memory_size,
            ).to(device)
            self.model.load_state_dict(checkpoint["manager"], strict=True)
            self.model.eval()
            self.memory_h, self.memory_c = self.model.initial_state(
                self.num_envs * self.num_agents, device
            )
            self.current_options = torch.full(
                (self.num_envs, self.num_agents),
                -1,
                dtype=torch.long,
                device=device,
            )
        elif self.discrete:
            if self.recurrent:
                if self.cyclamen_ps:
                    self.model = PreviousStateRecurrentDiscreteActor(
                        raw_obs_dim=self.raw_obs_dim,
                        num_actions=self.num_actions,
                        hidden=self.hidden_dim,
                        num_layers=self.num_layers,
                        memory_size=self.memory_size,
                    ).to(device)
                else:
                    self.model = RecurrentDiscreteActor(
                        obs_dim,
                        self.num_actions,
                        self.hidden_dim,
                        self.num_layers,
                        self.memory_size,
                    ).to(device)
            else:
                self.model = DiscreteActor(
                    obs_dim,
                    self.num_actions,
                    self.hidden_dim,
                    self.num_layers,
                ).to(device)
            self.model.load_state_dict(checkpoint["actor"], strict=True)
            self.model.eval()
            if self.recurrent:
                self.memory_h, self.memory_c = self.model.initial_state(
                    self.num_envs * self.num_agents, device
                )
            else:
                self.memory_h = None
                self.memory_c = None
            self.current_options = None
            self.previous_module = (
                torch.zeros(
                    self.num_envs,
                    self.num_agents,
                    self.num_actions,
                    dtype=torch.float32,
                    device=device,
                )
                if self.cyclamen_ps
                else None
            )
        else:
            self.model = Actor(
                obs_dim,
                self.act_dim,
                self.hidden_dim,
                self.num_layers,
            ).to(device)
            self.model.load_state_dict(checkpoint["actor"], strict=True)
            self.model.eval()
            self.memory_h = None
            self.memory_c = None
            self.current_options = None

    @property
    def label(self) -> str:
        recurrence = "recurrent" if self.recurrent or self.trainer_type == "option_critic" else "feed-forward"
        action = (
            f"discrete({self.num_options if self.trainer_type == 'option_critic' else self.num_actions})"
            if self.discrete or self.trainer_type == "option_critic"
            else f"continuous({self.act_dim})"
        )
        prefix = "cyclamen_ps actor-only, " if self.cyclamen_ps else ""
        return f"{prefix}{self.trainer_type}, {recurrence}, {action}"

    def act(self, obs_dict: dict[str, Any], agents: list[str]) -> tuple[dict[str, Any], Any | None]:
        obs_stacked = torch.stack([obs_dict[agent] for agent in agents], dim=1)
        if obs_stacked.shape[-1] != self.raw_obs_dim:
            raise ValueError(
                f"Environment observation width changed: expected {self.raw_obs_dim}, "
                f"got {obs_stacked.shape[-1]}"
            )
        if self.cyclamen_ps:
            actor_obs = torch.cat(
                (obs_stacked, self.previous_module.to(dtype=obs_stacked.dtype)),
                dim=-1,
            )
        else:
            actor_obs = obs_stacked
        flat_obs = actor_obs.reshape(-1, actor_obs.shape[-1])

        if self.trainer_type == "option_critic":
            option_logits, termination_logits, next_memory = self.model.step(
                flat_obs, (self.memory_h, self.memory_c)
            )
            self.memory_h = next_memory[0].detach()
            self.memory_c = next_memory[1].detach()
            option_dist = torch.distributions.Categorical(logits=option_logits)
            proposed = (
                option_dist.probs.argmax(dim=-1)
                if self.deterministic
                else option_dist.sample()
            ).view(self.num_envs, self.num_agents)

            force_new = self.current_options < 0
            safe_current = self.current_options.clamp(min=0).reshape(-1)
            beta_logits = termination_logits.gather(
                -1, safe_current.unsqueeze(-1)
            ).squeeze(-1)
            if self.deterministic:
                terminate = (torch.sigmoid(beta_logits) > 0.5).view(
                    self.num_envs, self.num_agents
                )
            else:
                terminate = torch.distributions.Bernoulli(
                    logits=beta_logits
                ).sample().bool().view(self.num_envs, self.num_agents)
            self.current_options = torch.where(
                terminate | force_new, proposed, self.current_options
            )
            module_ids = self.current_options
            actions = module_ids.unsqueeze(-1)
            return {
                agent: actions[:, index] for index, agent in enumerate(agents)
            }, module_ids

        if self.discrete:
            if self.recurrent:
                logits, next_memory = self.model.step(
                    flat_obs, (self.memory_h, self.memory_c)
                )
                self.memory_h = next_memory[0].detach()
                self.memory_c = next_memory[1].detach()
                dist = torch.distributions.Categorical(logits=logits)
            else:
                dist = self.model.get_dist(flat_obs)
            flat_action = (
                dist.probs.argmax(dim=-1) if self.deterministic else dist.sample()
            )
            module_ids = flat_action.view(self.num_envs, self.num_agents)
            if self.cyclamen_ps:
                self.previous_module = torch.nn.functional.one_hot(
                    module_ids.to(torch.long),
                    num_classes=self.num_actions,
                ).to(dtype=obs_stacked.dtype)
            actions = module_ids.unsqueeze(-1)
            return {
                agent: actions[:, index] for index, agent in enumerate(agents)
            }, module_ids

        dist = self.model.get_dist(flat_obs)
        flat_action = dist.mean if self.deterministic else dist.sample()
        actions = flat_action.view(self.num_envs, self.num_agents, self.act_dim)
        actions = actions.clamp(-3, 3) / 3
        return {
            agent: actions[:, index] for index, agent in enumerate(agents)
        }, None

    def reset(self, done: Any) -> None:
        if not bool(done.any()):
            return
        if self.current_options is not None:
            self.current_options[done] = -1
        if getattr(self, "previous_module", None) is not None:
            self.previous_module[done] = 0.0
        if self.memory_h is None or self.memory_c is None:
            return
        agent_done = done.repeat_interleave(self.num_agents)
        self.memory_h[:, agent_done, :] = 0.0
        self.memory_c[:, agent_done, :] = 0.0


def _effective_checkpoint_envs() -> int:
    episodes = int(core.args.episodes)
    requested = int(core.args.num_envs)
    if episodes <= 0:
        raise ValueError("--episodes must be positive")
    if requested <= 0:
        raise ValueError("--num-envs must be positive")
    effective = min(episodes, requested)
    if LAUNCH_ARGS.max_total_envs:
        effective = min(effective, int(LAUNCH_ARGS.max_total_envs))
    if effective < 1:
        raise ValueError("No checkpoint evaluation environments remain after applying caps")
    return effective


def _update_checkpoint_accumulators(
    acc: dict[str, Any], base: Any, reward: Any, done: Any, active: Any
) -> None:
    if core.SPEC.kind == "aggregation":
        acc["max_black"][active] = torch.maximum(
            acc["max_black"][active], reward[active]
        )
        return
    if core.SPEC.kind == "foraging":
        carrying = torch.where(done, base.completed_carrying, base.last_carrying)
        acc["carrying_sum"][active] += carrying[active]
        acc["food_sum"][active] += base.last_in_food[active]
        acc["nest_sum"][active] += base.last_in_nest[active]
        acc["max_carrying"][active] = torch.maximum(
            acc["max_carrying"][active], carrying[active]
        )
        acc["max_step_deliveries"][active] = torch.maximum(
            acc["max_step_deliveries"][active], reward[active]
        )
        return
    mean_age = torch.where(done, base.completed_grid_mean_age, base.last_grid_mean_age)
    coverage = torch.where(done, base.completed_grid_coverage, base.last_grid_coverage)
    visited = torch.where(
        done, base.completed_grid_visited_cells, base.last_grid_visited_cells
    )
    max_age = torch.where(done, base.completed_grid_max_age, base.last_grid_max_age)
    acc["mean_age_sum"][active] += mean_age[active]
    acc["coverage_sum"][active] += coverage[active]
    acc["visited_sum"][active] += visited[active]
    acc["max_age"][active] = torch.maximum(acc["max_age"][active], max_age[active])


def _module_name(index: int) -> str:
    if 0 <= index < len(core.MODULE_NAMES):
        return str(core.MODULE_NAMES[index])
    return f"module_{index}"


def _checkpoint_record(
    *,
    mission: CheckpointMission,
    policy: CheckpointPolicy,
    base: Any,
    env_id: int,
    episode_number: int,
    episode_score: Any,
    episode_steps: Any,
    mission_acc: dict[str, Any],
    module_counts: Any | None,
    num_agents: int,
) -> dict[str, Any]:
    steps = int(episode_steps[env_id].item())
    score = float(episode_score[env_id].item())
    row: dict[str, Any] = {
        "mission": core.SPEC.key,
        "robot_profile": str(base.cfg.robot_profile),
        "controller": "checkpoint",
        "checkpoint": str(mission.checkpoint_path),
        "checkpoint_name": mission.checkpoint_path.name,
        "trainer_type": policy.trainer_type,
        "deterministic": policy.deterministic,
        "episode": episode_number,
        "seed": int(core.args.seed),
        "parallel_env": env_id,
        "steps": steps,
        "score": score,
        "decision_period": mission.decision_period,
    }
    row.update(
        core._mission_record(base, mission_acc, env_id, score, steps, num_agents)
    )
    if module_counts is not None:
        denominator = max(1, steps * num_agents)
        for module_index in range(module_counts.shape[1]):
            row[f"module_{module_index}_{_module_name(module_index)}_fraction"] = (
                float(module_counts[env_id, module_index].item()) / denominator
            )
    return row


def _values(records: list[dict[str, Any]], key: str) -> list[float]:
    return [float(row[key]) for row in records]


def _checkpoint_summary(
    records: list[dict[str, Any]],
    mission: CheckpointMission,
    policy: CheckpointPolicy,
    num_agents: int,
    num_envs: int,
) -> dict[str, Any]:
    scores = _values(records, "score")
    std = statistics.stdev(scores) if len(scores) > 1 else 0.0
    summary: dict[str, Any] = {
        "mission": core.SPEC.key,
        "robot_profile": str(records[0]["robot_profile"]),
        "controller": "checkpoint",
        "checkpoint": str(mission.checkpoint_path),
        "checkpoint_name": mission.checkpoint_path.name,
        "trainer_type": policy.trainer_type,
        "deterministic": policy.deterministic,
        "episodes": len(records),
        "num_envs": num_envs,
        "num_agents": num_agents,
        "decision_period": mission.decision_period,
        "score_mean": statistics.mean(scores),
        "score_median": statistics.median(scores),
        "score_std": std,
        "score_ci95_half_width": 1.96 * std / math.sqrt(len(scores)),
        "score_min": min(scores),
        "score_max": max(scores),
    }
    if core.SPEC.kind == "aggregation":
        final_black = _values(records, "final_black")
        summary.update(
            mean_black_over_time=statistics.mean(_values(records, "mean_black")),
            normalized_score_mean=statistics.mean(_values(records, "normalized_score")),
            final_black_mean=statistics.mean(final_black),
            final_black_std=statistics.stdev(final_black) if len(final_black) > 1 else 0.0,
            all_robots_black_rate=statistics.mean(
                1.0 if value >= float(num_agents) else 0.0 for value in final_black
            ),
        )
    elif core.SPEC.kind == "foraging":
        for output_key, record_key in (
            ("deliveries_mean", "deliveries"),
            ("pickups_mean", "pickups"),
            ("delivery_efficiency_mean", "delivery_efficiency"),
            ("deliveries_per_robot_mean", "deliveries_per_robot"),
            ("deliveries_per_1000_robot_steps_mean", "deliveries_per_1000_robot_steps"),
            ("carrying_at_end_mean", "carrying_at_end"),
            ("mean_carrying_over_time", "mean_carrying"),
            ("mean_on_food_over_time", "mean_on_food"),
            ("mean_in_nest_over_time", "mean_in_nest"),
        ):
            summary[output_key] = statistics.mean(_values(records, record_key))
    else:
        for output_key, record_key in (
            ("mean_grid_age_over_time", "mean_grid_age"),
            ("final_grid_mean_age_mean", "final_grid_mean_age"),
            ("final_grid_max_age_mean", "final_grid_max_age"),
            ("final_grid_coverage_mean", "final_grid_coverage"),
            ("mean_grid_coverage_over_time", "mean_grid_coverage_over_time"),
            ("mean_unique_visited_cells_per_step", "mean_unique_visited_cells_per_step"),
            ("max_grid_age_over_episode_mean", "max_grid_age_over_episode"),
        ):
            summary[output_key] = statistics.mean(_values(records, record_key))

    module_keys = sorted(key for key in records[0] if key.startswith("module_") and key.endswith("_fraction"))
    for key in module_keys:
        summary[f"{key}_mean"] = statistics.mean(_values(records, key))
    return summary


def _write_checkpoint_outputs(
    output_dir: Path,
    records: list[dict[str, Any]],
    summary: dict[str, Any],
) -> tuple[Path, Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    profile = str(records[0].get("robot_profile", "mercator"))
    prefix = f"{core.SPEC.output_prefix}_{profile}_checkpoint"
    episode_path = output_dir / f"{prefix}_episodes_{stamp}.csv"
    summary_csv_path = output_dir / f"{prefix}_summary_{stamp}.csv"
    summary_json_path = output_dir / f"{prefix}_summary_{stamp}.json"

    episode_fields = sorted({key for row in records for key in row})
    with episode_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=episode_fields)
        writer.writeheader()
        writer.writerows(records)
    with summary_csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted(summary))
        writer.writeheader()
        writer.writerow(summary)
    summary_json_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return episode_path, summary_csv_path, summary_json_path


def _checkpoint_summary_detail(summary: dict[str, Any]) -> str:
    if core.SPEC.kind == "aggregation":
        return (
            f"mean N_black={summary['mean_black_over_time']:.3f}, "
            f"final N_black={summary['final_black_mean']:.3f}"
        )
    if core.SPEC.kind == "foraging":
        return (
            f"deliveries={summary['deliveries_mean']:.3f}, "
            f"efficiency={summary['delivery_efficiency_mean']:.3f}"
        )
    return (
        f"mean cell age={summary['mean_grid_age_over_time']:.3f}, "
        f"coverage={100.0 * summary['final_grid_coverage_mean']:.1f}%"
    )


def score_checkpoint() -> None:
    mission = _load_checkpoint_mission()
    num_envs = _effective_checkpoint_envs()
    if LAUNCH_ARGS.parallel_fsms:
        print("[Checkpoint] --parallel-fsms is ignored in checkpoint mode.")
    core.apply_env_overrides(
        mission.env_cfg,
        mission.env_overrides,
        num_envs=num_envs,
        visualize=False,
    )

    print(f"\n========== MERCATOR {core.SPEC.key} / CHECKPOINT SCORE ==========")
    print(f"Mission              : {core.SPEC.title}")
    print(f"Profile              : {mission.env_cfg.robot_profile}")
    print(f"Config               : {mission.config_path}")
    print(f"Checkpoint           : {mission.checkpoint_path}")
    print(f"Episodes             : {core.args.episodes}")
    print(f"Parallel environments: {num_envs}")
    print(f"Decision period      : {mission.decision_period}")
    print(f"Action selection     : {'deterministic' if LAUNCH_ARGS.deterministic else 'stochastic'}")
    print("================================================================\n")

    core.reseed(int(core.args.seed))
    env = core.gym.make(core.SPEC.task_id, cfg=mission.env_cfg)
    records: list[dict[str, Any]] = []
    try:
        base = env.unwrapped
        agents = list(base.cfg.possible_agents)
        num_agents = len(agents)
        device = base.device
        obs_dict, _ = env.reset(seed=int(core.args.seed))
        policy = CheckpointPolicy(
            mission.checkpoint,
            obs_dim=int(obs_dict[agents[0]].shape[-1]),
            num_envs=num_envs,
            num_agents=num_agents,
            device=device,
            deterministic=LAUNCH_ARGS.deterministic,
        )
        print(f"Checkpoint policy     : {policy.label}")
        if policy.trainer_type == "option_critic" and policy.deterministic:
            print(
                "[Checkpoint] Warning: deterministic Option-Critic uses a 0.5 "
                "termination threshold; stochastic mode matches call-and-return sampling."
            )

        episode_score = torch.zeros(num_envs, dtype=torch.float32, device=device)
        episode_steps = torch.zeros(num_envs, dtype=torch.long, device=device)
        mission_acc = core._init_mission_accumulators(num_envs, device)
        action_count = (
            policy.num_options if policy.trainer_type == "option_critic" else policy.num_actions
        ) if policy.discrete or policy.trainer_type == "option_critic" else 0
        module_counts = (
            torch.zeros(num_envs, action_count, dtype=torch.long, device=device)
            if action_count > 0 else None
        )
        global_step = 0

        while len(records) < int(core.args.episodes) and core.simulation_app.is_running():
            with torch.no_grad():
                action_dict, module_ids = policy.act(obs_dict, agents)

            active = torch.ones(num_envs, dtype=torch.bool, device=device)
            for _ in range(mission.decision_period):
                obs_dict, rewards, terminated, truncated, _ = env.step(action_dict)
                reward = rewards[agents[0]].to(torch.float32)
                done = terminated[agents[0]] | truncated[agents[0]]
                newly_done = active & done

                episode_score[active] += reward[active]
                episode_steps[active] += 1
                _update_checkpoint_accumulators(
                    mission_acc, base, reward, newly_done, active
                )
                if module_counts is not None and module_ids is not None:
                    weights = active.unsqueeze(1).expand_as(module_ids).to(torch.long)
                    module_counts.scatter_add_(1, module_ids.to(torch.long), weights)
                global_step += 1

                if bool(newly_done.any()):
                    for env_id in newly_done.nonzero(as_tuple=False).flatten().tolist():
                        if len(records) >= int(core.args.episodes):
                            break
                        records.append(
                            _checkpoint_record(
                                mission=mission,
                                policy=policy,
                                base=base,
                                env_id=int(env_id),
                                episode_number=len(records) + 1,
                                episode_score=episode_score,
                                episode_steps=episode_steps,
                                mission_acc=mission_acc,
                                module_counts=module_counts,
                                num_agents=num_agents,
                            )
                        )
                    policy.reset(newly_done)
                    episode_score[newly_done] = 0.0
                    episode_steps[newly_done] = 0
                    core._reset_accumulators(mission_acc, newly_done)
                    if module_counts is not None:
                        module_counts[newly_done] = 0
                    for agent in agents:
                        action_dict[agent][newly_done] = 0
                    active &= ~newly_done
                    if len(records) >= int(core.args.episodes) or not bool(active.any()):
                        break

            if core.args.print_every > 0 and global_step % int(core.args.print_every) == 0:
                print(
                    f"[{core.SPEC.key} checkpoint] step={global_step:6d} "
                    f"episodes={len(records):4d}/{core.args.episodes} "
                    f"mean_live_score={float(episode_score.mean().item()):.3f}",
                    flush=True,
                )

        if len(records) < int(core.args.episodes):
            raise RuntimeError(
                f"Simulation stopped after {len(records)}/{core.args.episodes} episodes"
            )

        summary = _checkpoint_summary(
            records, mission, policy, num_agents, num_envs
        )
        print(
            f"Checkpoint score={summary['score_mean']:.3f} "
            f"± {summary['score_std']:.3f}, {_checkpoint_summary_detail(summary)}"
        )
        output_dir = core.resolve_path(core.args.output_dir or core.SPEC.output_dir)
        paths = _write_checkpoint_outputs(output_dir, records, summary)
        print("\nOutputs:")
        for path in paths:
            print(f"  {path}")
    finally:
        env.close()


class CheckpointStatusHud:
    def __init__(self) -> None:
        self.label = None
        self.window = None
        if core.headless:
            return
        try:
            import omni.ui as ui

            self.window = ui.Window(
                f"Mercator {core.SPEC.key} checkpoint", width=560, height=290
            )
            with self.window.frame:
                with ui.VStack(spacing=5):
                    ui.Label(f"{core.SPEC.title} / trained checkpoint", height=24)
                    self.label = ui.Label("", word_wrap=True)
        except Exception as exc:
            print(f"HUD unavailable: {exc}")

    def set(self, text: str) -> None:
        if self.label is not None:
            self.label.text = text


def _checkpoint_episode_message(base: Any, episode_number: int, score: float) -> str:
    if core.SPEC.kind == "aggregation":
        return (
            f"[Episode {episode_number:02d}] score={score:.1f}, "
            f"final_black={int(base.completed_n_black[0].item())}, "
            f"final_white={int(base.completed_n_white[0].item())}"
        )
    if core.SPEC.kind == "foraging":
        deliveries = float(base.completed_deliveries[0].item())
        pickups = float(base.completed_pickups[0].item())
        efficiency = deliveries / pickups if pickups > 0.0 else 0.0
        return (
            f"[Episode {episode_number:02d}] deliveries={deliveries:.0f}, "
            f"pickups={pickups:.0f}, efficiency={efficiency:.3f}, "
            f"carrying_at_end={base.completed_carrying[0].item():.0f}"
        )
    return (
        f"[Episode {episode_number:02d}] score={score:.2f}, "
        f"final_mean_age={base.completed_grid_mean_age[0].item():.2f}, "
        f"final_max_age={base.completed_grid_max_age[0].item():.0f}, "
        f"coverage={100.0 * base.completed_grid_coverage[0].item():.1f}%"
    )


def observe_checkpoint() -> None:
    mission = _load_checkpoint_mission()
    core.apply_env_overrides(
        mission.env_cfg,
        mission.env_overrides,
        num_envs=1,
        visualize=True,
    )
    core.force_viewport_extensions()

    print(f"\n========== MERCATOR {core.SPEC.key} / CHECKPOINT OBSERVE ==========")
    print(f"Mission          : {core.SPEC.title}")
    print(f"Profile          : {mission.env_cfg.robot_profile}")
    print(f"Config           : {mission.config_path}")
    print(f"Checkpoint       : {mission.checkpoint_path}")
    print(f"Decision period  : {mission.decision_period}")
    print(f"Action selection : {'deterministic' if LAUNCH_ARGS.deterministic else 'stochastic'}")
    print("==================================================================\n")

    core.reseed(int(core.args.seed))
    env = core.gym.make(core.SPEC.task_id, cfg=mission.env_cfg, render_mode="human")
    base = env.unwrapped
    agents = list(base.cfg.possible_agents)
    num_agents = len(agents)
    device = base.device
    hud = CheckpointStatusHud()

    try:
        obs_dict, _ = env.reset(seed=int(core.args.seed))
        policy = CheckpointPolicy(
            mission.checkpoint,
            obs_dim=int(obs_dict[agents[0]].shape[-1]),
            num_envs=1,
            num_agents=num_agents,
            device=device,
            deterministic=LAUNCH_ARGS.deterministic,
        )
        print(f"Checkpoint policy : {policy.label}")

        base._update_visual_markers()
        color_inputs = []
        if policy.discrete or policy.trainer_type == "option_critic":
            if len(getattr(base, "_robot_visual_xforms", [])) != num_agents:
                raise RuntimeError(
                    f"{core.SPEC.key} Mercator robot visuals were not created"
                )
            color_inputs = core.prepare_robot_color_inputs(base)
        camera_y = (
            core.SPEC.camera_y if core.args.camera_y is None else float(core.args.camera_y)
        )
        camera_height = (
            core.SPEC.camera_height
            if core.args.camera_height is None
            else float(core.args.camera_height)
        )
        base.sim.set_camera_view(
            eye=[0.0, camera_y, camera_height], target=[0.0, 0.0, 0.0]
        )
        for _ in range(30):
            try:
                base.sim.render()
            except Exception:
                pass
            core.simulation_app.update()

        timeline = core.omni.timeline.get_timeline_interface()
        if not timeline.is_playing():
            timeline.play()

        episode_score = 0.0
        episode_number = 1
        control_step = 0
        previous_colors = None

        while core.simulation_app.is_running():
            if core.args.num_episodes > 0 and episode_number > core.args.num_episodes:
                break
            with torch.no_grad():
                action_dict, module_ids = policy.act(obs_dict, agents)

            if module_ids is not None and color_inputs:
                ids = module_ids[0].detach().cpu().tolist()
                color_ids = [int(value) % len(core.MODULE_COLORS) for value in ids]
                previous_colors = core.update_robot_colors(
                    color_inputs,
                    color_ids,
                    core.MODULE_COLORS,
                    previous_colors,
                )
                counts = torch.bincount(
                    module_ids[0], minlength=max(6, policy.num_actions)
                ).detach().cpu().tolist()
                module_text = " ".join(
                    f"{_module_name(index)}:{count}"
                    for index, count in enumerate(counts)
                    if count
                )
            else:
                module_text = "continuous actions"

            done = False
            reward_value = 0.0
            for _ in range(mission.decision_period):
                obs_dict, rewards, terminated, truncated, _ = env.step(action_dict)
                try:
                    base.sim.render()
                except Exception:
                    pass
                core.simulation_app.update()

                reward_value = float(rewards[agents[0]][0].item())
                done = bool((terminated[agents[0]] | truncated[agents[0]])[0].item())
                episode_score += reward_value
                control_step += 1
                metric_lines = core._mission_observe_lines(
                    base, done, episode_score, reward_value
                )
                hud.set(
                    "\n".join(
                        [
                            f"{core.SPEC.key} | {mission.checkpoint_path.name} | "
                            f"episode {episode_number} | "
                            f"t={control_step * float(base.cfg.sim.dt):.1f}s",
                            *metric_lines,
                            f"Modules: {module_text}",
                            f"Policy: {'deterministic' if policy.deterministic else 'stochastic'}",
                        ]
                    )
                )
                if done:
                    break

            if core.args.print_every > 0 and control_step % int(core.args.print_every) == 0:
                print(
                    f"episode={episode_number:02d} step={control_step:04d} "
                    f"score={episode_score:.3f} | modules=[{module_text}]",
                    flush=True,
                )
            if done:
                print(_checkpoint_episode_message(base, episode_number, episode_score))
                policy.reset(torch.tensor([True], dtype=torch.bool, device=device))
                episode_score = 0.0
                control_step = 0
                previous_colors = None
                episode_number += 1
    finally:
        env.close()

def score_parallel() -> None:
    if not core.args.score:
        raise ValueError("Parallel FSM scoring requires --score")
    if core.args.episodes <= 0:
        raise ValueError("--episodes must be positive")
    if core.args.num_envs <= 0:
        raise ValueError("--num-envs must be positive")

    config_path, fsm_path, fsms, env_cfg, env_overrides = core.load_mission()
    selected = _selected_fsms(fsms)

    envs_per_fsm = min(int(core.args.num_envs), int(core.args.episodes))
    width = _parallel_width(len(selected), envs_per_fsm)
    total_envs = envs_per_fsm * width
    wave_count = math.ceil(len(selected) / width)

    core.apply_env_overrides(
        env_cfg,
        env_overrides,
        num_envs=total_envs,
        visualize=False,
    )

    print(f"\n========== MERCATOR {core.SPEC.key} / PARALLEL FSM SCORE ==========")
    print(f"Mission                    : {core.SPEC.title}")
    print(f"Profile                    : {env_cfg.robot_profile}")
    print(f"Config                     : {config_path}")
    print(f"FSM file                   : {fsm_path}")
    print(f"Selected FSMs              : {[index for index, _ in selected]}")
    print(f"Episodes per FSM           : {core.args.episodes}")
    print(f"Environments per FSM       : {envs_per_fsm}")
    print(f"Simultaneous FSMs          : {width}")
    print(f"Total Isaac environments   : {total_envs}")
    print(f"FSM waves in one Isaac app : {wave_count}")
    print("=================================================================\n")

    env = core.gym.make(core.SPEC.task_id, cfg=env_cfg)
    all_records: list[dict] = []
    summaries: list[dict] = []
    try:
        num_agents = len(env.unwrapped.cfg.possible_agents)
        for wave_index in range(wave_count):
            wave_start = wave_index * width
            wave = selected[wave_start : wave_start + width]
            print(
                f"\n========== WAVE {wave_index + 1}/{wave_count}: "
                f"FSM {[index for index, _ in wave]} =========="
            )
            groups = _evaluate_wave(
                env,
                wave,
                envs_per_fsm=envs_per_fsm,
                total_envs=total_envs,
                episodes_requested=int(core.args.episodes),
                seed=int(core.args.seed),
                wave_index=wave_index,
            )
            for group in groups:
                summary = core.summarize(
                    group.records,
                    group.fsm,
                    group.fsm_index,
                    num_agents,
                )
                summary["parallel_fsms_capacity"] = width
                summary["parallel_fsms_in_wave"] = len(groups)
                summary["envs_per_fsm"] = envs_per_fsm
                summary["total_isaac_envs"] = total_envs
                summary["fsm_parallel_wave"] = wave_index + 1
                summary["effective_seed"] = int(core.args.seed) + wave_index * 1_000_003
                all_records.extend(group.records)
                summaries.append(summary)
                print(
                    f"FSM {group.fsm_index}: "
                    f"score={summary['score_mean']:.3f} "
                    f"± {summary['score_std']:.3f}, "
                    f"{_summary_detail(summary)}"
                )
    finally:
        env.close()

    summaries.sort(key=lambda row: int(row["fsm_index"]))
    all_records.sort(key=lambda row: (int(row["fsm_index"]), int(row["episode"])))
    output_dir = core.resolve_path(core.args.output_dir or core.SPEC.output_dir)
    paths = core.write_outputs(output_dir, all_records, summaries)
    print("\nOutputs:")
    for path in paths:
        print(f"  {path}")


def main() -> int:
    try:
        if core.unknown_args:
            print("Ignoring simulator arguments:", " ".join(core.unknown_args))
        if LAUNCH_ARGS.checkpoint:
            if core.args.observe:
                observe_checkpoint()
            else:
                score_checkpoint()
        elif core.args.observe:
            core.observe()
        else:
            score_parallel()
        return 0
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    except Exception:
        controller = "checkpoint" if LAUNCH_ARGS.checkpoint else "FSM"
        print(
            f"\nMercator {core.SPEC.key} {controller} controller tool failed",
            file=sys.stderr,
        )
        traceback.print_exc()
        return 1
    finally:
        core.simulation_app.close()


if __name__ == "__main__":
    raise SystemExit(main())