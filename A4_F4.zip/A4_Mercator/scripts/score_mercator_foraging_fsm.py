#!/usr/bin/env python3
"""Compatibility launcher; the implementation lives in ``mercator_fsm.py``."""

from pathlib import Path
import runpy
import sys


target = Path(__file__).with_name("mercator_fsm.py")
sys.argv = [str(target), "--mission", "FOR", "--score", *sys.argv[1:]]
runpy.run_path(str(target), run_name="__main__")
