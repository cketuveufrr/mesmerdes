#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Mercator Light GUI visualizer.

This script intentionally uses ``isaacsim.SimulationApp`` directly instead of
Isaac Lab's AppLauncher.  The full Mercator debug scripts supplied with this
project use the same launch path, which is more reliable for opening the local
Isaac Sim window on the target installation.
"""

from __future__ import annotations

import argparse
import importlib
import os
import statistics
import sys
import traceback
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

parser = argparse.ArgumentParser(description="Visualize Mercator Light AAC")
parser.add_argument("--config", default="configs/mercator/AAC_mercator_cyclamen.yaml")
parser.add_argument("--task", default=None)
parser.add_argument(
    "--variant",
    default=None,
    choices=["dandelion", "daisy", "lily", "tulip", "cyclamen"],
)
parser.add_argument("--checkpoint", default=None)
parser.add_argument("--module", type=int, default=0, choices=range(6))
parser.add_argument(
    "--num_episodes",
    type=int,
    default=0,
    help="0 keeps the GUI open until the window is closed or Ctrl+C is pressed.",
)
parser.add_argument("--deterministic", action="store_true")
parser.add_argument(
    "--camera_height", type=float, default=None,
    help="Camera height. Defaults to 4.2 m for AAC2/FOR2 and 13 m for AAC/FOR/GRID.",
)
parser.add_argument(
    "--camera_y", type=float, default=None,
    help="Camera Y position. Defaults to -3 m for AAC2/FOR2 and -8 m for AAC/FOR/GRID.",
)
parser.add_argument("--print_every", type=int, default=50)
parser.add_argument("--width", type=int, default=1600)
parser.add_argument("--height", type=int, default=900)
parser.add_argument(
    "--headless",
    action="store_true",
    help="Diagnostic only. Omit this flag to open the Isaac Sim window.",
)
args, _unknown = parser.parse_known_args()

# SimulationApp must be created before importing Isaac Lab, Gym task modules or
# any omni/pxr package.
# Remove inherited headless flags from training shells. The explicit
# SimulationApp configuration below remains the source of truth.
if not args.headless:
    for _name in (
        "HEADLESS",
        "ISAACLAB_HEADLESS",
        "OMNI_KIT_HEADLESS",
        "DISABLE_VIEWPORT_UPDATES",
    ):
        os.environ.pop(_name, None)

from isaacsim import SimulationApp  # noqa: E402

print("[Visualize] Launching isaacsim.SimulationApp directly...")
print(f"[Visualize] headless={args.headless}, DISPLAY={os.environ.get('DISPLAY')!r}, WAYLAND_DISPLAY={os.environ.get('WAYLAND_DISPLAY')!r}")
simulation_app = SimulationApp(
    {
        "headless": bool(args.headless),
        "multi_gpu": False,
        "width": int(args.width),
        "height": int(args.height),
    }
)

# Isaac/Isaac Lab imports only after SimulationApp construction.
import gymnasium as gym  # noqa: E402
import omni.kit.app  # noqa: E402
import omni.timeline  # noqa: E402
import torch  # noqa: E402
from pxr import Gf, Sdf, UsdGeom, UsdShade  # noqa: E402

import SwarmACB_isaac.tasks  # noqa: E402,F401
from SwarmACB_isaac.tasks.direct.agents.config_loader import load_config, print_config  # noqa: E402
from SwarmACB_isaac.tasks.direct.agents.poca_networks import (  # noqa: E402
    Actor,
    DiscreteActor,
    RecurrentDiscreteActor,
)


MODULE_NAMES = {
    0: "exploration",
    1: "stop",
    2: "phototaxis",
    3: "anti_phototaxis",
    4: "attraction",
    5: "repulsion",
}

MODULE_COLORS = {
    0: (0.20, 0.55, 1.00),  # exploration: blue
    1: (0.45, 0.45, 0.45),  # stop: gray
    2: (1.00, 0.85, 0.10),  # phototaxis: yellow
    3: (0.65, 0.20, 0.90),  # anti-phototaxis: purple
    4: (0.15, 0.80, 0.30),  # attraction: green
    5: (1.00, 0.20, 0.15),  # repulsion: red
}

REQUIRED_CFG_FIELDS = (
    "robot_length",
    "robot_width",
    "robot_base_height",
    "lidar_tower_diameter",
    "lidar_tower_offset",
    "lidar_height",
    "spawn_half_range",
    "spawn_max_trials",
    "cyclamen_neighbor_range",
    "enable_visualization",
)


def _resolve_path(path: str) -> str:
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = ROOT / candidate
    return str(candidate.resolve())


def _resolve_env_cfg(task_id: str):
    spec = gym.spec(task_id)
    entry = spec.kwargs.get("env_cfg_entry_point")
    if entry is None:
        raise ValueError(f"Task {task_id!r} has no env_cfg_entry_point")
    module_path, cls_name = entry.rsplit(":", 1)
    module = importlib.import_module(module_path)
    print(f"[Visualize] Environment cfg module: {module.__file__}")
    return getattr(module, cls_name)()


def _apply_env_overrides(env_cfg, overrides: dict) -> None:
    missing = []
    for key, value in overrides.items():
        if key == "task":
            continue
        if key == "num_envs":
            env_cfg.scene.num_envs = 1
            continue
        if not hasattr(env_cfg, key):
            missing.append(key)
            continue
        current = getattr(env_cfg, key)
        if isinstance(current, tuple) and isinstance(value, list):
            value = tuple(value)
        setattr(env_cfg, key, value)

    if missing:
        raise RuntimeError(
            "Installed Mercator environment config is obsolete; missing YAML keys: "
            + ", ".join(missing)
        )


def _validate_cfg(env_cfg) -> None:
    missing = [name for name in REQUIRED_CFG_FIELDS if not hasattr(env_cfg, name)]
    if missing:
        raise RuntimeError("Incomplete Mercator config: " + ", ".join(missing))


def _infer_actor_metadata(checkpoint: dict) -> dict:
    state = checkpoint["actor"]
    recurrent = bool(checkpoint.get("recurrent", any(k.startswith("lstm.") for k in state)))
    if recurrent:
        if int(checkpoint.get("paper_parity_version", 0)) != 3:
            raise RuntimeError(
                "This visualizer expects a learner-parity v3 recurrent checkpoint."
            )
        memory_total = int(checkpoint["memory_size"])
        return {
            "recurrent": True, "discrete": True,
            "obs_dim": int(checkpoint["obs_dim"]),
            "hidden": int(checkpoint["hidden_dim"]),
            "num_layers": int(checkpoint["num_layers"]),
            "memory_total": memory_total,
            "lstm_hidden": memory_total // 2,
            "num_actions": int(checkpoint["num_actions"]),
        }

    discrete = bool(checkpoint.get("discrete", any(k.startswith("logits_head") for k in state)))
    first = state["net.0.weight"]
    if discrete:
        return {
            "recurrent": False, "discrete": True,
            "obs_dim": int(first.shape[1]), "hidden": int(first.shape[0]),
            "num_layers": int(checkpoint.get("num_layers", 2)),
            "num_actions": int(state["logits_head.weight"].shape[0]),
        }
    return {
        "recurrent": False, "discrete": False,
        "obs_dim": int(first.shape[1]), "hidden": int(first.shape[0]),
        "num_layers": int(checkpoint.get("num_layers", 2)),
        "act_dim": int(state["mu_head.weight"].shape[0]),
    }


def _force_viewport_extensions() -> None:
    """Best-effort viewport enablement for installations with custom profiles."""
    app = omni.kit.app.get_app()
    manager = app.get_extension_manager()
    candidates = (
        "omni.kit.window.viewport",
        "omni.kit.viewport.window",
        "omni.kit.viewport.utility",
    )
    for extension in candidates:
        try:
            manager.set_extension_enabled_immediate(extension, True)
            print(f"[Visualize] viewport extension enabled: {extension}")
        except Exception:
            # Extension names differ across Isaac Sim releases. SimulationApp's
            # standard GUI experience normally enables the correct one already.
            pass


def _set_camera(env, task_id: str) -> None:
    small_arena = (
        task_id == "SwarmACB-MercatorAggregation2-v0"
        or task_id == "SwarmACB-MercatorForaging2-v0"
        or task_id == "SwarmACB-MercatorGridExploration2-v0"
    )
    camera_y = args.camera_y if args.camera_y is not None else (-3.0 if small_arena else -8.0)
    camera_height = (
        args.camera_height
        if args.camera_height is not None
        else (4.2 if small_arena else 13.0)
    )
    eye = [0.0, float(camera_y), float(camera_height)]
    target = [0.0, 0.0, 0.0]
    env.unwrapped.sim.set_camera_view(eye=eye, target=target)
    print(f"[Visualize] Camera eye={tuple(eye)}, target={tuple(target)}")


def _render_warmup(env, frames: int = 30) -> None:
    """Push USD changes to the viewport before entering the control loop."""
    base = env.unwrapped
    for _ in range(frames):
        try:
            base.sim.render()
        except Exception:
            pass
        simulation_app.update()


def _prepare_robot_color_inputs(base):
    """Create one material per robot and bind it once to the robot root."""
    inputs = []
    for index, visual in enumerate(getattr(base, "_robot_visual_xforms", [])):
        prim = visual.GetPrim()
        stage = prim.GetStage()
        material_path = f"/World/RobotModuleMaterials/Robot_{index:03d}"
        material = UsdShade.Material.Define(stage, material_path)
        shader = UsdShade.Shader.Define(stage, material_path + "/Shader")
        shader.CreateIdAttr("UsdPreviewSurface")
        color_input = shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f)
        shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.45)
        shader.CreateOutput("surface", Sdf.ValueTypeNames.Token)
        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
        UsdShade.MaterialBindingAPI.Apply(prim).Bind(
            material, UsdShade.Tokens.strongerThanDescendants
        )
        inputs.append(color_input)
    return inputs


def _update_robot_colors(color_inputs, module_ids, previous=None):
    """Only edit colors for robots whose selected module changed."""
    current = [int(module_id) for module_id in module_ids]
    for index, module_id in enumerate(current):
        if previous is None or previous[index] != module_id:
            color_inputs[index].Set(Gf.Vec3f(*MODULE_COLORS[module_id]))
    return current


class _ModuleHud:
    """Small viewport window showing the currently selected AutoMoDe modules."""

    def __init__(self):
        self._label = None
        self._window = None
        if args.headless:
            return
        try:
            import omni.ui as ui

            self._window = ui.Window("Mercator Modules", width=430, height=205)
            with self._window.frame:
                with ui.VStack(spacing=4):
                    ui.Label("Selected AutoMoDe modules", height=24)
                    self._label = ui.Label("", word_wrap=True)
        except Exception as exc:
            print(f"[Visualize] Warning: module HUD unavailable: {exc}")

    def update(self, module_ids, *, episode: int, step: int) -> None:
        if self._label is None:
            return
        if module_ids is None:
            detail = "continuous wheel command (no discrete module ID)"
        else:
            counts = {index: 0 for index in MODULE_NAMES}
            for module_id in module_ids:
                counts[int(module_id)] += 1
            detail = "\n".join(
                f"{index}  {MODULE_NAMES[index]:18s}: {counts[index]} robot(s)"
                for index in MODULE_NAMES
            )
        self._label.text = f"episode={episode}  step={step}\n{detail}"


def main() -> None:
    config_path = _resolve_path(args.config)
    run_name, cfg_variant, train_cfg, env_overrides = load_config(config_path)
    variant = args.variant or cfg_variant
    task_id = args.task or env_overrides.get("task", "SwarmACB-MercatorAggregation-v0")
    env_overrides["num_envs"] = 1
    print_config(run_name, variant, train_cfg, env_overrides)

    env_cfg = _resolve_env_cfg(task_id)
    if hasattr(env_cfg, "update_variant"):
        env_cfg.update_variant(variant)
    _apply_env_overrides(env_cfg, env_overrides)
    _validate_cfg(env_cfg)
    env_cfg.scene.num_envs = 1
    env_cfg.enable_visualization = True
    env_cfg.sim.render_interval = 1

    _force_viewport_extensions()
    print("[Visualize] Creating GUI environment...")
    env = gym.make(task_id, cfg=env_cfg, render_mode="human")
    base = env.unwrapped
    device = base.device
    agents = base.cfg.possible_agents
    num_agents = len(agents)
    environment_signature = (
        base.get_environment_signature()
        if hasattr(base, "get_environment_signature")
        else None
    )
    if environment_signature is not None:
        print(
            "[Visualize] Environment fingerprint: "
            f"{environment_signature['fingerprint']}"
        )
        print(
            "[Visualize] Arena fingerprint      : "
            f"{environment_signature['arena_fingerprint']}"
        )

    try:
        obs_dict, _ = env.reset(seed=int(getattr(base.cfg, "seed", 0)))
        base._update_visual_markers()
        visual_count = len(getattr(base, "_robot_visual_xforms", []))
        first_pos = base.agent_pos[0, 0].detach().cpu().tolist()
        print(
            f"[Visualize] Direct robot visuals={visual_count}; "
            f"first analytical position=({first_pos[0]:+.3f}, {first_pos[1]:+.3f})"
        )
        if visual_count != num_agents:
            raise RuntimeError(
                f"Expected {num_agents} direct robot visuals, but created {visual_count}."
            )
        robot_color_inputs = _prepare_robot_color_inputs(base)
        module_hud = _ModuleHud()
        _set_camera(env, task_id)

        timeline = omni.timeline.get_timeline_interface()
        if not timeline.is_playing():
            timeline.play()

        _render_warmup(env)
        if not simulation_app.is_running():
            raise RuntimeError("SimulationApp stopped before the GUI loop started")

        actor = None
        metadata = None
        h = c_mem = None

        if args.checkpoint:
            checkpoint_path = _resolve_path(args.checkpoint)
            checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
            saved_signature = checkpoint.get("environment_signature")
            if saved_signature is None:
                print(
                    "[Visualize] WARNING: checkpoint predates environment fingerprints; "
                    "the .pt file cannot prove which arena created it."
                )
            elif environment_signature is not None:
                saved_fp = saved_signature.get("fingerprint")
                current_fp = environment_signature.get("fingerprint")
                if saved_fp != current_fp:
                    raise RuntimeError(
                        "Checkpoint/environment mismatch.\n"
                        f"  checkpoint: {saved_fp}\n"
                        f"  visualizer: {current_fp}\n"
                        "Refusing to display a controller on a different arena."
                    )
                print(f"[Visualize] Checkpoint environment verified: {current_fp}")
            metadata = _infer_actor_metadata(checkpoint)
            actual_obs_dim = int(obs_dict[agents[0]].shape[-1])
            if metadata["obs_dim"] != actual_obs_dim:
                raise ValueError(
                    f"Checkpoint obs_dim={metadata['obs_dim']} but environment obs_dim={actual_obs_dim}."
                )

            if metadata["recurrent"]:
                actor = RecurrentDiscreteActor(
                    metadata["obs_dim"], metadata["num_actions"],
                    metadata["hidden"], metadata["num_layers"],
                    metadata["memory_total"],
                ).to(device)
                h, c_mem = actor.initial_state(num_agents, device)
            elif metadata["discrete"]:
                actor = DiscreteActor(
                    metadata["obs_dim"], metadata["num_actions"],
                    metadata["hidden"], metadata["num_layers"],
                ).to(device)
            else:
                actor = Actor(
                    metadata["obs_dim"], metadata["act_dim"],
                    metadata["hidden"], metadata["num_layers"],
                ).to(device)
            actor.load_state_dict(checkpoint["actor"], strict=True)
            actor.eval()
            mode_text = f"checkpoint={checkpoint_path}, deterministic={args.deterministic}"
        else:
            mode_text = f"fixed module={args.module}:{MODULE_NAMES[args.module]}"

        print("\n========== MERCATOR LIGHT VISUALIZATION ==========")
        print(f"task          : {task_id}")
        print(f"variant       : {variant}")
        print(f"mode          : {mode_text}")
        print(
            f"robot base    : {base.cfg.robot_length:.3f} x "
            f"{base.cfg.robot_width:.3f} x {base.cfg.robot_base_height:.3f} m"
        )
        print(
            f"lidar tower   : diameter={base.cfg.lidar_tower_diameter:.3f} m, "
            f"offset={tuple(base.cfg.lidar_tower_offset)}, "
            f"lidar_z={base.cfg.lidar_height:.5f} m"
        )
        print(f"light         : {tuple(base.cfg.light_position)}")
        if environment_signature is not None:
            print(f"arena hash    : {environment_signature['arena_fingerprint']}")
            print(f"setup hash    : {environment_signature['fingerprint']}")
        print("Close the Isaac Sim window or press Ctrl+C to stop.")
        print("==================================================\n")
        print("[Visualize] GUI loop started successfully.")

        completed: list[float] = []
        episode_reward = torch.zeros(1, dtype=torch.float32, device=device)
        control_step = 0
        previous_module_ids = None
        if actor is None:
            previous_module_ids = _update_robot_colors(
                robot_color_inputs, [args.module] * num_agents
            )
        module_hud.update(previous_module_ids, episode=1, step=0)

        while simulation_app.is_running():
            if args.num_episodes > 0 and len(completed) >= args.num_episodes:
                break

            with torch.no_grad():
                if actor is None:
                    action_all = torch.full(
                        (1, num_agents, 1), args.module,
                        dtype=torch.long, device=device,
                    )
                else:
                    obs_all = torch.stack([obs_dict[a] for a in agents], dim=1)
                    flat_obs = obs_all.reshape(num_agents, -1)
                    if metadata["recurrent"]:
                        logits, (h, c_mem) = actor.step(flat_obs, (h, c_mem))
                        dist = torch.distributions.Categorical(logits=logits)
                    else:
                        dist = actor.get_dist(flat_obs)

                    if metadata["discrete"]:
                        flat_action = dist.probs.argmax(-1) if args.deterministic else dist.sample()
                        action_all = flat_action.view(1, num_agents, 1)
                    else:
                        flat_action = dist.mean if args.deterministic else dist.sample()
                        action_all = flat_action.view(1, num_agents, metadata["act_dim"])
                        action_all = action_all.clamp(-3.0, 3.0) / 3.0

                action_dict = {agent: action_all[:, i] for i, agent in enumerate(agents)}

                if actor is not None and metadata["discrete"]:
                    module_ids = action_all[0, :, 0].detach().cpu().tolist()
                    previous_module_ids = _update_robot_colors(
                        robot_color_inputs, module_ids, previous_module_ids
                    )
                module_hud.update(
                    previous_module_ids if metadata is None or metadata["discrete"] else None,
                    episode=len(completed) + 1,
                    step=control_step,
                )

            obs_dict, rewards, terminated, truncated, _ = env.step(action_dict)
            # Force both the simulation renderer and Kit's application event
            # loop. This is intentionally redundant and makes the viewport
            # update on installations where env.step() alone does not pump UI.
            try:
                base.sim.render()
            except Exception:
                pass
            simulation_app.update()

            episode_reward += rewards[agents[0]]
            done = terminated[agents[0]] | truncated[agents[0]]
            control_step += 1

            if args.print_every > 0 and control_step % args.print_every == 0:
                if hasattr(base, "last_grid_mean_age"):
                    print(
                        f"step={control_step:5d} "
                        f"t={control_step * base.cfg.sim.dt:7.1f}s "
                        f"score={episode_reward[0].item():10.2f} "
                        f"mean_age={base.last_grid_mean_age[0].item():7.2f} "
                        f"max_age={base.last_grid_max_age[0].item():5.0f} "
                        f"coverage={100.0 * base.last_grid_coverage[0].item():6.1f}%"
                    )
                elif hasattr(base, "last_deliveries"):
                    print(
                        f"step={control_step:5d} "
                        f"t={control_step * base.cfg.sim.dt:7.1f}s "
                        f"deliveries={int(round(episode_reward[0].item())):3d} "
                        f"carrying={int(base.last_carrying[0].item()):2d} "
                        f"on_food={int(base.last_in_food[0].item()):2d} "
                        f"in_nest={int(base.last_in_nest[0].item()):2d}"
                    )
                else:
                    n_black = int(base.last_n_black[0].item())
                    n_white = int(base.last_n_white[0].item())
                    print(
                        f"step={control_step:5d} "
                        f"t={control_step * base.cfg.sim.dt:7.1f}s "
                        f"N_black={n_black:2d} N_white={n_white:2d}"
                    )

            if bool(done[0]):
                score = float(episode_reward[0].item())
                completed.append(score)
                if hasattr(base, "completed_grid_mean_age"):
                    print(
                        f"[Episode {len(completed):02d}] score={score:.2f}, "
                        f"final_mean_age={base.completed_grid_mean_age[0].item():.2f}, "
                        f"final_max_age={base.completed_grid_max_age[0].item():.0f}, "
                        f"coverage={100.0 * base.completed_grid_coverage[0].item():.1f}%"
                    )
                elif hasattr(base, "completed_pickups"):
                    pickups = float(base.completed_pickups[0].item())
                    efficiency = score / pickups if pickups > 0.0 else 0.0
                    print(
                        f"[Episode {len(completed):02d}] deliveries={score:.0f}, "
                        f"pickups={pickups:.0f}, efficiency={efficiency:.3f}"
                    )
                else:
                    print(f"[Episode {len(completed):02d}] score={score:.1f}")
                episode_reward.zero_()
                control_step = 0
                if metadata is not None and metadata["recurrent"]:
                    h.zero_()
                    c_mem.zero_()

        if completed:
            print("\n================ RESULTS ================")
            print(f"episodes : {len(completed)}")
            print(f"mean     : {statistics.mean(completed):.2f}")
            print(f"min/max  : {min(completed):.2f} / {max(completed):.2f}")
            print("=========================================")
    finally:
        env.close()


if __name__ == "__main__":
    exit_code = 0
    try:
        main()
    except KeyboardInterrupt:
        print("\n[Visualize] Interrupted by user.")
    except Exception:
        exit_code = 1
        print("\n[Visualize] FATAL ERROR", file=sys.stderr)
        traceback.print_exc()
    finally:
        simulation_app.close()
    raise SystemExit(exit_code)