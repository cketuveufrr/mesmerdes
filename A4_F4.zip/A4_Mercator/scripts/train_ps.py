#!/usr/bin/env python3
"""Run the validated Mercator tensor trainer with isolated POCA alternatives.

Project layout::

    poca_alt/
        poca_opti/       # optimized baseline
        poca_opti_ps/    # inherits optimized baseline; actor-only previous module
    scripts/
        train_2.py       # existing validated tensor trainer
        train_ps.py      # this selector

A normal ``variant: cyclamen`` YAML uses ``poca_alt.poca_opti``. A
``variant: cyclamen_ps`` YAML uses ``poca_alt.poca_opti_ps`` and maps only the
environment sensor variant back to ``cyclamen``. No source package, critic or
mission file is monkey-patched on disk.
"""

from __future__ import annotations

import os
from pathlib import Path
import sys

os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")

_SCRIPT_DIR = Path(__file__).resolve().parent
_ROOT = _SCRIPT_DIR.parent
if not (_ROOT / "scripts" / "train_2.py").is_file():
    raise RuntimeError("train_ps.py must be placed in the project's scripts/ directory")
if not (_ROOT / "poca_alt" / "poca_opti" / "poca_trainer.py").is_file():
    raise RuntimeError("Missing poca_alt/poca_opti at the project root")
if not (_ROOT / "poca_alt" / "poca_opti_ps" / "poca_trainer.py").is_file():
    raise RuntimeError("Missing poca_alt/poca_opti_ps at the project root")

if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

import train_2 as _train2

from poca_alt.poca_opti.poca_trainer import (
    POCATrainer as _OptimizedPOCATrainer,
    trust_region_policy_loss as _optimized_policy_loss,
    trust_region_value_loss as _optimized_value_loss,
)
from poca_alt.poca_opti_ps.poca_trainer import POCATrainerPS as _POCATrainerPS


class _FastOptimizedPOCATrainer(_OptimizedPOCATrainer):
    _compute_recurrent_losses = _train2.FastPOCATrainer._compute_recurrent_losses


class _FastPOCATrainerPS(_POCATrainerPS):
    _compute_recurrent_losses = _train2.FastPOCATrainer._compute_recurrent_losses


class _TrainerDispatcher:
    def __new__(cls, env, cfg):
        target = _POCATrainerPS if bool(getattr(cfg, "cyclamen_ps", False)) else _OptimizedPOCATrainer
        return target(env, cfg)


class _FastTrainerDispatcher:
    def __new__(cls, env, cfg):
        target = _FastPOCATrainerPS if bool(getattr(cfg, "cyclamen_ps", False)) else _FastOptimizedPOCATrainer
        return target(env, cfg)


_original_load_config = _train2.load_config
_original_build_env_cfg = _train2._build_env_cfg


def _load_config_with_ps(path):
    run_name, variant, cfg, env_overrides = _original_load_config(path)
    cfg.cyclamen_ps = variant == "cyclamen_ps"
    if cfg.cyclamen_ps:
        if getattr(cfg, "trainer_type", "poca") != "poca":
            raise ValueError("cyclamen_ps supports trainer_type: poca only")
        if not bool(getattr(cfg, "recurrent", False)):
            raise ValueError("cyclamen_ps requires recurrent memory settings")
    return run_name, variant, cfg, env_overrides


def _build_env_cfg_with_ps(task_id, variant, device, env_overrides):
    # The physical Mercator environment remains exactly Cyclamen. Only the actor
    # interface is extended by the alternate trainer.
    env_variant = "cyclamen" if variant == "cyclamen_ps" else variant
    cfg = _original_build_env_cfg(task_id, env_variant, device, env_overrides)
    cfg.policy_variant = variant
    return cfg


# Rebind only the trainer selected by train_2.main() and the in-memory PS mapping.
_train2.load_config = _load_config_with_ps
_train2._build_env_cfg = _build_env_cfg_with_ps
_train2.POCATrainer = _TrainerDispatcher
_train2.FastPOCATrainer = _FastTrainerDispatcher
_train2.trust_region_policy_loss = _optimized_policy_loss
_train2.trust_region_value_loss = _optimized_value_loss


def main() -> None:
    print(f"[train_ps] Optimized baseline: {_ROOT / 'poca_alt' / 'poca_opti'}")
    print(f"[train_ps] Cyclamen-PS child : {_ROOT / 'poca_alt' / 'poca_opti_ps'}")
    _train2.main()


if __name__ == "__main__":
    main()
