#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""High-throughput tensor-only training for all six Mercator missions.

This is a drop-in training entry point for the Mercator YAML files:

    python scripts/train_2.py --config configs/mercator/AAC_mercator_cyclamen.yaml
    python scripts/train_2.py --config configs/mercator/FOR2_tmercator_cyclamen.yaml

Supported task IDs
------------------
* SwarmACB-MercatorAggregation-v0
* SwarmACB-MercatorAggregation2-v0
* SwarmACB-MercatorForaging-v0
* SwarmACB-MercatorForaging2-v0
* SwarmACB-MercatorGridExploration-v0
* SwarmACB-MercatorGridExploration2-v0

The script deliberately does not launch Isaac Sim, Kit, USD, rendering or
PhysX. The six Mercator environments already implement their robot dynamics,
sensors, collisions and task objectives analytically in PyTorch.

Training semantics retained from scripts/train.py
--------------------------------------------------
* same YAML loader and CLI overrides;
* same POCA actor, recurrent memory, centralized critic and buffer;
* same rollouts, lambda-returns, counterfactual advantages and schedules;
* same checkpoint format, TensorBoard tags and global-step convention;
* same six analytical 1/60 s substeps per 0.1 s decision by default.

Additional safe optimizations
-----------------------------
* tensor-only environment transport [env, agent, ...];
* one batched LSTM call per recurrent minibatch instead of 128 Python calls;
* optional TF32 through --matmul_precision high (conservative default: highest).
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import os
from pathlib import Path
import random
import sys
import types
from typing import Any

# This must be set before importing SwarmACB_isaac. It prevents task package
# registration from importing Isaac Lab, Omniverse, USD and PhysX modules.
os.environ.setdefault("SWARMACB_SKIP_ISAAC_TASKS", "1")

_SCRIPT_DIR = Path(__file__).resolve().parent
if (_SCRIPT_DIR / "source" / "SwarmACB_isaac").is_dir():
    ROOT = _SCRIPT_DIR
elif (_SCRIPT_DIR.parent / "source" / "SwarmACB_isaac").is_dir():
    ROOT = _SCRIPT_DIR.parent
else:
    raise RuntimeError(
        "Place train_2.py either at the project root or inside its scripts/ directory"
    )
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

import numpy as np
import torch

# The mission model files are Isaac-independent, but their package __init__.py
# files register Gym environments. Install lightweight namespace packages so
# importing the pure model modules does not require Gymnasium either.
_MISSIONS_ROOT = (
    SOURCE_ROOT / "SwarmACB_isaac" / "tasks" / "direct" / "missions"
)
for _suffix in (
    "",
    "mercator_aggregation2",
    "mercator_foraging",
    "mercator_foraging2",
    "mercator_grid_exploration",
    "mercator_grid_exploration2",
):
    _name = "SwarmACB_isaac.tasks.direct.missions"
    _path = _MISSIONS_ROOT
    if _suffix:
        _name += f".{_suffix}"
        _path = _path / _suffix
    if _name not in sys.modules:
        _module = types.ModuleType(_name)
        _module.__path__ = [str(_path)]
        _module.__package__ = _name
        sys.modules[_name] = _module

from SwarmACB_isaac.tasks.direct.agents.config_loader import load_config, print_config
from SwarmACB_isaac.tasks.direct.agents.poca_trainer import (
    POCATrainer,
    trust_region_policy_loss,
    trust_region_value_loss,
)
from SwarmACB_isaac.tasks.direct.mercator_light import mercator_tensor_env as tensor_module
from SwarmACB_isaac.tasks.direct.mercator_light.mercator_tensor_env import (
    MercatorTensorEnv,
    MercatorTensorEnvCfg,
)
from SwarmACB_isaac.tasks.direct.missions.mercator_aggregation2.mercator_aggregation2_arena import (
    build_argos_aac2_arena,
)
from SwarmACB_isaac.tasks.direct.missions.mercator_foraging import mercator_foraging_model as foraging1
from SwarmACB_isaac.tasks.direct.missions.mercator_foraging2 import mercator_foraging2_model as foraging2
from SwarmACB_isaac.tasks.direct.missions.mercator_grid_exploration import (
    mercator_grid_exploration_model as grid1,
)
from SwarmACB_isaac.tasks.direct.missions.mercator_grid_exploration2 import (
    mercator_grid_exploration2_model as grid2,
)


@dataclass(frozen=True)
class MissionSpec:
    key: str
    task_id: str
    experiment: int
    num_agents: int


MISSION_SPECS: dict[str, MissionSpec] = {
    "SwarmACB-MercatorAggregation-v0": MissionSpec(
        "aggregation", "SwarmACB-MercatorAggregation-v0", 1, 20,
    ),
    "SwarmACB-MercatorAggregation2-v0": MissionSpec(
        "aggregation2", "SwarmACB-MercatorAggregation2-v0", 2, 3,
    ),
    "SwarmACB-MercatorForaging-v0": MissionSpec(
        "foraging", "SwarmACB-MercatorForaging-v0", 1, 20,
    ),
    "SwarmACB-MercatorForaging2-v0": MissionSpec(
        "foraging2", "SwarmACB-MercatorForaging2-v0", 2, 3,
    ),
    "SwarmACB-MercatorGridExploration-v0": MissionSpec(
        "grid", "SwarmACB-MercatorGridExploration-v0", 1, 20,
    ),
    "SwarmACB-MercatorGridExploration2-v0": MissionSpec(
        "grid2", "SwarmACB-MercatorGridExploration2-v0", 2, 3,
    ),
}


@dataclass
class UniversalMercatorTensorEnvCfg(MercatorTensorEnvCfg):
    """Tensor configuration containing the union of all six mission fields."""

    task_id: str = "SwarmACB-MercatorAggregation-v0"
    food_centers: tuple[tuple[float, float], ...] = foraging1.FOOD_CENTERS
    food_radius: float = foraging1.FOOD_RADIUS
    nest_limit_y: float = foraging1.NEST_LIMIT_Y
    grid_arena_size: float = grid1.ARENA_SIZE
    grid_size: int = grid1.GRID_SIZE


class UniversalMercatorTensorEnv(MercatorTensorEnv):
    """One tensor backend preserving each mission's exact analytical objective."""

    cfg: UniversalMercatorTensorEnvCfg

    def __init__(self, cfg: UniversalMercatorTensorEnvCfg):
        if cfg.task_id not in MISSION_SPECS:
            supported = "\n  - ".join(MISSION_SPECS)
            raise ValueError(
                f"Unsupported tensor task {cfg.task_id!r}. Supported tasks:\n  - {supported}"
            )
        self.mission = MISSION_SPECS[cfg.task_id]

        # MercatorTensorEnv currently imports the Experiment-1 arena builder as
        # a module global. Substitute the exact Experiment-2 builder only while
        # its constructor creates the geometry and binds sensor/collision tensors.
        original_builder = tensor_module.build_argos_aac_arena
        if self.mission.experiment == 2:
            tensor_module.build_argos_aac_arena = build_argos_aac2_arena
        try:
            super().__init__(cfg)
        finally:
            tensor_module.build_argos_aac_arena = original_builder

        e, n, dev = self.num_envs, self.num_agents, self.device

        # Mission state is allocated after the base constructor. The base reset
        # already sampled valid poses; all mission states begin at their exact
        # zero/false initial values, so no second random reset is performed.
        if self.mission.key in ("foraging", "foraging2"):
            self._carrying_food = torch.zeros(e, n, dtype=torch.bool, device=dev)
            self._episode_pickups = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_deliveries = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_pickups = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_carrying = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_in_food = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_in_nest = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_deliveries = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_pickups = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_carrying = torch.zeros(e, dtype=torch.float32, device=dev)
        elif self.mission.key in ("grid", "grid2"):
            g = int(cfg.grid_size)
            self._grid_ages = torch.zeros(e, g, g, dtype=torch.long, device=dev)
            self._ever_visited = torch.zeros(e, g, g, dtype=torch.bool, device=dev)
            self._episode_visited_cell_events = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_grid_total_age = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_grid_mean_age = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_grid_max_age = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_grid_visited_cells = torch.zeros(e, dtype=torch.float32, device=dev)
            self.last_grid_coverage = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_grid_total_age = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_grid_mean_age = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_grid_max_age = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_grid_visited_cells = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_grid_coverage = torch.zeros(e, dtype=torch.float32, device=dev)
            self.completed_grid_visit_events = torch.zeros(e, dtype=torch.float32, device=dev)

        self._replace_environment_signature()

    def _replace_environment_signature(self) -> None:
        """Use the same mission-specific signature builders as Isaac environments."""
        key = self.mission.key
        if key == "foraging":
            self._environment_signature = foraging1.build_foraging_environment_signature(
                self.cfg, self._arena_geometry,
            )
        elif key == "foraging2":
            self._environment_signature = foraging2.build_foraging2_environment_signature(
                self.cfg, self._arena_geometry,
            )
        elif key == "grid":
            self._environment_signature = grid1.build_grid_environment_signature(
                self.cfg, self._arena_geometry,
            )
        elif key == "grid2":
            self._environment_signature = grid2.build_grid2_environment_signature(
                self.cfg, self._arena_geometry,
            )
        else:
            # The base signature already contains all AAC/AAC2 geometry and
            # embodiment values. Add the task ID without changing dynamics.
            signature = dict(self._environment_signature)
            payload = dict(signature.get("payload", {}))
            payload["task_id"] = self.cfg.task_id
            signature["payload"] = payload
            self._environment_signature = signature

    def _ground_scalar_at(self, points: torch.Tensor) -> torch.Tensor:
        key = self.mission.key
        if key == "foraging":
            return foraging1.ground_scalar(
                points, self.cfg.food_centers, self.cfg.food_radius, self.cfg.nest_limit_y,
            )
        if key == "foraging2":
            return foraging2.ground_scalar(
                points, self.cfg.food_centers, self.cfg.food_radius, self.cfg.nest_limit_y,
            )
        if key == "grid":
            return grid1.ground_scalar(points)
        if key == "grid2":
            return grid2.ground_scalar(points)
        return super()._ground_scalar_at(points)

    def _zone_counts_from_centers(self) -> tuple[torch.Tensor, torch.Tensor]:
        key = self.mission.key
        if key in ("foraging", "foraging2"):
            model = foraging1 if key == "foraging" else foraging2
            in_food = model.food_membership(
                self.agent_pos, self.cfg.food_centers, self.cfg.food_radius,
            ).any(dim=-1)
            in_nest = model.score_nest_membership(
                self.agent_pos, self.cfg.nest_limit_y,
            )
            return in_food.sum(dim=1).float(), in_nest.sum(dim=1).float()
        if key in ("grid", "grid2"):
            zeros = torch.zeros(self.num_envs, dtype=torch.float32, device=self.device)
            return zeros, zeros
        return super()._zone_counts_from_centers()

    def _mission_reward_step(self) -> torch.Tensor:
        key = self.mission.key
        if key in ("aggregation", "aggregation2"):
            n_black, n_white = self._zone_counts_from_centers()
            self.last_n_black.copy_(n_black)
            self.last_n_white.copy_(n_white)
            self._episode_group_reward.add_(n_black)
            return n_black

        if key in ("foraging", "foraging2"):
            model = foraging1 if key == "foraging" else foraging2
            step = model.update_carrying_state(
                self.agent_pos,
                self._carrying_food,
                self.cfg.food_centers,
                self.cfg.food_radius,
                self.cfg.nest_limit_y,
            )
            self._carrying_food.copy_(step.carrying)
            deliveries = step.delivery_mask.sum(dim=1).float()
            pickups = step.pickup_mask.sum(dim=1).float()
            carrying = step.carrying.sum(dim=1).float()
            in_food = step.in_food.sum(dim=1).float()
            in_nest = step.in_nest.sum(dim=1).float()

            self.last_deliveries.copy_(deliveries)
            self.last_pickups.copy_(pickups)
            self.last_carrying.copy_(carrying)
            self.last_in_food.copy_(in_food)
            self.last_in_nest.copy_(in_nest)
            self.last_n_black.copy_(in_food)
            self.last_n_white.copy_(in_nest)
            self._episode_pickups.add_(pickups)
            self._episode_group_reward.add_(deliveries)
            return deliveries

        model = grid1 if key == "grid" else grid2
        step = model.update_grid_ages(
            self._grid_ages,
            self.agent_pos,
            arena_size=float(self.cfg.grid_arena_size),
            grid_size=int(self.cfg.grid_size),
        )
        self._grid_ages.copy_(step.ages)
        self._ever_visited |= step.visited_mask
        coverage = self._ever_visited.sum(dim=(1, 2)).float() / float(
            int(self.cfg.grid_size) ** 2
        )
        self.last_grid_total_age.copy_(step.total_age)
        self.last_grid_mean_age.copy_(step.mean_age)
        self.last_grid_max_age.copy_(step.max_age)
        self.last_grid_visited_cells.copy_(step.visited_cells)
        self.last_grid_coverage.copy_(coverage)
        self._episode_visited_cell_events.add_(step.visited_cells)
        self.last_n_black.zero_()
        self.last_n_white.zero_()
        self._episode_group_reward.add_(step.reward)
        return step.reward

    def step_tensor(
        self, actions: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, dict[str, Any]]:
        if actions.shape[:2] != (self.num_envs, self.num_agents):
            raise ValueError(
                f"Expected actions [E,N,...]=[{self.num_envs},{self.num_agents},...], "
                f"got {tuple(actions.shape)}"
            )
        actions = actions.to(device=self.device)
        self._compute_wheels(actions)
        self._integrate()
        reward = self._mission_reward_step()

        self._episode_step += 1
        self.episode_length_buf.fill_(self._episode_step)
        timed_out = self._episode_step >= self.max_episode_length - 1
        self.last_transition_was_terminal = bool(timed_out)

        if timed_out:
            self._last_transition_final_state_mask.fill_(True)
            self._last_transition_final_critic_state.copy_(self.get_critic_state())
            truncated = self._true_done
            self._reset_all(initial=False)
            self.last_transition_was_terminal = True
        else:
            self._last_transition_final_state_mask.zero_()
            truncated = self._false_done

        return self._get_observations_tensor(), reward, self._false_done, truncated, {}

    def _reset_all(self, *, initial: bool) -> None:
        # Base construction calls this method before mission tensors exist.
        mission_ready = hasattr(self, "mission")
        key = self.mission.key if mission_ready else ""
        has_foraging = hasattr(self, "_carrying_food")
        has_grid = hasattr(self, "_grid_ages")

        super()._reset_all(initial=initial)

        if key in ("foraging", "foraging2") and has_foraging:
            if not initial:
                self.completed_deliveries.copy_(self.completed_group_reward)
                self.completed_pickups.copy_(self._episode_pickups)
                self.completed_carrying.copy_(self.last_carrying)
            else:
                self.completed_deliveries.zero_()
                self.completed_pickups.zero_()
                self.completed_carrying.zero_()
            self._carrying_food.zero_()
            self._episode_pickups.zero_()
            self.last_deliveries.zero_()
            self.last_pickups.zero_()
            self.last_carrying.zero_()
            self.last_in_food.zero_()
            self.last_in_nest.zero_()

        if key in ("grid", "grid2") and has_grid:
            if not initial:
                self.completed_grid_total_age.copy_(self.last_grid_total_age)
                self.completed_grid_mean_age.copy_(self.last_grid_mean_age)
                self.completed_grid_max_age.copy_(self.last_grid_max_age)
                self.completed_grid_visited_cells.copy_(self.last_grid_visited_cells)
                self.completed_grid_coverage.copy_(self.last_grid_coverage)
                self.completed_grid_visit_events.copy_(self._episode_visited_cell_events)
            else:
                self.completed_grid_total_age.zero_()
                self.completed_grid_mean_age.zero_()
                self.completed_grid_max_age.zero_()
                self.completed_grid_visited_cells.zero_()
                self.completed_grid_coverage.zero_()
                self.completed_grid_visit_events.zero_()
            self._grid_ages.zero_()
            self._ever_visited.zero_()
            self._episode_visited_cell_events.zero_()
            self.last_grid_total_age.zero_()
            self.last_grid_mean_age.zero_()
            self.last_grid_max_age.zero_()
            self.last_grid_visited_cells.zero_()
            self.last_grid_coverage.zero_()

    @property
    def carrying_food(self) -> torch.Tensor:
        if not hasattr(self, "_carrying_food"):
            raise AttributeError("carrying_food is only defined for foraging missions")
        return self._carrying_food

    @property
    def grid_ages(self) -> torch.Tensor:
        if not hasattr(self, "_grid_ages"):
            raise AttributeError("grid_ages is only defined for grid missions")
        return self._grid_ages


class FastPOCATrainer(POCATrainer):
    """POCA with an exactly equivalent batched recurrent actor update."""

    def _compute_recurrent_losses(
        self,
        batch: dict,
        current_eps: float,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        obs = batch["obs"]
        critic_states = batch["critic_states"]
        actions = batch["actions"]
        critic_actions = batch["critic_actions"]
        old_logp = batch["old_log_probs"]
        advantages = batch["advantages"]
        returns = batch["returns"]
        old_tv = batch["old_team_values"]
        old_bl = batch["old_baselines"]
        loss_mask = batch["loss_mask"].bool()

        batch_size, sequence_length = obs.shape[:2]
        num_agents = critic_states.shape[2]
        initial_state = (
            batch["memory_h"].unsqueeze(0).detach(),
            batch["memory_c"].unsqueeze(0).detach(),
        )

        # get_sequence_batches() splits every trajectory at done boundaries.
        # Consequently one LSTM call over each padded sequence is mathematically
        # equivalent to the old Python loop and its post-terminal state reset.
        logp_seq, ent_seq = self.actor.evaluate_sequence(obs, actions, initial_state)

        policy_loss = trust_region_policy_loss(
            advantages.unsqueeze(-1).reshape(-1, 1),
            logp_seq.reshape(-1, logp_seq.shape[-1]),
            old_logp.reshape(-1, old_logp.shape[-1]),
            current_eps,
            loss_mask.reshape(-1),
        )
        mean_entropy = (ent_seq * loss_mask).sum() / loss_mask.sum().clamp_min(1)

        flat_states = critic_states.reshape(
            batch_size * sequence_length, num_agents, critic_states.shape[-1],
        )
        flat_actions = critic_actions.reshape(
            batch_size * sequence_length, num_agents, critic_actions.shape[-1],
        )
        flat_returns = returns.reshape(batch_size * sequence_length)
        flat_old_tv = old_tv.reshape(batch_size * sequence_length)
        flat_old_bl = old_bl.reshape(batch_size * sequence_length)

        critic_act = self._encode_actions_for_critic(flat_actions)
        focal_ids = batch["focal_agent_ids"].unsqueeze(1).expand(
            batch_size, sequence_length,
        ).reshape(-1)
        new_tv = self.critic.critic_pass(
            flat_states,
            (
                batch["critic_memory_h"].unsqueeze(0).detach(),
                batch["critic_memory_c"].unsqueeze(0).detach(),
            ),
            sequence_length=sequence_length,
        ).squeeze(-1)
        new_bl = self.critic.focal_baselines(
            flat_states,
            critic_act,
            focal_ids,
            (
                batch["baseline_memory_h"].unsqueeze(0).detach(),
                batch["baseline_memory_c"].unsqueeze(0).detach(),
            ),
            sequence_length=sequence_length,
        ).squeeze(-1)

        flat_mask = loss_mask.reshape(batch_size * sequence_length)
        value_loss = trust_region_value_loss(
            new_tv, flat_old_tv, flat_returns, current_eps, flat_mask,
        )
        baseline_loss = trust_region_value_loss(
            new_bl, flat_old_bl, flat_returns, current_eps, flat_mask,
        )
        return policy_loss, value_loss, baseline_loss, mean_entropy


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Tensor-only POCA training for all six Mercator missions",
    )
    parser.add_argument("--config", type=str, default=None,
                        help="Path to an ML-Agents-style YAML config")
    parser.add_argument("--task", type=str, default=None,
                        help="Task ID override")
    parser.add_argument("--variant", type=str, default=None,
                        choices=["dandelion", "daisy", "lily", "tulip", "cyclamen"])
    parser.add_argument("--num_envs", type=int, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--total_timesteps", type=int, default=None)
    parser.add_argument("--decision_period", type=int, default=None)
    parser.add_argument("--hidden_dim", type=int, default=None)
    parser.add_argument("--num_layers", type=int, default=None)
    parser.add_argument("--log_dir", type=str, default=None)
    parser.add_argument("--checkpoint_dir", type=str, default=None)
    parser.add_argument("--seed", type=int, default=None)

    parser.add_argument(
        "--device",
        default="cuda:0" if torch.cuda.is_available() else "cpu",
        help="PyTorch device, e.g. cuda:0 or cpu",
    )
    parser.add_argument(
        "--matmul_precision",
        choices=("highest", "high", "medium"),
        default="highest",
        help="Use 'high' to permit TF32 on compatible NVIDIA GPUs",
    )
    parser.add_argument(
        "--no_vectorized_lstm",
        action="store_true",
        help="Use the original recurrent Python loop for diagnostic comparison",
    )
    parser.add_argument(
        "--smoke_test",
        action="store_true",
        help="Build the resolved environment, execute four random steps, then exit",
    )

    # Accepted and ignored for command compatibility with train.py/AppLauncher.
    parser.add_argument("--headless", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--enable_cameras", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--livestream", type=int, default=0, help=argparse.SUPPRESS)
    parser.add_argument("--experience", type=str, default=None, help=argparse.SUPPRESS)
    return parser.parse_args()


def _positive(name: str, value: int | None) -> None:
    if value is not None and value <= 0:
        raise ValueError(f"{name} must be positive, got {value}")


def _configure_precision(device: torch.device, precision: str) -> None:
    torch.set_float32_matmul_precision(precision)
    if device.type == "cuda":
        permit_tf32 = precision in ("high", "medium")
        torch.backends.cuda.matmul.allow_tf32 = permit_tf32
        torch.backends.cudnn.allow_tf32 = permit_tf32


def _build_env_cfg(
    task_id: str,
    variant: str,
    device: str,
    env_overrides: dict[str, Any],
) -> UniversalMercatorTensorEnvCfg:
    if task_id not in MISSION_SPECS:
        supported = ", ".join(MISSION_SPECS)
        raise ValueError(
            f"train_2.py supports the six Mercator scenarios only. Got {task_id!r}. "
            f"Supported: {supported}"
        )
    spec = MISSION_SPECS[task_id]
    cfg = UniversalMercatorTensorEnvCfg(
        task_id=task_id,
        variant=variant,
        num_agents=spec.num_agents,
        device=device,
    )

    # Select exact mission constants before applying explicit YAML overrides.
    if spec.key == "foraging":
        cfg.food_centers = foraging1.FOOD_CENTERS
        cfg.food_radius = foraging1.FOOD_RADIUS
        cfg.nest_limit_y = foraging1.NEST_LIMIT_Y
    elif spec.key == "foraging2":
        cfg.food_centers = foraging2.FOOD_CENTERS
        cfg.food_radius = foraging2.FOOD_RADIUS
        cfg.nest_limit_y = foraging2.NEST_LIMIT_Y
    elif spec.key == "grid":
        cfg.grid_arena_size = grid1.ARENA_SIZE
        cfg.grid_size = grid1.GRID_SIZE
    elif spec.key == "grid2":
        cfg.grid_arena_size = grid2.ARENA_SIZE
        cfg.grid_size = grid2.GRID_SIZE

    overrides = dict(env_overrides)
    overrides.pop("task", None)
    if "num_agents" in overrides and int(overrides["num_agents"]) != spec.num_agents:
        raise ValueError(
            f"{task_id} requires {spec.num_agents} robots; changing num_agents would "
            "change the scenario and checkpoint architecture"
        )
    overrides.pop("num_agents", None)
    cfg.apply_overrides(overrides)
    cfg.task_id = task_id
    cfg.num_agents = spec.num_agents
    cfg.update_variant(variant)
    return cfg


def _run_smoke_test(env: UniversalMercatorTensorEnv) -> None:
    obs, _ = env.reset_tensor(seed=int(env.cfg.seed))
    expected = (env.num_envs, env.num_agents)
    if obs.shape[:2] != expected:
        raise AssertionError(f"Bad observation shape {tuple(obs.shape)}, expected {expected}")
    for _ in range(4):
        if env.cfg.discrete_actions:
            actions = torch.randint(
                0, env.cfg.num_actions,
                (env.num_envs, env.num_agents, 1),
                device=env.device,
            )
        else:
            actions = torch.empty(
                env.num_envs, env.num_agents, 2, device=env.device,
            ).uniform_(-1.0, 1.0)
        obs, reward, terminated, truncated, _ = env.step_tensor(actions)
        assert obs.shape[:2] == expected
        assert reward.shape == (env.num_envs,)
        assert terminated.shape == (env.num_envs,)
        assert truncated.shape == (env.num_envs,)
        assert torch.isfinite(obs).all()
        assert torch.isfinite(reward).all()
    print(
        f"[train_2] Smoke test OK: task={env.cfg.task_id}, "
        f"envs={env.num_envs}, agents={env.num_agents}, obs={tuple(obs.shape)}"
    )


def main() -> None:
    args = _parse_args()
    if args.config is None:
        raise ValueError(
            "train_2.py requires --config for one of the six Mercator YAML files"
        )

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path

    run_name, variant, trainer_cfg, env_overrides = load_config(config_path)
    trainer_type = getattr(trainer_cfg, "trainer_type", "poca")
    if trainer_type != "poca":
        raise ValueError(
            "train_2.py currently preserves the six Mercator POCA scenarios only; "
            f"got trainer_type={trainer_type!r}"
        )

    if args.variant is not None:
        variant = args.variant
        trainer_cfg.recurrent = variant == "cyclamen"
    if args.total_timesteps is not None:
        _positive("--total_timesteps", args.total_timesteps)
        trainer_cfg.total_timesteps = int(args.total_timesteps)
    if args.hidden_dim is not None:
        _positive("--hidden_dim", args.hidden_dim)
        trainer_cfg.hidden_dim = int(args.hidden_dim)
    if args.num_layers is not None:
        _positive("--num_layers", args.num_layers)
        trainer_cfg.num_layers = int(args.num_layers)
    if args.decision_period is not None:
        _positive("--decision_period", args.decision_period)
        trainer_cfg.decision_period = int(args.decision_period)
    if args.log_dir is not None:
        trainer_cfg.log_dir = args.log_dir
    if args.checkpoint_dir is not None:
        trainer_cfg.checkpoint_dir = args.checkpoint_dir
    if args.seed is not None:
        trainer_cfg.seed = int(args.seed)
    elif "seed" in env_overrides:
        trainer_cfg.seed = int(env_overrides["seed"])
    if args.num_envs is not None:
        _positive("--num_envs", args.num_envs)
        env_overrides["num_envs"] = int(args.num_envs)

    task_id = args.task or env_overrides.get("task")
    if task_id is None:
        raise ValueError("The YAML must define environment.task or --task must be supplied")
    if int(trainer_cfg.decision_period) != 1:
        raise ValueError(
            "The tensor Mercator backend requires decision_period=1: each step_tensor() "
            "already represents the complete 0.1 s controller decision with all "
            "analytical substeps. A larger value would repeat the action too long."
        )

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(f"CUDA device requested ({device}) but torch.cuda.is_available() is false")
    _configure_precision(device, args.matmul_precision)

    random.seed(trainer_cfg.seed)
    np.random.seed(trainer_cfg.seed)
    torch.manual_seed(trainer_cfg.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(trainer_cfg.seed)

    env_cfg = _build_env_cfg(task_id, variant, str(device), env_overrides)
    env_cfg.seed = int(trainer_cfg.seed)

    printable = dict(env_overrides)
    printable.update({
        "task": task_id,
        "backend": "tensor-only/no-Isaac/no-PhysX",
        "device": str(device),
        "num_envs": env_cfg.scene.num_envs,
        "num_agents": env_cfg.num_agents,
        "analytical_substeps": env_cfg.analytical_substeps,
        "collision_iterations": env_cfg.collision_iterations,
        "matmul_precision": args.matmul_precision,
        "vectorized_lstm": not args.no_vectorized_lstm,
    })
    print_config(run_name, variant, trainer_cfg, printable)

    env = UniversalMercatorTensorEnv(env_cfg)
    try:
        if args.smoke_test:
            _run_smoke_test(env)
            return

        trainer_cls: type[POCATrainer] = (
            POCATrainer if args.no_vectorized_lstm else FastPOCATrainer
        )
        trainer = trainer_cls(env, trainer_cfg)
        if not trainer.tensor_env:
            raise RuntimeError("UniversalMercatorTensorEnv was not detected as tensor_api=True")
        if args.checkpoint:
            trainer.load_checkpoint(args.checkpoint)
        trainer.train()
    finally:
        env.close()


if __name__ == "__main__":
    main()
