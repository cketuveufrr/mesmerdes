#!/usr/bin/env python3
# Copyright (c) 2025-2026 SwarmACB Project
# SPDX-License-Identifier: BSD-3-Clause

"""Visualise e-puck behavior modules with robust direct USD robot bodies.

Unlike the environment's VisualizationMarkers/PointInstancer path, this script
creates one ordinary USD hierarchy per robot.  This matches the robust strategy
used by the Mercator visualizer and works on Isaac Sim installations where
PointInstancer prototypes remain invisible.

Examples
--------
Phototaxis in Foraging::

    python scripts/visualize_epucks_4.py \
      --config configs/epucks/Foraging_cyclamen.yaml \
      --module 4

Anti-phototaxis::

    python scripts/visualize_epucks_4.py \
      --config configs/epucks/Foraging_cyclamen.yaml \
      --module 5

Add ``--verbose-kit`` only when debugging Isaac Sim startup itself.
"""

from __future__ import annotations

import argparse
import importlib
import math
import os
from pathlib import Path
import statistics
import sys
import traceback
import warnings


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "source" / "SwarmACB_isaac"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

MODULE_NAMES = {
    0: "stop",
    1: "exploration",
    2: "attraction",
    3: "repulsion",
    4: "phototaxis",
    5: "anti_phototaxis",
}

MODULE_COLORS = {
    0: (0.45, 0.45, 0.45),
    1: (0.18, 0.48, 0.95),
    2: (0.15, 0.80, 0.30),
    3: (0.95, 0.20, 0.15),
    4: (1.00, 0.82, 0.10),
    5: (0.62, 0.20, 0.88),
}

parser = argparse.ArgumentParser(description="Visualise SwarmACB e-puck modules")
parser.add_argument(
    "--config",
    default="configs/epucks/Foraging_cyclamen.yaml",
    help="Training YAML whose environment overrides are reproduced.",
)
parser.add_argument("--task", default=None, help="Override the task from the YAML.")
parser.add_argument(
    "--variant",
    default=None,
    choices=["daisy", "lily", "tulip", "cyclamen"],
    help="Discrete CASA variant. Defaults to the YAML variant.",
)
parser.add_argument("--module", type=int, default=1, choices=range(6))
parser.add_argument(
    "--num-episodes",
    type=int,
    default=0,
    help="0 keeps the GUI open until the window is closed.",
)
parser.add_argument("--seed", type=int, default=0)
parser.add_argument(
    "--num-robots",
    type=int,
    default=20,
    choices=range(1, 21),
    help="Number of robots instantiated. Use 1 to isolate a module from proximity interactions.",
)
parser.add_argument("--show-sensors", action="store_true")
parser.add_argument("--sensor-robot", type=int, default=0)
parser.add_argument("--sensor-ring-segments", type=int, default=48)
parser.add_argument("--print-every", type=int, default=10)
parser.add_argument("--camera-height", type=float, default=3.2)
parser.add_argument("--camera-y", type=float, default=-0.3)
parser.add_argument(
    "--robot-visual-scale",
    type=float,
    default=1.0,
    help="Visual-only scale; 1.0 matches the configured physical robot size.",
)
parser.add_argument("--width", type=int, default=1600)
parser.add_argument("--height", type=int, default=900)
parser.add_argument("--headless", action="store_true")
parser.add_argument(
    "--verbose-kit",
    action="store_true",
    help="Show Isaac Sim warning spam and startup diagnostics.",
)
args, _unknown = parser.parse_known_args()

if args.robot_visual_scale <= 0.0:
    parser.error("--robot-visual-scale must be strictly positive")

# Do not inherit a headless training shell when a local window is requested.
if not args.headless:
    for name in (
        "HEADLESS",
        "ISAACLAB_HEADLESS",
        "OMNI_KIT_HEADLESS",
        "DISABLE_VIEWPORT_UPDATES",
        "LIVESTREAM",
    ):
        os.environ.pop(name, None)

# Ask Kit to emit only errors.  These arguments are consumed by SimulationApp.
if not args.verbose_kit:
    warnings.filterwarnings("ignore")
    for kit_arg in (
        "--/log/level=error",
        "--/log/outputStreamLevel=error",
        "--/log/fileLogLevel=error",
    ):
        if kit_arg not in sys.argv:
            sys.argv.append(kit_arg)

# SimulationApp must exist before importing Gym tasks, Isaac Lab, omni or pxr.
from isaacsim import SimulationApp  # noqa: E402


def _launch_simulation_app() -> SimulationApp:
    launch_cfg = {
        "headless": bool(args.headless),
        "multi_gpu": False,
        "width": int(args.width),
        "height": int(args.height),
    }
    print(
        f"[EpuckVisualize] Starting Isaac Sim: headless={args.headless}, "
        f"DISPLAY={os.environ.get('DISPLAY')!r}",
        flush=True,
    )

    if args.verbose_kit:
        return SimulationApp(launch_cfg)

    # C++ extension warnings are written directly to file descriptor 2, so a
    # normal Python warnings filter cannot hide them.  Capture only startup
    # stderr and restore it immediately after SimulationApp is ready.
    startup_log = Path("/tmp/visualize_epucks_4_kit_startup.log")
    saved_stderr = os.dup(2)
    log_fd = os.open(
        str(startup_log),
        os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
        0o600,
    )
    try:
        os.dup2(log_fd, 2)
        return SimulationApp(launch_cfg)
    except Exception:
        os.dup2(saved_stderr, 2)
        print(
            f"[EpuckVisualize] Isaac Sim startup failed. Full log: {startup_log}",
            file=sys.stderr,
        )
        try:
            tail = startup_log.read_text(errors="replace").splitlines()[-40:]
            if tail:
                print("\n".join(tail), file=sys.stderr)
        except OSError:
            pass
        raise
    finally:
        os.dup2(saved_stderr, 2)
        os.close(saved_stderr)
        os.close(log_fd)


simulation_app = _launch_simulation_app()

import carb  # noqa: E402
import gymnasium as gym  # noqa: E402
import omni.timeline  # noqa: E402
import omni.usd  # noqa: E402
import torch  # noqa: E402
from pxr import Gf, UsdGeom  # noqa: E402

import isaaclab.sim as sim_utils  # noqa: E402
import isaaclab.utils as _isaaclab_utils  # noqa: E402
from isaaclab.utils.configclass import configclass as _configclass  # noqa: E402

# Compatibility with older project cfg files on Isaac Lab 6.0.
if not callable(getattr(_isaaclab_utils, "configclass", None)):
    _isaaclab_utils.configclass = _configclass

# Keep later Isaac/PhysX/DLSS warnings quiet while preserving errors.
if not args.verbose_kit:
    try:
        settings = carb.settings.get_settings()
        settings.set("/log/level", "error")
        settings.set("/log/outputStreamLevel", "error")
        settings.set("/log/fileLogLevel", "error")
    except Exception:
        pass

import SwarmACB_isaac.tasks  # noqa: E402,F401
from SwarmACB_isaac.tasks.direct.agents.config_loader import load_config  # noqa: E402


def _resolve_path(path: str) -> Path:
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = ROOT / candidate
    return candidate.resolve()


def _resolve_env_cfg(task_id: str):
    spec = gym.spec(task_id)
    entry = spec.kwargs.get("env_cfg_entry_point")
    if entry is None:
        raise ValueError(f"Task {task_id!r} has no env_cfg_entry_point")
    module_path, cls_name = entry.rsplit(":", 1)
    module = importlib.import_module(module_path)
    return getattr(module, cls_name)()


def _apply_env_overrides(env_cfg, overrides: dict) -> None:
    for key, value in overrides.items():
        if key in {"task", "num_envs"}:
            continue
        if not hasattr(env_cfg, key):
            raise RuntimeError(
                f"Environment override {key!r} is not supported by "
                f"{type(env_cfg).__name__}."
            )
        current = getattr(env_cfg, key)
        if isinstance(current, tuple) and isinstance(value, list):
            value = tuple(value)
        setattr(env_cfg, key, value)


def _create_direct_epuck_visuals(base, module_id: int, visual_scale: float):
    """Create ordinary USD robot hierarchies instead of PointInstancers."""
    stage = omni.usd.get_context().get_stage()
    if stage is None:
        raise RuntimeError("USD stage is unavailable while creating e-puck visuals")

    root_path = "/World/Visuals/DirectEpucks"
    if stage.GetPrimAtPath(root_path).IsValid():
        stage.RemovePrim(root_path)
    UsdGeom.Xform.Define(stage, root_path)

    radius = float(base.cfg.robot_radius) * visual_scale
    height = float(base.cfg.robot_height) * visual_scale
    # Keep the visual body faithful to the configured physical dimensions.
    radius = max(radius, 0.005)
    height = max(height, 0.005)

    body_material = sim_utils.PreviewSurfaceCfg(
        diffuse_color=(0.08, 0.10, 0.12),
        roughness=0.55,
        metallic=0.10,
    )
    rim_material = sim_utils.PreviewSurfaceCfg(
        diffuse_color=(0.72, 0.75, 0.78),
        roughness=0.45,
    )
    module_material = sim_utils.PreviewSurfaceCfg(
        diffuse_color=MODULE_COLORS[int(module_id)],
        roughness=0.35,
    )
    heading_material = sim_utils.PreviewSurfaceCfg(
        diffuse_color=(1.0, 1.0, 1.0),
        emissive_color=(0.35, 0.35, 0.35),
    )
    food_material = sim_utils.PreviewSurfaceCfg(
        diffuse_color=(1.0, 0.35, 0.05),
        emissive_color=(0.25, 0.05, 0.0),
    )

    robot_xforms: list[UsdGeom.XformCommonAPI] = []
    food_indicators: list[UsdGeom.Imageable] = []

    for robot_idx in range(int(base.cfg.num_agents)):
        robot_path = f"{root_path}/Epuck_{robot_idx:02d}"
        robot_xform = UsdGeom.Xform.Define(stage, robot_path)
        robot_xforms.append(UsdGeom.XformCommonAPI(robot_xform.GetPrim()))

        body_cfg = sim_utils.CylinderCfg(
            radius=radius,
            height=0.68 * height,
            visual_material=body_material,
        )
        body_cfg.func(
            f"{robot_path}/Body",
            body_cfg,
            translation=(0.0, 0.0, 0.34 * height),
        )

        rim_cfg = sim_utils.CylinderCfg(
            radius=1.04 * radius,
            height=0.10 * height,
            visual_material=rim_material,
        )
        rim_cfg.func(
            f"{robot_path}/Rim",
            rim_cfg,
            translation=(0.0, 0.0, 0.73 * height),
        )

        top_cfg = sim_utils.CylinderCfg(
            radius=0.76 * radius,
            height=0.18 * height,
            visual_material=module_material,
        )
        top_cfg.func(
            f"{robot_path}/ModuleTop",
            top_cfg,
            translation=(0.0, 0.0, 0.87 * height),
        )

        # A large white nose marker makes heading unambiguous from overhead.
        heading_cfg = sim_utils.SphereCfg(
            radius=max(0.012, 0.23 * radius),
            visual_material=heading_material,
        )
        heading_cfg.func(
            f"{robot_path}/Heading",
            heading_cfg,
            translation=(0.82 * radius, 0.0, 0.92 * height),
        )

        food_path = f"{robot_path}/FoodIndicator"
        food_cfg = sim_utils.SphereCfg(
            radius=max(0.014, 0.27 * radius),
            visual_material=food_material,
        )
        food_cfg.func(
            food_path,
            food_cfg,
            translation=(-0.55 * radius, 0.0, 1.18 * height),
        )
        food_imageable = UsdGeom.Imageable(stage.GetPrimAtPath(food_path))
        food_imageable.MakeInvisible()
        food_indicators.append(food_imageable)

    print(
        f"[EpuckVisualize] Created {len(robot_xforms)} direct USD e-pucks "
        f"under {root_path} (visual scale={visual_scale:.2f}).",
        flush=True,
    )
    return robot_xforms, food_indicators


def _update_direct_epuck_visuals(base, robot_xforms, food_indicators) -> None:
    positions = base.agent_pos[0].detach().cpu().numpy()
    yaws = base.agent_yaw[0].detach().cpu().numpy()

    has_food = None
    if hasattr(base, "_has_food"):
        has_food = base._has_food[0].detach().cpu().numpy().astype(bool)

    for idx, xform_api in enumerate(robot_xforms):
        xform_api.SetTranslate(
            Gf.Vec3d(float(positions[idx, 0]), float(positions[idx, 1]), 0.004)
        )
        xform_api.SetRotate(
            Gf.Vec3f(0.0, 0.0, float(math.degrees(yaws[idx]))),
            UsdGeom.XformCommonAPI.RotationOrderXYZ,
        )

        if has_food is not None and bool(has_food[idx]):
            food_indicators[idx].MakeVisible()
        else:
            food_indicators[idx].MakeInvisible()


def _update_optional_sensor_markers(base) -> None:
    """Best-effort sensor overlay; robot bodies do not depend on this path."""
    if not bool(getattr(base.cfg, "debug_visual_sensors", False)):
        return
    if not hasattr(base, "_update_sensor_visual_markers"):
        return
    positions = base.agent_pos[0].detach().cpu().numpy()
    yaws = base.agent_yaw[0].detach().cpu().numpy()
    try:
        base._update_sensor_visual_markers(positions, yaws)
    except Exception:
        # A sensor overlay must never prevent the robust robot bodies rendering.
        pass


def _render_warmup(base, robot_xforms, food_indicators, frames: int = 30) -> None:
    for _ in range(frames):
        _update_direct_epuck_visuals(base, robot_xforms, food_indicators)
        _update_optional_sensor_markers(base)
        try:
            base.sim.render()
        except Exception:
            pass
        simulation_app.update()


def main() -> None:
    config_path = _resolve_path(args.config)
    run_name, yaml_variant, _train_cfg, env_overrides = load_config(config_path)
    task_id = args.task or env_overrides.get("task", "SwarmACB-Foraging-v0")
    variant = args.variant or yaml_variant

    if variant == "dandelion":
        raise ValueError(
            "This script selects discrete modules; choose daisy, lily, tulip or cyclamen."
        )

    env_cfg = _resolve_env_cfg(task_id)
    _apply_env_overrides(env_cfg, env_overrides)
    env_cfg.scene.num_envs = 1
    env_cfg.num_agents = int(args.num_robots)
    env_cfg.possible_agents = [f"epuck_{i}" for i in range(env_cfg.num_agents)]
    env_cfg.update_variant(variant)
    env_cfg.sim.render_interval = 1
    env_cfg.debug_visual_sensors = bool(args.show_sensors)
    env_cfg.sensor_visual_robot_index = int(args.sensor_robot)
    env_cfg.sensor_visual_rab_ring_segments = int(args.sensor_ring_segments)
    if hasattr(env_cfg, "seed"):
        env_cfg.seed = int(args.seed)

    # Do not force version-specific viewport extensions. SimulationApp's normal
    # GUI experience already owns the viewport, and forcing the old extension
    # name caused the dependency-resolution error seen in the previous script.
    print("[EpuckVisualize] Creating the training environment...", flush=True)
    env = gym.make(task_id, cfg=env_cfg, render_mode="human")
    base = env.unwrapped
    agents = list(base.cfg.possible_agents)
    device = base.device
    control_dt = float(base.cfg.sim.dt) * int(base.cfg.decimation)

    try:
        obs, _ = env.reset(seed=args.seed)
        del obs

        robot_xforms, food_indicators = _create_direct_epuck_visuals(
            base,
            module_id=int(args.module),
            visual_scale=float(args.robot_visual_scale),
        )
        _update_direct_epuck_visuals(base, robot_xforms, food_indicators)

        base.sim.set_camera_view(
            eye=[0.0, float(args.camera_y), float(args.camera_height)],
            target=[0.0, 0.0, 0.0],
        )

        timeline = omni.timeline.get_timeline_interface()
        if not timeline.is_playing():
            timeline.play()

        _render_warmup(base, robot_xforms, food_indicators)
        if not simulation_app.is_running():
            raise RuntimeError("SimulationApp stopped before the GUI loop started.")

        print("\n========== E-PUCK MODULE VISUALIZATION ==========")
        print(f"config       : {config_path}")
        print(f"run          : {run_name}")
        print(f"task         : {task_id}")
        print(f"variant      : {variant}")
        print(f"module       : {args.module} — {MODULE_NAMES[args.module]}")
        print(f"robots       : {len(robot_xforms)} direct USD bodies")
        print("debug mode   : isolated" if len(robot_xforms) == 1 else "debug mode   : swarm interactions enabled")
        print(f"visual scale : {args.robot_visual_scale:.2f} (visual only)")
        print(
            f"light        : position={tuple(base.cfg.light_position)}, "
            f"intensity={base.cfg.light_intensity}"
        )
        print(f"control dt   : {control_dt:.3f} s")
        print("Close the Isaac Sim window or press Ctrl+C to stop.")
        print("=================================================\n")

        completed: list[float] = []
        episode_reward = 0.0
        control_step = 0
        fixed_action = torch.full(
            (1, 1), int(args.module), dtype=torch.long, device=device
        )

        while simulation_app.is_running():
            if args.num_episodes > 0 and len(completed) >= args.num_episodes:
                break

            action_dict = {agent: fixed_action for agent in agents}
            _, rewards, terminated, truncated, _ = env.step(action_dict)
            _update_direct_epuck_visuals(base, robot_xforms, food_indicators)
            _update_optional_sensor_markers(base)

            try:
                base.sim.render()
            except Exception:
                pass
            simulation_app.update()

            reward = float(rewards[agents[0]][0].item())
            episode_reward += reward
            control_step += 1
            done = bool((terminated[agents[0]] | truncated[agents[0]])[0].item())

            if args.print_every > 0 and control_step % args.print_every == 0:
                carrying = (
                    int(base._has_food[0].sum().item())
                    if hasattr(base, "_has_food")
                    else 0
                )
                print(
                    f"step={control_step:5d} "
                    f"t={control_step * control_dt:7.1f}s "
                    f"score={episode_reward:5.0f} carrying={carrying:2d}",
                    flush=True,
                )

            if done:
                completed.append(episode_reward)
                print(
                    f"[Episode {len(completed):02d}] score={episode_reward:.0f}",
                    flush=True,
                )
                episode_reward = 0.0
                control_step = 0

        if completed:
            print("\n================ RESULTS ================")
            print(f"episodes : {len(completed)}")
            print(f"mean     : {statistics.mean(completed):.2f}")
            print(f"min/max  : {min(completed):.2f} / {max(completed):.2f}")
            print("=========================================")
    finally:
        env.close()


if __name__ == "__main__":
    exit_code = 0
    try:
        main()
    except KeyboardInterrupt:
        print("\n[EpuckVisualize] Interrupted by user.")
    except Exception:
        exit_code = 1
        print("\n[EpuckVisualize] FATAL ERROR", file=sys.stderr)
        traceback.print_exc()
    finally:
        simulation_app.close()
    raise SystemExit(exit_code)